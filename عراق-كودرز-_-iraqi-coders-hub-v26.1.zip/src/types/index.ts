export type AuthProvider = "google";

export type UserRole = "user" | "developer" | "moderator" | "director" | "admin";

export type ThemeDecoration =
  | "default"
  | "halloween"
  | "cyber"
  | "electric"
  | "fantasy";

export interface UserProfile {
  id: string;
  name: string;
  handle: string;
  email: string;
  avatarUrl: string;
  provider: AuthProvider;
  city: string;
  role: UserRole;
  themeDecoration: ThemeDecoration;
  desktopMode: boolean;
  loggedInAt: string;
}

export type CloudFileType = "game" | "apk" | "code" | "minecraft" | "web";
export type CloudVisibility = "private" | "public";

export interface CloudFileItem {
  id: string;
  ownerId: string;
  ownerName: string;
  ownerHandle: string;
  title: string;
  description: string;
  fileName: string;
  fileType: CloudFileType;
  fileSizeBytes: number;
  content: string;
  visibility: CloudVisibility;
  downloads: number;
  createdAt: string;
}

export interface UserEconomy {
  activeSeconds: number;
  coins: number;
  unlockedItems: string[];
  equippedSkin: string;
}

export interface StoreItem {
  id: string;
  name: string;
  description: string;
  priceCoins: number;
  category: "skin" | "tool" | "theme";
  previewColor: string;
}

export interface SystemLogEntry {
  id: string;
  level: "INFO" | "AUTH" | "FIRESTORE" | "CLOUD";
  message: string;
  timestamp: string;
}

export type ProjectCategory = "roblox" | "minecraft";

export interface ProjectItem {
  id: string;
  title: string;
  category: ProjectCategory;
  categoryLabel: string;
  author: string;
  city: string;
  version: string;
  downloads: number;
  summary: string;
  imageUrl: string;
  fileName: string;
  language: string;
  codePreview: string;
  installSteps: string[];
}

export interface ForumReply {
  id: string;
  authorName: string;
  authorAvatar: string;
  content: string;
  createdAt: string;
}

export type PostTopic = "roblox" | "minecraft" | "web" | "general";

export interface ForumPost {
  id: string;
  title: string;
  content: string;
  topic: PostTopic;
  topicLabel: string;
  authorName: string;
  authorCity: string;
  authorAvatar: string;
  createdAt: string;
  likes: number;
  likedByUser?: boolean;
  replies: ForumReply[];
}

export interface PlaygroundTemplate {
  id: string;
  name: string;
  description: string;
  html: string;
  css: string;
  js: string;
}

export type ExtensionPairingStatus =
  | "unpaired"
  | "waiting"
  | "pending_confirm"
  | "paired"
  | "rejected"
  | "revoked";

export interface DomScanReport {
  matched: boolean;
  code: string;
  scannedNodesCount: number;
  durationMs: number;
  sourceHint: string;
  scannedAt: string;
}

export interface ExtensionPairingSession {
  id: string;
  code: string;
  extensionName: string;
  browser: string;
  status: ExtensionPairingStatus;
  feedbackMessage?: string;
  domScan?: DomScanReport;
  createdAt: string;
  updatedAt: string;
}

export interface UnpackedExtensionFile {
  path: string;
  sizeBytes: number;
  content: string;
  isBinary: boolean;
}

export interface UnpackedExtensionPackage {
  archiveName: string;
  extensionName: string;
  version: string;
  description: string;
  popupPath?: string;
  popupHtml?: string;
  manifestRaw?: string;
  files: UnpackedExtensionFile[];
  unpackedAt: string;
}

export interface AdminRoleRequest {
  id: string;
  fullName: string;
  email: string;
  requestedRole: "admin" | "supervisor";
  note: string;
  status: "pending" | "reviewed" | "approved" | "rejected";
  createdAt: string;
}

export type PlatformUpdateVisibility = "public" | "private";
export type PlatformUpdateAccent = "blue" | "emerald" | "violet" | "amber";
export type PlatformUpdateFeatureType = "banner" | "widget" | "theme" | "tool";

export interface PlatformAiUpdate {
  id: string;
  authorId: string;
  authorName: string;
  title: string;
  description: string;
  badgeText: string;
  accentColor: PlatformUpdateAccent;
  featureType: PlatformUpdateFeatureType;
  actionLabel: string;
  actionPayload: string;
  targetVersion: string;
  visibility: PlatformUpdateVisibility;
  createdAt: string;
  isAiGenerated?: boolean;
}

export interface DeviceContextState {
  mobile: boolean;
  desktop: boolean;
  extension: boolean;
}

export type ShopCategoryId = "all" | "web" | "games" | "services" | "tools";

export type ShopAvailability =
  | "available"
  | "special_offer"
  | "limited"
  | "out_of_stock";

export interface ShopProduct {
  id: string;
  title: string;
  category: Exclude<ShopCategoryId, "all">;
  categoryLabel: string;
  description: string;
  features: string[];
  priceUsd: number;
  originalPriceUsd?: number;
  availability: ShopAvailability;
  availabilityLabel: string;
  deliveryTime: string;
  accentColor: "emerald" | "violet" | "sky" | "amber";
  imageUrl?: string;
  externalUrl?: string;
  publishedBy?: string;
  publishedByRole?: UserRole;
  isCustomPublished?: boolean;
  createdAt?: string;
}

export interface ShopCartItem {
  productId: string;
  quantity: number;
}

export type OrderContactChannel = "whatsapp" | "telegram" | "discord" | "email";

export interface ShopOrderLineItem {
  productId: string;
  title: string;
  unitPriceUsd: number;
  quantity: number;
  lineTotalUsd: number;
}

export interface ShopOrderRecord {
  id: string;
  customerName: string;
  contactChannel: OrderContactChannel;
  contactValue: string;
  notes: string;
  items: ShopOrderLineItem[];
  subtotalUsd: number;
  savingsUsd: number;
  promoCode?: string;
  promoDiscountUsd: number;
  totalUsd: number;
  totalIqd: number;
  signedInvoiceVerified?: boolean;
  signedInvoiceText?: string;
  createdAt: string;
}

export interface CommunityChannelLink {
  id: "telegram" | "whatsapp" | "discord";
  name: string;
  englishName: string;
  handleOrTag: string;
  description: string;
  ctaLabel: string;
  url: string;
  accentColor: "sky" | "emerald" | "indigo";
}

export interface ChallengeComment {
  id: string;
  authorName: string;
  authorRole: UserRole;
  content: string;
  createdAt: string;
}

export interface ChallengeItem {
  id: string;
  title: string;
  question: string;
  codeSnippet?: string;
  buttonALabel: string;
  buttonBLabel: string;
  correctButton: "A" | "B";
  publisherName: string;
  publisherHandle: string;
  publisherAvatar: string;
  publisherRole: UserRole;
  createdAt: string;
  comments: ChallengeComment[];
}

export type ProgrammingLanguageId =
  | "python"
  | "java"
  | "groovy"
  | "luau"
  | "javascript"
  | "cpp";

export interface BetaBrowserInspection {
  browserName: string;
  browserVersion: string;
  isGoogleChrome: boolean;
  isGoogleAppOrBetaChannel: boolean;
  isBetaJoined: boolean;
  autoActivated: boolean;
  reasonLabel: string;
}

export interface PublishedMiniProject {
  id: string;
  title: string;
  description: string;
  kind: "game" | "app";
  language: ProgrammingLanguageId;
  is3D: boolean;
  code: string;
  authorName: string;
  authorHandle: string;
  authorRole: UserRole;
  createdAt: string;
}

export interface SchoolUpdateItem {
  id: string;
  title: string;
  details: string;
  badge: string;
  authorName: string;
  createdAt: string;
}

export interface CustomNationalityCard {
  id: string;
  ownerUid: string;
  ownerHandle: string;
  ownerEmail: string;
  numericId?: string;
  fullName: string;
  governorate: string;
  nationalityCode: string;
  specialty: string;
  titleRank: string;
  rankTitle?: string;
  bio: string;
  frontPhotoUrl: string;
  backEmblemUrl: string;
  frontPhotoDataUrl?: string;
  backPhotoDataUrl?: string;
  issuedAt: string;
  updatedAt?: string;
  verified: boolean;
}

export interface PlatformMessageRecord {
  id: string;
  direction: "incoming" | "outgoing";
  source?: "gmail" | "platform";
  senderEmail: string;
  senderName?: string;
  recipientEmail: string;
  recipientIdentifier?: string;
  subject: string;
  body: string;
  sentViaGmail: boolean;
  gmailSynced?: boolean;
  read?: boolean;
  rankAssigned?: "moderator" | "developer" | "admin";
  rankGranted?: UserRole;
  createdAt: string;
}

export type AgeVerificationStatus =
  | "unverified"
  | "adult_verified"
  | "kids_mode"
  | "adult_bypass";

export interface GmailConfirmRequest {
  to: string;
  subject: string;
  textBody?: string;
  previewText?: string;
  htmlBody: string;
  rankAssigned?: "moderator" | "developer" | "admin";
  targetIdentifier?: string;
}

