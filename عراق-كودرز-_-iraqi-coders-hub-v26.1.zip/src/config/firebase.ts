import { getApps, initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";
import { doc, getDocFromServer, getFirestore } from "firebase/firestore";
import firebaseAppletConfig from "../../firebase-applet-config.json";

export const firebaseConfig = firebaseAppletConfig;

export const FIREBASE_HOSTING_SITE = "iraqi-coders-hub-4b512";

export const APP_VERSION = "26.5";

export const OWNER_PERSON = {
  username: "amirbaqir226",
  handle: "@amirbaqir226",
  email: "amirbaqir226@gmail.com",
  displayName: "أمير باقر",
  city: "بغداد",
  role: "admin" as const,
} as const;

export function isOwnerEmail(email?: string | null): boolean {
  return Boolean(email && email.trim().toLowerCase() === OWNER_PERSON.email);
}

export function matchesOwnerIdentity(identifier?: string | null): boolean {
  if (!identifier) return false;
  const normalized = identifier.trim().toLowerCase();
  return (
    normalized === OWNER_PERSON.username ||
    normalized === OWNER_PERSON.handle ||
    normalized === OWNER_PERSON.email ||
    normalized === `owner-${OWNER_PERSON.username}`
  );
}

export function isMasterAdminIdentity(
  user?: { id?: string | null; handle?: string | null; email?: string | null } | null,
  fbUser?: { uid?: string | null; email?: string | null } | null
): boolean {
  return (
    isOwnerEmail(fbUser?.email) ||
    isOwnerEmail(user?.email) ||
    matchesOwnerIdentity(user?.id) ||
    matchesOwnerIdentity(user?.handle) ||
    matchesOwnerIdentity(fbUser?.uid)
  );
}

export const MEDIAFIRE_EXTENSION_URL =
  "https://www.mediafire.com/file/0no84g8ycn72347/IraqiCodersAdmin.zip/file";

export const STORAGE_KEYS = {
  USER_SESSION: "iraqi_coders_user_v26_3",
  USER_ROLE: "iraqi_coders_user_role_v26_5",
  DEV_TASKS: "iraqi_coders_dev_tasks_v26_5",
  ROLE_REQUESTS: "iraqi_coders_role_requests_v26_5",
  FLOATING_EXTENSION_PKG: "iraqi_coders_floating_ext_pkg_v26_5",
  ASSISTANT_URL: "iraqi_coders_assistant_url_v26_3",
  ASSISTANT_TITLE: "iraqi_coders_assistant_title_v26_3",
  ADMIN_AUTH: "iraqi_coders_admin_unlocked_v26_3",
  FORUM_POSTS: "iraqi_coders_forum_posts_v26_3",
  PROJECT_DOWNLOADS: "iraqi_coders_project_downloads_v26_3",
  CODE_RUNS: "iraqi_coders_code_runs_v26_3",
  MAINTENANCE_BYPASSED: "iraqi_coders_maintenance_bypassed_v26_3",
  COMEDY_BAN: "iraqi_coders_comedy_ban_v26_3",
  THEME_DECORATION: "iraqi_coders_theme_v26_3",
  DESKTOP_MODE: "iraqi_coders_desktop_mode_v26_3",
  CLOUD_FILES: "iraqi_coders_cloud_files_v26_3",
  SYSTEM_LOGS: "iraqi_coders_system_logs_v26_3",
  USER_ECONOMY: "iraqi_coders_economy_v26_4",
  EXTENSION_PAIRING: "iraqi_coders_extension_pairing_v26_5",
  EXT_DOWNLOAD_MODE: "iraqi_coders_ext_download_mode_v26_5",
  PLATFORM_UPDATES: "iraqi_coders_platform_updates_v26_5",
  EXTENSION_MODE: "iraqi_coders_extension_mode_v26_5",
  PREVIEW_VERSION: "iraqi_coders_preview_version_v26_5",
  SHOP_CART: "iraqi_coders_shop_cart_v26_5",
  SHOP_ORDERS: "iraqi_coders_shop_orders_v26_5",
  SHOP_CUSTOM_PRODUCTS: "iraqi_coders_shop_custom_products_v26_5",
  AD_DNS_ENABLED: "iraqi_coders_ad_dns_enabled_v26_5",
  VIP_PAID_ACTIVE: "iraqi_coders_vip_paid_active_v26_5",
  EDU_ROBOT_SKIPPED: "iraqi_coders_edu_robot_skipped_v26_6",
  SPEAKER_ENABLED: "iraqi_coders_speaker_enabled_v26_6",
  CHALLENGES: "iraqi_coders_challenges_v26_6",
  BETA_MODE: "iraqi_coders_beta_mode_v26_6",
  GOOGLE_BETA_JOINED: "iraqi_coders_google_beta_joined_v26_6",
  BETA_PROG_LANG: "iraqi_coders_beta_prog_lang_v26_6",
  PUBLISHED_MINI_APPS: "iraqi_coders_published_mini_apps_v26_6",
  SCHOOL_UPDATES: "iraqi_coders_school_updates_v26_6",
  FANTASY_WORLD: "iraqi_coders_fantasy_world_v26_6",
  NATIONALITIES: "iraqi_coders_nationalities_v26_7",
  PLATFORM_MESSAGES: "iraqi_coders_platform_messages_v26_7",
  GMAIL_ALERTS_ENABLED: "iraqi_coders_gmail_alerts_v26_7",
  AGE_STATUS: "iraqi_coders_age_status_v26_7",
  KIDS_MODE: "iraqi_coders_kids_mode_v26_7",
  OFFLINE_DOWNLOADS: "iraqi_coders_offline_downloads_v26_8",
  IPHONE_PACK_ENABLED: "iraqi_coders_iphone_pack_v26_8",
} as const;

const firebaseApp =
  getApps().length > 0 ? getApps()[0] : initializeApp(firebaseConfig);

const configuredDbId = (firebaseConfig as { firestoreDatabaseId?: string })
  .firestoreDatabaseId;
export const db = configuredDbId
  ? getFirestore(firebaseApp, configuredDbId)
  : getFirestore(firebaseApp);
export const firebaseAuth = getAuth(firebaseApp);
export const googleProvider = new GoogleAuthProvider();
googleProvider.addScope("https://www.googleapis.com/auth/gmail.readonly");
googleProvider.addScope("https://www.googleapis.com/auth/gmail.send");
googleProvider.setCustomParameters({ prompt: "select_account" });

// Strictly in-memory OAuth token storage (never persisted to localStorage/sessionStorage)
let inMemoryGmailAccessToken: string | null = null;

export function setGmailAccessToken(token: string | null): void {
  inMemoryGmailAccessToken = token ? token.trim() : null;
}

export function getGmailAccessToken(): string | null {
  return inMemoryGmailAccessToken;
}

export enum OperationType {
  CREATE = "create",
  UPDATE = "update",
  DELETE = "delete",
  LIST = "list",
  GET = "get",
  WRITE = "write",
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: firebaseAuth.currentUser?.uid,
      email: firebaseAuth.currentUser?.email,
      emailVerified: firebaseAuth.currentUser?.emailVerified,
      isAnonymous: firebaseAuth.currentUser?.isAnonymous,
      tenantId: firebaseAuth.currentUser?.tenantId,
      providerInfo:
        firebaseAuth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error("Firestore Error: ", JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

async function testFirestoreConnection() {
  try {
    await getDocFromServer(doc(db, "test", "connection"));
  } catch (error) {
    if (
      error instanceof Error &&
      error.message.includes("the client is offline")
    ) {
      console.error("Please check your Firebase configuration.");
    }
  }
}

void testFirestoreConnection();
