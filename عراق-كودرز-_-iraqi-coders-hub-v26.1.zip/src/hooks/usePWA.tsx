import React, { useCallback, useEffect, useState } from "react";
import { Download, Smartphone, WifiOff } from "lucide-react";

interface BeforeInstallPromptEvent extends Event {
  readonly platforms: string[];
  readonly userChoice: Promise<{ outcome: "accepted" | "dismissed"; platform: string }>;
  prompt(): Promise<void>;
}

export function usePWAInstall() {
  const [deferredPrompt, setDeferredPrompt] =
    useState<BeforeInstallPromptEvent | null>(null);
  const [isInstallable, setIsInstallable] = useState(false);
  const [isInstalled, setIsInstalled] = useState(() => {
    if (typeof window === "undefined") return false;
    return (
      window.matchMedia("(display-mode: standalone)").matches ||
      (window.navigator as { standalone?: boolean }).standalone === true
    );
  });

  useEffect(() => {
    if (typeof window === "undefined") return;

    const handleBeforeInstall = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
      setIsInstallable(true);
    };

    const handleAppInstalled = () => {
      setIsInstalled(true);
      setIsInstallable(false);
      setDeferredPrompt(null);
    };

    window.addEventListener("beforeinstallprompt", handleBeforeInstall);
    window.addEventListener("appinstalled", handleAppInstalled);

    return () => {
      window.removeEventListener("beforeinstallprompt", handleBeforeInstall);
      window.removeEventListener("appinstalled", handleAppInstalled);
    };
  }, []);

  const promptInstall = useCallback(async () => {
    if (!deferredPrompt) return false;
    await deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === "accepted") {
      setIsInstalled(true);
    }
    setDeferredPrompt(null);
    setIsInstallable(false);
    return outcome === "accepted";
  }, [deferredPrompt]);

  const isIOS =
    typeof navigator !== "undefined" &&
    /iPad|iPhone|iPod/.test(navigator.userAgent) &&
    !(window as { MSStream?: unknown }).MSStream;

  return { isInstallable, isInstalled, isIOS, promptInstall };
}

export function useOnlineStatus(): boolean {
  const [isOnline, setIsOnline] = useState(() =>
    typeof navigator !== "undefined" ? navigator.onLine : true
  );

  useEffect(() => {
    if (typeof window === "undefined") return;
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);

    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, []);

  return isOnline;
}

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();
  if (isOnline) return null;

  return (
    <div
      role="status"
      aria-live="polite"
      className="fixed bottom-4 left-4 z-[60] flex max-w-sm items-center gap-2.5 rounded-xl border border-amber-400/55 bg-[#191307]/95 px-4 py-2.5 text-xs font-extrabold text-amber-200 shadow-2xl backdrop-blur-md"
    >
      <WifiOff className="h-4 w-4 shrink-0 text-amber-400" />
      <span>
        أنت تتصفح الآن بدون اتصال بالإنترنت — المحتوى المحمّل متاح، والميزات
        المباشرة تتطلب إنترنت.
      </span>
    </div>
  );
};

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, promptInstall } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  if (isInstalled) {
    return (
      <div className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-400/40 bg-emerald-500/15 px-3 py-1.5 text-[11px] font-extrabold text-emerald-200">
        <Smartphone className="h-3.5 w-3.5 text-emerald-400" />
        <span>التطبيق مثبّت على جهازك</span>
      </div>
    );
  }

  if (isInstallable) {
    return (
      <button
        type="button"
        onClick={() => void promptInstall()}
        className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3 py-1.5 text-[11px] font-extrabold text-white hover:bg-emerald-500 transition-colors cursor-pointer"
      >
        <Download className="h-3.5 w-3.5" />
        <span>تثبيت الموقع كتطبيق</span>
      </button>
    );
  }

  if (isIOS) {
    return (
      <div className="space-y-1.5">
        <button
          type="button"
          onClick={() => setShowIOSGuide((v) => !v)}
          className="inline-flex items-center gap-1.5 rounded-lg border border-sky-400/40 bg-sky-500/15 px-3 py-1.5 text-[11px] font-extrabold text-sky-200 hover:bg-sky-500/25 cursor-pointer"
        >
          <Smartphone className="h-3.5 w-3.5" />
          <span>تثبيت على iOS</span>
        </button>
        {showIOSGuide && (
          <p className="rounded-lg border border-white/10 bg-[#0B0F19] p-2 text-[11px] leading-relaxed text-slate-300">
            من متصفح Safari اضغط زر المشاركة ثم اختر «إضافة إلى الشاشة الرئيسية».
          </p>
        )}
      </div>
    );
  }

  return null;
};
