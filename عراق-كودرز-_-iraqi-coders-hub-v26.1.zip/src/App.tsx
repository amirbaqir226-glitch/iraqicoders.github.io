import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { onAuthStateChanged, signOut } from "firebase/auth";
import { Terminal } from "lucide-react";
import { AccountSettingsDrawer } from "./components/AccountSettingsDrawer";
import { AdBannerSlot } from "./components/AdBannerSlot";
import { AdminModal } from "./components/AdminModal";
import { AgeVerificationModal } from "./components/AgeVerificationModal";
import {
  AssistantSection,
  GeneratedCodeBundle,
} from "./components/AssistantSection";
import { AuthModal } from "./components/AuthModal";
import { BanErrorScreen } from "./components/BanErrorScreen";
import { BetaExperienceHub, BetaTabId } from "./components/BetaExperienceHub";
import { BrownDuolingoModal } from "./components/BrownDuolingoModal";
import {
  CategoriesTeleportMenu,
  TeleportAction,
} from "./components/CategoriesTeleportMenu";
import { ChallengesSection } from "./components/ChallengesSection";
import { CloudHubSection } from "./components/CloudHubSection";
import { CodePlayground } from "./components/CodePlayground";
import { ComedyBackstageModal } from "./components/ComedyBackstageModal";
import { CommunityHub } from "./components/CommunityHub";
import { CommunityLinksSection } from "./components/CommunityLinksSection";
import { CurrencyStoreModal } from "./components/CurrencyStoreModal";
import { DeveloperOptionsModal } from "./components/DeveloperOptionsModal";
import { EducationGuideRobot } from "./components/EducationGuideRobot";
import { ExtensionAndUpdatesHub } from "./components/ExtensionAndUpdatesHub";
import { FloatingArabicSpeaker } from "./components/FloatingArabicSpeaker";
import { FloatingExtensionBridgeOverlay } from "./components/FloatingExtensionBridgeOverlay";
import { Footer } from "./components/Footer";
import { GmailConfirmDialog } from "./components/GmailConfirmDialog";
import { HeroSection } from "./components/HeroSection";
import { IraqiKidsView } from "./components/IraqiKidsView";
import { MaintenanceScreen } from "./components/MaintenanceScreen";
import { MessagesCenterModal } from "./components/MessagesCenterModal";
import { Navbar } from "./components/Navbar";
import { NetworkVoiceNationalityModal } from "./components/NetworkVoiceNationalityModal";
import { OmniCreatorStudio } from "./components/OmniCreatorStudio";
import { ProjectModal } from "./components/ProjectModal";
import { SecretCodeEditorModal } from "./components/SecretCodeEditorModal";
import { SecretCreatorConsole } from "./components/SecretCreatorConsole";
import { ShopSection } from "./components/ShopSection";
import { SleepingRobotTopWidget } from "./components/SleepingRobotTopWidget";
import { ThemeDecorationLayer } from "./components/ThemeDecorationLayer";
import { WorkerCelebrationHeader } from "./components/WorkerCelebrationHeader";
import {
  APP_VERSION,
  firebaseAuth,
  getGmailAccessToken,
  isMasterAdminIdentity,
  isOwnerEmail,
  setGmailAccessToken,
  STORAGE_KEYS,
} from "./config/firebase";
import { buildEmbeddedExtensionPackage } from "./data/embeddedExtensionFiles";
import {
  DEFAULT_DEVELOPER_AVATAR,
  INITIAL_CHALLENGES,
  INITIAL_FORUM_POSTS,
  INITIAL_PROJECTS,
  INITIAL_PUBLIC_CLOUD_FILES,
  INITIAL_PUBLISHED_MINI_APPS,
  INITIAL_SCHOOL_UPDATES,
} from "./data/initialData";
import {
  deleteCloudBinaryBlob,
  getCloudBinaryBlob,
} from "./services/blobStore";
import {
  createCloudFileInFirestore,
  createForumPostInFirestore,
  createPlatformUpdateInFirestore,
  createRoleRequestInFirestore,
  deleteCloudFileInFirestore,
  deleteForumPostInFirestore,
  deletePlatformUpdateInFirestore,
  fetchNationalitiesFromFirestore,
  incrementCloudFileDownloadsInFirestore,
  saveExtensionPairingInFirestore,
  saveNationalityCardInFirestore,
  savePlatformMessageInFirestore,
  savePlatformSettingsInFirestore,
  saveUserEconomyToFirestore,
  subscribeToCloudForumPosts,
  subscribeToPrivateCloudFiles,
  subscribeToPrivatePlatformUpdates,
  subscribeToPublicCloudFiles,
  subscribeToPublicPlatformUpdates,
  syncUserEconomyFromFirestore,
  syncUserProfileToFirestore,
  updateCloudFileVisibilityInFirestore,
  updateComedyBanInFirestore,
  updateExtensionPairingStatusInFirestore,
  updatePlatformUpdateVisibilityInFirestore,
  updateUserProfileInFirestore,
  upgradeUserToDeveloperInFirestore,
} from "./services/firestoreService";
import { inspectBrowserAndBetaStatus } from "./services/betaDetector";
import { scanLiveScreenDomForCode } from "./services/domPairingScanner";
import {
  evaluateAdVisibility,
  hasVipCoinSubscription,
  VIP_PAID_PRODUCT_IDS,
} from "./services/adManager";
import { sendRealGmailMessage } from "./services/gmailService";
import {
  canPublishShopProduct,
  getGreetingForRole,
  SHOP_PUBLISH_SETTINGS,
} from "./data/siteConfig";
import { compileDownloadableBlobForCloudItem } from "./services/packageBuilder";
import { stopArabicSpeech } from "./services/speechEngine";
import { OfflineIndicator } from "./hooks/usePWA";
import { IPhoneKeyboard } from "./components/IPhoneKeyboard";
import {
  AdminRoleRequest,
  AgeVerificationStatus,
  ChallengeComment,
  ChallengeItem,
  CloudFileItem,
  CloudVisibility,
  CustomNationalityCard,
  ExtensionPairingSession,
  ForumPost,
  GmailConfirmRequest,
  PlatformAiUpdate,
  PlatformMessageRecord,
  PlatformUpdateVisibility,
  PostTopic,
  ProgrammingLanguageId,
  ProjectItem,
  PublishedMiniProject,
  SchoolUpdateItem,
  ShopCartItem,
  ShopOrderRecord,
  ShopProduct,
  StoreItem,
  SystemLogEntry,
  ThemeDecoration,
  UnpackedExtensionPackage,
  UserEconomy,
  UserProfile,
  UserRole,
} from "./types";

const TOPIC_LABELS: Record<PostTopic, string> = {
  roblox: "Roblox (Luau)",
  minecraft: "Minecraft Add-on",
  web: "تطوير الويب",
  general: "نقاش عام",
};

function readStorageJson<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

export function App() {
  const [user, setUser] = useState<UserProfile | null>(() => {
    const stored = readStorageJson<UserProfile | null>(
      STORAGE_KEYS.USER_SESSION,
      null
    );
    if (!stored) return null;
    return {
      ...stored,
      handle: stored.handle || "@iraqi_dev",
      role: stored.role || "user",
      themeDecoration: stored.themeDecoration || "default",
      desktopMode: Boolean(stored.desktopMode),
    };
  });
  const [authReady, setAuthReady] = useState(false);

  const [storedRole, setStoredRole] = useState<UserRole>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.USER_ROLE) as UserRole | null;
      return saved === "developer" ||
        saved === "director" ||
        saved === "moderator" ||
        saved === "admin"
        ? saved
        : "user";
    } catch {
      return "user";
    }
  });

  const [themeDecoration, setThemeDecoration] = useState<ThemeDecoration>(() => {
    try {
      const saved = localStorage.getItem(
        STORAGE_KEYS.THEME_DECORATION
      ) as ThemeDecoration | null;
      return saved || "default";
    } catch {
      return "default";
    }
  });

  const [desktopMode, setDesktopMode] = useState<boolean>(() => {
    try {
      // Never force a desktop layout on mobile devices upon initial load
      if (typeof window !== "undefined" && window.innerWidth < 1024) {
        return false;
      }
      return localStorage.getItem(STORAGE_KEYS.DESKTOP_MODE) === "true";
    } catch {
      return false;
    }
  });

  const [extensionMode, setExtensionMode] = useState<boolean>(() => {
    try {
      return localStorage.getItem(STORAGE_KEYS.EXTENSION_MODE) === "true";
    } catch {
      return false;
    }
  });

  const [previewVersion, setPreviewVersion] = useState<number>(() => {
    try {
      const saved = Number(localStorage.getItem(STORAGE_KEYS.PREVIEW_VERSION));
      if (!Number.isNaN(saved) && saved >= 26.5 && saved <= 999.9) {
        return saved;
      }
      return Number(APP_VERSION);
    } catch {
      return Number(APP_VERSION);
    }
  });

  const [assistantUrl, setAssistantUrl] = useState<string>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.ASSISTANT_URL) || "";
      if (!saved || saved.startsWith("http")) {
        return "#assistant";
      }
      return saved;
    } catch {
      return "#assistant";
    }
  });

  const [assistantTitle, setAssistantTitle] = useState<string>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.ASSISTANT_TITLE);
      if (!saved || saved === "تحدث مع عراقي بوت") {
        return "Talk to Iraqi Bots";
      }
      return saved;
    } catch {
      return "Talk to Iraqi Bots";
    }
  });

  const [maintenanceActive, setMaintenanceActive] = useState<boolean>(() => {
    try {
      return localStorage.getItem(STORAGE_KEYS.MAINTENANCE_BYPASSED) !== "true";
    } catch {
      return true;
    }
  });

  const [bannedEmail, setBannedEmail] = useState<string>(() => {
    try {
      return localStorage.getItem(STORAGE_KEYS.COMEDY_BAN) || "";
    } catch {
      return "";
    }
  });

  const [localPosts, setLocalPosts] = useState<ForumPost[]>(() =>
    readStorageJson<ForumPost[]>(STORAGE_KEYS.FORUM_POSTS, INITIAL_FORUM_POSTS)
  );
  const [cloudPosts, setCloudPosts] = useState<ForumPost[]>([]);

  const [localCloudFiles, setLocalCloudFiles] = useState<CloudFileItem[]>(() =>
    readStorageJson<CloudFileItem[]>(STORAGE_KEYS.CLOUD_FILES, [])
  );
  const [firestorePublicFiles, setFirestorePublicFiles] = useState<
    CloudFileItem[]
  >([]);
  const [firestorePrivateFiles, setFirestorePrivateFiles] = useState<
    CloudFileItem[]
  >([]);
  const [cloudDownloadDeltas, setCloudDownloadDeltas] = useState<
    Record<string, number>
  >({});

  const [systemLogs, setSystemLogs] = useState<SystemLogEntry[]>(() =>
    readStorageJson<SystemLogEntry[]>(STORAGE_KEYS.SYSTEM_LOGS, [
      {
        id: "log-boot",
        level: "INFO",
        message: "تم تشغيل منصة عراقي كودرز الإصدار 26.5",
        timestamp: new Date().toLocaleTimeString("en-GB"),
      },
    ])
  );

  const [localAiUpdates, setLocalAiUpdates] = useState<PlatformAiUpdate[]>(() =>
    readStorageJson<PlatformAiUpdate[]>(STORAGE_KEYS.PLATFORM_UPDATES, [])
  );
  const [serverAiUpdates, setServerAiUpdates] = useState<PlatformAiUpdate[]>(
    []
  );
  const [firestorePublicUpdates, setFirestorePublicUpdates] = useState<
    PlatformAiUpdate[]
  >([]);
  const [firestorePrivateUpdates, setFirestorePrivateUpdates] = useState<
    PlatformAiUpdate[]
  >([]);

  const [economy, setEconomy] = useState<UserEconomy>(() =>
    readStorageJson<UserEconomy>(STORAGE_KEYS.USER_ECONOMY, {
      activeSeconds: 60,
      coins: 50,
      unlockedItems: [],
      equippedSkin: "default",
    })
  );
  const economyRef = useRef<UserEconomy>(economy);
  economyRef.current = economy;

  const [downloadDeltas, setDownloadDeltas] = useState<Record<string, number>>(
    () =>
      readStorageJson<Record<string, number>>(
        STORAGE_KEYS.PROJECT_DOWNLOADS,
        {}
      )
  );

  const [codeRunsCount, setCodeRunsCount] = useState<number>(() =>
    readStorageJson<number>(STORAGE_KEYS.CODE_RUNS, 384)
  );

  const [adminUnlocked, setAdminUnlocked] = useState<boolean>(() => {
    try {
      return localStorage.getItem(STORAGE_KEYS.ADMIN_AUTH) === "true";
    } catch {
      return false;
    }
  });

  const [secretDevUnlocked, setSecretDevUnlocked] = useState(false);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [accountSettingsOpen, setAccountSettingsOpen] = useState(false);
  const [drawerScrollTarget, setDrawerScrollTarget] = useState<
    | "developer-category"
    | "admin-request"
    | "ad-dns-settings"
    | "speaker-settings"
    | "downloads"
    | null
  >(null);
  const [categoriesMenuOpen, setCategoriesMenuOpen] = useState(false);
  const [iphoneKeyboardOpen, setIphoneKeyboardOpen] = useState(false);
  const [iphoneFontEnabled, setIphoneFontEnabled] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.IPHONE_PACK_ENABLED);
      return saved === null ? true : saved === "true";
    } catch {
      return true;
    }
  });
  const [developerOptionsOpen, setDeveloperOptionsOpen] = useState(false);
  const [adminModalOpen, setAdminModalOpen] = useState(false);
  const [brownOwlOpen, setBrownOwlOpen] = useState(false);
  const [comedyModalOpen, setComedyModalOpen] = useState(false);
  const [comedyMode, setComedyMode] = useState<"comedy" | "prank">("comedy");
  const [currencyStoreOpen, setCurrencyStoreOpen] = useState(false);
  const [secretConsoleOpen, setSecretConsoleOpen] = useState(false);
  const [secretCodeEditorOpen, setSecretCodeEditorOpen] = useState(false);
  const [secretEditorInitialFile, setSecretEditorInitialFile] = useState<{
    name: string;
    content: string;
  } | null>(null);
  const [selectedProject, setSelectedProject] = useState<ProjectItem | null>(
    null
  );
  const [injectedBundle, setInjectedBundle] =
    useState<GeneratedCodeBundle | null>(null);
  const [toastMessage, setToastMessage] = useState("");

  // Shared Extension Pairing & "ما بيا حيل" Floating Extension Package State
  const [pairingSession, setPairingSession] =
    useState<ExtensionPairingSession | null>(() => {
      const saved = readStorageJson<ExtensionPairingSession | null>(
        STORAGE_KEYS.EXTENSION_PAIRING,
        null
      );
      if (saved) return saved;
      return {
        id: "extpair-live-777",
        code: "IRAQI-CODE-777",
        extensionName: "إدارة عراقي كودرز",
        browser: "Live DOM Scanner Bridge",
        status: "waiting",
        feedbackMessage:
          "الرمز معروض حياً على الشاشة أونلاين — أدخله لبدء فحص الشاشة والاقتران الفوري.",
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
    });
  const [pairingUnlockedControl, setPairingUnlockedControl] = useState<boolean>(
    () => {
      const saved = readStorageJson<ExtensionPairingSession | null>(
        STORAGE_KEYS.EXTENSION_PAIRING,
        null
      );
      return saved?.status === "paired";
    }
  );
  const [pairingLoading, setPairingLoading] = useState(false);
  const [activeFloatingExtension, setActiveFloatingExtension] =
    useState<UnpackedExtensionPackage | null>(() =>
      readStorageJson<UnpackedExtensionPackage | null>(
        STORAGE_KEYS.FLOATING_EXTENSION_PKG,
        null
      )
    );
  const [lazyBridgeOpenNonce, setLazyBridgeOpenNonce] = useState(0);
  const [communityFilterReq, setCommunityFilterReq] = useState<{
    filter: "all" | "roblox" | "minecraft" | "forum";
    nonce: number;
  }>({ filter: "all", nonce: 0 });
  const [shopCart, setShopCart] = useState<ShopCartItem[]>(() =>
    readStorageJson<ShopCartItem[]>(STORAGE_KEYS.SHOP_CART, [])
  );
  const [shopOrders, setShopOrders] = useState<ShopOrderRecord[]>(() =>
    readStorageJson<ShopOrderRecord[]>(STORAGE_KEYS.SHOP_ORDERS, [])
  );
  const [customShopProducts, setCustomShopProducts] = useState<ShopProduct[]>(() =>
    readStorageJson<ShopProduct[]>(STORAGE_KEYS.SHOP_CUSTOM_PRODUCTS, [])
  );
  const [shopCartOpen, setShopCartOpen] = useState(false);
  const [dnsAdBlockEnabled, setDnsAdBlockEnabled] = useState<boolean>(() => {
    try {
      return localStorage.getItem(STORAGE_KEYS.AD_DNS_ENABLED) === "true";
    } catch {
      return false;
    }
  });
  const [vipPaidActive, setVipPaidActive] = useState<boolean>(() => {
    try {
      return localStorage.getItem(STORAGE_KEYS.VIP_PAID_ACTIVE) === "true";
    } catch {
      return false;
    }
  });

  // 7-Pillar New States: Edu Robot, Speaker A11y, Challenges, Auto Beta & Plus Settings
  const [eduRobotSkipped, setEduRobotSkipped] = useState<boolean>(() => {
    try {
      return localStorage.getItem(STORAGE_KEYS.EDU_ROBOT_SKIPPED) === "true";
    } catch {
      return false;
    }
  });
  const [speakerEnabled, setSpeakerEnabled] = useState<boolean>(() => {
    try {
      return localStorage.getItem(STORAGE_KEYS.SPEAKER_ENABLED) === "true";
    } catch {
      return false;
    }
  });
  const [challenges, setChallenges] = useState<ChallengeItem[]>(() =>
    readStorageJson<ChallengeItem[]>(STORAGE_KEYS.CHALLENGES, INITIAL_CHALLENGES)
  );
  const [googleBetaJoined, setGoogleBetaJoined] = useState<boolean>(() => {
    try {
      return localStorage.getItem(STORAGE_KEYS.GOOGLE_BETA_JOINED) === "true";
    } catch {
      return false;
    }
  });
  const browserInspection = useMemo(
    () => inspectBrowserAndBetaStatus(),
    [googleBetaJoined]
  );
  const [betaEnabled, setBetaEnabled] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.BETA_MODE);
      if (saved !== null) return saved === "true";
      return inspectBrowserAndBetaStatus().isBetaJoined;
    } catch {
      return false;
    }
  });
  const [activeProgLang, setActiveProgLang] = useState<ProgrammingLanguageId>(
    () => {
      try {
        return (
          (localStorage.getItem(STORAGE_KEYS.BETA_PROG_LANG) as ProgrammingLanguageId) ||
          "javascript"
        );
      } catch {
        return "javascript";
      }
    }
  );
  const [publishedMiniApps, setPublishedMiniApps] = useState<PublishedMiniProject[]>(
    () =>
      readStorageJson<PublishedMiniProject[]>(
        STORAGE_KEYS.PUBLISHED_MINI_APPS,
        INITIAL_PUBLISHED_MINI_APPS
      )
  );
  const [schoolUpdates, setSchoolUpdates] = useState<SchoolUpdateItem[]>(() =>
    readStorageJson<SchoolUpdateItem[]>(
      STORAGE_KEYS.SCHOOL_UPDATES,
      INITIAL_SCHOOL_UPDATES
    )
  );

  // Pillars 8 & 9 States: Check Messages + Gmail Alerts, Custom Nationality, Age Verification & Iraqi Kids Mode
  const [messagesModalOpen, setMessagesModalOpen] = useState(false);
  const [networkVoiceModalOpen, setNetworkVoiceModalOpen] = useState(false);
  const [gmailAlertsEnabled, setGmailAlertsEnabled] = useState<boolean>(() => {
    try {
      return localStorage.getItem(STORAGE_KEYS.GMAIL_ALERTS_ENABLED) === "true";
    } catch {
      return false;
    }
  });
  const [gmailConfirmRequest, setGmailConfirmRequest] =
    useState<GmailConfirmRequest | null>(null);
  const [platformMessages, setPlatformMessages] = useState<PlatformMessageRecord[]>(
    () =>
      readStorageJson<PlatformMessageRecord[]>(STORAGE_KEYS.PLATFORM_MESSAGES, [])
  );
  const [nationalities, setNationalities] = useState<CustomNationalityCard[]>(() =>
    readStorageJson<CustomNationalityCard[]>(STORAGE_KEYS.NATIONALITIES, [])
  );
  const [betaTabRequest, setBetaTabRequest] = useState<{
    tab: BetaTabId;
    nonce: number;
  }>({ tab: "school", nonce: 0 });
  const [ageStatus, setAgeStatus] = useState<AgeVerificationStatus>(() => {
    try {
      const saved = localStorage.getItem(
        STORAGE_KEYS.AGE_STATUS
      ) as AgeVerificationStatus | null;
      return saved || "unverified";
    } catch {
      return "unverified";
    }
  });
  const [kidsMode, setKidsMode] = useState<boolean>(() => {
    try {
      return localStorage.getItem(STORAGE_KEYS.KIDS_MODE) === "true";
    } catch {
      return false;
    }
  });
  const [kidsTransitionState, setKidsTransitionState] = useState<
    "none" | "entering-kids" | "exiting-kids"
  >("none");

  const fantasyMode = themeDecoration === "fantasy";

  const shopCartTotalCount = useMemo(
    () => shopCart.reduce((sum, item) => sum + item.quantity, 0),
    [shopCart]
  );

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    window.setTimeout(() => setToastMessage(""), 3400);
  }, []);

  const addSystemLog = useCallback(
    (level: SystemLogEntry["level"], message: string) => {
      const entry: SystemLogEntry = {
        id: `log-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        level,
        message,
        timestamp: new Date().toLocaleTimeString("en-GB"),
      };
      setSystemLogs((prev) => {
        const next = [entry, ...prev].slice(0, 120);
        try {
          localStorage.setItem(STORAGE_KEYS.SYSTEM_LOGS, JSON.stringify(next));
        } catch {
          // Safe no-op
        }
        return next;
      });
    },
    []
  );

  // Sync Firebase Auth state & Firestore User Profile
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(firebaseAuth, (fbUser) => {
      if (fbUser) {
        void (async () => {
          let synced = null;
          try {
            synced = await syncUserProfileToFirestore(fbUser, {
              city: "العراق",
              themeDecoration,
              desktopMode,
            });
          } catch (err) {
            console.error(err);
          }

          const fallbackHandle = `@${(
            fbUser.email?.split("@")[0] || "iraqi_dev"
          )
            .replace(/[^a-zA-Z0-9_]/g, "")
            .toLowerCase()
            .slice(0, 28)}`;

          const isMobileScreen =
            typeof window !== "undefined" && window.innerWidth < 1024;
          const resolvedDesktopMode = isMobileScreen
            ? false
            : synced?.desktopMode !== undefined
            ? synced.desktopMode
            : desktopMode;

          const resolvedRole: UserRole =
            isOwnerEmail(fbUser.email)
              ? "admin"
              : storedRole === "director"
              ? "director"
              : storedRole === "moderator"
              ? "moderator"
              : synced?.role === "developer" || storedRole === "developer"
              ? "developer"
              : "user";

          const profile: UserProfile = {
            id: fbUser.uid,
            name: synced?.displayName || fbUser.displayName || "مطور Google",
            handle: synced?.handle || fallbackHandle,
            email: fbUser.email || "",
            avatarUrl:
              synced?.avatarUrl ||
              fbUser.photoURL ||
              DEFAULT_DEVELOPER_AVATAR,
            provider: "google",
            city: synced?.city || "العراق",
            role: resolvedRole,
            themeDecoration: synced?.themeDecoration || themeDecoration,
            desktopMode: resolvedDesktopMode,
            loggedInAt: new Date().toISOString(),
          };

          setUser(profile);
          setStoredRole(resolvedRole);
          localStorage.setItem(STORAGE_KEYS.USER_ROLE, resolvedRole);
          setThemeDecoration(profile.themeDecoration);
          setDesktopMode(resolvedDesktopMode);
          localStorage.setItem(
            STORAGE_KEYS.USER_SESSION,
            JSON.stringify(profile)
          );
          localStorage.setItem(
            STORAGE_KEYS.THEME_DECORATION,
            profile.themeDecoration
          );
          localStorage.setItem(
            STORAGE_KEYS.DESKTOP_MODE,
            String(resolvedDesktopMode)
          );
          const syncedEconomy = await syncUserEconomyFromFirestore(fbUser.uid).catch(
            () => null
          );
          if (syncedEconomy) {
            const merged: UserEconomy = {
              activeSeconds: Math.max(
                syncedEconomy.activeSeconds,
                economyRef.current.activeSeconds
              ),
              coins: Math.max(syncedEconomy.coins, economyRef.current.coins),
              unlockedItems: Array.from(
                new Set([
                  ...syncedEconomy.unlockedItems,
                  ...economyRef.current.unlockedItems,
                ])
              ),
              equippedSkin:
                syncedEconomy.equippedSkin !== "default"
                  ? syncedEconomy.equippedSkin
                  : economyRef.current.equippedSkin,
            };
            setEconomy(merged);
            localStorage.setItem(
              STORAGE_KEYS.USER_ECONOMY,
              JSON.stringify(merged)
            );
          }

          addSystemLog(
            "AUTH",
            `تمت مزامنة جلسة Google: ${profile.name} (${profile.handle})`
          );
        })();
      } else {
        setGmailAccessToken(null);
      }
      setAuthReady(true);
    });
    return () => unsubscribe();
  }, [addSystemLog]);

  // Synchronize forced Desktop View class on <html>
  useEffect(() => {
    document.documentElement.classList.toggle("force-desktop-view", desktopMode);
    return () => {
      document.documentElement.classList.remove("force-desktop-view");
    };
  }, [desktopMode]);

  // Active Time-to-Coins real-time accumulator while user is active on the page
  useEffect(() => {
    if (bannedEmail) return;
    let tickCounter = 0;

    const timer = window.setInterval(() => {
      if (document.visibilityState !== "visible") return;
      tickCounter += 1;

      setEconomy((prev) => {
        const next: UserEconomy = {
          ...prev,
          activeSeconds: prev.activeSeconds + 1,
        };
        if (tickCounter % 15 === 0) {
          try {
            localStorage.setItem(
              STORAGE_KEYS.USER_ECONOMY,
              JSON.stringify(next)
            );
          } catch {
            // Safe no-op
          }
          if (firebaseAuth.currentUser && tickCounter % 30 === 0) {
            void saveUserEconomyToFirestore(
              firebaseAuth.currentUser.uid,
              next
            ).catch((err) => console.error(err));
          }
        }
        return next;
      });
    }, 1000);

    return () => window.clearInterval(timer);
  }, [bannedEmail]);

  // Subscribe to Cloud Firestore Forum Posts + Cloud Hub Files + Platform Updates once Auth is ready
  useEffect(() => {
    if (!authReady || !firebaseAuth.currentUser) return;

    const unsubForum = subscribeToCloudForumPosts((postsFromCloud) => {
      setCloudPosts(postsFromCloud);
    });
    const unsubPublicCloud = subscribeToPublicCloudFiles((files) => {
      setFirestorePublicFiles(files);
    });
    const unsubPrivateCloud = subscribeToPrivateCloudFiles(
      firebaseAuth.currentUser.uid,
      (files) => {
        setFirestorePrivateFiles(files);
      }
    );
    const unsubPublicUpdates = subscribeToPublicPlatformUpdates((updates) => {
      setFirestorePublicUpdates(updates);
    });
    const unsubPrivateUpdates = subscribeToPrivatePlatformUpdates(
      firebaseAuth.currentUser.uid,
      (updates) => {
        setFirestorePrivateUpdates(updates);
      }
    );

    return () => {
      unsubForum();
      unsubPublicCloud();
      unsubPrivateCloud();
      unsubPublicUpdates();
      unsubPrivateUpdates();
    };
  }, [authReady, user?.id]);

  // Fetch server-synced public/private live updates and custom shop products on mount
  useEffect(() => {
    let active = true;
    const authorId = user?.id || "local-admin-dev";
    void fetch(`/api/updates?authorId=${encodeURIComponent(authorId)}`)
      .then((res) => (res.ok ? res.json() : null))
      .then((data: { updates?: PlatformAiUpdate[] } | null) => {
        if (active && data?.updates) {
          setServerAiUpdates(data.updates);
        }
      })
      .catch(() => undefined);

    void fetch("/api/shop-products")
      .then((res) => (res.ok ? res.json() : null))
      .then((data: { products?: ShopProduct[] } | null) => {
        if (!active || !Array.isArray(data?.products)) return;
        const serverItems = data.products;
        if (serverItems.length === 0) return;
        setCustomShopProducts((prev) => {
          const mergedMap = new Map<string, ShopProduct>();
          for (const item of serverItems) mergedMap.set(item.id, item);
          for (const item of prev) {
            if (!mergedMap.has(item.id)) mergedMap.set(item.id, item);
          }
          const merged = Array.from(mergedMap.values()).slice(
            0,
            SHOP_PUBLISH_SETTINGS.maxCustomProducts
          );
          try {
            localStorage.setItem(
              STORAGE_KEYS.SHOP_CUSTOM_PRODUCTS,
              JSON.stringify(merged)
            );
          } catch {
            // Safe no-op
          }
          return merged;
        });
      })
      .catch(() => undefined);

    void fetch("/api/challenges")
      .then((res) => (res.ok ? res.json() : null))
      .then((data: { challenges?: ChallengeItem[] } | null) => {
        if (!active || !Array.isArray(data?.challenges) || data.challenges.length === 0) return;
        setChallenges((prev) => {
          const map = new Map<string, ChallengeItem>();
          for (const item of data.challenges!) map.set(item.id, item);
          for (const item of prev) if (!map.has(item.id)) map.set(item.id, item);
          const merged = Array.from(map.values());
          try {
            localStorage.setItem(STORAGE_KEYS.CHALLENGES, JSON.stringify(merged));
          } catch {
            // Safe no-op
          }
          return merged;
        });
      })
      .catch(() => undefined);

    void fetch("/api/beta-projects")
      .then((res) => (res.ok ? res.json() : null))
      .then((data: { projects?: PublishedMiniProject[] } | null) => {
        if (!active || !Array.isArray(data?.projects) || data.projects.length === 0) return;
        setPublishedMiniApps((prev) => {
          const map = new Map<string, PublishedMiniProject>();
          for (const item of data.projects!) map.set(item.id, item);
          for (const item of prev) if (!map.has(item.id)) map.set(item.id, item);
          const merged = Array.from(map.values());
          try {
            localStorage.setItem(STORAGE_KEYS.PUBLISHED_MINI_APPS, JSON.stringify(merged));
          } catch {
            // Safe no-op
          }
          return merged;
        });
      })
      .catch(() => undefined);

    void fetch("/api/school-updates")
      .then((res) => (res.ok ? res.json() : null))
      .then((data: { updates?: SchoolUpdateItem[] } | null) => {
        if (!active || !Array.isArray(data?.updates) || data.updates.length === 0) return;
        setSchoolUpdates((prev) => {
          const map = new Map<string, SchoolUpdateItem>();
          for (const item of data.updates!) map.set(item.id, item);
          for (const item of prev) if (!map.has(item.id)) map.set(item.id, item);
          const merged = Array.from(map.values());
          try {
            localStorage.setItem(STORAGE_KEYS.SCHOOL_UPDATES, JSON.stringify(merged));
          } catch {
            // Safe no-op
          }
          return merged;
        });
      })
      .catch(() => undefined);

    void fetch("/api/nationalities")
      .then((res) => (res.ok ? res.json() : null))
      .then((data: { nationalities?: CustomNationalityCard[] } | null) => {
        if (!active || !Array.isArray(data?.nationalities)) return;
        setNationalities((prev) => {
          const map = new Map<string, CustomNationalityCard>();
          for (const item of data.nationalities!) map.set(item.id, item);
          for (const item of prev) if (!map.has(item.id)) map.set(item.id, item);
          const merged = Array.from(map.values());
          try {
            localStorage.setItem(STORAGE_KEYS.NATIONALITIES, JSON.stringify(merged));
          } catch {
            // Safe no-op
          }
          return merged;
        });
      })
      .catch(() => undefined);

    void fetch("/api/messages")
      .then((res) => (res.ok ? res.json() : null))
      .then((data: { messages?: PlatformMessageRecord[] } | null) => {
        if (!active || !Array.isArray(data?.messages)) return;
        setPlatformMessages((prev) => {
          const map = new Map<string, PlatformMessageRecord>();
          for (const item of data.messages!) map.set(item.id, item);
          for (const item of prev) if (!map.has(item.id)) map.set(item.id, item);
          const merged = Array.from(map.values()).slice(0, 120);
          try {
            localStorage.setItem(STORAGE_KEYS.PLATFORM_MESSAGES, JSON.stringify(merged));
          } catch {
            // Safe no-op
          }
          return merged;
        });
      })
      .catch(() => undefined);

    if (firebaseAuth.currentUser) {
      void fetchNationalitiesFromFirestore()
        .then((cards) => {
          if (!active || cards.length === 0) return;
          setNationalities((prev) => {
            const map = new Map<string, CustomNationalityCard>();
            for (const c of cards) map.set(c.id, c);
            for (const c of prev) if (!map.has(c.id)) map.set(c.id, c);
            return Array.from(map.values());
          });
        })
        .catch(() => undefined);
    }

    return () => {
      active = false;
    };
  }, [user?.id]);

  // Keyboard shortcut Ctrl+Shift+A to open Admin Panel
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.ctrlKey && event.shiftKey && event.key.toLowerCase() === "a") {
        event.preventDefault();
        setAdminModalOpen(true);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  const posts = useMemo(() => {
    const cloudIds = new Set(cloudPosts.map((p) => p.id));
    return [...cloudPosts, ...localPosts.filter((p) => !cloudIds.has(p.id))];
  }, [cloudPosts, localPosts]);

  const privateCloudFiles = useMemo(() => {
    const remoteIds = new Set(firestorePrivateFiles.map((f) => f.id));
    const currentOwnerId = user?.id || "local-guest-dev";
    const localOwned = localCloudFiles.filter(
      (f) =>
        !remoteIds.has(f.id) &&
        (f.ownerId === currentOwnerId || f.ownerId === "local-guest-dev")
    );
    return [...firestorePrivateFiles, ...localOwned].map((f) => ({
      ...f,
      downloads: f.downloads + (cloudDownloadDeltas[f.id] || 0),
    }));
  }, [firestorePrivateFiles, localCloudFiles, user?.id, cloudDownloadDeltas]);

  const publicCloudFiles = useMemo(() => {
    const seen = new Set<string>();
    const combined: CloudFileItem[] = [];

    for (const file of firestorePublicFiles) {
      if (!seen.has(file.id)) {
        seen.add(file.id);
        combined.push(file);
      }
    }
    for (const file of localCloudFiles) {
      if (file.visibility === "public" && !seen.has(file.id)) {
        seen.add(file.id);
        combined.push(file);
      }
    }
    for (const starter of INITIAL_PUBLIC_CLOUD_FILES) {
      if (!seen.has(starter.id)) {
        seen.add(starter.id);
        combined.push(starter);
      }
    }

    return combined.map((f) => ({
      ...f,
      downloads: f.downloads + (cloudDownloadDeltas[f.id] || 0),
    }));
  }, [firestorePublicFiles, localCloudFiles, cloudDownloadDeltas]);

  const projectsWithLiveDownloads = useMemo(() => {
    return INITIAL_PROJECTS.map((proj) => ({
      ...proj,
      downloads: proj.downloads + (downloadDeltas[proj.id] || 0),
    }));
  }, [downloadDeltas]);

  const totalDownloads = useMemo(
    () => projectsWithLiveDownloads.reduce((sum, p) => sum + p.downloads, 0),
    [projectsWithLiveDownloads]
  );

  const isMasterAdmin = isMasterAdminIdentity(user, firebaseAuth.currentUser);

  const isAdminPrivileged =
    isMasterAdmin ||
    adminUnlocked ||
    pairingUnlockedControl;

  const userRole: UserRole = isAdminPrivileged
    ? "admin"
    : user?.role === "director" || storedRole === "director"
    ? "director"
    : user?.role === "moderator" || storedRole === "moderator"
    ? "moderator"
    : user?.role === "developer" || storedRole === "developer"
    ? "developer"
    : "user";

  const canUseDevTools =
    userRole === "developer" ||
    userRole === "director" ||
    userRole === "moderator" ||
    userRole === "admin";

  const isVipCoins = hasVipCoinSubscription(economy.unlockedItems);

  const adVisibility = useMemo(
    () =>
      evaluateAdVisibility({
        isVipPaid: vipPaidActive,
        isVipCoins,
        userRole,
        isSupervisorOrAdmin: isAdminPrivileged,
        isDnsEnabledInSettings: dnsAdBlockEnabled,
      }),
    [vipPaidActive, isVipCoins, userRole, isAdminPrivileged, dnsAdBlockEnabled]
  );

  const displayVersion = previewVersion.toFixed(1);

  const visiblePlatformUpdates = useMemo(() => {
    const map = new Map<string, PlatformAiUpdate>();
    const currentId = user?.id || "local-admin-dev";
    const addIfAllowed = (item: PlatformAiUpdate) => {
      if (
        item.visibility === "public" ||
        isAdminPrivileged ||
        item.authorId === currentId
      ) {
        map.set(item.id, item);
      }
    };

    for (const item of firestorePublicUpdates) addIfAllowed(item);
    for (const item of firestorePrivateUpdates) addIfAllowed(item);
    for (const item of serverAiUpdates) addIfAllowed(item);
    for (const item of localAiUpdates) addIfAllowed(item);

    return Array.from(map.values());
  }, [
    firestorePublicUpdates,
    firestorePrivateUpdates,
    serverAiUpdates,
    localAiUpdates,
    user?.id,
    isAdminPrivileged,
  ]);

  const persistEconomy = useCallback((next: UserEconomy) => {
    setEconomy(next);
    try {
      localStorage.setItem(STORAGE_KEYS.USER_ECONOMY, JSON.stringify(next));
    } catch {
      // Safe no-op
    }
    if (firebaseAuth.currentUser) {
      void saveUserEconomyToFirestore(
        firebaseAuth.currentUser.uid,
        next
      ).catch((err) => console.error(err));
    }
  }, []);

  const handleTradeTimeForCoins = (secondsCost: number, coinsReward: number) => {
    if (!isAdminPrivileged && economy.activeSeconds < secondsCost) {
      showToast("وقتك المتراكم غير كافٍ لهذه الباقة بعد.");
      return;
    }

    const next: UserEconomy = {
      ...economy,
      activeSeconds: isAdminPrivileged
        ? economy.activeSeconds
        : Math.max(0, economy.activeSeconds - secondsCost),
      coins: economy.coins + coinsReward,
    };
    persistEconomy(next);
    addSystemLog("INFO", `تم تحويل وقت التفاعل إلى +${coinsReward} عملة`);
    showToast(`تمت إضافة +${coinsReward} عملة رقمية إلى رصيدك!`);
  };

  const handlePurchaseOrActivateItem = (item: StoreItem) => {
    const alreadyOwned =
      isAdminPrivileged || economy.unlockedItems.includes(item.id);

    if (!alreadyOwned && economy.coins < item.priceCoins) {
      showToast("رصيدك من العملات غير كافٍ، حوّل وقت تفاعلك أولاً!");
      return;
    }

    const nextUnlocked = economy.unlockedItems.includes(item.id)
      ? economy.unlockedItems
      : [...economy.unlockedItems, item.id];

    const nextCoins = alreadyOwned
      ? economy.coins
      : Math.max(0, economy.coins - item.priceCoins);

    let nextSkin = economy.equippedSkin;
    if (item.category === "skin") {
      nextSkin = economy.equippedSkin === item.id ? "default" : item.id;
    }

    const next: UserEconomy = {
      ...economy,
      coins: nextCoins,
      unlockedItems: nextUnlocked,
      equippedSkin: nextSkin,
    };
    persistEconomy(next);

    if (item.id === "theme-halloween-pack") {
      handleChangeTheme("halloween");
    } else if (item.id === "theme-electric-pack") {
      handleChangeTheme("electric");
    }

    const unlockedVipAdFree =
      !alreadyOwned && hasVipCoinSubscription([item.id]);

    showToast(
      alreadyOwned
        ? item.category === "skin"
          ? nextSkin === item.id
            ? `تم تجهيز ${item.name}!`
            : "تمت إزالة إطار السكن."
          : `تم تفعيل ${item.name}!`
        : unlockedVipAdFree
        ? `مبروك! تم تفعيل «${item.name}» وإخفاء الإعلانات تلقائياً!`
        : `مبروك! تم فتح «${item.name}» بنجاح.`
    );
  };

  const handleChangeTheme = (nextTheme: ThemeDecoration) => {
    setThemeDecoration(nextTheme);
    try {
      localStorage.setItem(STORAGE_KEYS.THEME_DECORATION, nextTheme);
    } catch {
      // Safe no-op
    }
    if (user) {
      const updatedUser: UserProfile = {
        ...user,
        themeDecoration: nextTheme,
      };
      setUser(updatedUser);
      localStorage.setItem(
        STORAGE_KEYS.USER_SESSION,
        JSON.stringify(updatedUser)
      );
      if (firebaseAuth.currentUser) {
        void updateUserProfileInFirestore(firebaseAuth.currentUser.uid, {
          displayName: updatedUser.name,
          handle: updatedUser.handle,
          city: updatedUser.city,
          avatarUrl: updatedUser.avatarUrl,
          themeDecoration: nextTheme,
          desktopMode: updatedUser.desktopMode,
        }).catch((err) => console.error(err));
      }
    }
    addSystemLog("INFO", `تم تغيير ثيم الزينة إلى: ${nextTheme}`);
  };

  const handleToggleExtensionMode = useCallback((enabled: boolean) => {
    setExtensionMode(enabled);
    try {
      localStorage.setItem(STORAGE_KEYS.EXTENSION_MODE, String(enabled));
    } catch {
      // Safe no-op
    }
  }, []);

  const persistPairingSession = useCallback(
    (next: ExtensionPairingSession | null) => {
      setPairingSession(next);
      try {
        if (next) {
          localStorage.setItem(
            STORAGE_KEYS.EXTENSION_PAIRING,
            JSON.stringify(next)
          );
        } else {
          localStorage.removeItem(STORAGE_KEYS.EXTENSION_PAIRING);
        }
      } catch {
        // Safe no-op
      }
    },
    []
  );

  // Background poll while waiting/pending_confirm so external extensions auto-open the confirmation modal
  useEffect(() => {
    if (
      !pairingSession?.code ||
      (pairingSession.status !== "waiting" &&
        pairingSession.status !== "pending_confirm")
    ) {
      return;
    }
    const interval = window.setInterval(() => {
      void (async () => {
        try {
          const res = await fetch(
            `/api/extension/pairing/status/${encodeURIComponent(
              pairingSession.code
            )}`
          );
          if (!res.ok) return;
          const data = (await res.json()) as {
            session?: ExtensionPairingSession;
          };
          if (data.session && data.session.status !== pairingSession.status) {
            persistPairingSession({
              ...data.session,
              id: pairingSession.id || data.session.id,
            });
            if (data.session.status === "paired") {
              handleToggleExtensionMode(true);
              showToast(
                data.session.feedbackMessage ||
                  "تم السماح بالاقتران والتحكم الكامل بالموقع بنجاح!"
              );
            }
          }
        } catch {
          // Safe background fallback
        }
      })();
    }, 2200);
    return () => window.clearInterval(interval);
  }, [
    pairingSession?.code,
    pairingSession?.status,
    pairingSession?.id,
    persistPairingSession,
    handleToggleExtensionMode,
    showToast,
  ]);

  const handleGeneratePairing = async () => {
    setPairingLoading(true);
    const pairId = `extpair-${Date.now()}`;
    try {
      const res = await fetch("/api/extension/pairing/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: pairId,
          extensionName: "إدارة عراقي كودرز",
          browser: "Chrome / Edge Extension",
        }),
      });
      const data = (await res.json()) as { session: ExtensionPairingSession };
      const session = data.session;
      persistPairingSession(session);
      handleToggleExtensionMode(true);

      await saveExtensionPairingInFirestore({
        id: session.id,
        code: session.code,
        extensionName: session.extensionName,
        browser: session.browser,
        status: "waiting",
        feedbackMessage: session.feedbackMessage || "",
      }).catch(() => undefined);

      showToast(
        `تم إنشاء رمز الاقتران (${session.code}) لإضافة «إدارة عراقي كودرز».`
      );
    } catch {
      const fallbackCode = `EXT-${Math.floor(1000 + Math.random() * 9000)}`;
      const localSession: ExtensionPairingSession = {
        id: pairId,
        code: fallbackCode,
        extensionName: "إدارة عراقي كودرز",
        browser: "Chrome / Edge Extension",
        status: "waiting",
        feedbackMessage: "تم توليد الرمز. أدخله في إضافة «إدارة عراقي كودرز».",
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      persistPairingSession(localSession);
      handleToggleExtensionMode(true);
      showToast(`تم توليد رمز الاقتران: ${fallbackCode}`);
    } finally {
      setPairingLoading(false);
    }
  };

  const handleTriggerPairingRequest = async (
    rawCode: string,
    extName = "إدارة عراقي كودرز"
  ) => {
    const targetCode = rawCode.trim().toUpperCase();
    if (targetCode.length < 4) {
      showToast("أدخل رمز الاقتران أولاً مثل EXT-4821.");
      return;
    }
    setPairingLoading(true);
    try {
      const res = await fetch("/api/extension/pairing/request", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          code: targetCode,
          extensionName: extName,
          browser: navigator.userAgent.includes("Edg")
            ? "Microsoft Edge Extension"
            : "Chrome Browser Extension",
        }),
      });
      const data = (await res.json()) as {
        session?: ExtensionPairingSession;
        error?: string;
      };
      if (!res.ok || !data.session) {
        showToast(data.error || "تعذر إرسال طلب الاقتران.");
        return;
      }

      const nextSession: ExtensionPairingSession = {
        ...data.session,
        id: pairingSession?.id || data.session.id,
      };
      persistPairingSession(nextSession);

      await updateExtensionPairingStatusInFirestore({
        id: nextSession.id,
        extensionName: nextSession.extensionName,
        browser: nextSession.browser,
        status: "pending_confirm",
        feedbackMessage: nextSession.feedbackMessage || "",
      }).catch(() => undefined);
    } catch {
      const localPending: ExtensionPairingSession = {
        id: pairingSession?.id || `extpair-${Date.now()}`,
        code: targetCode,
        extensionName: extName,
        browser: "Chrome / Edge Extension",
        status: "pending_confirm",
        feedbackMessage: "بانتظار موافقة مالك الموقع (نعم / لا).",
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      persistPairingSession(localPending);
    } finally {
      setPairingLoading(false);
    }
  };

  const handleScanAndPairFromScreen = useCallback(
    async (
      rawCode: string,
      extName = "إدارة عراقي كودرز"
    ): Promise<boolean> => {
      const scanResult = scanLiveScreenDomForCode(rawCode);
      if (!scanResult.matched) {
        addSystemLog(
          "INFO",
          `فحص الشاشة أونلاين لم يجد الرمز (${scanResult.code}) ضمن ${scanResult.scannedNodesCount} عنصر DOM.`
        );
        showToast(
          `لم يُعثر على الرمز «${scanResult.code}» معروضاً حياً على شاشة المنصة.`
        );
        return false;
      }

      const nowIso = new Date().toISOString();
      const verifiedSession: ExtensionPairingSession = {
        id: pairingSession?.id || `extpair-${Date.now()}`,
        code: scanResult.code,
        extensionName: extName,
        browser:
          typeof navigator !== "undefined" && navigator.userAgent.includes("Edg")
            ? "Microsoft Edge Extension"
            : "Chrome Browser Extension",
        status: "paired",
        feedbackMessage:
          "تم فحص الشاشة أونلاين ومطابقة الرمز بنجاح! تم فتح التحكم الكامل للمدير والمطور فوراً.",
        domScan: {
          matched: true,
          code: scanResult.code,
          scannedNodesCount: scanResult.scannedNodesCount,
          durationMs: scanResult.durationMs,
          sourceHint: scanResult.sourceHint,
          scannedAt: nowIso,
        },
        createdAt: pairingSession?.createdAt || nowIso,
        updatedAt: nowIso,
      };

      // Instant zero-delay authentication & full admin/developer control unlock
      persistPairingSession(verifiedSession);
      setPairingUnlockedControl(true);
      handleToggleExtensionMode(true);
      addSystemLog(
        "AUTH",
        `اقتران فوري عبر فحص الشاشة أونلاين: ${scanResult.code} (${scanResult.scannedNodesCount} DOM nodes in ${scanResult.durationMs}ms) — تم فتح تحكم الإدارة والمطور.`
      );
      showToast(
        `تم فحص الشاشة أونلاين ومطابقة «${scanResult.code}» بنجاح! تم فتح التحكم الكامل للإدارة والمطور.`
      );

      // Background persistence to API & Firestore without introducing UI delay
      void fetch("/api/extension/pairing/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          code: scanResult.code,
          extensionName: extName,
          browser: verifiedSession.browser,
          domMatched: true,
        }),
      }).catch(() => undefined);

      void updateExtensionPairingStatusInFirestore({
        id: verifiedSession.id,
        extensionName: verifiedSession.extensionName,
        browser: verifiedSession.browser,
        status: "paired",
        feedbackMessage: verifiedSession.feedbackMessage || "",
      }).catch(() => undefined);

      return true;
    },
    [
      pairingSession?.id,
      pairingSession?.createdAt,
      persistPairingSession,
      handleToggleExtensionMode,
      addSystemLog,
      showToast,
    ]
  );

  // External Browser Extension postMessage bridge for Live DOM Code-Scanning
  useEffect(() => {
    const handleExtensionMessage = (event: MessageEvent) => {
      if (event.source !== window || !event.data || typeof event.data !== "object") {
        return;
      }
      const msg = event.data as {
        type?: string;
        code?: string;
        extensionName?: string;
      };
      if (
        msg.type === "IRAQI_CODERS_DOM_PAIR_REQUEST" &&
        typeof msg.code === "string"
      ) {
        void handleScanAndPairFromScreen(
          msg.code,
          msg.extensionName || "إدارة عراقي كودرز"
        ).then((matched) => {
          window.postMessage(
            {
              type: "IRAQI_CODERS_DOM_PAIR_RESULT",
              matched,
              code: msg.code,
              unlocked: matched,
            },
            "*"
          );
        });
      }
    };
    window.addEventListener("message", handleExtensionMessage);
    return () => window.removeEventListener("message", handleExtensionMessage);
  }, [handleScanAndPairFromScreen]);

  const handleConfirmPairingDecision = async (allow: boolean) => {
    if (!pairingSession) return;
    setPairingLoading(true);
    try {
      const res = await fetch("/api/extension/pairing/confirm", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          code: pairingSession.code,
          allow,
        }),
      });
      const data = (await res.json()) as {
        session?: ExtensionPairingSession;
      };

      const nextStatus = allow ? "paired" : "rejected";
      const feedbackMessage =
        data.session?.feedbackMessage ||
        (allow
          ? "تم السماح بالاقتران والتحكم الكامل بالموقع بنجاح! واجهة الإضافة العائمة متصلة الآن."
          : "تم رفض طلب الاقتران والتحكم الكامل بالموقع من قِبل المستخدم.");

      const updatedSession: ExtensionPairingSession = {
        ...(data.session || pairingSession),
        id: pairingSession.id,
        status: nextStatus,
        feedbackMessage,
        updatedAt: new Date().toISOString(),
      };

      persistPairingSession(updatedSession);
      setPairingUnlockedControl(allow);
      handleToggleExtensionMode(allow);

      await updateExtensionPairingStatusInFirestore({
        id: updatedSession.id,
        extensionName: updatedSession.extensionName,
        browser: updatedSession.browser,
        status: nextStatus,
        feedbackMessage,
      }).catch(() => undefined);

      showToast(feedbackMessage);
    } catch {
      const nextStatus = allow ? "paired" : "rejected";
      const feedbackMessage = allow
        ? "تم السماح بالاقتران والتحكم الكامل بالموقع بنجاح!"
        : "تم رفض طلب الاقتران والتحكم الكامل بالموقع.";
      persistPairingSession({
        ...pairingSession,
        status: nextStatus,
        feedbackMessage,
        updatedAt: new Date().toISOString(),
      });
      setPairingUnlockedControl(allow);
      handleToggleExtensionMode(allow);
      showToast(feedbackMessage);
    } finally {
      setPairingLoading(false);
    }
  };

  const handleUnlinkPairing = async () => {
    if (!pairingSession) return;
    try {
      await fetch("/api/extension/pairing/unlink", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code: pairingSession.code }),
      });
      await updateExtensionPairingStatusInFirestore({
        id: pairingSession.id,
        extensionName: pairingSession.extensionName,
        browser: pairingSession.browser,
        status: "revoked",
        feedbackMessage: "تم إلغاء الاقتران وفصل إضافة «إدارة عراقي كودرز».",
      }).catch(() => undefined);
    } catch {
      // Safe fallback
    }
    setPairingUnlockedControl(false);
    persistPairingSession(null);
    showToast("تم فصل اقتران إضافة «إدارة عراقي كودرز».");
  };

  const handleActivateFloatingExtension = (pkg: UnpackedExtensionPackage) => {
    setActiveFloatingExtension(pkg);
    try {
      localStorage.setItem(
        STORAGE_KEYS.FLOATING_EXTENSION_PKG,
        JSON.stringify(pkg)
      );
    } catch {
      // Safe quota fallback
    }
  };

  const handleOpenSecretCodeEditor = (initialFile?: {
    name: string;
    content: string;
  }) => {
    setSecretEditorInitialFile(initialFile || null);
    setSecretCodeEditorOpen(true);
  };

  const handleTriggerAutoInjectCyberBridge = () => {
    const embeddedPkg = buildEmbeddedExtensionPackage();
    handleActivateFloatingExtension(embeddedPkg);
    handleToggleExtensionMode(true);
    setPairingUnlockedControl(true);

    const nowIso = new Date().toISOString();
    const autoPairedSession: ExtensionPairingSession = {
      id: pairingSession?.id || `extpair-embedded-${Date.now()}`,
      code: pairingSession?.code || "IRAQI-CODE-777",
      extensionName: embeddedPkg.extensionName,
      browser: "Embedded 6-File Core v4.0.0",
      status: "paired",
      feedbackMessage:
        "تم الحقن التلقائي عبر نواة الـ 6 ملفات المدمجة (ما بيا حيل) — لوحة Cyber-Admin متصلة وتجاوزت رموز الاقتران!",
      createdAt: pairingSession?.createdAt || nowIso,
      updatedAt: nowIso,
    };
    persistPairingSession(autoPairedSession);
    addSystemLog(
      "AUTH",
      "Iraqi Coders Pro Extension with 6 Files Initialized Successfully."
    );
    showToast(
      "تم تشغيل لوحة Cyber-Admin العائمة مباشرة من الـ 6 ملفات المدمجة بدون تنزيل أو رمز اقتران!"
    );
  };

  const handleCloseFloatingExtension = () => {
    setActiveFloatingExtension(null);
    try {
      localStorage.removeItem(STORAGE_KEYS.FLOATING_EXTENSION_PKG);
    } catch {
      // Safe no-op
    }
    showToast("تم إغلاق واجهة الإضافة العائمة.");
  };

  const teleportToDomId = useCallback((targetId: string) => {
    window.setTimeout(() => {
      const el = document.getElementById(targetId);
      if (!el) return;
      el.scrollIntoView({ behavior: "smooth", block: "center" });
      el.classList.remove("teleport-highlight");
      void el.offsetWidth;
      el.classList.add("teleport-highlight");
      window.setTimeout(() => {
        el.classList.remove("teleport-highlight");
      }, 1600);
    }, 70);
  }, []);

  const handleTeleportFromMenu = (action: TeleportAction) => {
    setCategoriesMenuOpen(false);
    if (action.communityFilter) {
      const targetFilter = action.communityFilter;
      setCommunityFilterReq((prev) => ({
        filter: targetFilter,
        nonce: prev.nonce + 1,
      }));
    }

    if (action.actionType === "store") {
      setCurrencyStoreOpen(true);
      return;
    }
    if (action.actionType === "shop-cart") {
      setShopCartOpen(true);
      return;
    }
    if (action.actionType === "owl") {
      setBrownOwlOpen(true);
      return;
    }
    if (action.actionType === "secret-console") {
      handleOpenSecretConsoleGuarded();
      return;
    }
    if (action.actionType === "secret-code-editor") {
      handleOpenSecretCodeEditor();
      return;
    }
    if (action.actionType === "dev-category") {
      setDrawerScrollTarget("developer-category");
      setAccountSettingsOpen(true);
      return;
    }
    if (action.actionType === "admin-request") {
      setDrawerScrollTarget("admin-request");
      setAccountSettingsOpen(true);
      return;
    }
    if (action.actionType === "ad-dns-settings") {
      setDrawerScrollTarget("ad-dns-settings");
      setAccountSettingsOpen(true);
      return;
    }
    if (action.actionType === "speaker-settings") {
      setDrawerScrollTarget("speaker-settings");
      setAccountSettingsOpen(true);
      return;
    }
    if (action.actionType === "downloads-settings") {
      setDrawerScrollTarget("downloads");
      setAccountSettingsOpen(true);
      return;
    }
    if (action.actionType === "iphone-keyboard") {
      setIphoneKeyboardOpen(true);
      return;
    }
    if (action.actionType === "messages-center") {
      setMessagesModalOpen(true);
      return;
    }
    if (action.actionType === "network-voice") {
      setNetworkVoiceModalOpen(true);
      return;
    }
    if (action.actionType === "admin-rank-miniapp") {
      if (!betaEnabled) handleToggleBeta(true);
      setBetaTabRequest((prev) => ({ tab: "mini-apps", nonce: prev.nonce + 1 }));
      teleportToDomId("beta-hub");
      return;
    }
    if (action.actionType === "lazy-bridge") {
      if (canUseDevTools) {
        handleTriggerAutoInjectCyberBridge();
        return;
      }
      setLazyBridgeOpenNonce((prev) => prev + 1);
    }

    if (action.targetSectionId) {
      teleportToDomId(action.targetSectionId);
    }
  };

  const handleSubmitAdminRoleRequest = async (req: {
    fullName: string;
    email: string;
    requestedRole: "admin" | "supervisor";
    note: string;
  }): Promise<AdminRoleRequest> => {
    const reqId = `rolereq-${Date.now()}`;
    const record: AdminRoleRequest = {
      id: reqId,
      fullName: req.fullName,
      email: req.email,
      requestedRole: req.requestedRole,
      note: req.note,
      status: "pending",
      createdAt: new Date().toISOString(),
    };

    try {
      await fetch("/api/role-requests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(record),
      });
    } catch {
      // Safe fallback
    }

    if (firebaseAuth.currentUser) {
      await createRoleRequestInFirestore({
        id: record.id,
        fullName: record.fullName,
        email: record.email,
        requestedRole: record.requestedRole,
        note: record.note,
      }).catch(() => undefined);
    }

    try {
      const prev = readStorageJson<AdminRoleRequest[]>(
        STORAGE_KEYS.ROLE_REQUESTS,
        []
      );
      localStorage.setItem(
        STORAGE_KEYS.ROLE_REQUESTS,
        JSON.stringify([record, ...prev].slice(0, 10))
      );
    } catch {
      // Safe no-op
    }

    addSystemLog(
      "AUTH",
      `طلب رتبة (${record.requestedRole}) من ${record.fullName} (${record.email})`
    );
    showToast("تم إرسال طلب الرتبة إلى الإدارة بنجاح!");
    return record;
  };

  const handleToggleDesktopMode = (enabled: boolean) => {
    setDesktopMode(enabled);
    try {
      localStorage.setItem(STORAGE_KEYS.DESKTOP_MODE, String(enabled));
    } catch {
      // Safe no-op
    }
    if (user) {
      const updatedUser: UserProfile = {
        ...user,
        desktopMode: enabled,
      };
      setUser(updatedUser);
      localStorage.setItem(
        STORAGE_KEYS.USER_SESSION,
        JSON.stringify(updatedUser)
      );
      if (firebaseAuth.currentUser) {
        void updateUserProfileInFirestore(firebaseAuth.currentUser.uid, {
          displayName: updatedUser.name,
          handle: updatedUser.handle,
          city: updatedUser.city,
          avatarUrl: updatedUser.avatarUrl,
          themeDecoration: updatedUser.themeDecoration,
          desktopMode: enabled,
        }).catch((err) => console.error(err));
      }
    }
    addSystemLog(
      "INFO",
      enabled
        ? "تم تفعيل وضع سطح المكتب وكشف أدوات المطورين"
        : "تم إيقاف وضع سطح المكتب"
    );
    showToast(
      enabled
        ? "تم تفعيل وضع سطح المكتب! خيارات المطورين متاحة الآن."
        : "تم الرجوع إلى العرض القياسي."
    );
  };

  // Multi-Context Header Selector: Mobile or Desktop auto-syncs Extension mode
  const handleSelectDeviceContext = (
    ctx: "mobile" | "desktop" | "extension"
  ) => {
    if (ctx === "mobile") {
      handleToggleDesktopMode(false);
      handleToggleExtensionMode(true);
      showToast("تم اختيار وضع الموبايل مع مزامنة الإضافة تلقائياً!");
      return;
    }
    if (ctx === "desktop") {
      handleToggleDesktopMode(true);
      handleToggleExtensionMode(true);
      showToast("تم اختيار وضع سطح المكتب مع مزامنة الإضافة تلقائياً!");
      return;
    }
    const nextExt = !extensionMode;
    handleToggleExtensionMode(nextExt);
    showToast(
      nextExt
        ? "تم تفعيل سياق الإضافة بنجاح!"
        : "تم إيقاف سياق الإضافة مؤقتاً."
    );
  };

  const handleChangePreviewVersion = (nextVal: number) => {
    const clamped = Math.max(26.5, Math.min(999.9, Number(nextVal.toFixed(1))));
    setPreviewVersion(clamped);
    try {
      localStorage.setItem(STORAGE_KEYS.PREVIEW_VERSION, String(clamped));
    } catch {
      // Safe no-op
    }
  };

  const handleCreateAiUpdate = (item: PlatformAiUpdate) => {
    setLocalAiUpdates((prev) => {
      const next = [item, ...prev];
      try {
        localStorage.setItem(
          STORAGE_KEYS.PLATFORM_UPDATES,
          JSON.stringify(next)
        );
      } catch {
        // Safe no-op
      }
      return next;
    });
    setServerAiUpdates((prev) => [item, ...prev.filter((x) => x.id !== item.id)]);

    void fetch("/api/updates", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ update: item }),
    }).catch(() => undefined);

    if (firebaseAuth.currentUser) {
      void createPlatformUpdateInFirestore(item).catch((err) =>
        console.error(err)
      );
    }
    addSystemLog("INFO", `تم توليد ميزة ذكية جديدة: ${item.title}`);
  };

  const handleToggleAiUpdateVisibility = (
    updateId: string,
    visibility: PlatformUpdateVisibility
  ) => {
    let targetItem: PlatformAiUpdate | undefined;
    setLocalAiUpdates((prev) => {
      const next = prev.map((u) => {
        if (u.id === updateId) {
          targetItem = { ...u, visibility };
          return targetItem;
        }
        return u;
      });
      try {
        localStorage.setItem(
          STORAGE_KEYS.PLATFORM_UPDATES,
          JSON.stringify(next)
        );
      } catch {
        // Safe no-op
      }
      return next;
    });

    setServerAiUpdates((prev) =>
      prev.map((u) => {
        if (u.id === updateId) {
          targetItem = { ...u, visibility };
          return targetItem;
        }
        return u;
      })
    );

    if (targetItem) {
      void fetch("/api/updates", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ update: targetItem }),
      }).catch(() => undefined);
    }

    if (firebaseAuth.currentUser) {
      void updatePlatformUpdateVisibilityInFirestore(updateId, visibility).catch(
        (err) => console.error(err)
      );
    }

    showToast(
      visibility === "public"
        ? "تم تعيين الميزة إلى «عام» — ظاهرة لجميع الزوار الآن!"
        : "تم تعيين الميزة إلى «خاص» — ظاهرة لك وللمنشئ فقط."
    );
  };

  const handleDeleteAiUpdate = (updateId: string) => {
    setLocalAiUpdates((prev) => {
      const next = prev.filter((u) => u.id !== updateId);
      try {
        localStorage.setItem(
          STORAGE_KEYS.PLATFORM_UPDATES,
          JSON.stringify(next)
        );
      } catch {
        // Safe no-op
      }
      return next;
    });
    setServerAiUpdates((prev) => prev.filter((u) => u.id !== updateId));
    void fetch(`/api/updates/${encodeURIComponent(updateId)}`, {
      method: "DELETE",
    }).catch(() => undefined);

    if (firebaseAuth.currentUser) {
      void deletePlatformUpdateInFirestore(updateId).catch((err) =>
        console.error(err)
      );
    }
    showToast("تم حذف التحديث المولّد.");
  };

  const handleExecuteAiUpdateAction = (item: PlatformAiUpdate) => {
    if (item.featureType === "theme") {
      handleChangeTheme("cyber");
    }
    setInjectedBundle({
      id: Date.now(),
      label: item.title,
      html: `<div style="padding:24px;border-radius:16px;background:#0F172A;color:#F8FAFC;font-family:Cairo,sans-serif;border:1px solid #38BDF8">
  <span style="font-size:12px;color:#38BDF8;font-weight:700">${item.badgeText} · v${item.targetVersion}</span>
  <h2 style="margin:8px 0">${item.title}</h2>
  <p style="color:#CBD5E1;line-height:1.7">${item.description}</p>
</div>`,
      css: `body{margin:0;background:#0B0F19;padding:16px;}`,
      js: item.actionPayload || `console.log("Activated: ${item.title}");`,
    });
    showToast(`تم تفعيل «${item.title}» بنجاح!`);
  };

  const handleSaveProfileSettings = (updates: {
    name: string;
    handle: string;
    city: string;
    avatarUrl: string;
    themeDecoration: ThemeDecoration;
    desktopMode: boolean;
  }) => {
    setThemeDecoration(updates.themeDecoration);
    setDesktopMode(updates.desktopMode);
    try {
      localStorage.setItem(
        STORAGE_KEYS.THEME_DECORATION,
        updates.themeDecoration
      );
      localStorage.setItem(
        STORAGE_KEYS.DESKTOP_MODE,
        String(updates.desktopMode)
      );
    } catch {
      // Safe no-op
    }

    if (user) {
      const nextUser: UserProfile = {
        ...user,
        name: updates.name,
        handle: updates.handle,
        city: updates.city,
        avatarUrl: updates.avatarUrl,
        themeDecoration: updates.themeDecoration,
        desktopMode: updates.desktopMode,
      };
      setUser(nextUser);
      localStorage.setItem(STORAGE_KEYS.USER_SESSION, JSON.stringify(nextUser));

      if (firebaseAuth.currentUser) {
        void updateUserProfileInFirestore(firebaseAuth.currentUser.uid, {
          displayName: updates.name,
          handle: updates.handle,
          city: updates.city,
          avatarUrl: updates.avatarUrl,
          themeDecoration: updates.themeDecoration,
          desktopMode: updates.desktopMode,
        }).catch((err) => console.error(err));
      }
    }

    addSystemLog(
      "AUTH",
      `تم تحديث إعدادات الحساب (${updates.name} | ${updates.handle})`
    );
    showToast("تم حفظ إعدادات الحساب والزينة بنجاح!");
  };

  const handleUploadCloudFile = (item: CloudFileItem) => {
    const nextLocal = [item, ...localCloudFiles];
    setLocalCloudFiles(nextLocal);
    try {
      localStorage.setItem(STORAGE_KEYS.CLOUD_FILES, JSON.stringify(nextLocal));
    } catch {
      // Safe no-op
    }

    if (firebaseAuth.currentUser) {
      void createCloudFileInFirestore(item).catch((err) => console.error(err));
    }

    addSystemLog(
      "CLOUD",
      `تم رفع «${item.fileName}» (${item.visibility}) إلى السحابة`
    );
    showToast(
      item.visibility === "public"
        ? `تم نشر «${item.title}» في سحابات الناس!`
        : `تم حفظ «${item.title}» في سحابتك الخاصة.`
    );
  };

  const handleToggleCloudVisibility = (
    fileId: string,
    nextVisibility: CloudVisibility
  ) => {
    const updatedLocal = localCloudFiles.map((f) =>
      f.id === fileId ? { ...f, visibility: nextVisibility } : f
    );
    setLocalCloudFiles(updatedLocal);
    try {
      localStorage.setItem(
        STORAGE_KEYS.CLOUD_FILES,
        JSON.stringify(updatedLocal)
      );
    } catch {
      // Safe no-op
    }

    if (firebaseAuth.currentUser) {
      void updateCloudFileVisibilityInFirestore(fileId, nextVisibility).catch(
        (err) => console.error(err)
      );
    }

    addSystemLog(
      "CLOUD",
      `تحديث خصوصية الملف ${fileId} إلى ${nextVisibility}`
    );
    showToast(
      nextVisibility === "public"
        ? "تم نشر المشروع في سحابات الناس بنجاح!"
        : "تم نقل المشروع إلى سحابتك الخاصة."
    );
  };

  const handleDeleteCloudFile = (fileId: string) => {
    const updatedLocal = localCloudFiles.filter((f) => f.id !== fileId);
    setLocalCloudFiles(updatedLocal);
    try {
      localStorage.setItem(
        STORAGE_KEYS.CLOUD_FILES,
        JSON.stringify(updatedLocal)
      );
    } catch {
      // Safe no-op
    }
    void deleteCloudBinaryBlob(fileId);

    if (firebaseAuth.currentUser) {
      void deleteCloudFileInFirestore(fileId).catch((err) =>
        console.error(err)
      );
    }

    addSystemLog("CLOUD", `تم حذف الملف السحابي ${fileId}`);
    showToast("تم حذف الملف من السحابة.");
  };

  const handleDownloadCloudFile = async (item: CloudFileItem) => {
    const binaryBlob = await getCloudBinaryBlob(item.id);
    const blob = binaryBlob || compileDownloadableBlobForCloudItem(item);
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = item.fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    setCloudDownloadDeltas((prev) => ({
      ...prev,
      [item.id]: (prev[item.id] || 0) + 1,
    }));

    const isRemoteDoc =
      firestorePublicFiles.some((f) => f.id === item.id) ||
      firestorePrivateFiles.some((f) => f.id === item.id);
    if (isRemoteDoc && firebaseAuth.currentUser) {
      void incrementCloudFileDownloadsInFirestore(
        item.id,
        item.downloads + 1
      ).catch((err) => console.error(err));
    }

    addSystemLog("CLOUD", `تم تنزيل الملف السحابي: ${item.fileName}`);
    showToast(`بدأ تنزيل ${item.fileName}`);
  };

  const handleBypassMaintenance = () => {
    setMaintenanceActive(false);
    try {
      localStorage.setItem(STORAGE_KEYS.MAINTENANCE_BYPASSED, "true");
    } catch {
      // Safe no-op
    }
    addSystemLog("INFO", "تم تجاوز شاشة الصيانة والدخول للمنصة");
    showToast("تم فتح منصة عراقي كودرز 26.5!");
  };

  const handleUnlockAdminFromMaintenance = () => {
    setMaintenanceActive(false);
    setAdminUnlocked(true);
    try {
      localStorage.setItem(STORAGE_KEYS.MAINTENANCE_BYPASSED, "true");
      localStorage.setItem(STORAGE_KEYS.ADMIN_AUTH, "true");
    } catch {
      // Safe no-op
    }
    setAdminModalOpen(true);
    addSystemLog("AUTH", "تم فتح صلاحيات المسؤول عبر رمز الصيانة 2019");
    showToast("أهلاً بالمدير! تم فتح لوحة التحكم والموقع.");
  };

  const handleShowMaintenance = () => {
    setMaintenanceActive(true);
    try {
      localStorage.removeItem(STORAGE_KEYS.MAINTENANCE_BYPASSED);
    } catch {
      // Safe no-op
    }
  };

  const handleTriggerComedyBan = () => {
    const lockedEmail = user?.email || "guest-visitor@iraqicoders.iq";
    setComedyModalOpen(false);
    setBannedEmail(lockedEmail);
    try {
      localStorage.setItem(STORAGE_KEYS.COMEDY_BAN, lockedEmail);
    } catch {
      // Safe no-op
    }
    if (firebaseAuth.currentUser) {
      void updateComedyBanInFirestore(firebaseAuth.currentUser.uid, true).catch(
        (err) => console.error(err)
      );
    }
    addSystemLog("INFO", `تم تفعيل حظر الكوميديا للحساب: ${lockedEmail}`);
  };

  const handleApologizeFromBan = () => {
    setBannedEmail("");
    try {
      localStorage.removeItem(STORAGE_KEYS.COMEDY_BAN);
    } catch {
      // Safe no-op
    }
    if (firebaseAuth.currentUser) {
      void updateComedyBanInFirestore(
        firebaseAuth.currentUser.uid,
        false
      ).catch((err) => console.error(err));
    }
    setComedyMode("prank");
    setComedyModalOpen(true);
    showToast("المسامح كريم! نورت عراقي كودرز من جديد.");
  };

  const handleBecomeDeveloper = () => {
    setStoredRole("developer");
    try {
      localStorage.setItem(STORAGE_KEYS.USER_ROLE, "developer");
    } catch {
      // Safe no-op
    }
    if (user) {
      const updatedUser: UserProfile = {
        ...user,
        role: "developer",
      };
      setUser(updatedUser);
      localStorage.setItem(
        STORAGE_KEYS.USER_SESSION,
        JSON.stringify(updatedUser)
      );
      if (firebaseAuth.currentUser) {
        void upgradeUserToDeveloperInFirestore(
          firebaseAuth.currentUser.uid
        ).catch((err) => console.error(err));
      }
    }
    addSystemLog("AUTH", "تم ترقية الصلاحية إلى مطور عبر خيار «كن مطور»");
    showToast("مبروك! أصبحت الآن مطوراً في عراقي كودرز وتم فتح أدوات المطورين.");
  };

  const handleOpenSecretConsoleGuarded = () => {
    if (!canUseDevTools) {
      showToast(
        "استوديو المطورين (/) يتطلب شارة المطور — أكمل مهام «فئة المطور» عبر صورتك الشخصية!"
      );
      setDrawerScrollTarget("developer-category");
      setAccountSettingsOpen(true);
      return;
    }
    setSecretConsoleOpen(true);
  };

  const persistShopCart = (next: ShopCartItem[]) => {
    setShopCart(next);
    try {
      localStorage.setItem(STORAGE_KEYS.SHOP_CART, JSON.stringify(next));
    } catch {
      // Safe no-op
    }
  };

  const handleAddToShopCart = (product: ShopProduct, openDrawer = false) => {
    const existing = shopCart.find((c) => c.productId === product.id);
    const next = existing
      ? shopCart.map((c) =>
          c.productId === product.id ? { ...c, quantity: c.quantity + 1 } : c
        )
      : [...shopCart, { productId: product.id, quantity: 1 }];
    persistShopCart(next);
    if (openDrawer) {
      setShopCartOpen(true);
    } else {
      showToast(`تمت إضافة «${product.title}» إلى سلة المشتريات.`);
    }
  };

  const handleUpdateShopQuantity = (productId: string, delta: number) => {
    const next = shopCart
      .map((item) =>
        item.productId === productId
          ? { ...item, quantity: item.quantity + delta }
          : item
      )
      .filter((item) => item.quantity > 0);
    persistShopCart(next);
  };

  const handleRemoveFromShopCart = (productId: string) => {
    persistShopCart(shopCart.filter((item) => item.productId !== productId));
  };

  const handleClearShopCart = () => {
    persistShopCart([]);
  };

  const handleToggleDnsAdBlock = (enabled: boolean) => {
    setDnsAdBlockEnabled(enabled);
    try {
      localStorage.setItem(STORAGE_KEYS.AD_DNS_ENABLED, String(enabled));
    } catch {
      // Safe no-op
    }
    addSystemLog(
      "INFO",
      enabled
        ? "تم تفعيل وضع DNS لحجب الإعلانات من إعدادات الموقع"
        : "تم إيقاف وضع DNS لحجب الإعلانات"
    );
    showToast(
      enabled
        ? "تم تفعيل وضع DNS — تم إخفاء جميع الإعلانات فوراً!"
        : "تم إيقاف وضع DNS الخاص بالإعلانات."
    );
  };

  useEffect(() => {
    if (typeof document === "undefined") return;
    document.documentElement.classList.toggle(
      "iphone-font-mode",
      iphoneFontEnabled
    );
    try {
      localStorage.setItem(
        STORAGE_KEYS.IPHONE_PACK_ENABLED,
        String(iphoneFontEnabled)
      );
    } catch {
      // Safe no-op
    }
  }, [iphoneFontEnabled]);

  const [siteArchiveMeta, setSiteArchiveMeta] = useState<{
    downloadUrl: string;
    sizeBytes: number;
    fileCount: number;
  } | null>(null);
  const [siteArchiveProgress, setSiteArchiveProgress] = useState<{
    active: boolean;
    percent: number;
    loadedMb: string;
    totalMb: string;
  } | null>(null);

  const canExportSiteZip = userRole === "admin" || isAdminPrivileged;

  const prepareSiteArchiveTicket = useCallback(async () => {
    if (!canExportSiteZip) return null;
    try {
      const resp = await fetch("/api/export-site-zip/prepare", {
        method: "POST",
        headers: {
          "x-user-role": userRole,
          "x-admin-unlocked": String(adminUnlocked),
          "x-admin-email": user?.email || "",
        },
      });
      if (!resp.ok) return null;
      const data = (await resp.json()) as {
        ok?: boolean;
        downloadUrl?: string;
        sizeBytes?: number;
        fileCount?: number;
      };
      if (data.ok && data.downloadUrl) {
        const meta = {
          downloadUrl: data.downloadUrl,
          sizeBytes: Number(data.sizeBytes || 0),
          fileCount: Number(data.fileCount || 0),
        };
        setSiteArchiveMeta(meta);
        return meta;
      }
    } catch {
      // Safe fallback handled on manual click
    }
    return null;
  }, [canExportSiteZip, userRole, adminUnlocked, user?.email]);

  useEffect(() => {
    if (!canExportSiteZip) {
      setSiteArchiveMeta(null);
      return;
    }
    void prepareSiteArchiveTicket();
    const timer = window.setInterval(() => {
      void prepareSiteArchiveTicket();
    }, 10 * 60 * 1000);
    return () => window.clearInterval(timer);
  }, [canExportSiteZip, prepareSiteArchiveTicket]);

  const handleDownloadSiteArchive = useCallback(async () => {
    if (!canExportSiteZip) {
      showToast("هذا الخيار مخصص للمسؤولين فقط.");
      return;
    }
    setSiteArchiveProgress({
      active: true,
      percent: 5,
      loadedMb: "0.0",
      totalMb: siteArchiveMeta
        ? (siteArchiveMeta.sizeBytes / (1024 * 1024)).toFixed(1)
        : "...",
    });
    showToast("جاري تحميل ملف الموقع المضغوط (بداخله جميع ملفات الموقع)...");
    try {
      const meta = siteArchiveMeta || (await prepareSiteArchiveTicket());
      const targetUrl = meta?.downloadUrl || "/api/export-site-zip";
      const resp = await fetch(targetUrl, {
        method: "GET",
        headers: {
          "x-user-role": userRole,
          "x-admin-unlocked": String(adminUnlocked),
          "x-admin-email": user?.email || "",
        },
      });
      if (!resp.ok) {
        const errBody = (await resp.json().catch(() => null)) as
          | { error?: string }
          | null;
        setSiteArchiveProgress(null);
        showToast(
          errBody?.error || "تعذر تنزيل ملف الموقع (تأكد من صلاحية المسؤول)."
        );
        return;
      }

      const contentLengthHeader = Number(resp.headers.get("Content-Length") || 0);
      const totalBytes = contentLengthHeader || meta?.sizeBytes || 0;
      const totalMbStr =
        totalBytes > 0 ? (totalBytes / (1024 * 1024)).toFixed(1) : "...";

      let blob: Blob;
      if (resp.body && typeof resp.body.getReader === "function") {
        const reader = resp.body.getReader();
        const chunks: Uint8Array[] = [];
        let received = 0;
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          if (value) {
            chunks.push(value);
            received += value.length;
            const pct =
              totalBytes > 0
                ? Math.min(99, Math.round((received / totalBytes) * 100))
                : 50;
            setSiteArchiveProgress({
              active: true,
              percent: pct,
              loadedMb: (received / (1024 * 1024)).toFixed(1),
              totalMb: totalMbStr,
            });
          }
        }
        const blobParts = chunks.map((chunk) => {
          const copy = new Uint8Array(chunk.byteLength);
          copy.set(chunk);
          return copy.buffer;
        });
        blob = new Blob(blobParts, { type: "application/zip" });
      } else {
        blob = await resp.blob();
      }

      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "iraqi-coders-website-complete.zip";
      a.rel = "noopener";
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 60_000);
      setSiteArchiveProgress({
        active: false,
        percent: 100,
        loadedMb: (blob.size / (1024 * 1024)).toFixed(1),
        totalMb: (blob.size / (1024 * 1024)).toFixed(1),
      });
      showToast("تم تنزيل ملف الموقع المضغوط بجميع الملفات بنجاح 100%!");
    } catch {
      setSiteArchiveProgress(null);
      showToast("حدث خطأ أثناء تحميل ملف الموقع المضغوط. جرّب رابط التنزيل المباشر.");
    }
  }, [
    canExportSiteZip,
    siteArchiveMeta,
    prepareSiteArchiveTicket,
    userRole,
    adminUnlocked,
    user?.email,
    showToast,
  ]);

  const handleSubmitShopOrder = (order: ShopOrderRecord) => {
    const next = [order, ...shopOrders].slice(0, 30);
    setShopOrders(next);
    try {
      localStorage.setItem(STORAGE_KEYS.SHOP_ORDERS, JSON.stringify(next));
    } catch {
      // Safe no-op
    }
    const includesVipUpgrade = order.items.some((it) =>
      VIP_PAID_PRODUCT_IDS.includes(
        it.productId as (typeof VIP_PAID_PRODUCT_IDS)[number]
      )
    );
    if (includesVipUpgrade) {
      setVipPaidActive(true);
      try {
        localStorage.setItem(STORAGE_KEYS.VIP_PAID_ACTIVE, "true");
      } catch {
        // Safe no-op
      }
      addSystemLog("INFO", "تم تفعيل اشتراك VIP المدفوع وإخفاء الإعلانات");
    }
    addSystemLog(
      "INFO",
      `تم تأكيد طلب شراء جديد (${order.id}) بمبلغ $${order.totalUsd}`
    );
    showToast(
      order.signedInvoiceVerified
        ? `تمت الشراء بنجاح! رقم الفاتورة: ${order.id}`
        : includesVipUpgrade
        ? `تم تأكيد الطلب ${order.id} وتفعيل VIP لإخفاء الإعلانات فوراً!`
        : `تم تأكيد الطلب ${order.id} بنجاح!`
    );
  };

  const handlePublishShopProduct = (product: ShopProduct) => {
    if (!canPublishShopProduct(userRole)) {
      showToast(
        "عذراً، نشر المنتجات متاح حصرياً لأصحاب رتبة المطور أو المشرف أو المسؤول."
      );
      return;
    }

    setCustomShopProducts((prev) => {
      const next = [product, ...prev.filter((p) => p.id !== product.id)].slice(
        0,
        SHOP_PUBLISH_SETTINGS.maxCustomProducts
      );
      try {
        localStorage.setItem(
          STORAGE_KEYS.SHOP_CUSTOM_PRODUCTS,
          JSON.stringify(next)
        );
      } catch {
        // Safe no-op
      }
      return next;
    });

    void fetch("/api/shop-products", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        publisherRole: userRole,
        product,
      }),
    }).catch(() => undefined);

    addSystemLog(
      "INFO",
      `تم نشر منتج جديد في المتجر (${product.title}) بواسطة ${product.publishedBy || userRole}`
    );
    showToast(`تم حفظ ونشر «${product.title}» في المتجر بنجاح!`);
  };

  const handleDeleteCustomShopProduct = (productId: string) => {
    if (!canPublishShopProduct(userRole)) {
      showToast("صلاحية غير كافية لحذف المنتجات المنشورة.");
      return;
    }

    setCustomShopProducts((prev) => {
      const next = prev.filter((p) => p.id !== productId);
      try {
        localStorage.setItem(
          STORAGE_KEYS.SHOP_CUSTOM_PRODUCTS,
          JSON.stringify(next)
        );
      } catch {
        // Safe no-op
      }
      return next;
    });

    void fetch(`/api/shop-products/${encodeURIComponent(productId)}`, {
      method: "DELETE",
      headers: { "x-user-role": userRole },
    }).catch(() => undefined);

    showToast("تم حذف المنتج المنشور من المتجر.");
  };

  const handleInjectCodeToPlayground = (bundle: GeneratedCodeBundle) => {
    setInjectedBundle(bundle);
    handleCodeRun();
    showToast(`تم لصق «${bundle.label}» في محرر الكود المباشر!`);
    const el = document.getElementById("playground");
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  };

  const handleLogin = (profile: UserProfile) => {
    const isMobileScreen =
      typeof window !== "undefined" && window.innerWidth < 1024;
    const nextDesktopMode = isMobileScreen
      ? desktopMode
      : profile.desktopMode;
    const resolvedRole: UserRole =
      isMasterAdminIdentity(profile, firebaseAuth.currentUser) ||
      profile.role === "admin"
        ? "admin"
        : profile.role === "director" || storedRole === "director"
        ? "director"
        : profile.role === "moderator" || storedRole === "moderator"
        ? "moderator"
        : profile.role === "developer" || storedRole === "developer"
        ? "developer"
        : "user";
    const finalProfile = {
      ...profile,
      role: resolvedRole,
      desktopMode: nextDesktopMode,
    };
    setUser(finalProfile);
    setStoredRole(resolvedRole);
    setThemeDecoration(finalProfile.themeDecoration);
    setDesktopMode(nextDesktopMode);
    localStorage.setItem(STORAGE_KEYS.USER_ROLE, resolvedRole);
    localStorage.setItem(STORAGE_KEYS.USER_SESSION, JSON.stringify(finalProfile));
    addSystemLog("AUTH", `تسجيل دخول ناجح: ${finalProfile.name}`);
    showToast(`مرحباً بك يا ${finalProfile.name} في عراقي كودرز!`);
  };

  const handleLogout = async () => {
    try {
      await signOut(firebaseAuth);
    } catch {
      // Safe fallback
    }
    setGmailAccessToken(null);
    setUser(null);
    setStoredRole("user");
    setCloudPosts([]);
    setFirestorePrivateFiles([]);
    localStorage.removeItem(STORAGE_KEYS.USER_SESSION);
    localStorage.removeItem(STORAGE_KEYS.USER_ROLE);
    addSystemLog("AUTH", "تم تسجيل الخروج من الحساب");
    showToast("تم تسجيل الخروج بنجاح.");
  };

  const handleUnlockAdmin = () => {
    setAdminUnlocked(true);
    localStorage.setItem(STORAGE_KEYS.ADMIN_AUTH, "true");
    addSystemLog("AUTH", "تم فتح لوحة تحكم المسؤول");
  };

  const handleLockAdmin = () => {
    setAdminUnlocked(false);
    localStorage.removeItem(STORAGE_KEYS.ADMIN_AUTH);
  };

  const handleSaveAssistantConfig = (url: string, title: string) => {
    const cleanUrl = url.trim() || "#assistant";
    setAssistantUrl(cleanUrl);
    setAssistantTitle(title);
    localStorage.setItem(STORAGE_KEYS.ASSISTANT_URL, cleanUrl);
    localStorage.setItem(STORAGE_KEYS.ASSISTANT_TITLE, title);

    if (firebaseAuth.currentUser) {
      void savePlatformSettingsInFirestore(cleanUrl, title).catch((err) =>
        console.error(err)
      );
    }
    showToast("تم حفظ إعدادات المساعد بنجاح.");
  };

  const handleDownloadProject = (project: ProjectItem) => {
    const blob = new Blob([project.codePreview], {
      type: "text/plain;charset=utf-8",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = project.fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    setDownloadDeltas((prev) => {
      const updated = { ...prev, [project.id]: (prev[project.id] || 0) + 1 };
      localStorage.setItem(
        STORAGE_KEYS.PROJECT_DOWNLOADS,
        JSON.stringify(updated)
      );
      return updated;
    });

    if (selectedProject && selectedProject.id === project.id) {
      setSelectedProject({ ...project, downloads: project.downloads + 1 });
    }

    showToast(`بدأ تنزيل الملف: ${project.fileName}`);
  };

  const handleCodeRun = () => {
    setCodeRunsCount((prev) => {
      const next = prev + 1;
      localStorage.setItem(STORAGE_KEYS.CODE_RUNS, String(next));
      return next;
    });
    addSystemLog("INFO", "تم تشغيل كود في محرر الكود المباشر");
  };

  const handleCreatePost = (
    title: string,
    content: string,
    topic: PostTopic
  ) => {
    const postId = `post-${Date.now()}`;
    const newPost: ForumPost = {
      id: postId,
      title,
      content,
      topic,
      topicLabel: TOPIC_LABELS[topic],
      authorName: user?.name || "مطور ضيف",
      authorCity: user?.city || "العراق",
      authorAvatar: user?.avatarUrl || DEFAULT_DEVELOPER_AVATAR,
      createdAt: "الآن",
      likes: 1,
      likedByUser: true,
      replies: [],
    };
    const updated = [newPost, ...localPosts];
    setLocalPosts(updated);
    localStorage.setItem(STORAGE_KEYS.FORUM_POSTS, JSON.stringify(updated));

    if (firebaseAuth.currentUser) {
      void createForumPostInFirestore({
        postId,
        title,
        content,
        topic,
        topicLabel: TOPIC_LABELS[topic],
        authorCity: user?.city || "العراق",
      }).catch((err) => console.error(err));
    }

    addSystemLog("FIRESTORE", `نشر موضوع جديد في المنتدى: ${title}`);
    showToast("تم نشر موضوعك في منتدى المطورين.");
  };

  const handleToggleLike = (postId: string) => {
    const updated = localPosts.map((post) => {
      if (post.id !== postId) return post;
      const liked = !post.likedByUser;
      return {
        ...post,
        likedByUser: liked,
        likes: liked ? post.likes + 1 : Math.max(0, post.likes - 1),
      };
    });
    setLocalPosts(updated);
    localStorage.setItem(STORAGE_KEYS.FORUM_POSTS, JSON.stringify(updated));
  };

  const handleAddReply = (postId: string, content: string) => {
    const updated = localPosts.map((post) => {
      if (post.id !== postId) return post;
      return {
        ...post,
        replies: [
          ...post.replies,
          {
            id: `rep-${Date.now()}`,
            authorName: user?.name || "مطور زائر",
            authorAvatar: user?.avatarUrl || DEFAULT_DEVELOPER_AVATAR,
            content,
            createdAt: "الآن",
          },
        ],
      };
    });
    setLocalPosts(updated);
    localStorage.setItem(STORAGE_KEYS.FORUM_POSTS, JSON.stringify(updated));
    showToast("تمت إضافة ردك بنجاح.");
  };

  const handleDeletePost = (postId: string) => {
    const updated = localPosts.filter((p) => p.id !== postId);
    setLocalPosts(updated);
    localStorage.setItem(STORAGE_KEYS.FORUM_POSTS, JSON.stringify(updated));

    if (firebaseAuth.currentUser) {
      void deleteForumPostInFirestore(postId).catch((err) =>
        console.error(err)
      );
    }
    showToast("تم حذف الموضوع من المنتدى.");
  };

  const handleResetCommunity = () => {
    setLocalPosts(INITIAL_FORUM_POSTS);
    localStorage.setItem(
      STORAGE_KEYS.FORUM_POSTS,
      JSON.stringify(INITIAL_FORUM_POSTS)
    );
    showToast("تمت استعادة المواضيع الافتراضية.");
  };

  const handleSkipEduRobotForever = () => {
    stopArabicSpeech();
    setEduRobotSkipped(true);
    try {
      localStorage.setItem(STORAGE_KEYS.EDU_ROBOT_SKIPPED, "true");
    } catch {
      // Safe no-op
    }
    teleportToDomId("hero");
    showToast("تم إخفاء المساعد التعليمي بشكل دائم والعودة للواجهة الرئيسية.");
  };

  const handleToggleSpeaker = (enabled: boolean) => {
    if (!enabled) stopArabicSpeech();
    setSpeakerEnabled(enabled);
    try {
      localStorage.setItem(STORAGE_KEYS.SPEAKER_ENABLED, String(enabled));
    } catch {
      // Safe no-op
    }
    showToast(
      enabled
        ? "تم تفعيل زر السماعة — اضغط على أي نص أو زر لقراءته بالعربية الفصحى."
        : "تم إيقاف زر السماعة الفصحى."
    );
  };

  const handleToggleBeta = (enabled: boolean) => {
    setBetaEnabled(enabled);
    try {
      localStorage.setItem(STORAGE_KEYS.BETA_MODE, String(enabled));
    } catch {
      // Safe no-op
    }
    showToast(
      enabled
        ? "تم تفعيل النسخة التجريبية! (مدرسة ميسون + ببجي + المبرمج + عالم الخيال)"
        : "تم الرجوع للنسخة الرئيسية."
    );
  };

  const handleToggleGoogleBetaJoined = (joined: boolean) => {
    setGoogleBetaJoined(joined);
    try {
      localStorage.setItem(STORAGE_KEYS.GOOGLE_BETA_JOINED, String(joined));
    } catch {
      // Safe no-op
    }
    if (joined) {
      handleToggleBeta(true);
    }
  };

  const handleChangeProgLang = (lang: ProgrammingLanguageId) => {
    setActiveProgLang(lang);
    try {
      localStorage.setItem(STORAGE_KEYS.BETA_PROG_LANG, lang);
    } catch {
      // Safe no-op
    }
    addSystemLog("INFO", `تم تبديل لغة المحرك في إعدادات بلس إلى: ${lang}`);
  };

  const handleToggleFantasyMode = (enabled: boolean) => {
    handleChangeTheme(enabled ? "fantasy" : "default");
    try {
      localStorage.setItem(STORAGE_KEYS.FANTASY_WORLD, String(enabled));
    } catch {
      // Safe no-op
    }
    showToast(
      enabled
        ? "مرحباً بك في عالم الخيال! الحلويات والغيوم المضيئة تغمر المنصة ✨"
        : "تم الخروج من عالم الخيال."
    );
  };

  const handleCreateChallenge = (challenge: ChallengeItem) => {
    setChallenges((prev) => {
      const next = [challenge, ...prev];
      try {
        localStorage.setItem(STORAGE_KEYS.CHALLENGES, JSON.stringify(next));
      } catch {
        // Safe no-op
      }
      return next;
    });
    void fetch("/api/challenges", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ role: userRole, challenge }),
    }).catch(() => undefined);
  };

  const handleAddChallengeComment = (challengeId: string, content: string) => {
    const comment: ChallengeComment = {
      id: `cmt-${Date.now()}`,
      authorName: user?.name || "زائر عراقي كودرز",
      authorRole: userRole,
      content,
      createdAt: "الآن",
    };
    setChallenges((prev) => {
      const next = prev.map((c) =>
        c.id === challengeId
          ? { ...c, comments: [...c.comments, comment] }
          : c
      );
      try {
        localStorage.setItem(STORAGE_KEYS.CHALLENGES, JSON.stringify(next));
      } catch {
        // Safe no-op
      }
      return next;
    });
    void fetch(`/api/challenges/${encodeURIComponent(challengeId)}/comments`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ comment }),
    }).catch(() => undefined);
    showToast("تمت إضافة تعليقك على التحدي!");
  };

  const handlePublishMiniProject = (proj: PublishedMiniProject) => {
    setPublishedMiniApps((prev) => {
      const next = [proj, ...prev];
      try {
        localStorage.setItem(STORAGE_KEYS.PUBLISHED_MINI_APPS, JSON.stringify(next));
      } catch {
        // Safe no-op
      }
      return next;
    });
    void fetch("/api/beta-projects", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ role: userRole, project: proj }),
    }).catch(() => undefined);
  };

  const handleAddSchoolUpdate = (upd: SchoolUpdateItem) => {
    setSchoolUpdates((prev) => {
      const next = [upd, ...prev];
      try {
        localStorage.setItem(STORAGE_KEYS.SCHOOL_UPDATES, JSON.stringify(next));
      } catch {
        // Safe no-op
      }
      return next;
    });
    void fetch("/api/school-updates", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ update: upd }),
    }).catch(() => undefined);
  };

  // Pillar 8 & 9 Computed Values & Handlers
  const myNationality = useMemo(() => {
    const uid = user?.id || "";
    const handle = (user?.handle || "").toLowerCase();
    const email = (user?.email || "").toLowerCase();
    return (
      nationalities.find(
        (n) =>
          (uid && n.ownerUid === uid) ||
          (handle && n.ownerHandle.toLowerCase() === handle) ||
          (email && n.ownerEmail.toLowerCase() === email) ||
          (!uid && n.id.startsWith("nat-local-"))
      ) || null
    );
  }, [nationalities, user?.id, user?.handle, user?.email]);

  const unreadMessagesCount = useMemo(
    () => platformMessages.filter((m) => !m.read).length,
    [platformMessages]
  );

  const handleToggleGmailAlerts = (enabled: boolean) => {
    setGmailAlertsEnabled(enabled);
    try {
      localStorage.setItem(STORAGE_KEYS.GMAIL_ALERTS_ENABLED, String(enabled));
    } catch {
      // Safe no-op
    }
  };

  const handleUpsertNationality = useCallback(async (card: CustomNationalityCard) => {
    setNationalities((prev) => {
      const next = [card, ...prev.filter((c) => c.id !== card.id)];
      try {
        localStorage.setItem(STORAGE_KEYS.NATIONALITIES, JSON.stringify(next));
      } catch {
        // Safe no-op
      }
      return next;
    });

    void fetch("/api/nationalities", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ card }),
    }).catch(() => undefined);

    if (firebaseAuth.currentUser) {
      await saveNationalityCardInFirestore(card).catch(() => undefined);
    }
    addSystemLog("INFO", `تم إصدار الجنسية الرقمية: ${card.fullName} (${card.nationalityCode})`);
    showToast(`تم إنشاء جنسيتك «${card.nationalityCode}» بنجاح بواجهتين!`);
  }, [addSystemLog, showToast]);

  const handleNationalityLoadedFromServer = useCallback((card: CustomNationalityCard) => {
    setNationalities((prev) => {
      const next = [card, ...prev.filter((c) => c.id !== card.id)];
      try {
        localStorage.setItem(STORAGE_KEYS.NATIONALITIES, JSON.stringify(next));
      } catch {
        // Safe no-op
      }
      return next;
    });
  }, []);

  const handleAddPlatformMessage = useCallback(
    (msg: PlatformMessageRecord) => {
      setPlatformMessages((prev) => {
        const next = [msg, ...prev.filter((m) => m.id !== msg.id)].slice(0, 120);
        try {
          localStorage.setItem(STORAGE_KEYS.PLATFORM_MESSAGES, JSON.stringify(next));
        } catch {
          // Safe no-op
        }
        return next;
      });
      void fetch("/api/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: msg }),
      }).catch(() => undefined);

      if (firebaseAuth.currentUser) {
        void savePlatformMessageInFirestore(msg).catch(() => undefined);
      }
    },
    []
  );

  const handleConfirmSendRealGmail = async (req: GmailConfirmRequest) => {
    const token = getGmailAccessToken();
    if (!token) {
      throw new Error("يرجى تفويض صلاحية Gmail من Google أولاً.");
    }
    await sendRealGmailMessage({
      to: req.to,
      subject: req.subject,
      htmlBody: req.htmlBody,
    });
    setGmailConfirmRequest(null);
    addSystemLog("INFO", `تم إرسال إشعار Gmail إلى ${req.to}: ${req.subject}`);
    showToast(`تم إرسال الإشعار إلى تطبيق Gmail (${req.to}) بنجاح!`);
  };

  const handleAdultVerified = (methodLabel: string) => {
    setAgeStatus("adult_verified");
    setKidsMode(false);
    try {
      localStorage.setItem(STORAGE_KEYS.AGE_STATUS, "adult_verified");
      localStorage.setItem(STORAGE_KEYS.KIDS_MODE, "false");
    } catch {
      // Safe no-op
    }
    addSystemLog("AUTH", `تم إتمام التحقق من العمر (12+) عبر: ${methodLabel}`);
    showToast(`تم التحقق بنجاح (${methodLabel}) — أهلاً بك في عراقي كودرز!`);
  };

  const handleChooseKidMode = () => {
    setKidsTransitionState("entering-kids");
    window.setTimeout(() => {
      setAgeStatus("kids_mode");
      setKidsMode(true);
      try {
        localStorage.setItem(STORAGE_KEYS.AGE_STATUS, "kids_mode");
        localStorage.setItem(STORAGE_KEYS.KIDS_MODE, "true");
      } catch {
        // Safe no-op
      }
      setKidsTransitionState("none");
      showToast("أهلاً بك في عراقي كيدز! تجربة ممتعة وآمنة 🎈");
    }, 650);
  };

  const handleExitKidsMode = () => {
    setKidsTransitionState("exiting-kids");
    window.setTimeout(() => {
      setAgeStatus("adult_bypass");
      setKidsMode(false);
      try {
        localStorage.setItem(STORAGE_KEYS.AGE_STATUS, "adult_bypass");
        localStorage.setItem(STORAGE_KEYS.KIDS_MODE, "false");
      } catch {
        // Safe no-op
      }
      setKidsTransitionState("none");
      showToast("تم الانتقال بسلاسة إلى النسخة العالمية المعتادة من عراقي كودرز!");
    }, 650);
  };

  const roleGreeting = getGreetingForRole(userRole);

  return (
    <div
      className={`desktop-viewport-shell min-h-screen bg-[#0B0F19] text-slate-100 flex flex-col relative ${
        desktopMode ? "desktop-mode-active" : ""
      }`}
    >
      <ThemeDecorationLayer theme={themeDecoration} />

      <Navbar
        user={user}
        userRole={userRole}
        desktopMode={desktopMode}
        extensionMode={extensionMode}
        displayVersion={displayVersion}
        coins={economy.coins}
        isAdminPrivileged={isAdminPrivileged}
        equippedSkin={economy.equippedSkin}
        hasVipBadge={isVipCoins || vipPaidActive}
        onSelectDeviceContext={handleSelectDeviceContext}
        onOpenAuth={() => setAuthModalOpen(true)}
        onOpenAccountSettings={() => {
          setDrawerScrollTarget(null);
          setAccountSettingsOpen(true);
        }}
        onOpenCategoriesMenu={() => setCategoriesMenuOpen(true)}
        onLogout={handleLogout}
        onOpenBrownOwl={() => setBrownOwlOpen(true)}
        onOpenSecretConsole={handleOpenSecretConsoleGuarded}
        onOpenCurrencyStore={() => setCurrencyStoreOpen(true)}
        cartItemCount={shopCartTotalCount}
        betaEnabled={betaEnabled}
        fantasyMode={fantasyMode}
        kidsMode={kidsMode}
        unreadMessagesCount={unreadMessagesCount}
        onToggleBeta={() => {
          const next = !betaEnabled;
          handleToggleBeta(next);
          if (next) teleportToDomId("beta-hub");
        }}
        onOpenShopCart={() => setShopCartOpen(true)}
        onOpenMessages={() => {
          setMessagesModalOpen(true);
          if (gmailAlertsEnabled === false) {
            handleToggleGmailAlerts(true);
          }
        }}
        onOpenNetworkVoice={() => setNetworkVoiceModalOpen(true)}
        iphoneKeyboardOpen={iphoneKeyboardOpen}
        onToggleIPhoneKeyboard={() => setIphoneKeyboardOpen((v) => !v)}
      />

      {!kidsMode &&
        activeFloatingExtension &&
        (!maintenanceActive || isMasterAdmin) &&
        !bannedEmail && (
          <FloatingExtensionBridgeOverlay
            pkg={activeFloatingExtension}
            pairingSession={pairingSession}
            user={user}
            userRole={userRole}
            isAdminPrivileged={isAdminPrivileged}
            isMasterAdmin={isMasterAdmin}
            themeDecoration={themeDecoration}
            previewVersion={previewVersion}
            desktopMode={desktopMode}
            extensionMode={extensionMode}
            onChangeTheme={handleChangeTheme}
            onChangePreviewVersion={handleChangePreviewVersion}
            onToggleDesktopMode={handleToggleDesktopMode}
            onToggleExtensionMode={handleToggleExtensionMode}
            onOpenSecretCodeEditor={handleOpenSecretCodeEditor}
            onOpenSecretStudio={handleOpenSecretConsoleGuarded}
            onOpenDeveloperOptions={() => setDeveloperOptionsOpen(true)}
            onOpenAdminModal={() => setAdminModalOpen(true)}
            onScanAndPairFromScreen={handleScanAndPairFromScreen}
            onClose={handleCloseFloatingExtension}
            onTeleport={(targetId) => teleportToDomId(targetId)}
            onShowToast={showToast}
          />
        )}

      <main className="relative z-20 flex-1">
        {kidsMode ? (
          <IraqiKidsView
            onOpenSettingsExitHint={() => {
              setDrawerScrollTarget(null);
              setAccountSettingsOpen(true);
            }}
          />
        ) : (
          <>
            {/* Sleeping Robot on Mini Bed at Top of Page */}
            <SleepingRobotTopWidget onJumpToSection={teleportToDomId} />

            {/* المستشار العام Role-Based Greeting Banner */}
            <div className="mx-auto max-w-7xl px-4 pt-3 sm:px-6 lg:px-8">
              <div className="flex flex-wrap items-center justify-between gap-2 rounded-2xl border border-emerald-400/35 bg-gradient-to-l from-emerald-950/60 via-[#0E1629] to-violet-950/50 px-4 py-2.5 shadow-lg">
                <div className="flex items-center gap-2.5">
                  <span className="rounded-lg border border-emerald-400/40 bg-emerald-500/20 px-2 py-0.5 text-[11px] font-extrabold text-emerald-300">
                    {roleGreeting.badgeText}
                  </span>
                  <span className="text-sm sm:text-base font-extrabold text-white">
                    {roleGreeting.title}
                  </span>
                  <span className="hidden md:inline text-xs text-slate-300">
                    — {roleGreeting.advisorTitle}
                  </span>
                </div>
                <div className="flex items-center gap-2 text-[11px] font-bold">
                  <button
                    type="button"
                    onClick={() => teleportToDomId("challenges")}
                    className="rounded-lg border border-amber-400/40 bg-amber-500/15 px-2.5 py-1 text-amber-200 hover:bg-amber-500/25 cursor-pointer"
                  >
                    التحديات
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      if (!betaEnabled) handleToggleBeta(true);
                      teleportToDomId("beta-hub");
                    }}
                    className="rounded-lg border border-fuchsia-400/40 bg-fuchsia-500/15 px-2.5 py-1 text-fuchsia-200 hover:bg-fuchsia-500/25 cursor-pointer"
                  >
                    {betaEnabled ? "قسم التجربة" : "تفعيل التجربة"}
                  </button>
                </div>
              </div>
            </div>

            <WorkerCelebrationHeader
              displayVersion={displayVersion}
              extensionMode={extensionMode}
              updates={visiblePlatformUpdates}
              currentUserId={user?.id || "local-admin-dev"}
              isAdminPrivileged={isAdminPrivileged}
              onToggleVisibility={handleToggleAiUpdateVisibility}
              onExecuteUpdateAction={handleExecuteAiUpdateAction}
              onDeleteUpdate={handleDeleteAiUpdate}
              onJumpToPairing={() => teleportToDomId("extension-pairing")}
            />

            <HeroSection
              displayVersion={displayVersion}
              projectCount={projectsWithLiveDownloads.length}
              postCount={posts.length}
              codeRunsCount={codeRunsCount}
              totalDownloads={totalDownloads}
              fantasyMode={fantasyMode}
              betaEnabled={betaEnabled}
              activeProgLang={activeProgLang}
            />

            <AdBannerSlot
              placement="top-leaderboard"
              adVisibility={adVisibility}
              onOpenDnsSettings={() => {
                setDrawerScrollTarget("ad-dns-settings");
                setAccountSettingsOpen(true);
              }}
              onOpenVipUpgrade={() => teleportToDomId("shop")}
            />

            <ExtensionAndUpdatesHub
              user={user}
              userRole={userRole}
              extensionMode={extensionMode}
              previewVersion={previewVersion}
              updates={visiblePlatformUpdates}
              isAdminPrivileged={isAdminPrivileged}
              pairingSession={pairingSession}
              pairingLoading={pairingLoading}
              activeFloatingExtension={activeFloatingExtension}
              lazyBridgeOpenNonce={lazyBridgeOpenNonce}
              onGeneratePairing={handleGeneratePairing}
              onScanAndPairFromScreen={handleScanAndPairFromScreen}
              onTriggerPairingRequest={handleTriggerPairingRequest}
              onConfirmPairingDecision={handleConfirmPairingDecision}
              onUnlinkPairing={handleUnlinkPairing}
              onActivateFloatingExtension={handleActivateFloatingExtension}
              onTriggerAutoInjectCyberBridge={handleTriggerAutoInjectCyberBridge}
              onOpenSecretCodeEditor={handleOpenSecretCodeEditor}
              onChangePreviewVersion={handleChangePreviewVersion}
              onToggleExtensionMode={handleToggleExtensionMode}
              onCreateUpdate={handleCreateAiUpdate}
              onToggleVisibility={handleToggleAiUpdateVisibility}
              onDeleteUpdate={handleDeleteAiUpdate}
              onExecuteUpdateAction={handleExecuteAiUpdateAction}
              onOpenDeveloperCategory={() => {
                setDrawerScrollTarget("developer-category");
                setAccountSettingsOpen(true);
              }}
              onOpenAdminRequest={() => {
                setDrawerScrollTarget("admin-request");
                setAccountSettingsOpen(true);
              }}
              onShowToast={showToast}
            />

            <OmniCreatorStudio
              user={user}
              onInjectToPlayground={handleInjectCodeToPlayground}
              onOpenInSecretEditor={(file) => handleOpenSecretCodeEditor(file)}
              onSaveToCloud={handleUploadCloudFile}
              onCodeRun={handleCodeRun}
              onShowToast={showToast}
            />

            <ShopSection
              user={user}
              userRole={userRole}
              customProducts={customShopProducts}
              cart={shopCart}
              orders={shopOrders}
              isCartOpen={shopCartOpen}
              onSetCartOpen={setShopCartOpen}
              onAddToCart={handleAddToShopCart}
              onUpdateQuantity={handleUpdateShopQuantity}
              onRemoveFromCart={handleRemoveFromShopCart}
              onClearCart={handleClearShopCart}
              onSubmitOrder={handleSubmitShopOrder}
              onPublishProduct={handlePublishShopProduct}
              onDeleteCustomProduct={handleDeleteCustomShopProduct}
              onOpenCurrencyStore={() => setCurrencyStoreOpen(true)}
              onShowToast={showToast}
            />

            <AssistantSection
              assistantTitle={assistantTitle}
              onOpenAdmin={() => setAdminModalOpen(true)}
              onInjectCodeToPlayground={handleInjectCodeToPlayground}
            />

            <CodePlayground
              user={user}
              onCodeRun={handleCodeRun}
              onSaveToCloud={handleUploadCloudFile}
              onShowToast={showToast}
              injectedBundle={injectedBundle}
            />

            <AdBannerSlot
              placement="mid-infeed"
              adVisibility={adVisibility}
              onOpenDnsSettings={() => {
                setDrawerScrollTarget("ad-dns-settings");
                setAccountSettingsOpen(true);
              }}
              onOpenVipUpgrade={() => setCurrencyStoreOpen(true)}
            />

            <CloudHubSection
              user={user}
              privateFiles={privateCloudFiles}
              publicFiles={publicCloudFiles}
              onUploadFile={handleUploadCloudFile}
              onToggleVisibility={handleToggleCloudVisibility}
              onDeleteFile={handleDeleteCloudFile}
              onDownloadFile={(file) => void handleDownloadCloudFile(file)}
              onRequestAuth={() => setAuthModalOpen(true)}
              onOpenCreatorStudio={handleOpenSecretConsoleGuarded}
            />

            <CommunityHub
              projects={projectsWithLiveDownloads}
              posts={posts}
              user={user}
              requestedFilter={communityFilterReq}
              onSelectProject={(proj) => setSelectedProject(proj)}
              onDownloadProject={handleDownloadProject}
              onCreatePost={handleCreatePost}
              onToggleLike={handleToggleLike}
              onAddReply={handleAddReply}
              onRequestAuth={() => setAuthModalOpen(true)}
            />

            <ChallengesSection
              challenges={challenges}
              user={user}
              userRole={userRole}
              onCreateChallenge={handleCreateChallenge}
              onAddComment={handleAddChallengeComment}
              onShowToast={showToast}
            />

            <BetaExperienceHub
              betaEnabled={betaEnabled}
              browserInspection={browserInspection}
              googleBetaJoined={googleBetaJoined}
              activeProgLang={activeProgLang}
              fantasyMode={fantasyMode}
              user={user}
              userRole={userRole}
              schoolUpdates={schoolUpdates}
              publishedMiniApps={publishedMiniApps}
              allNationalities={nationalities}
              requestedTab={betaTabRequest}
              onToggleBeta={handleToggleBeta}
              onToggleGoogleBetaJoined={handleToggleGoogleBetaJoined}
              onChangeProgLang={handleChangeProgLang}
              onToggleFantasyMode={handleToggleFantasyMode}
              onPublishMiniProject={handlePublishMiniProject}
              onAddSchoolUpdate={handleAddSchoolUpdate}
              onNationalityLoaded={handleNationalityLoadedFromServer}
              onAddPlatformMessage={handleAddPlatformMessage}
              onRequestSendGmail={(req) => setGmailConfirmRequest(req)}
              onOpenDeveloperCategory={() => {
                setDrawerScrollTarget("developer-category");
                setAccountSettingsOpen(true);
              }}
              onShowToast={showToast}
            />

            <CommunityLinksSection />
          </>
        )}
      </main>

      <Footer
        displayVersion={displayVersion}
        canExportSiteZip={canExportSiteZip}
        siteArchiveMeta={siteArchiveMeta}
        siteArchiveProgress={siteArchiveProgress}
        onDownloadSiteArchive={handleDownloadSiteArchive}
        onNotifyDownloadStarted={(msg) => showToast(msg)}
        onOpenAdmin={() => setAdminModalOpen(true)}
        onShowMaintenance={handleShowMaintenance}
      />

      {/* Desktop Mode Floating Developer Dock Trigger (strictly gated by RBAC & hidden in Kids Mode) */}
      {!kidsMode &&
        canUseDevTools &&
        (desktopMode || secretDevUnlocked || isMasterAdmin) &&
        (!maintenanceActive || isMasterAdmin) &&
        !bannedEmail && (
          <button
            type="button"
            onClick={() => setDeveloperOptionsOpen(true)}
            className="fixed bottom-5 left-5 z-40 inline-flex items-center gap-2 rounded-xl border border-emerald-400/50 bg-[#0E1424]/95 px-4 py-2.5 text-xs font-extrabold text-emerald-300 shadow-2xl backdrop-blur-md transition-transform hover:scale-105 cursor-pointer"
          >
            <Terminal className="h-4 w-4" />
            <span>خيارات المطورين</span>
          </button>
        )}

      <MaintenanceScreen
        isOpen={maintenanceActive && !isMasterAdmin && !bannedEmail}
        desktopMode={desktopMode}
        onToggleDesktopMode={handleToggleDesktopMode}
        onBypassMaintenance={handleBypassMaintenance}
        onUnlockAdminAndEnter={handleUnlockAdminFromMaintenance}
      />

      {/* 12+ Age Verification Gate after MaintenanceScreen */}
      <AgeVerificationModal
        isOpen={
          !maintenanceActive &&
          !isMasterAdmin &&
          !bannedEmail &&
          ageStatus === "unverified"
        }
        onVerifiedAdult={handleAdultVerified}
        onChooseKidMode={handleChooseKidMode}
      />

      <BanErrorScreen
        isOpen={Boolean(bannedEmail)}
        bannedEmail={bannedEmail}
        onApologize={handleApologizeFromBan}
      />

      <BrownDuolingoModal
        isOpen={brownOwlOpen}
        onClose={() => setBrownOwlOpen(false)}
        onEnterComedyBackstage={() => {
          setComedyMode("comedy");
          setComedyModalOpen(true);
        }}
      />

      <ComedyBackstageModal
        isOpen={comedyModalOpen && !bannedEmail}
        mode={comedyMode}
        onClose={() => setComedyModalOpen(false)}
        onTriggerBan={handleTriggerComedyBan}
      />

      <AuthModal
        isOpen={authModalOpen}
        defaultTheme={themeDecoration}
        defaultDesktopMode={desktopMode}
        onClose={() => setAuthModalOpen(false)}
        onLogin={handleLogin}
        onUnlockAdmin={handleUnlockAdmin}
      />

      <CategoriesTeleportMenu
        isOpen={categoriesMenuOpen && !kidsMode}
        userRole={userRole}
        projects={projectsWithLiveDownloads}
        publicCloudFiles={publicCloudFiles}
        liveUpdates={visiblePlatformUpdates}
        onClose={() => setCategoriesMenuOpen(false)}
        onTeleport={handleTeleportFromMenu}
      />

      <MessagesCenterModal
        isOpen={messagesModalOpen}
        user={user}
        platformMessages={platformMessages}
        gmailAlertsEnabled={gmailAlertsEnabled}
        onToggleGmailAlerts={handleToggleGmailAlerts}
        onClose={() => setMessagesModalOpen(false)}
        onRequestSendGmail={(req) => setGmailConfirmRequest(req)}
        onSaveLocalPlatformMessage={handleAddPlatformMessage}
        onShowToast={showToast}
      />

      <NetworkVoiceNationalityModal
        isOpen={networkVoiceModalOpen}
        user={user}
        userRole={userRole}
        myNationality={myNationality}
        onClose={() => setNetworkVoiceModalOpen(false)}
        onCreateNationality={handleUpsertNationality}
        onShowToast={showToast}
      />

      <GmailConfirmDialog
        request={gmailConfirmRequest}
        onCancel={() => setGmailConfirmRequest(null)}
        onConfirmSend={handleConfirmSendRealGmail}
      />

      <AccountSettingsDrawer
        isOpen={accountSettingsOpen}
        user={user}
        userRole={userRole}
        themeDecoration={themeDecoration}
        desktopMode={desktopMode}
        secretDevUnlocked={secretDevUnlocked}
        codeRunsCount={codeRunsCount}
        hasUsedBridge={
          Boolean(pairingSession) || Boolean(activeFloatingExtension)
        }
        dnsAdBlockEnabled={dnsAdBlockEnabled}
        adVisibility={adVisibility}
        speakerEnabled={speakerEnabled}
        betaEnabled={betaEnabled}
        activeProgLang={activeProgLang}
        kidsMode={kidsMode}
        initialScrollTarget={drawerScrollTarget}
        onClose={() => {
          setAccountSettingsOpen(false);
          setDrawerScrollTarget(null);
        }}
        onSaveProfile={handleSaveProfileSettings}
        onChangeTheme={handleChangeTheme}
        onToggleDesktopMode={handleToggleDesktopMode}
        onToggleDnsAdBlock={handleToggleDnsAdBlock}
        onToggleSpeaker={handleToggleSpeaker}
        onOpenBetaPlusSettings={() => {
          if (!betaEnabled) handleToggleBeta(true);
          teleportToDomId("beta-hub");
        }}
        onOpenCurrencyStore={() => setCurrencyStoreOpen(true)}
        onOpenVipShop={() => teleportToDomId("shop")}
        onBecomeDeveloper={handleBecomeDeveloper}
        onSubmitAdminRoleRequest={handleSubmitAdminRoleRequest}
        onUnlockSecretDev={() => {
          if (!canUseDevTools) {
            showToast("أكمل مهام «فئة المطور» لفتح أدوات المطورين.");
            return;
          }
          setSecretDevUnlocked(true);
          addSystemLog(
            "AUTH",
            "تم فتح وضع المطورين السري من إعدادات الحساب"
          );
          showToast("تم كشف خيارات المطورين السرية!");
        }}
        onOpenDeveloperOptions={() => setDeveloperOptionsOpen(true)}
        onOpenAuth={() => setAuthModalOpen(true)}
        onExitKidsMode={handleExitKidsMode}
        iphoneFontEnabled={iphoneFontEnabled}
        onToggleIPhoneFont={(enabled) => {
          setIphoneFontEnabled(enabled);
          showToast(
            enabled
              ? "تم تفعيل خط وإيموجيات الآيفون على الموقع!"
              : "تم إرجاع الخط الافتراضي."
          );
        }}
        onOpenIPhoneKeyboard={() => setIphoneKeyboardOpen(true)}
        canExportSiteZip={canExportSiteZip}
        siteArchiveMeta={siteArchiveMeta}
        siteArchiveProgress={siteArchiveProgress}
        onDownloadSiteArchive={handleDownloadSiteArchive}
        onNotifySiteArchiveStarted={(msg) => showToast(msg)}
      />

      <DeveloperOptionsModal
        isOpen={developerOptionsOpen}
        isAuthorized={adminUnlocked}
        userRole={userRole}
        currentUser={user}
        themeDecoration={themeDecoration}
        desktopMode={desktopMode}
        maintenanceActive={maintenanceActive}
        assistantUrl={assistantUrl}
        assistantTitle={assistantTitle}
        systemLogs={systemLogs}
        onClose={() => setDeveloperOptionsOpen(false)}
        onAuthorize={handleUnlockAdmin}
        onChangeTheme={handleChangeTheme}
        onToggleDesktopMode={handleToggleDesktopMode}
        onToggleMaintenance={(active) => {
          if (active) handleShowMaintenance();
          else handleBypassMaintenance();
        }}
        onSaveAssistantConfig={handleSaveAssistantConfig}
        onClearLogs={() => {
          setSystemLogs([]);
          localStorage.removeItem(STORAGE_KEYS.SYSTEM_LOGS);
        }}
        onAddLog={addSystemLog}
      />

      <AdminModal
        isOpen={adminModalOpen}
        isUnlocked={adminUnlocked}
        assistantUrl={assistantUrl}
        assistantTitle={assistantTitle}
        posts={posts}
        onClose={() => setAdminModalOpen(false)}
        onUnlock={handleUnlockAdmin}
        onLock={handleLockAdmin}
        onSaveAssistantConfig={handleSaveAssistantConfig}
        onDeletePost={handleDeletePost}
        onResetCommunity={handleResetCommunity}
      />

      <ProjectModal
        project={selectedProject}
        onClose={() => setSelectedProject(null)}
        onDownload={handleDownloadProject}
      />

      <CurrencyStoreModal
        isOpen={currencyStoreOpen}
        economy={economy}
        isAdminPrivileged={isAdminPrivileged}
        onClose={() => setCurrencyStoreOpen(false)}
        onTradeTimeForCoins={handleTradeTimeForCoins}
        onPurchaseOrActivateItem={handlePurchaseOrActivateItem}
        onApplyThemeFromStore={(theme) => {
          handleChangeTheme(theme);
          showToast("تم تطبيق الزينة فوراً!");
        }}
      />

      <SecretCreatorConsole
        isOpen={secretConsoleOpen}
        user={user}
        economy={economy}
        isAdminPrivileged={isAdminPrivileged}
        privateFiles={privateCloudFiles}
        onClose={() => setSecretConsoleOpen(false)}
        onSaveToCloud={handleUploadCloudFile}
        onOpenStore={() => setCurrencyStoreOpen(true)}
        onDownloadCloudItem={(file) => void handleDownloadCloudFile(file)}
      />

      <SecretCodeEditorModal
        isOpen={secretCodeEditorOpen}
        user={user}
        initialFileToLoad={secretEditorInitialFile}
        onClose={() => setSecretCodeEditorOpen(false)}
        onSaveToDataCenter={handleUploadCloudFile}
        onShowToast={showToast}
      />

      {/* Education Law AI Guide Robot (shows after opening & age gate until skipped; hidden in Kids Mode) */}
      <EducationGuideRobot
        isVisible={
          !kidsMode &&
          !maintenanceActive &&
          ageStatus !== "unverified" &&
          !bannedEmail &&
          !eduRobotSkipped
        }
        onSkipForever={handleSkipEduRobotForever}
      />

      {/* Arabic Accessibility Floating Speaker (Works in Main & Beta; hidden in Kids Mode) */}
      <FloatingArabicSpeaker
        isEnabled={!kidsMode && speakerEnabled && !maintenanceActive && !bannedEmail}
        onClose={() => handleToggleSpeaker(false)}
      />

      {/* Smooth Transition Overlay for Kids <-> Global Version */}
      {kidsTransitionState !== "none" && (
        <div
          aria-live="polite"
          className="fixed inset-0 z-[80] flex flex-col items-center justify-center bg-[#0B0F19]/95 backdrop-blur-md text-center p-6"
        >
          <div className="h-14 w-14 rounded-2xl border-2 border-amber-400 bg-amber-500/20 flex items-center justify-center animate-bounce mb-4">
            <span className="text-3xl">
              {kidsTransitionState === "entering-kids" ? "🎈" : "🚀"}
            </span>
          </div>
          <h3 className="text-xl font-extrabold text-white">
            {kidsTransitionState === "entering-kids"
              ? "جاري تجهيز نسخة عراقي كيدز الآمنة..."
              : "جاري الانتقال بسلاسة إلى النسخة العالمية المعتادة..."}
          </h3>
          <p className="mt-2 text-xs text-slate-300">
            يرجى الانتظار لحظة واحدة
          </p>
        </div>
      )}

      {toastMessage && (
        <div
          role="status"
          aria-live="polite"
          data-dom-scan-ignore="true"
          className="fixed bottom-5 right-5 z-50 rounded-xl border border-emerald-500/40 bg-[#0E1424]/95 px-4 py-3 text-xs font-bold text-emerald-300 shadow-2xl backdrop-blur-md"
        >
          {toastMessage}
        </div>
      )}

      <OfflineIndicator />

      <IPhoneKeyboard
        isOpen={iphoneKeyboardOpen}
        onClose={() => setIphoneKeyboardOpen(false)}
        onShowToast={showToast}
      />
    </div>
  );
}

export default App;
