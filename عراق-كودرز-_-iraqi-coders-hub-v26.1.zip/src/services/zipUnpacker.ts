import { UnpackedExtensionFile, UnpackedExtensionPackage } from "../types";

const TEXT_EXTENSIONS = [
  ".json",
  ".html",
  ".htm",
  ".js",
  ".mjs",
  ".ts",
  ".css",
  ".txt",
  ".md",
  ".svg",
  ".xml",
];

function isTextFile(path: string): boolean {
  const lower = path.toLowerCase();
  return TEXT_EXTENSIONS.some((ext) => lower.endsWith(ext));
}

async function inflateRawBytes(compressed: Uint8Array<ArrayBuffer>): Promise<Uint8Array<ArrayBuffer>> {
  if (typeof DecompressionStream !== "undefined") {
    try {
      const ds = new DecompressionStream("deflate-raw");
      const writer = ds.writable.getWriter();
      const copy = new Uint8Array(compressed.length);
      copy.set(compressed);
      await writer.write(copy);
      await writer.close();
      const response = new Response(ds.readable);
      const buf = await response.arrayBuffer();
      return new Uint8Array(buf);
    } catch {
      return compressed;
    }
  }
  return compressed;
}

/**
 * Unpacks an extension .zip package completely in-browser (supports STORE=0 and DEFLATE=8)
 * and extracts manifest.json, popup.html, scripts, and metadata for the floating bridge UI.
 */
export async function unpackExtensionZip(
  file: File
): Promise<UnpackedExtensionPackage> {
  const buffer = await file.arrayBuffer();
  const bytes = new Uint8Array(buffer);
  const view = new DataView(buffer);
  const decoder = new TextDecoder("utf-8", { fatal: false });

  // Locate End of Central Directory (PK\x05\x06)
  let eocdOffset = -1;
  const minScan = Math.max(0, bytes.length - 65557);
  for (let i = bytes.length - 22; i >= minScan; i--) {
    if (
      bytes[i] === 0x50 &&
      bytes[i + 1] === 0x4b &&
      bytes[i + 2] === 0x05 &&
      bytes[i + 3] === 0x06
    ) {
      eocdOffset = i;
      break;
    }
  }

  if (eocdOffset === -1) {
    throw new Error("الملف المرفوع ليس أرشيف ZIP صالحاً (لم يتم العثور على رأس PKZIP).");
  }

  const totalEntries = view.getUint16(eocdOffset + 10, true);
  const centralDirOffset = view.getUint32(eocdOffset + 16, true);

  const unpackedFiles: UnpackedExtensionFile[] = [];
  let cursor = centralDirOffset;

  for (let idx = 0; idx < totalEntries && cursor + 46 <= bytes.length; idx++) {
    const sig = view.getUint32(cursor, true);
    if (sig !== 0x02014b50) break;

    const compressionMethod = view.getUint16(cursor + 10, true);
    const compressedSize = view.getUint32(cursor + 20, true);
    const uncompressedSize = view.getUint32(cursor + 24, true);
    const nameLen = view.getUint16(cursor + 28, true);
    const extraLen = view.getUint16(cursor + 30, true);
    const commentLen = view.getUint16(cursor + 32, true);
    const localHeaderOffset = view.getUint32(cursor + 42, true);

    const filePath = decoder.decode(
      bytes.slice(cursor + 46, cursor + 46 + nameLen)
    );
    cursor += 46 + nameLen + extraLen + commentLen;

    // Skip directories & macOS metadata junk
    if (
      filePath.endsWith("/") ||
      filePath.startsWith("__MACOSX/") ||
      filePath.endsWith(".DS_Store")
    ) {
      continue;
    }

    if (localHeaderOffset + 30 > bytes.length) continue;
    const localSig = view.getUint32(localHeaderOffset, true);
    if (localSig !== 0x04034b50) continue;

    const localNameLen = view.getUint16(localHeaderOffset + 26, true);
    const localExtraLen = view.getUint16(localHeaderOffset + 28, true);
    const dataStart = localHeaderOffset + 30 + localNameLen + localExtraLen;
    const dataEnd = Math.min(bytes.length, dataStart + compressedSize);
    const rawSlice = bytes.slice(dataStart, dataEnd);

    let extractedBytes: Uint8Array<ArrayBuffer> = rawSlice;
    if (compressionMethod === 8) {
      extractedBytes = await inflateRawBytes(rawSlice);
    }

    const textEntry = isTextFile(filePath);
    const decodedText = textEntry
      ? decoder.decode(extractedBytes).slice(0, 60000)
      : `[Binary Asset · ${uncompressedSize || extractedBytes.length} bytes]`;

    unpackedFiles.push({
      path: filePath,
      sizeBytes: uncompressedSize || extractedBytes.length,
      content: decodedText,
      isBinary: !textEntry,
    });

    if (unpackedFiles.length >= 80) break;
  }

  if (unpackedFiles.length === 0) {
    throw new Error("لم يتم العثور على ملفات داخل حزمة ZIP المختارة.");
  }

  // Locate manifest.json even if wrapped inside a top-level subfolder
  const manifestEntry = unpackedFiles.find((f) =>
    /(^|\/)manifest\.json$/i.test(f.path)
  );

  let extensionName = file.name.replace(/\.zip$/i, "") || "إضافة عراقي كودرز";
  let version = "26.5";
  let description = "حزمة إضافة مرفوعة ومفكوكة مباشرة عبر جسر ما بيا حيل الذكي.";
  let defaultPopupName = "popup.html";

  if (manifestEntry) {
    try {
      const parsed = JSON.parse(manifestEntry.content) as {
        name?: string;
        version?: string;
        description?: string;
        action?: { default_popup?: string };
        browser_action?: { default_popup?: string };
      };
      if (parsed.name && !parsed.name.startsWith("__MSG_")) {
        extensionName = String(parsed.name).slice(0, 80);
      }
      if (parsed.version) {
        version = String(parsed.version).slice(0, 24);
      }
      if (parsed.description && !parsed.description.startsWith("__MSG_")) {
        description = String(parsed.description).slice(0, 220);
      }
      const popupCandidate =
        parsed.action?.default_popup || parsed.browser_action?.default_popup;
      if (popupCandidate) {
        defaultPopupName = popupCandidate.replace(/^\.?\//, "");
      }
    } catch {
      // Non-JSON or localized manifest stays resilient
    }
  }

  const popupEntry =
    unpackedFiles.find((f) =>
      f.path.toLowerCase().endsWith(defaultPopupName.toLowerCase())
    ) ||
    unpackedFiles.find((f) => /(^|\/)(popup|index)\.html?$/i.test(f.path));

  return {
    archiveName: file.name,
    extensionName,
    version,
    description,
    popupPath: popupEntry?.path,
    popupHtml: popupEntry?.content,
    manifestRaw: manifestEntry?.content,
    files: unpackedFiles,
    unpackedAt: new Date().toLocaleTimeString("ar-IQ", {
      hour: "2-digit",
      minute: "2-digit",
    }),
  };
}
