import { UserRole } from "../types";

/**
 * ============================================================================
 * وحدة إدارة الإعلانات والتحقق المركزي (Ad Manager & Exemption Rules)
 * ----------------------------------------------------------------------------
 * دالة واحدة واضحة ومنظمة للتحقق من حالات إخفاء الإعلانات بالكامل:
 * 1) اشتراك VIP (عبر الدفع الحقيقي أو عبر العملات الخاصة داخل النظام)
 * 2) رتبة المشرف / المدير (Supervisor / Admin Role)
 * 3) تفعيل وضع DNS مباشرة من إعدادات الموقع
 * ============================================================================
 */

export const VIP_COIN_ITEM_IDS = [
  "item-vip-badge",
  "item-vip-subscription",
] as const;

export const VIP_PAID_PRODUCT_IDS = ["prod-vip-subscription"] as const;

export interface AdVisibilityContext {
  /** اشتراك VIP عبر الدفع الحقيقي / المتجر */
  isVipPaid: boolean;
  /** اشتراك VIP عبر العملات الخاصة داخل المنصة */
  isVipCoins: boolean;
  /** رتبة المستخدم الحالية في المنصة */
  userRole: UserRole;
  /** هل يمتلك المستخدم صلاحية إشراف أو إدارة مفعلة */
  isSupervisorOrAdmin?: boolean;
  /** حالة تفعيل خيار DNS من إعدادات الموقع */
  isDnsEnabledInSettings: boolean;
}

export type AdExemptionReason =
  | "vip_paid"
  | "vip_coins"
  | "supervisor_admin"
  | "site_dns"
  | null;

export interface AdVisibilityResult {
  /** true = تظهر الإعلانات للمستخدم | false = تختفي الإعلانات بالكامل */
  shouldShowAds: boolean;
  /** هل المستخدم مستثنى من الإعلانات؟ */
  isExempt: boolean;
  /** رمز السبب الرئيسي لإخفاء الإعلانات */
  reason: AdExemptionReason;
  /** وصف عربي واضح لحالة الإعلانات */
  reasonLabel: string;
  /** تفاصيل كل قاعدة تحقق على حدة لسهولة العرض أو التعديل */
  activeRules: {
    vipSubscription: boolean;
    vipPaid: boolean;
    vipCoins: boolean;
    supervisorRole: boolean;
    siteDnsMode: boolean;
  };
}

/**
 * التحقق مما إذا كان المستخدم قد اشترك في VIP عبر عملات النظام
 */
export function hasVipCoinSubscription(unlockedItems: string[]): boolean {
  return VIP_COIN_ITEM_IDS.some((id) => unlockedItems.includes(id));
}

/**
 * دالة التحقق المركزية الوحيدة (Single Source of Truth) لإظهار أو إخفاء الإعلانات
 */
export function evaluateAdVisibility(
  ctx: AdVisibilityContext
): AdVisibilityResult {
  const vipPaid = Boolean(ctx.isVipPaid);
  const vipCoins = Boolean(ctx.isVipCoins);
  const vipSubscription = vipPaid || vipCoins;
  const supervisorRole =
    Boolean(ctx.isSupervisorOrAdmin) ||
    ctx.userRole === "admin" ||
    ctx.userRole === "moderator";
  const siteDnsMode = Boolean(ctx.isDnsEnabledInSettings);

  let reason: AdExemptionReason = null;
  let reasonLabel = "الإعلانات مفعّلة للمستخدمين العاديين";

  if (supervisorRole) {
    reason = "supervisor_admin";
    reasonLabel = "تم إخفاء الإعلانات تلقائياً (رتبة المشرف / المدير)";
  } else if (vipPaid) {
    reason = "vip_paid";
    reasonLabel = "تم إخفاء الإعلانات تلقائياً (اشتراك VIP المدفوع)";
  } else if (vipCoins) {
    reason = "vip_coins";
    reasonLabel = "تم إخفاء الإعلانات تلقائياً (اشتراك VIP بالعملات الخاصة)";
  } else if (siteDnsMode) {
    reason = "site_dns";
    reasonLabel = "تم إخفاء الإعلانات تلقائياً (وضع DNS مفعّل من إعدادات الموقع)";
  }

  const isExempt = vipSubscription || supervisorRole || siteDnsMode;

  return {
    shouldShowAds: !isExempt,
    isExempt,
    reason,
    reasonLabel,
    activeRules: {
      vipSubscription,
      vipPaid,
      vipCoins,
      supervisorRole,
      siteDnsMode,
    },
  };
}
