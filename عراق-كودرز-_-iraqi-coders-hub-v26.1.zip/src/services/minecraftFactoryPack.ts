import { buildZipArchive, ZipEntryInput } from "./packageBuilder";

export const FACTORY_PACK_UUIDS = {
  bpHeader: "a19f4c10-2640-4e1a-9b11-002026000001",
  bpData: "a19f4c10-2640-4e1a-9b11-002026000002",
  bpScript: "a19f4c10-2640-4e1a-9b11-002026000003",
  rpHeader: "b28e7d20-2640-4e1a-9b22-002026000004",
  rpResources: "b28e7d20-2640-4e1a-9b22-002026000005",
} as const;

// Minimal valid RGBA PNG icons/textures for Android 14 Bedrock zero-lag rendering
const CYAN_CORE_PNG = new Uint8Array([
  0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
  0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01,
  0x08, 0x06, 0x00, 0x00, 0x00, 0x1f, 0x15, 0xc4, 0x89, 0x00, 0x00, 0x00,
  0x0d, 0x49, 0x44, 0x41, 0x54, 0x78, 0x9c, 0x63, 0x28, 0xcf, 0xf0, 0xbf,
  0x1e, 0x00, 0x05, 0x85, 0x02, 0x7f, 0x32, 0x95, 0x23, 0x5c, 0x00, 0x00,
  0x00, 0x00, 0x49, 0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82,
]);

export const FACTORY_BP_MANIFEST = JSON.stringify(
  {
    format_version: 2,
    header: {
      name: "توسعة مصانع عراقي كودرز ومصنع A (Behavior)",
      description:
        "توليد مصنع آيرون كودرز الكبير (RGB) ومصنع A الكبير عند نقطة البداية — متوافق مع Android 14",
      uuid: FACTORY_PACK_UUIDS.bpHeader,
      version: [2, 6, 4],
      min_engine_version: [1, 21, 0],
    },
    modules: [
      {
        description: "Industrial Blocks, Recipes & Loot Tables",
        type: "data",
        uuid: FACTORY_PACK_UUIDS.bpData,
        version: [2, 6, 4],
      },
      {
        description: "Zero-Lag Async Factory World Generator (@minecraft/server)",
        type: "script",
        language: "javascript",
        uuid: FACTORY_PACK_UUIDS.bpScript,
        entry: "scripts/main.js",
        version: [2, 6, 4],
      },
    ],
    dependencies: [
      {
        uuid: FACTORY_PACK_UUIDS.rpHeader,
        version: [2, 6, 4],
      },
      {
        module_name: "@minecraft/server",
        version: "1.14.0",
      },
      {
        module_name: "@minecraft/server-ui",
        version: "1.3.0",
      },
    ],
  },
  null,
  2
);

export const FACTORY_RP_MANIFEST = JSON.stringify(
  {
    format_version: 2,
    header: {
      name: "توسعة مصانع عراقي كودرز ومصنع A (Resources)",
      description:
        "موارد وخامات النيون RGB والسبائك الصناعية لمصانع عراقي كودرز و Factory A",
      uuid: FACTORY_PACK_UUIDS.rpHeader,
      version: [2, 6, 4],
      min_engine_version: [1, 21, 0],
    },
    modules: [
      {
        description: "Cyberpunk Industrial Textures & Arabic Translations",
        type: "resources",
        uuid: FACTORY_PACK_UUIDS.rpResources,
        version: [2, 6, 4],
      },
    ],
    dependencies: [
      {
        uuid: FACTORY_PACK_UUIDS.bpHeader,
        version: [2, 6, 4],
      },
    ],
  },
  null,
  2
);

export const BLOCK_CYBER_CODE_CORE = JSON.stringify(
  {
    format_version: "1.21.0",
    "minecraft:block": {
      description: {
        identifier: "iraqicoders:cyber_code_core",
        menu_category: {
          category: "construction",
          group: "itemGroup.name.tech",
        },
      },
      components: {
        "minecraft:destructible_by_mining": { seconds_to_destroy: 2.5 },
        "minecraft:destructible_by_explosion": { explosion_resistance: 45 },
        "minecraft:light_emission": 15,
        "minecraft:light_dampening": 0,
        "minecraft:map_color": "#06B6D4",
        "minecraft:geometry": "geometry.iraqicoders.cyber_code_core",
        "minecraft:material_instances": {
          "*": {
            texture: "iraqicoders_cyber_core",
            render_method: "opaque",
          },
        },
      },
    },
  },
  null,
  2
);

export const BLOCK_RGB_NEON_FRAME = JSON.stringify(
  {
    format_version: "1.21.0",
    "minecraft:block": {
      description: {
        identifier: "iraqicoders:rgb_neon_frame",
        menu_category: {
          category: "construction",
        },
      },
      components: {
        "minecraft:destructible_by_mining": { seconds_to_destroy: 1.5 },
        "minecraft:destructible_by_explosion": { explosion_resistance: 25 },
        "minecraft:light_emission": 14,
        "minecraft:map_color": "#EC4899",
        "minecraft:geometry": "minecraft:geometry.full_block",
        "minecraft:material_instances": {
          "*": {
            texture: "iraqicoders_rgb_neon",
            render_method: "opaque",
          },
        },
      },
    },
  },
  null,
  2
);

export const BLOCK_FACTORY_A_ALLOY = JSON.stringify(
  {
    format_version: "1.21.0",
    "minecraft:block": {
      description: {
        identifier: "iraqicoders:factory_a_alloy_wall",
        menu_category: {
          category: "construction",
        },
      },
      components: {
        "minecraft:destructible_by_mining": { seconds_to_destroy: 3.5 },
        "minecraft:destructible_by_explosion": { explosion_resistance: 90 },
        "minecraft:light_emission": 2,
        "minecraft:map_color": "#334155",
        "minecraft:geometry": "minecraft:geometry.full_block",
        "minecraft:material_instances": {
          "*": {
            texture: "iraqicoders_factory_a_alloy",
            render_method: "opaque",
          },
        },
      },
    },
  },
  null,
  2
);

export const BLOCK_AUTOMATED_CRAFTER_NODE = JSON.stringify(
  {
    format_version: "1.21.0",
    "minecraft:block": {
      description: {
        identifier: "iraqicoders:automated_crafter_node",
        menu_category: {
          category: "items",
        },
      },
      components: {
        "minecraft:destructible_by_mining": { seconds_to_destroy: 2.0 },
        "minecraft:destructible_by_explosion": { explosion_resistance: 35 },
        "minecraft:light_emission": 10,
        "minecraft:map_color": "#8B5CF6",
        "minecraft:geometry": "minecraft:geometry.full_block",
        "minecraft:material_instances": {
          "*": {
            texture: "iraqicoders_crafter_node",
            render_method: "opaque",
          },
        },
      },
    },
  },
  null,
  2
);

export const BLOCK_VAULT_SECURITY_GATE = JSON.stringify(
  {
    format_version: "1.21.0",
    "minecraft:block": {
      description: {
        identifier: "iraqicoders:vault_security_gate",
        menu_category: {
          category: "construction",
        },
      },
      components: {
        "minecraft:destructible_by_mining": { seconds_to_destroy: 4.5 },
        "minecraft:destructible_by_explosion": { explosion_resistance: 120 },
        "minecraft:light_emission": 6,
        "minecraft:map_color": "#10B981",
        "minecraft:geometry": "geometry.iraqicoders.factory_a_gate",
        "minecraft:material_instances": {
          "*": {
            texture: "iraqicoders_vault_gate",
            render_method: "opaque",
          },
        },
      },
    },
  },
  null,
  2
);

export const RECIPE_CYBER_CORE = JSON.stringify(
  {
    format_version: "1.20.10",
    "minecraft:recipe_shaped": {
      description: {
        identifier: "iraqicoders:craft_cyber_code_core",
      },
      tags: ["crafting_table"],
      pattern: ["IRI", "RDR", "IRI"],
      key: {
        I: { item: "minecraft:iron_ingot" },
        R: { item: "minecraft:redstone" },
        D: { item: "minecraft:diamond" },
      },
      result: {
        item: "iraqicoders:cyber_code_core",
        count: 2,
      },
    },
  },
  null,
  2
);

export const LOOT_FACTORY_CYBER_VAULT = JSON.stringify(
  {
    pools: [
      {
        rolls: 4,
        entries: [
          { type: "item", name: "minecraft:iron_block", weight: 22, functions: [{ function: "set_count", count: { min: 2, max: 6 } }] },
          { type: "item", name: "minecraft:emerald", weight: 18, functions: [{ function: "set_count", count: { min: 4, max: 14 } }] },
          { type: "item", name: "minecraft:redstone_block", weight: 20, functions: [{ function: "set_count", count: { min: 2, max: 8 } }] },
          { type: "item", name: "minecraft:diamond", weight: 10, functions: [{ function: "set_count", count: { min: 2, max: 6 } }] },
          { type: "item", name: "minecraft:netherite_scrap", weight: 4, functions: [{ function: "set_count", count: { min: 1, max: 2 } }] },
          { type: "item", name: "iraqicoders:cyber_code_core", weight: 12, functions: [{ function: "set_count", count: { min: 1, max: 3 } }] },
        ],
      },
    ],
  },
  null,
  2
);

export const FACTORY_MAIN_SCRIPT = `import { world, system } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";

const SPAWN_FLAG = "iraqi_coders_factories_built_v264";

function safeSetBlock(dimension, x, y, z, blockId) {
  try {
    const block = dimension.getBlock({ x, y, z });
    if (block) block.setType(blockId);
  } catch {
    // Chunk still loading - skipped safely to preserve 60fps on Android 14
  }
}

/**
 * Generator 1: Iraqi Coders Mega Factory (مصنع آيرون كودرز الكبير)
 * Automated cyberpunk factory with RGB neon rings, code-block machinery, and hopper loot line.
 */
function* buildIraqiCodersMegaFactory(dimension, ox, oy, oz) {
  const w = 18;
  const h = 10;
  const d = 18;

  for (let x = 0; x <= w; x++) {
    for (let z = 0; z <= d; z++) {
      safeSetBlock(dimension, ox + x, oy - 1, oz + z, "minecraft:deepslate_tiles");
      const isBorder = x === 0 || x === w || z === 0 || z === d;
      const isCyberStrip = (x + z) % 4 === 0;
      safeSetBlock(
        dimension,
        ox + x,
        oy,
        oz + z,
        isBorder ? "iraqicoders:rgb_neon_frame" : isCyberStrip ? "minecraft:cyan_stained_glass" : "minecraft:polished_deepslate"
      );
    }
    yield;
  }

  for (let y = 1; y <= h; y++) {
    for (let x = 0; x <= w; x++) {
      for (let z = 0; z <= d; z++) {
        const isWall = x === 0 || x === w || z === 0 || z === d;
        const isCorner = (x === 0 || x === w) && (z === 0 || z === d);
        const isEntrance = z === 0 && x >= 7 && x <= 11 && y <= 4;

        if (!isWall) {
          if (y === h) {
            const roofGlow = (x % 4 === 0 && z % 4 === 0);
            safeSetBlock(dimension, ox + x, oy + y, oz + z, roofGlow ? "minecraft:sea_lantern" : "minecraft:tinted_glass");
          } else {
            safeSetBlock(dimension, ox + x, oy + y, oz + z, "minecraft:air");
          }
          continue;
        }

        if (isEntrance) {
          safeSetBlock(dimension, ox + x, oy + y, oz + z, y === 4 ? "iraqicoders:rgb_neon_frame" : "minecraft:air");
        } else if (isCorner || y === 5 || y === h) {
          safeSetBlock(dimension, ox + x, oy + y, oz + z, "iraqicoders:rgb_neon_frame");
        } else if (y >= 2 && y <= 4 && (x % 3 === 0 || z % 3 === 0)) {
          safeSetBlock(dimension, ox + x, oy + y, oz + z, "minecraft:purple_stained_glass");
        } else {
          safeSetBlock(dimension, ox + x, oy + y, oz + z, "minecraft:polished_blackstone_bricks");
        }
      }
    }
    yield;
  }

  // Interior Automated Machinery, Beacon Core & Cyber Code Nodes
  safeSetBlock(dimension, ox + 9, oy + 1, oz + 9, "iraqicoders:cyber_code_core");
  safeSetBlock(dimension, ox + 9, oy + 2, oz + 9, "minecraft:beacon");
  for (let i = 4; i <= 14; i += 2) {
    safeSetBlock(dimension, ox + i, oy + 1, oz + 5, "iraqicoders:automated_crafter_node");
    safeSetBlock(dimension, ox + i, oy + 1, oz + 6, "minecraft:hopper");
    safeSetBlock(dimension, ox + i, oy + 1, oz + 7, "minecraft:chest");
  }
  safeSetBlock(dimension, ox + 4, oy + 1, oz + 14, "minecraft:blast_furnace");
  safeSetBlock(dimension, ox + 6, oy + 1, oz + 14, "minecraft:crafter");
  safeSetBlock(dimension, ox + 8, oy + 1, oz + 14, "minecraft:enchanting_table");
  yield;
}

/**
 * Generator 2: Factory A (مصنع A الكبير)
 * Colossal rival industrial complex with security gates, automated crafters, and storage vaults.
 */
function* buildFactoryA(dimension, ox, oy, oz) {
  const w = 22;
  const h = 11;
  const d = 20;

  for (let x = 0; x <= w; x++) {
    for (let z = 0; z <= d; z++) {
      safeSetBlock(dimension, ox + x, oy - 1, oz + z, "minecraft:deepslate_bricks");
      safeSetBlock(
        dimension,
        ox + x,
        oy,
        oz + z,
        x === 0 || x === w || z === 0 || z === d ? "iraqicoders:factory_a_alloy_wall" : "minecraft:iron_block"
      );
    }
    yield;
  }

  for (let y = 1; y <= h; y++) {
    for (let x = 0; x <= w; x++) {
      for (let z = 0; z <= d; z++) {
        const isWall = x === 0 || x === w || z === 0 || z === d;
        const isGate = z === 0 && x >= 9 && x <= 13 && y <= 4;

        if (!isWall) {
          if (y === h) {
            safeSetBlock(dimension, ox + x, oy + y, oz + z, x % 5 === 0 ? "minecraft:glowstone" : "iraqicoders:factory_a_alloy_wall");
          } else {
            safeSetBlock(dimension, ox + x, oy + y, oz + z, "minecraft:air");
          }
          continue;
        }

        if (isGate) {
          safeSetBlock(dimension, ox + x, oy + y, oz + z, y === 4 ? "iraqicoders:vault_security_gate" : "minecraft:iron_bars");
        } else if (y === 1 || y === 6 || y === h) {
          safeSetBlock(dimension, ox + x, oy + y, oz + z, "iraqicoders:factory_a_alloy_wall");
        } else {
          safeSetBlock(dimension, ox + x, oy + y, oz + z, y % 3 === 0 ? "minecraft:copper_block" : "minecraft:deepslate_bricks");
        }
      }
    }
    yield;
  }

  // Massive Storage Vaults + Automated Crafting Tables inside Factory A
  for (let vx = 4; vx <= 18; vx += 2) {
    for (let vy = 1; vy <= 4; vy++) {
      safeSetBlock(dimension, ox + vx, oy + vy, oz + 17, "minecraft:barrel");
    }
    safeSetBlock(dimension, ox + vx, oy + 1, oz + 12, "minecraft:crafter");
    safeSetBlock(dimension, ox + vx, oy + 1, oz + 10, "iraqicoders:automated_crafter_node");
  }
  safeSetBlock(dimension, ox + 11, oy + 1, oz + 6, "iraqicoders:cyber_code_core");
  yield;
}

function* spawnIndustrialComplexJob(dimension, spawnLoc) {
  yield* buildIraqiCodersMegaFactory(dimension, spawnLoc.x + 14, spawnLoc.y, spawnLoc.z + 10);
  yield* buildFactoryA(dimension, spawnLoc.x - 38, spawnLoc.y, spawnLoc.z + 10);

  world.sendMessage("§b[Iraqi Coders] §aتم بناء «مصنع آيرون كودرز الكبير» و «مصنع A الكبير» عند نقطة البداية بنجاح!");
}

world.afterEvents.playerSpawn.subscribe((ev) => {
  if (!ev.initialSpawn) return;
  const player = ev.player;

  if (!world.getDynamicProperty(SPAWN_FLAG)) {
    world.setDynamicProperty(SPAWN_FLAG, true);
    const spawn = world.getDefaultSpawnLocation();
    const dim = world.getDimension("overworld");
    const safeY = Math.max(spawn.y, 64);
    system.runJob(spawnIndustrialComplexJob(dim, { x: spawn.x, y: safeY, z: spawn.z }));
  }

  player.onScreenDisplay.setActionBar("§dعراقي كودرز §7| §bمصنع آيرون كودرز + §eFactory A §aجاهزان!");
});

// Interactive Factory Control Menu when tapping Cyber Code Core block
world.afterEvents.playerInteractWithBlock.subscribe((ev) => {
  if (ev.block.typeId !== "iraqicoders:cyber_code_core") return;
  const player = ev.player;

  const ui = new ActionFormData()
    .title("لوحة تحكم المصانع — عراقي كودرز")
    .body("اختر عملية التشغيل الآلي للمصنع أو الانتقال السريع:")
    .button("تفعيل خطوط الإنتاج (+4 حديد وزمرد)")
    .button("إعادة بناء المصانع عند السباون")
    .button("إغلاق");

  ui.show(player).then((res) => {
    if (res.canceled || res.selection === 2) return;
    if (res.selection === 0) {
      player.runCommand("give @s iron_ingot 4");
      player.runCommand("give @s emerald 2");
      player.sendMessage("§a[مصنع عراقي كودرز] §fتم إنتاج الموارد وإضافتها لحقيبتك!");
    } else if (res.selection === 1) {
      const spawn = world.getDefaultSpawnLocation();
      system.runJob(spawnIndustrialComplexJob(player.dimension, { x: spawn.x, y: Math.max(spawn.y, 64), z: spawn.z }));
    }
  });
});

// Automated Cyber-Core Pulse Loop (low-frequency every 100 ticks for zero lag on Android 14)
system.runInterval(() => {
  for (const player of world.getAllPlayers()) {
    const under = player.dimension.getBlock({
      x: Math.floor(player.location.x),
      y: Math.floor(player.location.y) - 1,
      z: Math.floor(player.location.z),
    });
    if (under?.typeId === "iraqicoders:cyber_code_core") {
      player.addEffect("speed", 120, { amplifier: 1, showParticles: false });
    }
  }
}, 100);
`;

const TERRAIN_TEXTURE_JSON = JSON.stringify(
  {
    resource_pack_name: "iraqi_coders_factories_rp",
    texture_name: "atlas.terrain",
    padding: 8,
    num_mip_levels: 4,
    texture_data: {
      iraqicoders_cyber_core: { textures: "textures/blocks/cyber_code_core" },
      iraqicoders_rgb_neon: { textures: "textures/blocks/rgb_neon_frame" },
      iraqicoders_factory_a_alloy: { textures: "textures/blocks/factory_a_alloy_wall" },
      iraqicoders_crafter_node: { textures: "textures/blocks/automated_crafter_node" },
      iraqicoders_vault_gate: { textures: "textures/blocks/vault_security_gate" },
    },
  },
  null,
  2
);

const RP_BLOCKS_JSON = JSON.stringify(
  {
    format_version: [1, 1, 0],
    "iraqicoders:cyber_code_core": { sound: "metal", textures: "iraqicoders_cyber_core" },
    "iraqicoders:rgb_neon_frame": { sound: "glass", textures: "iraqicoders_rgb_neon" },
    "iraqicoders:factory_a_alloy_wall": { sound: "deepslate", textures: "iraqicoders_factory_a_alloy" },
    "iraqicoders:automated_crafter_node": { sound: "anvil", textures: "iraqicoders_crafter_node" },
    "iraqicoders:vault_security_gate": { sound: "metal", textures: "iraqicoders_vault_gate" },
  },
  null,
  2
);

export const GEO_CYBER_CODE_CORE = JSON.stringify(
  {
    format_version: "1.16.0",
    "minecraft:geometry": [
      {
        description: {
          identifier: "geometry.iraqicoders.cyber_code_core",
          texture_width: 16,
          texture_height: 16,
          visible_bounds_width: 2,
          visible_bounds_height: 2,
          visible_bounds_offset: [0, 0.5, 0],
        },
        bones: [
          {
            name: "core_chassis",
            pivot: [0, 8, 0],
            cubes: [
              { origin: [-8, 0, -8], size: [16, 16, 16], uv: [0, 0] },
              { origin: [-6, 16, -6], size: [12, 2, 12], uv: [0, 0] },
            ],
          },
        ],
      },
    ],
  },
  null,
  2
);

export const GEO_FACTORY_A_GATE = JSON.stringify(
  {
    format_version: "1.16.0",
    "minecraft:geometry": [
      {
        description: {
          identifier: "geometry.iraqicoders.factory_a_gate",
          texture_width: 16,
          texture_height: 16,
          visible_bounds_width: 2,
          visible_bounds_height: 2,
          visible_bounds_offset: [0, 0.5, 0],
        },
        bones: [
          {
            name: "gate_frame",
            pivot: [0, 8, 0],
            cubes: [
              { origin: [-8, 0, -6], size: [16, 16, 12], uv: [0, 0] },
              { origin: [-8, 12, -8], size: [16, 4, 16], uv: [0, 0] },
            ],
          },
        ],
      },
    ],
  },
  null,
  2
);

function createWorldLevelDat(): Uint8Array {
  // Minimal valid Bedrock NBT header + LevelName for .mcworld parsing
  const enc = new TextEncoder();
  const levelName = "Iraqi Coders Mega Factories World";
  const nameBytes = enc.encode(levelName);
  const keyBytes = enc.encode("LevelName");
  // Compound tag payload: TAG_Compound(1)+rootLen(2)+TAG_String(1)+keyLen(2)+key+valLen(2)+val+TAG_End(1)
  const payload = new Uint8Array(9 + keyBytes.length + nameBytes.length);
  const pv = new DataView(payload.buffer);
  let p = 0;
  payload[p++] = 0x0a; // TAG_Compound root
  pv.setUint16(p, 0, true); p += 2; // empty root name
  payload[p++] = 0x08; // TAG_String
  pv.setUint16(p, keyBytes.length, true); p += 2;
  payload.set(keyBytes, p); p += keyBytes.length;
  pv.setUint16(p, nameBytes.length, true); p += 2;
  payload.set(nameBytes, p); p += nameBytes.length;
  payload[p++] = 0x00; // TAG_End

  const out = new Uint8Array(8 + payload.length);
  const hv = new DataView(out.buffer);
  hv.setUint32(0, 10, true); // Bedrock Storage Version 10
  hv.setUint32(4, payload.length, true);
  out.set(payload, 8);
  return out;
}

export function buildMinecraftFactoriesEntries(prefixBp: string, prefixRp: string): ZipEntryInput[] {
  const langEn = [
    "pack.name=Iraqi Coders Industrial Factories",
    "pack.description=Iraqi Coders Mega Factory & Factory A for Minecraft Bedrock Android 14",
    "tile.iraqicoders:cyber_code_core.name=Cyber Code Core",
    "tile.iraqicoders:rgb_neon_frame.name=RGB Neon Factory Frame",
    "tile.iraqicoders:factory_a_alloy_wall.name=Factory A Reinforced Alloy",
    "tile.iraqicoders:automated_crafter_node.name=Automated Crafter Node",
    "tile.iraqicoders:vault_security_gate.name=Vault Security Gate",
  ].join("\n");

  const langAr = [
    "pack.name=توسعة مصانع عراقي كودرز ومصنع A",
    "pack.description=مصنع آيرون كودرز الكبير ومصنع A الكبير عند نقطة البداية — متوافق مع أندرويد 14",
    "tile.iraqicoders:cyber_code_core.name=نواة الكود السايبرانية",
    "tile.iraqicoders:rgb_neon_frame.name=إطار النيون الصناعي RGB",
    "tile.iraqicoders:factory_a_alloy_wall.name=جدار سبيكة مصنع A",
    "tile.iraqicoders:automated_crafter_node.name=وحدة التصنيع الآلي",
    "tile.iraqicoders:vault_security_gate.name=بوابة الخزنة الأمنية",
  ].join("\n");

  return [
    // Behavior Pack
    { path: `${prefixBp}manifest.json`, data: FACTORY_BP_MANIFEST },
    { path: `${prefixBp}pack_icon.png`, data: CYAN_CORE_PNG },
    { path: `${prefixBp}blocks/cyber_code_core.json`, data: BLOCK_CYBER_CODE_CORE },
    { path: `${prefixBp}blocks/rgb_neon_frame.json`, data: BLOCK_RGB_NEON_FRAME },
    { path: `${prefixBp}blocks/factory_a_alloy_wall.json`, data: BLOCK_FACTORY_A_ALLOY },
    { path: `${prefixBp}blocks/automated_crafter_node.json`, data: BLOCK_AUTOMATED_CRAFTER_NODE },
    { path: `${prefixBp}blocks/vault_security_gate.json`, data: BLOCK_VAULT_SECURITY_GATE },
    { path: `${prefixBp}recipes/cyber_code_core_recipe.json`, data: RECIPE_CYBER_CORE },
    { path: `${prefixBp}loot_tables/chests/factory_cyber_vault.json`, data: LOOT_FACTORY_CYBER_VAULT },
    { path: `${prefixBp}scripts/main.js`, data: FACTORY_MAIN_SCRIPT },
    {
      path: `${prefixBp}functions/spawn_factories.mcfunction`,
      data: "say §b[Iraqi Coders] §aتم تجهيز مصنع آيرون كودرز الكبير و Factory A عند السباون!\ngive @p iraqicoders:cyber_code_core 2\n",
    },

    // Resource Pack
    { path: `${prefixRp}manifest.json`, data: FACTORY_RP_MANIFEST },
    { path: `${prefixRp}pack_icon.png`, data: CYAN_CORE_PNG },
    { path: `${prefixRp}blocks.json`, data: RP_BLOCKS_JSON },
    { path: `${prefixRp}models/blocks/cyber_code_core.geo.json`, data: GEO_CYBER_CODE_CORE },
    { path: `${prefixRp}models/blocks/factory_a_gate.geo.json`, data: GEO_FACTORY_A_GATE },
    { path: `${prefixRp}textures/terrain_texture.json`, data: TERRAIN_TEXTURE_JSON },
    { path: `${prefixRp}textures/blocks/cyber_code_core.png`, data: CYAN_CORE_PNG },
    { path: `${prefixRp}textures/blocks/rgb_neon_frame.png`, data: CYAN_CORE_PNG },
    { path: `${prefixRp}textures/blocks/factory_a_alloy_wall.png`, data: CYAN_CORE_PNG },
    { path: `${prefixRp}textures/blocks/automated_crafter_node.png`, data: CYAN_CORE_PNG },
    { path: `${prefixRp}textures/blocks/vault_security_gate.png`, data: CYAN_CORE_PNG },
    { path: `${prefixRp}texts/en_US.lang`, data: langEn },
    { path: `${prefixRp}texts/ar_SA.lang`, data: langAr },
  ];
}

export function buildMinecraftFactoriesExpansionBlob(
  format: "mcaddon" | "mcworld"
): { blob: Blob; previewText: string } {
  if (format === "mcworld") {
    const worldEntries: ZipEntryInput[] = [
      { path: "levelname.txt", data: "Iraqi Coders Mega Factories World" },
      { path: "level.dat", data: createWorldLevelDat() },
      { path: "world_icon.jpeg", data: CYAN_CORE_PNG },
      {
        path: "world_behavior_packs.json",
        data: JSON.stringify(
          [{ pack_id: FACTORY_PACK_UUIDS.bpHeader, version: [2, 6, 4] }],
          null,
          2
        ),
      },
      {
        path: "world_resource_packs.json",
        data: JSON.stringify(
          [{ pack_id: FACTORY_PACK_UUIDS.rpHeader, version: [2, 6, 4] }],
          null,
          2
        ),
      },
      ...buildMinecraftFactoriesEntries(
        "behavior_packs/iraqi_coders_factories_bp/",
        "resource_packs/iraqi_coders_factories_rp/"
      ),
    ];
    const bytes = buildZipArchive(worldEntries);
    return {
      blob: new Blob([bytes.buffer as ArrayBuffer], {
        type: "application/octet-stream",
      }),
      previewText: FACTORY_MAIN_SCRIPT,
    };
  }

  const addonEntries = buildMinecraftFactoriesEntries(
    "iraqi_coders_factories_bp/",
    "iraqi_coders_factories_rp/"
  );
  const bytes = buildZipArchive(addonEntries);
  return {
    blob: new Blob([bytes.buffer as ArrayBuffer], {
      type: "application/octet-stream",
    }),
    previewText: FACTORY_MAIN_SCRIPT,
  };
}
