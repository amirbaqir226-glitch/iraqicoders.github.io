import { GoogleAuthProvider, signInWithPopup } from "firebase/auth";
import {
  firebaseAuth,
  getGmailAccessToken,
  googleProvider,
  setGmailAccessToken,
} from "../config/firebase";

export interface GmailHeaderMessage {
  id: string;
  threadId?: string;
  label: "INBOX" | "SENT";
  subject: string;
  from: string;
  to: string;
  date: string;
  snippet: string;
}

export type GmailMessageSummary = GmailHeaderMessage;

export function escapeHtml(unsafe: string): string {
  return unsafe
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function utf8ToBase64(str: string): string {
  const bytes = new TextEncoder().encode(str);
  let binary = "";
  for (let i = 0; i < bytes.length; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function utf8ToBase64Url(str: string): string {
  return utf8ToBase64(str)
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/g, "");
}

export async function authorizeGmailViaGooglePopup(): Promise<{
  token: string | null;
  email: string;
  displayName: string;
  uid: string;
  photoURL: string;
}> {
  const result = await signInWithPopup(firebaseAuth, googleProvider);
  const credential = GoogleAuthProvider.credentialFromResult(result);
  const token = credential?.accessToken || null;
  setGmailAccessToken(token);
  return {
    token,
    email: result.user.email || "",
    displayName: result.user.displayName || "مطور عراقي",
    uid: result.user.uid,
    photoURL: result.user.photoURL || "",
  };
}

export async function fetchGmailMessages(
  label: "INBOX" | "SENT",
  maxResults = 8
): Promise<GmailHeaderMessage[]> {
  const token = getGmailAccessToken();
  if (!token) {
    throw new Error("GMAIL_AUTH_REQUIRED");
  }

  const listRes = await fetch(
    `https://gmail.googleapis.com/gmail/v1/users/me/messages?labelIds=${encodeURIComponent(
      label
    )}&maxResults=${maxResults}`,
    {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
  );

  if (listRes.status === 401 || listRes.status === 403) {
    setGmailAccessToken(null);
    throw new Error("GMAIL_TOKEN_EXPIRED");
  }

  if (!listRes.ok) {
    throw new Error(`GMAIL_FETCH_ERROR_${listRes.status}`);
  }

  const listData = (await listRes.json()) as {
    messages?: Array<{ id: string; threadId?: string }>;
  };

  const ids = (listData.messages || []).slice(0, maxResults);
  if (ids.length === 0) return [];

  const details = await Promise.all(
    ids.map(async (item) => {
      try {
        const msgRes = await fetch(
          `https://gmail.googleapis.com/gmail/v1/users/me/messages/${encodeURIComponent(
            item.id
          )}?format=metadata&metadataHeaders=Subject&metadataHeaders=From&metadataHeaders=To&metadataHeaders=Date`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        if (!msgRes.ok) return null;
        const msgData = (await msgRes.json()) as {
          id: string;
          threadId?: string;
          snippet?: string;
          payload?: {
            headers?: Array<{ name?: string; value?: string }>;
          };
        };

        const headers = msgData.payload?.headers || [];
        const getHeader = (name: string) =>
          headers.find((h) => h.name?.toLowerCase() === name.toLowerCase())
            ?.value || "";

        return {
          id: msgData.id,
          threadId: msgData.threadId,
          label,
          subject: getHeader("Subject") || "(بدون عنوان)",
          from: getHeader("From") || "غير محدد",
          to: getHeader("To") || "حسابك",
          date: getHeader("Date") || "",
          snippet: msgData.snippet || "",
        } satisfies GmailHeaderMessage;
      } catch {
        return null;
      }
    })
  );

  return details.filter((d): d is NonNullable<typeof d> => d !== null);
}

export async function sendRealGmailMessage(params: {
  to: string;
  subject: string;
  htmlBody: string;
}): Promise<{ id: string; threadId?: string }> {
  const token = getGmailAccessToken();
  if (!token) {
    throw new Error("GMAIL_AUTH_REQUIRED");
  }

  const cleanTo = params.to.replace(/[\r\n]/g, "").trim();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanTo)) {
    throw new Error("البريد الإلكتروني للمستلم غير صالح.");
  }

  const cleanSubject = params.subject.replace(/[\r\n]/g, " ").trim();
  const encodedSubject = `=?UTF-8?B?${utf8ToBase64(cleanSubject)}?=`;
  const encodedHtml = utf8ToBase64(params.htmlBody);

  const mimeMessage = [
    `To: ${cleanTo}`,
    `Subject: ${encodedSubject}`,
    "MIME-Version: 1.0",
    'Content-Type: text/html; charset="UTF-8"',
    "Content-Transfer-Encoding: base64",
    "",
    encodedHtml,
  ].join("\r\n");

  const raw = utf8ToBase64Url(mimeMessage);

  const sendRes = await fetch(
    "https://gmail.googleapis.com/gmail/v1/users/me/messages/send",
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ raw }),
    }
  );

  if (sendRes.status === 401 || sendRes.status === 403) {
    setGmailAccessToken(null);
    throw new Error("GMAIL_TOKEN_EXPIRED");
  }

  if (!sendRes.ok) {
    const errText = await sendRes.text().catch(() => "");
    throw new Error(
      `فشل إرسال Gmail (${sendRes.status}): ${errText.slice(0, 140)}`
    );
  }

  return (await sendRes.json()) as { id: string; threadId?: string };
}

export function buildRankPromotionEmail(params: {
  recipientName: string;
  recipientEmail: string;
  rank: "moderator" | "developer" | "admin";
  assignerName: string;
}): {
  subject: string;
  greetingLine: string;
  congratsLine: string;
  textBody: string;
  htmlBody: string;
} {
  const rankMeta = {
    moderator: {
      subject: "مرحبا بك، لقد عيناك كمشرف — Iraqi Coders",
      greetingLine: "مرحبا بك، لقد عيناك كمشرف",
      congratsLine: "مبروك لقد أصبحت مشرف",
      badgeText: "رتبة مشرف معتمد · Moderator",
      accentHex: "#8B5CF6",
    },
    developer: {
      subject: "مرحبا بك، تم تعيينك كمطور — Iraqi Coders",
      greetingLine: "مرحبا بك، تم تعيينك كمطور",
      congratsLine: "مبروك لقد أصبحت مطور",
      badgeText: "رتبة مطور معتمد · Developer",
      accentHex: "#10B981",
    },
    admin: {
      subject: "مرحبا بك، تم تعيينك كمسؤول — Iraqi Coders",
      greetingLine: "مرحبا بك، تم تعيينك كمسؤول",
      congratsLine: "مبروك لقد صرت مسؤول",
      badgeText: "رتبة مسؤول النظام · Admin",
      accentHex: "#F59E0B",
    },
  }[params.rank];

  const safeName = escapeHtml(params.recipientName || "مطورنا العزيز");
  const safeAssigner = escapeHtml(params.assignerName || "إدارة عراقي كودرز");
  const safeEmail = escapeHtml(params.recipientEmail);

  const textBody = `${rankMeta.greetingLine}\n${rankMeta.congratsLine}\n\nمرحباً ${
    params.recipientName || "مطورنا"
  }، تم تحديث رتبتك في منصة عراقي كودرز (Iraqi Coders) من قِبل ${
    params.assignerName || "الإدارة"
  }.`;

  const htmlBody = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<body style="margin:0;padding:24px;background:#090D16;font-family:Tahoma,Arial,sans-serif;color:#F8FAFC;direction:rtl;">
  <div style="max-width:560px;margin:0 auto;background:#0F172A;border:1px solid ${rankMeta.accentHex};border-radius:18px;overflow:hidden;">
    <div style="padding:20px 24px;background:linear-gradient(135deg,#0B0F19,#1E1B4B);border-bottom:1px solid rgba(255,255,255,0.1);">
      <span style="display:inline-block;padding:4px 12px;border-radius:8px;background:${rankMeta.accentHex};color:#090D16;font-size:12px;font-weight:800;">
        ${rankMeta.badgeText}
      </span>
      <h1 style="margin:14px 0 6px;font-size:22px;color:#FFFFFF;">${rankMeta.greetingLine}</h1>
      <p style="margin:0;font-size:16px;font-weight:bold;color:#34D399;">${rankMeta.congratsLine}</p>
    </div>
    <div style="padding:22px 24px;line-height:1.8;font-size:14px;color:#CBD5E1;">
      <p style="margin:0 0 12px;">أهلاً <strong style="color:#FFFFFF;">${safeName}</strong>،</p>
      <p style="margin:0 0 12px;">
        نبارك لك ترقية حسابك (<span style="font-family:monospace;color:#38BDF8;">${safeEmail}</span>) داخل منصة
        <strong style="color:#FFFFFF;">عراقي كودرز · Iraqi Coders</strong>.
      </p>
      <div style="padding:14px;border-radius:12px;background:#090D16;border:1px solid rgba(255,255,255,0.08);margin-top:12px;">
        <div style="font-size:12px;color:#94A3B8;">تم منح الرتبة بواسطة:</div>
        <div style="font-size:14px;font-weight:bold;color:#FBBF24;margin-top:4px;">${safeAssigner}</div>
      </div>
    </div>
    <div style="padding:14px 24px;background:#090D16;font-size:11px;color:#64748B;text-align:center;">
      Iraqi Coders Official Notification · Gmail App Verified Alert
    </div>
  </div>
</body>
</html>`;

  return {
    subject: rankMeta.subject,
    greetingLine: rankMeta.greetingLine,
    congratsLine: rankMeta.congratsLine,
    textBody,
    htmlBody,
  };
}
