/**
 * محرك الصوت العربي والشخير (Web Speech API + Web Audio API)
 * يدعم صوت الروبوت المعلم، قراءة النصوص بالعربية الفصحى، وصوت الشخير للروبوت النائم
 */

let snoreIntervalId: number | null = null;
let audioCtxRef: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  if (typeof window === "undefined") return null;
  const Ctx =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext?: typeof AudioContext })
      .webkitAudioContext;
  if (!Ctx) return null;
  if (!audioCtxRef) {
    audioCtxRef = new Ctx();
  }
  if (audioCtxRef.state === "suspended") {
    void audioCtxRef.resume().catch(() => undefined);
  }
  return audioCtxRef;
}

export function stopArabicSpeech(): void {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
  try {
    window.speechSynthesis.cancel();
  } catch {
    // Safe fallback
  }
}

export function speakArabicText(
  rawText: string,
  options?: {
    voiceProfile?: "robot-male" | "fusha-clear";
    pitch?: number;
    rate?: number;
    onEnd?: () => void;
  }
): boolean {
  const text = rawText.replace(/\s+/g, " ").trim();
  if (!text) return false;

  if (typeof window === "undefined" || !("speechSynthesis" in window)) {
    playSoftUiTone(options?.voiceProfile === "robot-male" ? 420 : 560);
    return false;
  }

  try {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = "ar-SA";

    const voices = window.speechSynthesis.getVoices();
    const arabicVoices = voices.filter((v) =>
      v.lang.toLowerCase().startsWith("ar")
    );

    if (arabicVoices.length > 0) {
      if (options?.voiceProfile === "robot-male") {
        const malePreferred =
          arabicVoices.find((v) =>
            /male|naayf|tariq|maged|hamed|hamdan|omar|zaid|google/i.test(v.name)
          ) || arabicVoices[0];
        utterance.voice = malePreferred;
      } else {
        const fushaPreferred =
          arabicVoices.find((v) => /sa|eg|iq|ar/i.test(v.lang)) ||
          arabicVoices[0];
        utterance.voice = fushaPreferred;
      }
    }

    utterance.pitch =
      options?.pitch ?? (options?.voiceProfile === "robot-male" ? 0.92 : 1.0);
    utterance.rate =
      options?.rate ?? (options?.voiceProfile === "robot-male" ? 0.98 : 0.95);
    utterance.volume = 1;

    if (options?.onEnd) {
      utterance.onend = options.onEnd;
      utterance.onerror = options.onEnd;
    }

    window.speechSynthesis.speak(utterance);
    return true;
  } catch {
    playSoftUiTone(480);
    return false;
  }
}

export function playSoftUiTone(freq = 520): void {
  const ctx = getAudioContext();
  if (!ctx) return;
  try {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(freq, ctx.currentTime);
    gain.gain.setValueAtTime(0.04, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.16);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.17);
  } catch {
    // Safe fallback
  }
}

function playSingleSnoreBreath(): void {
  const ctx = getAudioContext();
  if (!ctx || ctx.state !== "running") return;
  try {
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const filter = ctx.createBiquadFilter();
    const gain = ctx.createGain();

    osc.type = "sawtooth";
    osc.frequency.setValueAtTime(86, now);
    osc.frequency.linearRampToValueAtTime(72, now + 0.45);
    osc.frequency.linearRampToValueAtTime(94, now + 0.85);

    filter.type = "lowpass";
    filter.frequency.setValueAtTime(260, now);

    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.032, now + 0.25);
    gain.gain.linearRampToValueAtTime(0.018, now + 0.65);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.95);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.98);
  } catch {
    // Ignore autoplay lock errors silently
  }
}

export function startSnoringSound(): void {
  if (typeof window === "undefined") return;
  stopSnoringSound();
  getAudioContext();
  playSingleSnoreBreath();
  snoreIntervalId = window.setInterval(() => {
    playSingleSnoreBreath();
  }, 2400);
}

export function stopSnoringSound(): void {
  if (snoreIntervalId !== null) {
    window.clearInterval(snoreIntervalId);
    snoreIntervalId = null;
  }
}
