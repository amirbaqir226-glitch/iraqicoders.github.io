export interface DomScanMatchResult {
  matched: boolean;
  code: string;
  scannedNodesCount: number;
  durationMs: number;
  sourceHint: string;
}

/**
 * Normalizes a pairing code for consistent DOM matching.
 */
export function normalizePairingCode(raw: string): string {
  return raw
    .trim()
    .toUpperCase()
    .replace(/[^A-Z0-9-]/g, "");
}

function escapeRegExp(str: string): string {
  return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function isElementVisible(el: Element | null): boolean {
  if (!el || !(el instanceof HTMLElement)) return false;
  const style = window.getComputedStyle(el);
  if (
    style.display === "none" ||
    style.visibility === "hidden" ||
    Number(style.opacity) === 0
  ) {
    return false;
  }
  const rect = el.getBoundingClientRect();
  return rect.width > 0 || rect.height > 0;
}

/**
 * Actively scans the entire rendered page DOM (all visible text nodes & live pairing attributes,
 * excluding scripts, styles, and input/ignore zones) to verify whether the entered pairing code
 * is authentically rendered live on the platform screen.
 */
export function scanLiveScreenDomForCode(
  enteredCode: string
): DomScanMatchResult {
  const start =
    typeof performance !== "undefined" ? performance.now() : Date.now();
  const normalized = normalizePairingCode(enteredCode);

  if (!normalized || normalized.length < 4 || typeof document === "undefined") {
    return {
      matched: false,
      code: normalized,
      scannedNodesCount: 0,
      durationMs: 0,
      sourceHint: "رمز غير صالح",
    };
  }

  // Exact token boundary match (case-insensitive)
  const tokenRegex = new RegExp(
    `(^|[^A-Z0-9-])${escapeRegExp(normalized)}([^A-Z0-9-]|$)`,
    "i"
  );

  let scannedNodesCount = 0;
  let matchedElement: HTMLElement | null = null;
  let sourceHint = "";

  const walker = document.createTreeWalker(
    document.body,
    NodeFilter.SHOW_TEXT,
    {
      acceptNode(node) {
        const parent = node.parentElement;
        if (!parent) return NodeFilter.FILTER_REJECT;

        const tag = parent.tagName;
        if (
          tag === "SCRIPT" ||
          tag === "STYLE" ||
          tag === "NOSCRIPT" ||
          tag === "TEXTAREA" ||
          tag === "INPUT"
        ) {
          return NodeFilter.FILTER_REJECT;
        }

        // Ignore scanner inputs, placeholder examples, and toast messages so they don't self-match
        if (parent.closest('[data-dom-scan-ignore="true"]')) {
          return NodeFilter.FILTER_REJECT;
        }

        if (!node.nodeValue || !node.nodeValue.trim()) {
          return NodeFilter.FILTER_SKIP;
        }

        return NodeFilter.FILTER_ACCEPT;
      },
    }
  );

  let currentNode = walker.nextNode();
  while (currentNode) {
    scannedNodesCount += 1;
    const text = (currentNode.nodeValue || "").trim().toUpperCase();
    if (text.includes(normalized) && tokenRegex.test(text)) {
      const parentEl = currentNode.parentElement;
      if (isElementVisible(parentEl)) {
        matchedElement = parentEl;
        sourceHint =
          parentEl?.getAttribute("data-live-pairing-code") !== null
            ? "بطاقة الاقتران الحية على الشاشة"
            : "محتوى الشاشة الحية (DOM)";
        break;
      }
    }
    currentNode = walker.nextNode();
  }

  // Also check explicit live pairing data-attributes if rendered cleanly
  if (!matchedElement) {
    const liveBadges = document.querySelectorAll("[data-live-pairing-code]");
    for (const badge of Array.from(liveBadges)) {
      scannedNodesCount += 1;
      if (badge.closest('[data-dom-scan-ignore="true"]')) continue;
      const attrVal = normalizePairingCode(
        badge.getAttribute("data-live-pairing-code") || ""
      );
      const visibleText = normalizePairingCode(badge.textContent || "");
      if (
        (attrVal === normalized || visibleText === normalized) &&
        isElementVisible(badge)
      ) {
        matchedElement = badge as HTMLElement;
        sourceHint = "شارة الاقتران الحية على الشاشة";
        break;
      }
    }
  }

  if (matchedElement) {
    matchedElement.classList.remove("teleport-highlight");
    void matchedElement.offsetWidth;
    matchedElement.classList.add("teleport-highlight");
    window.setTimeout(() => {
      matchedElement?.classList.remove("teleport-highlight");
    }, 1500);
  }

  const end =
    typeof performance !== "undefined" ? performance.now() : Date.now();
  const durationMs = Math.max(0.1, Number((end - start).toFixed(2)));

  return {
    matched: Boolean(matchedElement),
    code: normalized,
    scannedNodesCount,
    durationMs,
    sourceHint: matchedElement ? sourceHint : "غير موجود على الشاشة",
  };
}
