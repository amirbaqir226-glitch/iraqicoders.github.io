import { STORAGE_KEYS } from "../config/firebase";

export type OfflinePackId =
  | "shop-catalog"
  | "projects-studio"
  | "community-challenges"
  | "academy-tools"
  | "all-site";

export interface OfflinePackDefinition {
  id: OfflinePackId;
  title: string;
  description: string;
  sizeMb: number;
  isFullSite?: boolean;
  endpoints: string[];
}

export interface DownloadedPackRecord {
  id: OfflinePackId;
  title: string;
  sizeMb: number;
  downloadedAt: string;
  cachedAssetsCount: number;
}

export interface DownloadProgressSnapshot {
  packId: OfflinePackId;
  percent: number;
  downloadedMb: number;
  totalMb: number;
}

export const OFFLINE_CACHE_NAME = "iraqi-coders-offline-v1";

export const OFFLINE_DOWNLOAD_PACKS: OfflinePackDefinition[] = [
  {
    id: "shop-catalog",
    title: "المتجر ومنتجات عراقي كودرز",
    description:
      "يحفظ كتالوج المنتجات، الأسعار، تفاصيل الباقات والعروض لتصفح المتجر دون اتصال.",
    sizeMb: 2.4,
    endpoints: ["/api/shop-products"],
  },
  {
    id: "projects-studio",
    title: "مكتبة Roblox و Minecraft والمشاريع",
    description:
      "يحفظ مشاريع المجتمع الجاهزة، ملفات السكربتات، ومركز البيانات للتصفح المحلي.",
    sizeMb: 4.8,
    endpoints: ["/api/beta-projects", "/api/cloud-files"],
  },
  {
    id: "community-challenges",
    title: "التحديات والمنتدى والتحديثات",
    description:
      "يحفظ أسئلة التحديات، منشورات المنتدى، وإشعارات المدرسة للتصفح السريع دون إنترنت.",
    sizeMb: 3.1,
    endpoints: [
      "/api/challenges",
      "/api/forum-posts",
      "/api/updates",
      "/api/school-updates",
    ],
  },
  {
    id: "academy-tools",
    title: "محرر الكود والمبرمج ومصمم المشاريع",
    description:
      "يحفظ واجهات المحرر والقوالب وملفات التشغيل الأساسية لتشغيل الأدوات المحلية أوفلاين.",
    sizeMb: 3.6,
    endpoints: ["/"],
  },
  {
    id: "all-site",
    title: "تنزيل كل الموقع (حزمة العمل الكامل بدون إنترنت)",
    description:
      "تنزيل شامل للواجهة الكاملة، السكربتات، الأيقونات، وبيانات جميع الأقسام للعمل دون إنترنت.",
    sizeMb: 13.9,
    isFullSite: true,
    endpoints: [
      "/",
      "/index.html",
      "/manifest.webmanifest",
      "/icon.svg",
      "/pwa-192x192.png",
      "/api/shop-products",
      "/api/challenges",
      "/api/updates",
      "/api/beta-projects",
      "/api/school-updates",
      "/api/forum-posts",
      "/api/cloud-files",
    ],
  },
];

export function loadDownloadedPacks(): DownloadedPackRecord[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.OFFLINE_DOWNLOADS);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as DownloadedPackRecord[]) : [];
  } catch {
    return [];
  }
}

export function saveDownloadedPacks(records: DownloadedPackRecord[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.OFFLINE_DOWNLOADS, JSON.stringify(records));
  } catch {
    // Safe storage fallback
  }
}

function collectRuntimeAssetUrls(): string[] {
  if (typeof document === "undefined") return [];
  const urls = new Set<string>(["/", "/index.html"]);
  document.querySelectorAll<HTMLScriptElement>("script[src]").forEach((el) => {
    if (el.src && el.src.startsWith(window.location.origin)) {
      urls.add(el.src);
    }
  });
  document
    .querySelectorAll<HTMLLinkElement>('link[rel="stylesheet"][href]')
    .forEach((el) => {
      if (el.href && el.href.startsWith(window.location.origin)) {
        urls.add(el.href);
      }
    });
  return Array.from(urls);
}

function waitMs(ms: number): Promise<void> {
  return new Promise((resolve) => window.setTimeout(resolve, ms));
}

export async function downloadOfflinePack(
  packId: OfflinePackId,
  onProgress: (snapshot: DownloadProgressSnapshot) => void
): Promise<DownloadedPackRecord[]> {
  const pack = OFFLINE_DOWNLOAD_PACKS.find((p) => p.id === packId);
  if (!pack) {
    throw new Error("الحزمة المطلوبة غير موجودة.");
  }

  // Strictly proportional duration: ~250ms per MB so bigger packs visibly take longer
  const totalDurationMs = Math.max(600, Math.round(pack.sizeMb * 250));
  const steps = Math.max(12, Math.min(32, Math.round(pack.sizeMb * 2.5)));
  const stepDelayMs = Math.round(totalDurationMs / steps);

  const urlsToCache = new Set<string>(pack.endpoints);
  if (pack.isFullSite || pack.id === "academy-tools") {
    collectRuntimeAssetUrls().forEach((u) => urlsToCache.add(u));
  }

  let cachedAssetsCount = 0;

  const cacheOperationPromise = (async () => {
    if (typeof window === "undefined" || !("caches" in window)) {
      return;
    }
    const cache = await caches.open(OFFLINE_CACHE_NAME);
    const list = Array.from(urlsToCache);

    await Promise.all(
      list.map(async (targetUrl) => {
        try {
          const resp = await fetch(targetUrl, { cache: "no-store" });
          if (resp.ok) {
            await cache.put(targetUrl, resp.clone());
            cachedAssetsCount += 1;
          }
        } catch {
          // Skip individual non-critical network failures while keeping remaining assets cached
        }
      })
    );

    // Store an explicit offline manifest snapshot per downloaded pack
    try {
      const snapshotPayload = JSON.stringify({
        packId: pack.id,
        title: pack.title,
        sizeMb: pack.sizeMb,
        downloadedAt: new Date().toISOString(),
        urls: list,
      });
      await cache.put(
        `/__offline_packs__/${pack.id}.json`,
        new Response(snapshotPayload, {
          headers: { "Content-Type": "application/json; charset=utf-8" },
        })
      );
    } catch {
      // Safe no-op
    }
  })();

  // Emit smooth proportional progress matching the pack MB size
  for (let i = 1; i <= steps; i++) {
    await waitMs(stepDelayMs);
    const ratio = i / steps;
    onProgress({
      packId: pack.id,
      percent: Math.min(100, Math.round(ratio * 100)),
      downloadedMb: Number((pack.sizeMb * ratio).toFixed(2)),
      totalMb: pack.sizeMb,
    });
  }

  await cacheOperationPromise;

  const nowStr = new Date().toLocaleString("ar-IQ");
  const existing = loadDownloadedPacks();
  const nextMap = new Map<OfflinePackId, DownloadedPackRecord>(
    existing.map((rec) => [rec.id, rec])
  );

  if (pack.isFullSite) {
    // Full site includes every individual section
    OFFLINE_DOWNLOAD_PACKS.forEach((p) => {
      nextMap.set(p.id, {
        id: p.id,
        title: p.title,
        sizeMb: p.sizeMb,
        downloadedAt: nowStr,
        cachedAssetsCount: Math.max(1, cachedAssetsCount),
      });
    });
  } else {
    nextMap.set(pack.id, {
      id: pack.id,
      title: pack.title,
      sizeMb: pack.sizeMb,
      downloadedAt: nowStr,
      cachedAssetsCount: Math.max(1, cachedAssetsCount),
    });
  }

  const nextRecords = Array.from(nextMap.values());
  saveDownloadedPacks(nextRecords);
  return nextRecords;
}

export async function removeOfflinePack(
  packId: OfflinePackId
): Promise<DownloadedPackRecord[]> {
  if (typeof window !== "undefined" && "caches" in window) {
    try {
      if (packId === "all-site") {
        await caches.delete(OFFLINE_CACHE_NAME);
      } else {
        const cache = await caches.open(OFFLINE_CACHE_NAME);
        await cache.delete(`/__offline_packs__/${packId}.json`);
      }
    } catch {
      // Safe fallback
    }
  }

  const current = loadDownloadedPacks();
  const next =
    packId === "all-site"
      ? []
      : current.filter((rec) => rec.id !== packId && rec.id !== "all-site");
  saveDownloadedPacks(next);
  return next;
}
