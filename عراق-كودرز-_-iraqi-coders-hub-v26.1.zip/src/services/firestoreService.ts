import { User } from "firebase/auth";
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  Timestamp,
  updateDoc,
  where,
} from "firebase/firestore";
import {
  db,
  firebaseAuth,
  handleFirestoreError,
  isOwnerEmail,
  OperationType,
} from "../config/firebase";
import { DEFAULT_DEVELOPER_AVATAR } from "../data/initialData";
import {
  AdminRoleRequest,
  CloudFileItem,
  CloudFileType,
  CloudVisibility,
  CustomNationalityCard,
  ForumPost,
  PlatformAiUpdate,
  PlatformMessageRecord,
  PlatformUpdateAccent,
  PlatformUpdateFeatureType,
  PlatformUpdateVisibility,
  PostTopic,
  ThemeDecoration,
  UserEconomy,
  UserProfile,
  UserRole,
} from "../types";

const safeSlice = (val: string, max: number) => val.trim().slice(0, max);

const VALID_THEMES: ThemeDecoration[] = [
  "default",
  "halloween",
  "cyber",
  "electric",
  "fantasy",
];

const VALID_ROLES: UserRole[] = [
  "user",
  "developer",
  "moderator",
  "director",
  "admin",
];

function sanitizeRole(raw: unknown, email?: string | null): UserRole {
  if (isOwnerEmail(email)) return "admin";
  return VALID_ROLES.includes(raw as UserRole) ? (raw as UserRole) : "user";
}

function toFirestoreUserRole(
  role: UserRole
): "user" | "developer" | "moderator" | "director" | "admin" {
  if (role === "admin") return "admin";
  if (role === "director") return "director";
  if (role === "moderator") return "moderator";
  if (role === "developer") return "developer";
  return "user";
}

function sanitizeTheme(raw: unknown): ThemeDecoration {
  return VALID_THEMES.includes(raw as ThemeDecoration)
    ? (raw as ThemeDecoration)
    : "default";
}

function buildDefaultHandle(fbUser: User): string {
  const base =
    (fbUser.email?.split("@")[0] || fbUser.displayName || "iraqi_dev")
      .replace(/[^a-zA-Z0-9_]/g, "")
      .toLowerCase() || `dev_${fbUser.uid.slice(0, 6)}`;
  return `@${base.slice(0, 28)}`;
}

function formatTimestampArabic(ts: unknown): string {
  if (ts instanceof Timestamp) {
    return ts.toDate().toLocaleString("ar-IQ", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  }
  return "الآن";
}

export async function syncUserProfileToFirestore(
  fbUser: User,
  defaults?: {
    city?: string;
    role?: UserRole;
    themeDecoration?: ThemeDecoration;
    desktopMode?: boolean;
  }
): Promise<{
  displayName: string;
  handle: string;
  city: string;
  avatarUrl: string;
  role: UserRole;
  themeDecoration: ThemeDecoration;
  desktopMode: boolean;
} | null> {
  if (!fbUser.emailVerified) return null;

  const publicPath = `users/${fbUser.uid}`;
  const privatePath = `users_private/${fbUser.uid}`;
  let syncedProfile: {
    displayName: string;
    handle: string;
    city: string;
    avatarUrl: string;
    role: UserRole;
    themeDecoration: ThemeDecoration;
    desktopMode: boolean;
  } | null = null;

  try {
    const userRef = doc(db, "users", fbUser.uid);
    const existingSnap = await getDoc(userRef);

    if (!existingSnap.exists()) {
      const displayName = safeSlice(fbUser.displayName || "مطور عراقي", 120);
      const handle = safeSlice(buildDefaultHandle(fbUser), 40);
      const city = safeSlice(defaults?.city || "بغداد", 60);
      const avatarUrl = safeSlice(
        fbUser.photoURL || DEFAULT_DEVELOPER_AVATAR,
        120000
      );
      const role = sanitizeRole(defaults?.role || "user", fbUser.email);
      const themeDecoration = sanitizeTheme(defaults?.themeDecoration);
      const desktopMode = Boolean(defaults?.desktopMode);

      await setDoc(userRef, {
        uid: safeSlice(fbUser.uid, 128),
        displayName,
        handle,
        city,
        avatarUrl,
        role: toFirestoreUserRole(role),
        themeDecoration,
        desktopMode,
        updatedAt: serverTimestamp(),
      });

      syncedProfile = {
        displayName,
        handle,
        city,
        avatarUrl,
        role,
        themeDecoration,
        desktopMode,
      };
    } else {
      const data = existingSnap.data();
      const resolvedRole = sanitizeRole(data.role, fbUser.email);
      syncedProfile = {
        displayName: safeSlice(
          String(data.displayName || fbUser.displayName || "مطور عراقي"),
          120
        ),
        handle: safeSlice(
          String(data.handle || buildDefaultHandle(fbUser)),
          40
        ),
        city: safeSlice(String(data.city || defaults?.city || "بغداد"), 60),
        avatarUrl: safeSlice(
          String(data.avatarUrl || fbUser.photoURL || DEFAULT_DEVELOPER_AVATAR),
          120000
        ),
        role: resolvedRole,
        themeDecoration: sanitizeTheme(data.themeDecoration),
        desktopMode: Boolean(data.desktopMode),
      };

      // Backfill role on legacy docs lacking it
      if (!data.role) {
        await updateDoc(userRef, {
          displayName: syncedProfile.displayName,
          handle: syncedProfile.handle,
          city: syncedProfile.city,
          avatarUrl: syncedProfile.avatarUrl,
          role: toFirestoreUserRole(resolvedRole),
          themeDecoration: syncedProfile.themeDecoration,
          desktopMode: syncedProfile.desktopMode,
          updatedAt: serverTimestamp(),
        }).catch(() => undefined);
      }
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, publicPath);
  }

  try {
    const privateRef = doc(db, "users_private", fbUser.uid);
    const existing = await getDoc(privateRef);
    if (!existing.exists()) {
      await setDoc(privateRef, {
        uid: safeSlice(fbUser.uid, 128),
        email: safeSlice(fbUser.email || "user@iraqicoders.iq", 254),
        comedyBanned: false,
        updatedAt: serverTimestamp(),
      });
    } else {
      await updateDoc(privateRef, {
        comedyBanned: Boolean(existing.data()?.comedyBanned),
        updatedAt: serverTimestamp(),
      });
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, privatePath);
  }

  return syncedProfile;
}

export async function updateUserProfileInFirestore(
  uid: string,
  updates: {
    displayName: string;
    handle: string;
    city: string;
    avatarUrl: string;
    role?: UserRole;
    themeDecoration: ThemeDecoration;
    desktopMode: boolean;
  }
): Promise<void> {
  const currentUser = firebaseAuth.currentUser;
  if (!currentUser || !currentUser.emailVerified || currentUser.uid !== uid) {
    return;
  }

  const path = `users/${uid}`;
  try {
    const safeRole = sanitizeRole(updates.role || "user", currentUser.email);
    await updateDoc(doc(db, "users", uid), {
      displayName: safeSlice(updates.displayName || "مطور عراقي", 120),
      handle: safeSlice(updates.handle || "@iraqi_dev", 40),
      city: safeSlice(updates.city || "بغداد", 60),
      avatarUrl: safeSlice(
        updates.avatarUrl || DEFAULT_DEVELOPER_AVATAR,
        120000
      ),
      role:
        safeRole === "admin" && !isOwnerEmail(currentUser.email)
          ? "developer"
          : toFirestoreUserRole(safeRole),
      themeDecoration: sanitizeTheme(updates.themeDecoration),
      desktopMode: Boolean(updates.desktopMode),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function upgradeUserToDeveloperInFirestore(
  uid: string
): Promise<void> {
  const currentUser = firebaseAuth.currentUser;
  if (!currentUser || !currentUser.emailVerified || currentUser.uid !== uid) {
    return;
  }
  const path = `users/${uid}`;
  try {
    await updateDoc(doc(db, "users", uid), {
      role: "developer",
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function fetchAllUsersForAdmin(): Promise<UserProfile[]> {
  const currentUser = firebaseAuth.currentUser;
  if (!currentUser || !currentUser.emailVerified) return [];

  const path = "users";
  try {
    const snap = await getDocs(collection(db, path));
    return snap.docs.map((docSnap) => {
      const d = docSnap.data();
      return {
        id: String(d.uid || docSnap.id),
        name: String(d.displayName || "مطور عراقي"),
        handle: String(d.handle || "@iraqi_dev"),
        email: "",
        avatarUrl: String(d.avatarUrl || DEFAULT_DEVELOPER_AVATAR),
        provider: "google",
        city: String(d.city || "العراق"),
        role: sanitizeRole(d.role),
        themeDecoration: sanitizeTheme(d.themeDecoration),
        desktopMode: Boolean(d.desktopMode),
        loggedInAt: formatTimestampArabic(d.updatedAt),
      } satisfies UserProfile;
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
  }
}

export async function updateUserRoleByAdminInFirestore(
  uid: string,
  nextRole: UserRole
): Promise<void> {
  const currentUser = firebaseAuth.currentUser;
  if (!currentUser || !currentUser.emailVerified) return;

  const path = `users/${uid}`;
  try {
    await updateDoc(doc(db, "users", uid), {
      role: toFirestoreUserRole(sanitizeRole(nextRole)),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function updateComedyBanInFirestore(
  uid: string,
  comedyBanned: boolean
): Promise<void> {
  if (!firebaseAuth.currentUser?.emailVerified) return;
  const path = `users_private/${uid}`;
  try {
    await updateDoc(doc(db, "users_private", uid), {
      comedyBanned,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export function subscribeToCloudForumPosts(
  onPosts: (posts: ForumPost[]) => void
): () => void {
  const path = "forum_posts";
  const q = query(collection(db, path), where("visibility", "==", "public"));

  return onSnapshot(
    q,
    (snapshot) => {
      const docs = snapshot.docs.map((docSnap) => {
        const d = docSnap.data();
        const createdAtMs =
          d.createdAt instanceof Timestamp ? d.createdAt.toMillis() : 0;
        return {
          createdAtMs,
          post: {
            id: String(d.id || docSnap.id),
            title: String(d.title || ""),
            content: String(d.content || ""),
            topic: (d.topic as PostTopic) || "general",
            topicLabel: String(d.topicLabel || "نقاش عام"),
            authorName: String(d.authorName || "مطور عراقي"),
            authorCity: String(d.authorCity || "العراق"),
            authorAvatar: String(d.authorAvatar || DEFAULT_DEVELOPER_AVATAR),
            createdAt: formatTimestampArabic(d.createdAt),
            likes: 0,
            likedByUser: false,
            replies: [],
          } satisfies ForumPost,
        };
      });

      docs.sort((a, b) => b.createdAtMs - a.createdAtMs);
      onPosts(docs.map((item) => item.post));
    },
    (error) => {
      handleFirestoreError(error, OperationType.GET, path);
    }
  );
}

export async function createForumPostInFirestore(params: {
  postId: string;
  title: string;
  content: string;
  topic: PostTopic;
  topicLabel: string;
  authorCity: string;
}): Promise<void> {
  const currentUser = firebaseAuth.currentUser;
  if (!currentUser || !currentUser.emailVerified) return;

  const path = `forum_posts/${params.postId}`;
  try {
    await setDoc(doc(db, "forum_posts", params.postId), {
      id: safeSlice(params.postId, 128),
      authorId: safeSlice(currentUser.uid, 128),
      authorName: safeSlice(currentUser.displayName || "مطور عراقي", 120),
      authorCity: safeSlice(params.authorCity || "العراق", 60),
      authorAvatar: safeSlice(
        currentUser.photoURL || DEFAULT_DEVELOPER_AVATAR,
        120000
      ),
      title: safeSlice(params.title, 200),
      content: safeSlice(params.content, 4000),
      topic: params.topic,
      topicLabel: safeSlice(params.topicLabel, 40),
      visibility: "public",
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function deleteForumPostInFirestore(postId: string): Promise<void> {
  const currentUser = firebaseAuth.currentUser;
  if (!currentUser || !currentUser.emailVerified) return;

  const path = `forum_posts/${postId}`;
  try {
    await deleteDoc(doc(db, "forum_posts", postId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

function mapCloudFileSnapshot(
  docSnap: { id: string; data: () => Record<string, unknown> }
): { createdAtMs: number; file: CloudFileItem } {
  const d = docSnap.data();
  const createdAtMs =
    d.createdAt instanceof Timestamp ? d.createdAt.toMillis() : 0;
  return {
    createdAtMs,
    file: {
      id: String(d.id || docSnap.id),
      ownerId: String(d.ownerId || ""),
      ownerName: String(d.ownerName || "مطور عراقي"),
      ownerHandle: String(d.ownerHandle || "@iraqi_dev"),
      title: String(d.title || "مشروع سحابي"),
      description: String(d.description || ""),
      fileName: String(d.fileName || "project.txt"),
      fileType: (d.fileType as CloudFileType) || "code",
      fileSizeBytes: Number(d.fileSizeBytes || 0),
      content: String(d.content || ""),
      visibility: (d.visibility as CloudVisibility) || "private",
      downloads: Number(d.downloads || 0),
      createdAt: formatTimestampArabic(d.createdAt),
    },
  };
}

export function subscribeToPublicCloudFiles(
  onFiles: (files: CloudFileItem[]) => void
): () => void {
  const path = "cloud_files";
  const q = query(collection(db, path), where("visibility", "==", "public"));

  return onSnapshot(
    q,
    (snapshot) => {
      const docs = snapshot.docs.map((docSnap) =>
        mapCloudFileSnapshot(
          docSnap as unknown as {
            id: string;
            data: () => Record<string, unknown>;
          }
        )
      );
      docs.sort((a, b) => b.createdAtMs - a.createdAtMs);
      onFiles(docs.map((d) => d.file));
    },
    (error) => {
      handleFirestoreError(error, OperationType.LIST, path);
    }
  );
}

export function subscribeToPrivateCloudFiles(
  ownerId: string,
  onFiles: (files: CloudFileItem[]) => void
): () => void {
  const path = "cloud_files";
  const q = query(collection(db, path), where("ownerId", "==", ownerId));

  return onSnapshot(
    q,
    (snapshot) => {
      const docs = snapshot.docs.map((docSnap) =>
        mapCloudFileSnapshot(
          docSnap as unknown as {
            id: string;
            data: () => Record<string, unknown>;
          }
        )
      );
      docs.sort((a, b) => b.createdAtMs - a.createdAtMs);
      onFiles(docs.map((d) => d.file));
    },
    (error) => {
      handleFirestoreError(error, OperationType.LIST, path);
    }
  );
}

export async function createCloudFileInFirestore(
  item: CloudFileItem
): Promise<void> {
  const currentUser = firebaseAuth.currentUser;
  if (!currentUser || !currentUser.emailVerified) return;

  const path = `cloud_files/${item.id}`;
  try {
    await setDoc(doc(db, "cloud_files", item.id), {
      id: safeSlice(item.id, 128),
      ownerId: safeSlice(currentUser.uid, 128),
      ownerName: safeSlice(
        item.ownerName || currentUser.displayName || "مطور عراقي",
        120
      ),
      ownerHandle: safeSlice(item.ownerHandle || "@iraqi_dev", 40),
      title: safeSlice(item.title, 160),
      description: safeSlice(item.description || "ملف مشروع سحابي", 1500),
      fileName: safeSlice(item.fileName, 160),
      fileType: item.fileType,
      fileSizeBytes: Math.max(0, Math.round(item.fileSizeBytes)),
      content: item.content.slice(0, 380000),
      visibility: item.visibility,
      downloads: Math.max(0, Math.round(item.downloads)),
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function updateCloudFileVisibilityInFirestore(
  fileId: string,
  visibility: CloudVisibility
): Promise<void> {
  const currentUser = firebaseAuth.currentUser;
  if (!currentUser || !currentUser.emailVerified) return;

  const path = `cloud_files/${fileId}`;
  try {
    await updateDoc(doc(db, "cloud_files", fileId), {
      visibility,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function incrementCloudFileDownloadsInFirestore(
  fileId: string,
  nextDownloads: number
): Promise<void> {
  const currentUser = firebaseAuth.currentUser;
  if (!currentUser || !currentUser.emailVerified) return;

  const path = `cloud_files/${fileId}`;
  try {
    await updateDoc(doc(db, "cloud_files", fileId), {
      downloads: Math.max(0, Math.round(nextDownloads)),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function deleteCloudFileInFirestore(fileId: string): Promise<void> {
  const currentUser = firebaseAuth.currentUser;
  if (!currentUser || !currentUser.emailVerified) return;

  const path = `cloud_files/${fileId}`;
  try {
    await deleteDoc(doc(db, "cloud_files", fileId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export async function syncUserEconomyFromFirestore(
  uid: string
): Promise<UserEconomy | null> {
  const currentUser = firebaseAuth.currentUser;
  if (!currentUser || !currentUser.emailVerified || currentUser.uid !== uid) {
    return null;
  }

  const path = `users_economy/${uid}`;
  try {
    const ref = doc(db, "users_economy", uid);
    const snap = await getDoc(ref);
    if (!snap.exists()) {
      const initial: UserEconomy = {
        activeSeconds: 60,
        coins: 50,
        unlockedItems: [],
        equippedSkin: "default",
      };
      await setDoc(ref, {
        uid: safeSlice(uid, 128),
        activeSeconds: initial.activeSeconds,
        coins: initial.coins,
        unlockedItems: initial.unlockedItems,
        equippedSkin: initial.equippedSkin,
        updatedAt: serverTimestamp(),
      });
      return initial;
    }

    const d = snap.data();
    return {
      activeSeconds: Math.max(0, Number(d.activeSeconds || 0)),
      coins: Math.max(0, Number(d.coins || 0)),
      unlockedItems: Array.isArray(d.unlockedItems)
        ? d.unlockedItems.map((x) => String(x)).slice(0, 50)
        : [],
      equippedSkin: safeSlice(String(d.equippedSkin || "default"), 40),
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

export async function saveUserEconomyToFirestore(
  uid: string,
  economy: UserEconomy
): Promise<void> {
  const currentUser = firebaseAuth.currentUser;
  if (!currentUser || !currentUser.emailVerified || currentUser.uid !== uid) {
    return;
  }

  const path = `users_economy/${uid}`;
  try {
    await setDoc(
      doc(db, "users_economy", uid),
      {
        uid: safeSlice(uid, 128),
        activeSeconds: Math.max(
          0,
          Math.min(100000000, Math.round(economy.activeSeconds))
        ),
        coins: Math.max(0, Math.min(100000000, Math.round(economy.coins))),
        unlockedItems: economy.unlockedItems
          .map((x) => safeSlice(x, 60))
          .slice(0, 50),
        equippedSkin: safeSlice(economy.equippedSkin || "default", 40),
        updatedAt: serverTimestamp(),
      },
      { merge: true }
    );
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function savePlatformSettingsInFirestore(
  assistantUrl: string,
  assistantTitle: string
): Promise<void> {
  const currentUser = firebaseAuth.currentUser;
  if (!currentUser || !currentUser.emailVerified) return;

  const path = "platform_settings/public_bot";
  try {
    await setDoc(doc(db, "platform_settings", "public_bot"), {
      assistantUrl: safeSlice(assistantUrl, 500),
      assistantTitle: safeSlice(assistantTitle, 120),
      updatedBy: safeSlice(currentUser.uid, 128),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function saveExtensionPairingInFirestore(params: {
  id: string;
  code: string;
  extensionName: string;
  browser: string;
  status: "waiting" | "pending_confirm" | "paired" | "rejected" | "revoked";
  feedbackMessage?: string;
}): Promise<void> {
  const currentUser = firebaseAuth.currentUser;
  if (!currentUser || !currentUser.emailVerified) return;

  const path = `extension_pairings/${params.id}`;
  try {
    await setDoc(doc(db, "extension_pairings", params.id), {
      id: safeSlice(params.id, 128),
      ownerId: safeSlice(currentUser.uid, 128),
      code: safeSlice(params.code, 20),
      extensionName: safeSlice(
        params.extensionName || "إدارة عراقي كودرز",
        100
      ),
      browser: safeSlice(params.browser || "Chrome / Edge Extension", 60),
      status: params.status,
      feedbackMessage: safeSlice(params.feedbackMessage || "", 240),
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function updateExtensionPairingStatusInFirestore(params: {
  id: string;
  extensionName: string;
  browser: string;
  status: "waiting" | "pending_confirm" | "paired" | "rejected" | "revoked";
  feedbackMessage?: string;
}): Promise<void> {
  const currentUser = firebaseAuth.currentUser;
  if (!currentUser || !currentUser.emailVerified) return;

  const path = `extension_pairings/${params.id}`;
  try {
    await updateDoc(doc(db, "extension_pairings", params.id), {
      status: params.status,
      feedbackMessage: safeSlice(params.feedbackMessage || "", 240),
      extensionName: safeSlice(
        params.extensionName || "إدارة عراقي كودرز",
        100
      ),
      browser: safeSlice(params.browser || "Chrome / Edge Extension", 60),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

function mapPlatformUpdateSnapshot(docSnap: {
  id: string;
  data: () => Record<string, unknown>;
}): { createdAtMs: number; update: PlatformAiUpdate } {
  const d = docSnap.data();
  const createdAtMs =
    d.createdAt instanceof Timestamp ? d.createdAt.toMillis() : 0;
  return {
    createdAtMs,
    update: {
      id: String(d.id || docSnap.id),
      authorId: String(d.authorId || ""),
      authorName: String(d.authorName || "الإدارة"),
      title: String(d.title || "ميزة جديدة"),
      description: String(d.description || ""),
      badgeText: String(d.badgeText || "تحديث AI"),
      accentColor: (d.accentColor as PlatformUpdateAccent) || "blue",
      featureType: (d.featureType as PlatformUpdateFeatureType) || "widget",
      actionLabel: String(d.actionLabel || "تفعيل الميزة"),
      actionPayload: String(d.actionPayload || ""),
      targetVersion: String(d.targetVersion || "26.5"),
      visibility: (d.visibility as PlatformUpdateVisibility) || "private",
      createdAt: formatTimestampArabic(d.createdAt),
      isAiGenerated: true,
    },
  };
}

export function subscribeToPublicPlatformUpdates(
  onUpdates: (updates: PlatformAiUpdate[]) => void
): () => void {
  const path = "platform_updates";
  const q = query(collection(db, path), where("visibility", "==", "public"));

  return onSnapshot(
    q,
    (snapshot) => {
      const docs = snapshot.docs.map((docSnap) =>
        mapPlatformUpdateSnapshot(
          docSnap as unknown as {
            id: string;
            data: () => Record<string, unknown>;
          }
        )
      );
      docs.sort((a, b) => b.createdAtMs - a.createdAtMs);
      onUpdates(docs.map((d) => d.update));
    },
    (error) => {
      handleFirestoreError(error, OperationType.LIST, path);
    }
  );
}

export function subscribeToPrivatePlatformUpdates(
  authorId: string,
  onUpdates: (updates: PlatformAiUpdate[]) => void
): () => void {
  const path = "platform_updates";
  const q = query(collection(db, path), where("authorId", "==", authorId));

  return onSnapshot(
    q,
    (snapshot) => {
      const docs = snapshot.docs.map((docSnap) =>
        mapPlatformUpdateSnapshot(
          docSnap as unknown as {
            id: string;
            data: () => Record<string, unknown>;
          }
        )
      );
      docs.sort((a, b) => b.createdAtMs - a.createdAtMs);
      onUpdates(docs.map((d) => d.update));
    },
    (error) => {
      handleFirestoreError(error, OperationType.LIST, path);
    }
  );
}

export async function createPlatformUpdateInFirestore(
  item: PlatformAiUpdate
): Promise<void> {
  const currentUser = firebaseAuth.currentUser;
  if (!currentUser || !currentUser.emailVerified) return;

  const path = `platform_updates/${item.id}`;
  try {
    await setDoc(doc(db, "platform_updates", item.id), {
      id: safeSlice(item.id, 128),
      authorId: safeSlice(currentUser.uid, 128),
      authorName: safeSlice(
        item.authorName || currentUser.displayName || "المسؤول",
        120
      ),
      title: safeSlice(item.title, 160),
      description: safeSlice(item.description || "ميزة مولّدة بالذكاء الاصطناعي", 1000),
      badgeText: safeSlice(item.badgeText || "تحديث AI", 50),
      accentColor: item.accentColor || "blue",
      featureType: item.featureType || "widget",
      actionLabel: safeSlice(item.actionLabel || "تشغيل", 60),
      actionPayload: String(item.actionPayload || "").slice(0, 2000),
      targetVersion: safeSlice(item.targetVersion || "26.5", 20),
      visibility: item.visibility === "public" ? "public" : "private",
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function updatePlatformUpdateVisibilityInFirestore(
  updateId: string,
  visibility: PlatformUpdateVisibility
): Promise<void> {
  const currentUser = firebaseAuth.currentUser;
  if (!currentUser || !currentUser.emailVerified) return;

  const path = `platform_updates/${updateId}`;
  try {
    await updateDoc(doc(db, "platform_updates", updateId), {
      visibility,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function deletePlatformUpdateInFirestore(
  updateId: string
): Promise<void> {
  const currentUser = firebaseAuth.currentUser;
  if (!currentUser || !currentUser.emailVerified) return;

  const path = `platform_updates/${updateId}`;
  try {
    await deleteDoc(doc(db, "platform_updates", updateId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export async function createRoleRequestInFirestore(params: {
  id: string;
  fullName: string;
  email: string;
  requestedRole: "admin" | "supervisor";
  note: string;
}): Promise<void> {
  const currentUser = firebaseAuth.currentUser;
  if (!currentUser || !currentUser.emailVerified) return;

  const path = `role_requests/${params.id}`;
  try {
    await setDoc(doc(db, "role_requests", params.id), {
      id: safeSlice(params.id, 128),
      requesterUid: safeSlice(currentUser.uid, 128),
      fullName: safeSlice(params.fullName, 120),
      email: safeSlice(params.email, 254),
      requestedRole: params.requestedRole === "supervisor" ? "supervisor" : "admin",
      note: safeSlice(params.note || "", 500),
      status: "pending",
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function fetchRoleRequestsForAdmin(): Promise<AdminRoleRequest[]> {
  const currentUser = firebaseAuth.currentUser;
  if (!currentUser || !currentUser.emailVerified) return [];

  const path = "role_requests";
  try {
    const snap = await getDocs(collection(db, path));
    const list = snap.docs.map((docSnap) => {
      const d = docSnap.data();
      const createdAtMs =
        d.createdAt instanceof Timestamp ? d.createdAt.toMillis() : 0;
      const statusRaw = String(d.status || "pending");
      const status: AdminRoleRequest["status"] =
        statusRaw === "approved" ||
        statusRaw === "rejected" ||
        statusRaw === "reviewed"
          ? statusRaw
          : "pending";
      return {
        createdAtMs,
        request: {
          id: String(d.id || docSnap.id),
          fullName: String(d.fullName || ""),
          email: String(d.email || ""),
          requestedRole:
            d.requestedRole === "supervisor" ? "supervisor" : "admin",
          note: String(d.note || ""),
          status,
          createdAt: formatTimestampArabic(d.createdAt),
        } satisfies AdminRoleRequest,
      };
    });
    list.sort((a, b) => b.createdAtMs - a.createdAtMs);
    return list.map((item) => item.request);
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
  }
}

export async function updateRoleRequestStatusInFirestore(
  requestId: string,
  status: AdminRoleRequest["status"]
): Promise<void> {
  const currentUser = firebaseAuth.currentUser;
  if (!currentUser || !currentUser.emailVerified) return;

  const path = `role_requests/${requestId}`;
  try {
    await updateDoc(doc(db, "role_requests", requestId), {
      status,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function saveNationalityCardInFirestore(
  card: CustomNationalityCard
): Promise<void> {
  const currentUser = firebaseAuth.currentUser;
  if (!currentUser || !currentUser.emailVerified) return;

  const path = `nationalities/${card.id}`;
  try {
    await setDoc(doc(db, "nationalities", card.id), {
      id: safeSlice(card.id, 128),
      ownerUid: safeSlice(currentUser.uid, 128),
      ownerHandle: safeSlice(card.ownerHandle || "@iraqi_dev", 40),
      ownerEmail: safeSlice(
        card.ownerEmail || currentUser.email || "user@iraqicoders.iq",
        254
      ),
      fullName: safeSlice(card.fullName, 120),
      governorate: safeSlice(card.governorate || "بغداد", 60),
      nationalityCode: safeSlice(card.nationalityCode, 40),
      specialty: safeSlice(card.specialty || "مطور في عراقي كودرز", 120),
      titleRank: safeSlice(card.titleRank || "عضو الرقمية", 80),
      bio: safeSlice(card.bio || "", 600),
      frontPhotoUrl: card.frontPhotoUrl.slice(0, 195000),
      backEmblemUrl: card.backEmblemUrl.slice(0, 195000),
      issuedAt: safeSlice(card.issuedAt || "اليوم", 40),
      verified: Boolean(card.verified),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function fetchNationalitiesFromFirestore(): Promise<
  CustomNationalityCard[]
> {
  const currentUser = firebaseAuth.currentUser;
  if (!currentUser || !currentUser.emailVerified) return [];

  const path = "nationalities";
  try {
    const snap = await getDocs(collection(db, path));
    return snap.docs.map((docSnap) => {
      const d = docSnap.data();
      return {
        id: String(d.id || docSnap.id),
        ownerUid: String(d.ownerUid || ""),
        ownerHandle: String(d.ownerHandle || "@iraqi_dev"),
        ownerEmail: String(d.ownerEmail || ""),
        fullName: String(d.fullName || ""),
        governorate: String(d.governorate || "بغداد"),
        nationalityCode: String(d.nationalityCode || ""),
        specialty: String(d.specialty || ""),
        titleRank: String(d.titleRank || ""),
        bio: String(d.bio || ""),
        frontPhotoUrl: String(d.frontPhotoUrl || DEFAULT_DEVELOPER_AVATAR),
        backEmblemUrl: String(d.backEmblemUrl || DEFAULT_DEVELOPER_AVATAR),
        issuedAt: String(d.issuedAt || "الآن"),
        verified: Boolean(d.verified),
      } satisfies CustomNationalityCard;
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
  }
}

export async function savePlatformMessageInFirestore(
  msg: PlatformMessageRecord
): Promise<void> {
  const currentUser = firebaseAuth.currentUser;
  if (!currentUser || !currentUser.emailVerified) return;

  const path = `platform_messages/${msg.id}`;
  try {
    await setDoc(doc(db, "platform_messages", msg.id), {
      id: safeSlice(msg.id, 128),
      senderUid: safeSlice(currentUser.uid, 128),
      senderEmail: safeSlice(
        msg.senderEmail || currentUser.email || "user@iraqicoders.iq",
        254
      ),
      recipientEmail: safeSlice(
        msg.recipientEmail || "user@iraqicoders.iq",
        254
      ),
      subject: safeSlice(msg.subject, 200),
      body: safeSlice(msg.body, 4000),
      sentViaGmail: Boolean(msg.sentViaGmail),
      rankAssigned: msg.rankAssigned || "none",
      createdAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

