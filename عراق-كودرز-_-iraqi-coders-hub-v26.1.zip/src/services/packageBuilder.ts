import { CloudFileItem } from "../types";
import { buildMinecraftFactoriesExpansionBlob } from "./minecraftFactoryPack";

export interface ZipEntryInput {
  path: string;
  data: Uint8Array | string;
}

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) {
      c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    table[n] = c >>> 0;
  }
  return table;
})();

function crc32(bytes: Uint8Array): number {
  let c = 0xffffffff;
  for (let i = 0; i < bytes.length; i++) {
    c = CRC_TABLE[(c ^ bytes[i]) & 0xff] ^ (c >>> 8);
  }
  return (c ^ 0xffffffff) >>> 0;
}

const encoder = new TextEncoder();

function toBytes(input: Uint8Array | string): Uint8Array {
  return typeof input === "string" ? encoder.encode(input) : input;
}

export function generateUuidV4(): string {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
    return crypto.randomUUID();
  }
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === "x" ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

// Valid 1x1 emerald-violet RGBA PNG icon (67 bytes) for pack_icon.png / launcher icon
const MINIMAL_ICON_PNG = new Uint8Array([
  0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
  0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01,
  0x08, 0x06, 0x00, 0x00, 0x00, 0x1f, 0x15, 0xc4, 0x89, 0x00, 0x00, 0x00,
  0x0d, 0x49, 0x44, 0x41, 0x54, 0x78, 0x9c, 0x63, 0x28, 0xcf, 0xf0, 0xbf,
  0x1e, 0x00, 0x05, 0x85, 0x02, 0x7f, 0x32, 0x95, 0x23, 0x5c, 0x00, 0x00,
  0x00, 0x00, 0x49, 0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82,
]);

// Minimal valid Dalvik DEX file header for APK structure verification
function buildMinimalDexHeader(): Uint8Array {
  const dex = new Uint8Array(112);
  // magic: "dex\n035\0"
  dex.set([0x64, 0x65, 0x78, 0x0a, 0x30, 0x33, 0x35, 0x00], 0);
  // file_size = 112 (little-endian at offset 32)
  dex[32] = 112;
  // header_size = 112 (offset 36)
  dex[36] = 112;
  // endian_tag = 0x12345678 (offset 40)
  dex[40] = 0x78;
  dex[41] = 0x56;
  dex[42] = 0x34;
  dex[43] = 0x12;
  return dex;
}

/**
 * Pure TypeScript PKZIP binary archive builder (zero external deps, valid CRC32 & UTF-8 filenames)
 */
export function buildZipArchive(entries: ZipEntryInput[]): Uint8Array {
  const localParts: Uint8Array[] = [];
  const centralParts: Uint8Array[] = [];
  let offset = 0;

  for (const entry of entries) {
    const cleanPath = entry.path.replace(/^\/+/, "");
    const nameBytes = encoder.encode(cleanPath);
    const dataBytes = toBytes(entry.data);
    const sum = crc32(dataBytes);

    // Local File Header (30 bytes + filename)
    const localHeader = new Uint8Array(30 + nameBytes.length);
    const lv = new DataView(localHeader.buffer);
    lv.setUint32(0, 0x04034b50, true);
    lv.setUint16(4, 20, true); // version needed
    lv.setUint16(6, 0x0800, true); // UTF-8 filename flag
    lv.setUint16(8, 0, true); // compression: store (0)
    lv.setUint16(10, 0, true);
    lv.setUint16(12, 0x5421, true);
    lv.setUint32(14, sum, true);
    lv.setUint32(18, dataBytes.length, true);
    lv.setUint32(22, dataBytes.length, true);
    lv.setUint16(26, nameBytes.length, true);
    lv.setUint16(28, 0, true);
    localHeader.set(nameBytes, 30);

    localParts.push(localHeader, dataBytes);

    // Central Directory File Header (46 bytes + filename)
    const centralHeader = new Uint8Array(46 + nameBytes.length);
    const cv = new DataView(centralHeader.buffer);
    cv.setUint32(0, 0x02014b50, true);
    cv.setUint16(4, 20, true);
    cv.setUint16(6, 20, true);
    cv.setUint16(8, 0x0800, true);
    cv.setUint16(10, 0, true);
    cv.setUint16(12, 0, true);
    cv.setUint16(14, 0x5421, true);
    cv.setUint32(16, sum, true);
    cv.setUint32(20, dataBytes.length, true);
    cv.setUint32(24, dataBytes.length, true);
    cv.setUint16(28, nameBytes.length, true);
    cv.setUint16(30, 0, true);
    cv.setUint16(32, 0, true);
    cv.setUint16(34, 0, true);
    cv.setUint16(36, 0, true);
    cv.setUint32(38, 0, true);
    cv.setUint32(42, offset, true);
    centralHeader.set(nameBytes, 46);

    centralParts.push(centralHeader);
    offset += localHeader.length + dataBytes.length;
  }

  const centralSize = centralParts.reduce((acc, p) => acc + p.length, 0);
  const eocd = new Uint8Array(22);
  const ev = new DataView(eocd.buffer);
  ev.setUint32(0, 0x06054b50, true);
  ev.setUint16(4, 0, true);
  ev.setUint16(6, 0, true);
  ev.setUint16(8, entries.length, true);
  ev.setUint16(10, entries.length, true);
  ev.setUint32(12, centralSize, true);
  ev.setUint32(16, offset, true);
  ev.setUint16(20, 0, true);

  const totalSize = offset + centralSize + eocd.length;
  const out = new Uint8Array(totalSize);
  let cursor = 0;
  for (const part of localParts) {
    out.set(part, cursor);
    cursor += part.length;
  }
  for (const part of centralParts) {
    out.set(part, cursor);
    cursor += part.length;
  }
  out.set(eocd, cursor);
  return out;
}

export function buildMinecraftAddonBlob(params: {
  title: string;
  description: string;
  author: string;
  format: "mcpack" | "mcaddon";
  modKind: "behavior" | "skin";
  scriptCode: string;
}): { blob: Blob; previewManifest: string } {
  const headerUuid = generateUuidV4();
  const dataModuleUuid = generateUuidV4();
  const scriptModuleUuid = generateUuidV4();
  const resHeaderUuid = generateUuidV4();
  const resModuleUuid = generateUuidV4();

  if (params.modKind === "skin") {
    const manifest = JSON.stringify(
      {
        format_version: 2,
        header: {
          name: params.title,
          description: `${params.description} — صنع في عراقي كودرز (${params.author})`,
          uuid: headerUuid,
          version: [1, 0, 0],
        },
        modules: [
          {
            type: "skin_pack",
            uuid: dataModuleUuid,
            version: [1, 0, 0],
          },
        ],
      },
      null,
      2
    );

    const skinsJson = JSON.stringify(
      {
        serialize_name: params.title.replace(/\s+/g, "_").slice(0, 32),
        localization_name: params.title,
        skins: [
          {
            localization_name: "iraqi_coder_skin",
            geometry: "geometry.humanoid.custom",
            texture: "skin_iraqi_coder.png",
            type: "free",
          },
        ],
      },
      null,
      2
    );

    const bytes = buildZipArchive([
      { path: "manifest.json", data: manifest },
      { path: "skins.json", data: skinsJson },
      { path: "skin_iraqi_coder.png", data: MINIMAL_ICON_PNG },
      { path: "pack_icon.png", data: MINIMAL_ICON_PNG },
      {
        path: "texts/en_US.lang",
        data: `skinpack.${params.title}=${params.title}\nskin.${params.title}.iraqi_coder_skin=Iraqi Coder Skin\n`,
      },
    ]);

    return {
      blob: new Blob([bytes.buffer as ArrayBuffer], { type: "application/octet-stream" }),
      previewManifest: manifest,
    };
  }

  const behaviorManifest = JSON.stringify(
    {
      format_version: 2,
      header: {
        name: params.title,
        description: `${params.description} — عراقي كودرز (${params.author})`,
        uuid: headerUuid,
        version: [1, 0, 0],
        min_engine_version: [1, 21, 0],
      },
      modules: [
        {
          description: "Behavior Data Module",
          type: "data",
          uuid: dataModuleUuid,
          version: [1, 0, 0],
        },
        {
          description: "Script API Module",
          type: "script",
          language: "javascript",
          uuid: scriptModuleUuid,
          entry: "scripts/main.js",
          version: [1, 0, 0],
        },
      ],
      dependencies: [
        {
          module_name: "@minecraft/server",
          version: "1.14.0",
        },
      ],
    },
    null,
    2
  );

  const resourceManifest = JSON.stringify(
    {
      format_version: 2,
      header: {
        name: `${params.title} (Resources)`,
        description: params.description,
        uuid: resHeaderUuid,
        version: [1, 0, 0],
        min_engine_version: [1, 21, 0],
      },
      modules: [
        {
          type: "resources",
          uuid: resModuleUuid,
          version: [1, 0, 0],
        },
      ],
    },
    null,
    2
  );

  const cleanScript =
    params.scriptCode.trim() ||
    `import { world } from "@minecraft/server";\nworld.afterEvents.playerSpawn.subscribe(ev => ev.player.sendMessage("§aتم تفعيل إضافة ${params.title} بنجاح!"));`;

  const entries: ZipEntryInput[] =
    params.format === "mcpack"
      ? [
          { path: "manifest.json", data: behaviorManifest },
          { path: "pack_icon.png", data: MINIMAL_ICON_PNG },
          { path: "scripts/main.js", data: cleanScript },
          {
            path: "texts/en_US.lang",
            data: `pack.name=${params.title}\npack.description=${params.description}\n`,
          },
        ]
      : [
          { path: "behavior_pack/manifest.json", data: behaviorManifest },
          { path: "behavior_pack/pack_icon.png", data: MINIMAL_ICON_PNG },
          { path: "behavior_pack/scripts/main.js", data: cleanScript },
          {
            path: "behavior_pack/texts/en_US.lang",
            data: `pack.name=${params.title}\npack.description=${params.description}\n`,
          },
          { path: "resource_pack/manifest.json", data: resourceManifest },
          { path: "resource_pack/pack_icon.png", data: MINIMAL_ICON_PNG },
          {
            path: "resource_pack/texts/en_US.lang",
            data: `pack.name=${params.title} Resources\npack.description=${params.description}\n`,
          },
        ];

  const bytes = buildZipArchive(entries);
  return {
    blob: new Blob([bytes.buffer as ArrayBuffer], { type: "application/octet-stream" }),
    previewManifest: behaviorManifest,
  };
}

export function buildWebSourceZipBlob(params: {
  title: string;
  author: string;
  html: string;
  css: string;
  js: string;
}): { blob: Blob; previewText: string } {
  const fullIndexHtml = `<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${params.title}</title>
  <link rel="stylesheet" href="./styles.css" />
</head>
<body>
${params.html}
<script src="./script.js"></script>
</body>
</html>`;

  const readme = `# ${params.title}\nالمطور: ${params.author}\nتم تصديره بواسطة منصة عراقي كودرز 26.5\n\nافتح ملف index.html مباشرة في المتصفح للتشغيل.`;

  const bytes = buildZipArchive([
    { path: "index.html", data: fullIndexHtml },
    { path: "styles.css", data: params.css },
    { path: "script.js", data: params.js },
    { path: "README.txt", data: readme },
  ]);

  return {
    blob: new Blob([bytes.buffer as ArrayBuffer], { type: "application/zip" }),
    previewText: fullIndexHtml,
  };
}

export function buildAndroidApkBlob(params: {
  title: string;
  packageId: string;
  author: string;
  htmlContent: string;
  minSdkVersion?: number;
  targetSdkVersion?: number;
}): { blob: Blob; previewManifest: string } {
  const safePkg =
    params.packageId
      .toLowerCase()
      .replace(/[^a-z0-9_.]/g, "")
      .replace(/^\.+|\.+$/g, "") || "iq.coders.app";

  const targetSdk = params.targetSdkVersion ?? 34;
  const minSdk = params.minSdkVersion ?? 24;

  const androidManifest = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="${safePkg}"
    android:versionCode="340265"
    android:versionName="26.5"
    android:compileSdkVersion="${targetSdk}"
    android:compileSdkVersionCodename="14">
    <uses-sdk android:minSdkVersion="${minSdk}" android:targetSdkVersion="${targetSdk}" />
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <application
        android:label="${params.title}"
        android:usesCleartextTraffic="false"
        android:hardwareAccelerated="true"
        android:icon="@mipmap/ic_launcher">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|keyboardHidden|smallestScreenSize|screenLayout">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`;

  const manifestMf = `Manifest-Version: 1.0\nCreated-By: Iraqi Coders Hub Builder 26.5\nPackage-Id: ${safePkg}\nApp-Title: ${params.title}\nMin-Sdk: ${minSdk}\nTarget-Sdk: ${targetSdk}\nAuthor: ${params.author}\n`;

  const stringsXml = `<?xml version="1.0" encoding="utf-8"?>\n<resources>\n  <string name="app_name">${params.title}</string>\n  <string name="package_id">${safePkg}</string>\n</resources>`;

  const embeddedHtml =
    params.htmlContent.trim() ||
    `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"/><meta name="viewport" content="width=device-width,initial-scale=1.0"/><title>${params.title}</title></head><body style="margin:0;min-height:100vh;display:grid;place-items:center;background:#0B0F19;color:#fff;font-family:sans-serif"><h1>${params.title}</h1></body></html>`;

  const bytes = buildZipArchive([
    { path: "META-INF/MANIFEST.MF", data: manifestMf },
    { path: "AndroidManifest.xml", data: androidManifest },
    { path: "classes.dex", data: buildMinimalDexHeader() },
    { path: "res/values/strings.xml", data: stringsXml },
    { path: "res/mipmap-mdpi/ic_launcher.png", data: MINIMAL_ICON_PNG },
    { path: "assets/www/index.html", data: embeddedHtml },
  ]);

  return {
    blob: new Blob([bytes.buffer as ArrayBuffer], {
      type: "application/vnd.android.package-archive",
    }),
    previewManifest: androidManifest,
  };
}

/**
 * Ensures any community or user cloud item downloads as a valid, non-corrupted file or archive.
 */
export function compileDownloadableBlobForCloudItem(item: CloudFileItem): Blob {
  const lower = item.fileName.toLowerCase();

  if (lower.endsWith(".apk")) {
    return buildAndroidApkBlob({
      title: item.title,
      packageId: `iq.coders.${item.id.replace(/[^a-z0-9]/gi, "").slice(0, 14) || "app"}`,
      author: item.ownerName,
      htmlContent: item.content.includes("<html")
        ? item.content
        : `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"/><title>${item.title}</title></head><body style="background:#0B0F19;color:#fff;font-family:Cairo,sans-serif;padding:24px"><h2>${item.title}</h2><pre>${item.content}</pre></body></html>`,
    }).blob;
  }

  if (
    lower.endsWith(".mcworld") ||
    lower.includes("iraqi_coders_factories")
  ) {
    return buildMinecraftFactoriesExpansionBlob(
      lower.endsWith(".mcworld") ? "mcworld" : "mcaddon"
    ).blob;
  }

  if (lower.endsWith(".mcpack") || lower.endsWith(".mcaddon")) {
    return buildMinecraftAddonBlob({
      title: item.title,
      description: item.description,
      author: item.ownerName,
      format: lower.endsWith(".mcpack") ? "mcpack" : "mcaddon",
      modKind: item.content.includes("skin_pack") ? "skin" : "behavior",
      scriptCode: item.content,
    }).blob;
  }

  if (lower.endsWith(".zip")) {
    return buildWebSourceZipBlob({
      title: item.title,
      author: item.ownerName,
      html: item.content,
      css: "body{margin:0;background:#0B0F19;color:#F1F5F9;font-family:Cairo,sans-serif;}",
      js: `console.log("${item.title}");`,
    }).blob;
  }

  return new Blob([item.content], { type: "text/plain;charset=utf-8" });
}

/**
 * تجميع مشروع كروك (.krok) داخل أرشيف ZIP جاهز للفتح في تطبيقات إنشاء الألعاب والتطبيقات على أندرويد والكمبيوتر
 */
export function buildKrookProjectZipBlob(params: {
  title: string;
  author: string;
  language: string;
  isGame: boolean;
  is3D: boolean;
  sourceCode: string;
}): { blob: Blob; krookFileName: string; zipFileName: string } {
  const safeSlug =
    params.title
      .toLowerCase()
      .replace(/[^a-z0-9]+/gi, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 32) || "iraqi-coders-project";

  const krookFileName = `${safeSlug}.krok`;
  const zipFileName = `${safeSlug}-krook-bundle.zip`;

  const krookPayload = JSON.stringify(
    {
      format: "KROOK_STUDIO_PROJECT",
      formatVersion: "2.6.5",
      engine: params.is3D ? "Krook3D-Engine" : "Krook2D-Engine",
      projectType: params.isGame ? "game" : "android_app",
      name: params.title,
      author: params.author,
      language: params.language,
      androidReady: true,
      sealVerified: true,
      sealText: "Iraqi Coders  1329",
      scene: {
        gravity: params.isGame ? 9.81 : 0,
        renderQuality: params.is3D ? "realistic_3d" : "crisp_2d",
        background: "#0B0F19",
      },
      entryScript: params.sourceCode,
      createdAt: new Date().toISOString(),
    },
    null,
    2
  );

  const builderManifest = JSON.stringify(
    {
      packageName: `iq.coders.${safeSlug.replace(/-/g, "") || "app"}`,
      displayName: params.title,
      entryKrookFile: krookFileName,
      programmingLanguage: params.language,
      targetPlatforms: ["Android APK", "Mobile Game Builder", "Web Mini-Runner"],
    },
    null,
    2
  );

  const readme = `# ${params.title}\nصُدر من بيئة المبرمج — عراقي كودرز\nالمؤلف: ${params.author}\nلغة البرمجة: ${params.language}\n\nيحتوي هذا الأرشيف على ملف ${krookFileName} الجاهز للاستيراد والتعديل والبناء مباشرة على تطبيقات إنشاء الألعاب والتطبيقات على أندرويد والكمبيوتر.`;

  const bytes = buildZipArchive([
    { path: krookFileName, data: krookPayload },
    { path: "manifest.json", data: builderManifest },
    { path: `src/main.${params.language === "python" ? "py" : params.language === "java" ? "java" : params.language === "groovy" ? "groovy" : "js"}`, data: params.sourceCode },
    { path: "README.txt", data: readme },
  ]);

  return {
    blob: new Blob([bytes.buffer as ArrayBuffer], { type: "application/zip" }),
    krookFileName,
    zipFileName,
  };
}
