import { STORAGE_KEYS } from "../config/firebase";
import { BetaBrowserInspection } from "../types";

interface NavigatorWithUAData extends Navigator {
  userAgentData?: {
    brands?: Array<{ brand: string; version: string }>;
  };
}

/**
 * فحص المتصفح وتطبيق جوجل والانضمام للنسخة التجريبية (Beta) تلقائياً
 */
export function inspectBrowserAndBetaStatus(): BetaBrowserInspection {
  if (typeof window === "undefined" || typeof navigator === "undefined") {
    return {
      browserName: "Web Browser",
      browserVersion: "1.0",
      isGoogleChrome: false,
      isGoogleAppOrBetaChannel: false,
      isBetaJoined: false,
      autoActivated: false,
      reasonLabel: "فحص افتراضي للمتصفح",
    };
  }

  const nav = navigator as NavigatorWithUAData;
  const ua = nav.userAgent || "";
  const brands = nav.userAgentData?.brands || [];

  let browserName = "متصفح ويب";
  let browserVersion = "حديث";

  const edgeMatch = ua.match(/Edg\/(\d+(?:\.\d+)?)/i);
  const chromeMatch = ua.match(/(?:Chrome|CriOS)\/(\d+(?:\.\d+)?)/i);
  const firefoxMatch = ua.match(/Firefox\/(\d+(?:\.\d+)?)/i);
  const safariMatch = ua.match(/Version\/(\d+(?:\.\d+)?).*Safari/i);
  const gsaMatch = ua.match(/GSA\/(\d+(?:\.\d+)?)/i);

  const isGoogleChrome = Boolean(chromeMatch && !edgeMatch && !/OPR\//i.test(ua));

  if (gsaMatch) {
    browserName = "تطبيق Google (Google App)";
    browserVersion = gsaMatch[1];
  } else if (edgeMatch) {
    browserName = "Microsoft Edge";
    browserVersion = edgeMatch[1];
  } else if (chromeMatch) {
    browserName = "Google Chrome";
    browserVersion = chromeMatch[1];
  } else if (firefoxMatch) {
    browserName = "Mozilla Firefox";
    browserVersion = firefoxMatch[1];
  } else if (safariMatch) {
    browserName = "Safari";
    browserVersion = safariMatch[1];
  }

  const brandBetaDetected = brands.some((b) =>
    /beta|canary|dev/i.test(b.brand)
  );
  const uaBetaDetected =
    /Chrome Beta|Chrome Canary|GSA\/|GoogleApp|Beta/i.test(ua);

  let urlBetaJoined = false;
  let storedBetaJoined = false;
  try {
    const params = new URLSearchParams(window.location.search);
    urlBetaJoined =
      params.get("beta") === "1" ||
      params.get("google_beta") === "true" ||
      params.get("channel") === "beta";
    storedBetaJoined =
      localStorage.getItem(STORAGE_KEYS.GOOGLE_BETA_JOINED) === "true";
  } catch {
    // Safe fallback
  }

  const isGoogleAppOrBetaChannel =
    brandBetaDetected || uaBetaDetected || Boolean(gsaMatch) || urlBetaJoined;
  const isBetaJoined = isGoogleAppOrBetaChannel || storedBetaJoined;

  const reasonLabel = isGoogleAppOrBetaChannel
    ? `تم رصد قناة Google Beta (${browserName} ${browserVersion}) — تفعيل تلقائي للمزايا التجريبية`
    : storedBetaJoined
    ? `الحساب منضم لبرنامج Google Beta (${browserName} ${browserVersion}) — تفعيل تلقائي فوري`
    : `متصفح قياسي (${browserName} ${browserVersion}) — اضغط على «استعمال النسخة التجريبية» لتفعيل البيتا`;

  return {
    browserName,
    browserVersion,
    isGoogleChrome,
    isGoogleAppOrBetaChannel,
    isBetaJoined,
    autoActivated: isBetaJoined,
    reasonLabel,
  };
}
