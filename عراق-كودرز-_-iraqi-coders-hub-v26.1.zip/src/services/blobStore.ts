const DB_NAME = "iraqi_coders_blob_store_v26";
const STORE_NAME = "cloud_blobs";
const memoryFallback = new Map<string, Blob>();

function openBlobDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === "undefined") {
      reject(new Error("IndexedDB unavailable"));
      return;
    }
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error || new Error("IndexedDB open failed"));
  });
}

export async function saveCloudBinaryBlob(
  fileId: string,
  blob: Blob
): Promise<void> {
  memoryFallback.set(fileId, blob);
  try {
    const db = await openBlobDb();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, "readwrite");
      tx.objectStore(STORE_NAME).put(blob, fileId);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch {
    // Fallback remains in memoryFallback
  }
}

export async function getCloudBinaryBlob(
  fileId: string
): Promise<Blob | null> {
  const cached = memoryFallback.get(fileId);
  if (cached) return cached;

  try {
    const db = await openBlobDb();
    const res = await new Promise<Blob | null>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, "readonly");
      const req = tx.objectStore(STORE_NAME).get(fileId);
      req.onsuccess = () => resolve((req.result as Blob) || null);
      req.onerror = () => reject(req.error);
    });
    return res;
  } catch {
    return null;
  }
}

export async function deleteCloudBinaryBlob(fileId: string): Promise<void> {
  memoryFallback.delete(fileId);
  try {
    const db = await openBlobDb();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, "readwrite");
      tx.objectStore(STORE_NAME).delete(fileId);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch {
    // Safe no-op
  }
}
