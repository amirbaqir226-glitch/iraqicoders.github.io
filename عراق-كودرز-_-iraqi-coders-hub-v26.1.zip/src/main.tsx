import { createRoot } from "react-dom/client";
import { registerSW } from "virtual:pwa-register";
import App from "./App.tsx";
import "./index.css";

if (typeof window !== "undefined" && "serviceWorker" in navigator) {
  registerSW({
    immediate: true,
    onRegisteredSW() {
      // Active service worker ready for live network-first + offline pack caching
    },
    onRegisterError() {
      // Non-fatal fallback in environments where service workers are restricted
    },
  });
}

createRoot(document.getElementById("root")!).render(<App />);
