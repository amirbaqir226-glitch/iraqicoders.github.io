export interface IPhoneEmojiCategory {
  id: string;
  label: string;
  icon: string;
  emojis: string[];
}

export const IPHONE_EMOJI_CATEGORIES: IPhoneEmojiCategory[] = [
  {
    id: "faces",
    label: "الوجوه",
    icon: "😀",
    emojis: [
      "😀", "😃", "😄", "😁", "😆", "🥹", "😅", "😂",
      "🤣", "😊", "😇", "🙂", "😉", "😌", "😍", "🥰",
      "😘", "😗", "😋", "😛", "😜", "🤪", "🤨", "🧐",
      "🤓", "😎", "🥸", "🤩", "🥳", "😏", "😒", "😞",
      "😔", "😟", "😕", "🙁", "😣", "😖", "😫", "😩",
      "🥺", "😢", "😭", "😤", "😠", "😡", "🤬", "🤯",
      "😳", "🥵", "🥶", "😱", "😨", "😰", "🤫", "🤔",
      "🫣", "🤭", "🫡", "🤗", "🫠", "😴", "🤤", "🤑",
    ],
  },
  {
    id: "hearts",
    label: "القلوب والرموز",
    icon: "❤️",
    emojis: [
      "❤️", "🩷", "🧡", "💛", "💚", "💙", "🩵", "💜",
      "🤎", "🖤", "🩶", "🤍", "💔", "❤️‍🔥", "❤️‍🩹", "💖",
      "💗", "💓", "💞", "💕", "💘", "💝", "✨", "🌟",
      "💫", "🔥", "💥", "⚡", "👑", "💎", "🏆", "🥇",
      "🎯", "💯", "✅", "❌", "⚠️", "🔔", "📣", "💬",
    ],
  },
  {
    id: "gestures",
    label: "الأيدي",
    icon: "👍",
    emojis: [
      "👍", "👎", "👏", "🙌", "🫶", "🤝", "🙏", "✌️",
      "🤞", "🫰", "🤟", "🤘", "👌", "🤌", "🤏", "👈",
      "👉", "👆", "👇", "☝️", "✋", "🤚", "🖐️", "🖖",
      "👋", "🤙", "💪", "🦾", "✍️", "🤳", "👀", "🧠",
    ],
  },
  {
    id: "tech",
    label: "البرمجة والألعاب",
    icon: "💻",
    emojis: [
      "💻", "🖥️", "📱", "⌨️", "🖱️", "📲", "🤖", "👾",
      "🎮", "🕹️", "🎧", "🎙️", "📡", "🔋", "🔌", "💾",
      "💿", "📀", "🛠️", "⚙️", "🔧", "🔨", "🪛", "🧪",
      "🧬", "🚀", "🛸", "🛰️", "🌐", "🔒", "🔓", "🔑",
      "🛡️", "📦", "📁", "📂", "📄", "📊", "📈", "💰",
    ],
  },
  {
    id: "flags",
    label: "العراق والاحتفال",
    icon: "🇮🇶",
    emojis: [
      "🇮🇶", "🕌", "🌴", "🦁", "🦅", "🎉", "🎊", "🎈",
      "🎁", "🎂", "🍰", "☕", "🍵", "🌙", "⭐", "☀️",
      "🌈", "🌊", "🏔️", "🏙️", "🚗", "🏎️", "✈️", "🛫",
    ],
  },
];

export const IOS_ARABIC_ROWS: string[][] = [
  ["ض", "ص", "ث", "ق", "ف", "غ", "ع", "ه", "خ", "ح", "ج", "د"],
  ["ش", "س", "ي", "ب", "ل", "ا", "ت", "ن", "م", "ك", "ط"],
  ["ئ", "ء", "ؤ", "ر", "لا", "ى", "ة", "و", "ز", "ظ"],
];

export const IOS_ENGLISH_ROWS_LOWER: string[][] = [
  ["q", "w", "e", "r", "t", "y", "u", "i", "o", "p"],
  ["a", "s", "d", "f", "g", "h", "j", "k", "l"],
  ["z", "x", "c", "v", "b", "n", "m"],
];

export const IOS_ENGLISH_ROWS_UPPER: string[][] = [
  ["Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P"],
  ["A", "S", "D", "F", "G", "H", "J", "K", "L"],
  ["Z", "X", "C", "V", "B", "N", "M"],
];

export const IOS_NUMBERS_ROWS: string[][] = [
  ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"],
  ["-", "/", ":", ";", "(", ")", "$", "&", "@", '"'],
  [".", "،", "؟", "!", "'", "#", "%", "*", "+", "="],
];

export function isEditableInputElement(
  el: Element | null
): el is HTMLInputElement | HTMLTextAreaElement {
  if (!el) return false;
  if (el instanceof HTMLTextAreaElement) {
    return !el.readOnly && !el.disabled;
  }
  if (el instanceof HTMLInputElement) {
    const unsupported = [
      "file",
      "checkbox",
      "radio",
      "range",
      "color",
      "submit",
      "button",
      "reset",
      "hidden",
    ];
    return (
      !el.readOnly &&
      !el.disabled &&
      !unsupported.includes((el.type || "text").toLowerCase())
    );
  }
  return false;
}

function setReactControlledValue(
  el: HTMLInputElement | HTMLTextAreaElement,
  nextValue: string
): void {
  const proto =
    el instanceof HTMLTextAreaElement
      ? HTMLTextAreaElement.prototype
      : HTMLInputElement.prototype;
  const nativeSetter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
  if (nativeSetter) {
    nativeSetter.call(el, nextValue);
  } else {
    el.value = nextValue;
  }
  el.dispatchEvent(new Event("input", { bubbles: true }));
  el.dispatchEvent(new Event("change", { bubbles: true }));
}

export function insertTextIntoTarget(
  el: HTMLInputElement | HTMLTextAreaElement,
  text: string
): void {
  const start = el.selectionStart ?? el.value.length;
  const end = el.selectionEnd ?? el.value.length;
  const nextVal = el.value.slice(0, start) + text + el.value.slice(end);
  setReactControlledValue(el, nextVal);
  const nextCaret = start + text.length;
  try {
    el.focus();
    el.setSelectionRange(nextCaret, nextCaret);
  } catch {
    // Some input types (e.g. email/number) restrict setSelectionRange
  }
}

export function backspaceInTarget(
  el: HTMLInputElement | HTMLTextAreaElement
): void {
  const start = el.selectionStart ?? el.value.length;
  const end = el.selectionEnd ?? el.value.length;
  if (start === 0 && end === 0) return;

  let nextVal: string;
  let nextCaret: number;

  if (start !== end) {
    nextVal = el.value.slice(0, start) + el.value.slice(end);
    nextCaret = start;
  } else {
    // Handle multi-byte surrogate pairs / emojis safely when deleting backward
    const before = Array.from(el.value.slice(0, start));
    const removed = before.pop() || "";
    const prefix = before.join("");
    nextVal = prefix + el.value.slice(end);
    nextCaret = start - removed.length;
  }

  setReactControlledValue(el, nextVal);
  try {
    el.focus();
    el.setSelectionRange(nextCaret, nextCaret);
  } catch {
    // Safe fallback
  }
}
