import { UnpackedExtensionFile, UnpackedExtensionPackage } from "../types";

export const EMBEDDED_MANIFEST_JSON = `{
  "manifest_version": 3,
  "name": "Iraqi Coders Admin Pro",
  "version": "4.0.0",
  "description": "Iraqi Coders Official Advanced Extension",
  "permissions": ["storage", "tabs", "scripting", "activeTab"],
  "host_permissions": ["https://iraqi-coders-hub-v26-1.ai.studio/*"],
  "background": { "service_worker": "background.js" },
  "action": { "default_popup": "popup.html" }
}`;

export const EMBEDDED_POPUP_HTML = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>إدارة عراقي كودرز الاحترافية</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <div class="container">
    <h2>منصة عراقي كودرز</h2>
    <button id="openBridgeBtn" class="main-btn">تفعيل الشاشة العائمة فوراً</button>
    <div id="status">جاهز للاستخدام</div>
  </div>
  <script src="popup.js"></script>
</body>
</html>`;

export const EMBEDDED_STYLES_CSS = `body {
  width: 280px;
  background: #0f172a;
  color: #f8fafc;
  font-family: 'Segoe UI', Tahoma, sans-serif;
  margin: 0;
  padding: 15px;
}
.container { display: flex; flex-direction: column; align-items: center; }
h2 { font-size: 15px; color: #38bdf8; margin-bottom: 12px; }
.main-btn { width: 100%; padding: 10px; background: #0284c7; border: none; color: white; font-weight: bold; border-radius: 6px; cursor: pointer; transition: 0.2s; }
.main-btn:hover { background: #0369a1; }
#status { font-size: 11px; color: #94a3b8; margin-top: 10px; text-align: center; }`;

export const EMBEDDED_POPUP_JS = `document.getElementById('openBridgeBtn').addEventListener('click', () => {
  const statusDiv = document.getElementById('status');
  statusDiv.style.color = '#38bdf8';
  statusDiv.innerText = 'جاري حقن الشاشة العائمة للمطورين...';
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs[0]) return;
    chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      func: () => {
        if (document.getElementById('iraqi-admin-floating-panel')) return;
        const panel = document.createElement('div');
        panel.id = 'iraqi-admin-floating-panel';
        panel.innerHTML = \`
          <div style="position:fixed; top:10px; right:10px; z-index:999999; background:#0f172a; color:#fff; border:2px solid #38bdf8; padding:15px; border-radius:10px; width:260px; box-shadow:0 10px 25px rgba(0,0,0,0.5); font-family:sans-serif;">
            <h3 style="margin:0 0 10px 0; color:#38bdf8; font-size:14px; text-align:center;">لوحة تحكم عراقي كودرز</h3>
            <p style="font-size:11px; color:#94a3b8; margin:0 0 10px 0; text-align:center;">تم تفعيل صلاحيات المطورين والمشرفين بنجاح!</p>
            <button id="closePanel" style="width:100%; background:#ef4444; border:none; color:#fff; padding:6px; border-radius:4px; cursor:pointer; font-weight:bold;">إغلاق لوحة التحكم</button>
          </div>
        \`;
        document.body.appendChild(panel);
        document.getElementById('closePanel').onclick = () => panel.remove();
      }
    }, () => {
      statusDiv.style.color = '#4ade80';
      statusDiv.innerText = 'تم فتح الشاشة العائمة بنجاح!';
    });
  });
});`;

export const EMBEDDED_CONFIG_JSON = `{
  "platform_name": "Iraqi Coders",
  "version": "4.0.0",
  "environment": "production",
  "features": {
    "floating_bridge": true,
    "dev_tools": true,
    "auto_inject": true,
    "secret_ide": true
  }
}`;

export const EMBEDDED_BACKGROUND_JS = `chrome.runtime.onInstalled.addListener(() => {
  console.log("Iraqi Coders Pro Extension with 6 Files Initialized Successfully.");
});`;

export interface EmbeddedConfigParsed {
  platform_name: string;
  version: string;
  environment: string;
  features: {
    floating_bridge: boolean;
    dev_tools: boolean;
    auto_inject: boolean;
    secret_ide: boolean;
  };
}

export const EMBEDDED_EXTENSION_CONFIG: EmbeddedConfigParsed = JSON.parse(
  EMBEDDED_CONFIG_JSON
) as EmbeddedConfigParsed;

export const EMBEDDED_EXTENSION_FILES: UnpackedExtensionFile[] = [
  {
    path: "manifest.json",
    sizeBytes: EMBEDDED_MANIFEST_JSON.length,
    content: EMBEDDED_MANIFEST_JSON,
    isBinary: false,
  },
  {
    path: "popup.html",
    sizeBytes: EMBEDDED_POPUP_HTML.length,
    content: EMBEDDED_POPUP_HTML,
    isBinary: false,
  },
  {
    path: "styles.css",
    sizeBytes: EMBEDDED_STYLES_CSS.length,
    content: EMBEDDED_STYLES_CSS,
    isBinary: false,
  },
  {
    path: "popup.js",
    sizeBytes: EMBEDDED_POPUP_JS.length,
    content: EMBEDDED_POPUP_JS,
    isBinary: false,
  },
  {
    path: "config.json",
    sizeBytes: EMBEDDED_CONFIG_JSON.length,
    content: EMBEDDED_CONFIG_JSON,
    isBinary: false,
  },
  {
    path: "background.js",
    sizeBytes: EMBEDDED_BACKGROUND_JS.length,
    content: EMBEDDED_BACKGROUND_JS,
    isBinary: false,
  },
];

/**
 * Builds a live sandboxed HTML document combining popup.html, styles.css, and popup.js
 * with an internal chrome.* runtime shim that triggers the host Cyber-Admin Floating Panel.
 */
export function buildEmbeddedPopupRunnableHtml(): string {
  return `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <title>إدارة عراقي كودرز الاحترافية</title>
  <style>
    ${EMBEDDED_STYLES_CSS}
    body { width: 100%; box-sizing: border-box; min-height: 200px; display: flex; align-items: center; justify-content: center; }
    .container { width: 100%; max-width: 280px; }
  </style>
</head>
<body>
  <div class="container">
    <h2>منصة عراقي كودرز</h2>
    <button id="openBridgeBtn" class="main-btn">تفعيل الشاشة العائمة فوراً</button>
    <div id="status">جاهز للاستخدام (نواة الـ 6 ملفات مدمجة)</div>
  </div>
  <script>
    window.chrome = {
      tabs: {
        query: (_q, cb) => cb([{ id: 1, url: window.location.href }])
      },
      scripting: {
        executeScript: (_opts, done) => {
          try {
            window.parent.postMessage({ type: "IRAQI_EMBEDDED_POPUP_ACTIVATE_BRIDGE" }, "*");
          } catch {}
          if (typeof done === "function") done();
        }
      }
    };
    ${EMBEDDED_POPUP_JS}
  </script>
</body>
</html>`;
}

/**
 * Returns the complete 6-file embedded extension package ready for instant injection
 * without downloading or sideloading any ZIP files.
 */
export function buildEmbeddedExtensionPackage(): UnpackedExtensionPackage {
  return {
    archiveName: "embedded-core (6 files)",
    extensionName: "Iraqi Coders Admin Pro",
    version: "4.0.0",
    description:
      "نواة الإضافة المدمجة داخل المنصة (6 ملفات رسمية: manifest.json, popup.html, styles.css, popup.js, config.json, background.js) — تعمل تلقائياً عبر «ما بيا حيل» بدون تنزيل.",
    popupPath: "popup.html",
    popupHtml: buildEmbeddedPopupRunnableHtml(),
    manifestRaw: EMBEDDED_MANIFEST_JSON,
    files: EMBEDDED_EXTENSION_FILES,
    unpackedAt: new Date().toLocaleTimeString("ar-IQ", {
      hour: "2-digit",
      minute: "2-digit",
    }),
  };
}
