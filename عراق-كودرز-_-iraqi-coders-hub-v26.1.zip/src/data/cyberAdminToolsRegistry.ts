import { ThemeDecoration } from "../types";

export type CyberToolCategoryId =
  | "themes"
  | "database"
  | "server"
  | "bots"
  | "scripts"
  | "security"
  | "engines";

export type CyberToolActionKind =
  | "theme"
  | "version"
  | "layout"
  | "api-probe"
  | "script"
  | "open-editor"
  | "open-studio"
  | "open-dev-modal"
  | "teleport";

export interface CyberAdminTool {
  id: string;
  code: string;
  name: string;
  category: CyberToolCategoryId;
  categoryLabel: string;
  description: string;
  actionKind: CyberToolActionKind;
  themeTarget?: ThemeDecoration;
  versionTarget?: number;
  apiRoute?: string;
  teleportTarget?: string;
  scriptCode?: string;
}

export const CYBER_TOOL_CATEGORIES: {
  id: CyberToolCategoryId;
  label: string;
  count: number;
}[] = [
  { id: "themes", label: "الثيمات والواجهة الحية", count: 150 },
  { id: "database", label: "قواعد البيانات والسحابة", count: 160 },
  { id: "server", label: "السيرفر والـ API", count: 160 },
  { id: "bots", label: "وحدات نشر البوتات", count: 160 },
  { id: "scripts", label: "منفّذ السكربتات", count: 160 },
  { id: "security", label: "الصلاحيات والأمان", count: 130 },
  { id: "engines", label: "الألعاب والمصانع", count: 130 },
];

interface CategorySeed {
  category: CyberToolCategoryId;
  categoryLabel: string;
  count: number;
  featured: Omit<CyberAdminTool, "id" | "code" | "category" | "categoryLabel">[];
  verbs: string[];
  subjects: string[];
  makeAction: (
    idx: number,
    name: string
  ) => Pick<
    CyberAdminTool,
    | "actionKind"
    | "themeTarget"
    | "versionTarget"
    | "apiRoute"
    | "teleportTarget"
    | "scriptCode"
  >;
}

const SEEDS: CategorySeed[] = [
  {
    category: "themes",
    categoryLabel: "الثيمات والواجهة الحية",
    count: 150,
    featured: [
      {
        name: "تفعيل ثيم السايبر النيون الفوري",
        description: "تبديل واجهة المنصة إلى الوضع السايبر المضيء مباشرة",
        actionKind: "theme",
        themeTarget: "cyber",
      },
      {
        name: "تفعيل الثيم الكهربائي الفائق",
        description: "تشغيل تأثيرات الطاقة الكهربائية الزرقاء عبر الصفحة",
        actionKind: "theme",
        themeTarget: "electric",
      },
      {
        name: "تفعيل ثيم الهالوين الاحتفالي",
        description: "تغيير ألوان وزينة الموقع إلى ثيم الهالوين فوراً",
        actionKind: "theme",
        themeTarget: "halloween",
      },
      {
        name: "استعادة الثيم الرسمي الداكن",
        description: "إرجاع التصميم القياسي لمنصة عراقي كودرز",
        actionKind: "theme",
        themeTarget: "default",
      },
      {
        name: "قفزة معاينة المستقبل v999.9",
        description: "دفع شارات النظام وواجهة المنصة إلى الإصدار الأسطوري v999.9",
        actionKind: "version",
        versionTarget: 999.9,
      },
      {
        name: "العودة إلى الإصدار الرسمي v26.5",
        description: "ضبط نسخة العرض الرئيسية على 26.5",
        actionKind: "version",
        versionTarget: 26.5,
      },
    ],
    verbs: ["تخصيص", "معايرة", "تشغيل", "ضبط", "مزامنة", "تحسين"],
    subjects: [
      "تدرج السايبر للأزرار",
      "كثافة الشبكة لسطح المكتب",
      "توهج شارات الإصدار",
      "أسلوب الخط العربي RTL",
      "حركة بطاقات الألعاب",
      "تباين اللوحة العائمة",
      "خلفية الجسيمات الرقمية",
      "تأثيرات شريط الاحتفال",
      "مقاسات شاشات الموبايل",
      "نمط الإضاءة الديناميكي",
    ],
    makeAction: (idx, name) => {
      const themes: ThemeDecoration[] = ["cyber", "electric", "halloween", "default"];
      if (idx % 4 === 0) {
        return { actionKind: "theme", themeTarget: themes[idx % themes.length] };
      }
      if (idx % 5 === 0) {
        return { actionKind: "layout" };
      }
      return {
        actionKind: "script",
        scriptCode: `// ${name}\nconst theme = "${themes[idx % themes.length]}";\nconsole.log("[UI Engine] تم تطبيق وحدة الواجهة:", "${name}", "| الثيم:", theme);`,
      };
    },
  },
  {
    category: "database",
    categoryLabel: "قواعد البيانات والسحابة",
    count: 160,
    featured: [
      {
        name: "فتح مدير المستخدمين وطلبات Firestore",
        description: "عرض حسابات Cloud Firestore ومراجعة طلبات الإدارة والرتب",
        actionKind: "open-dev-modal",
      },
      {
        name: "الانتقال المباشر إلى مركز البيانات",
        description: "فتح سحابة الملفات العامة والخاصة ومزامنة المشاريع",
        actionKind: "teleport",
        teleportTarget: "cloud-hub",
      },
      {
        name: "فحص دليل الأشخاص (@amirbaqir226)",
        description: "الاستعلام الحي عن سجل حسابات الدليل من السيرفر",
        actionKind: "api-probe",
        apiRoute: "/api/directory/people",
      },
      {
        name: "مزامنة طلبات الرتب من قاعدة البيانات",
        description: "جلب أحدث طلبات الإدارة والمشرفين المعلّقة",
        actionKind: "api-probe",
        apiRoute: "/api/role-requests",
      },
    ],
    verbs: ["فحص", "مزامنة", "تنظيف", "فهرسة", "تصدير", "تدقيق"],
    subjects: [
      "مجموعة users في Firestore",
      "مجموعة cloud_files السحابية",
      "مجموعة role_requests الإدارية",
      "سجلات forum_posts للمنتدى",
      "سجل platform_updates المباشر",
      "محفظة العملات users_economy",
      "جلسات extension_pairings",
      "بيانات الكاش المحلي LocalStorage",
      "قواعد الأمان Firestore Rules",
      "نسخة احتياطية JSON لمركز البيانات",
    ],
    makeAction: (idx, name) => {
      if (idx % 3 === 0) {
        return { actionKind: "open-dev-modal" };
      }
      if (idx % 5 === 0) {
        return { actionKind: "api-probe", apiRoute: "/api/directory/people" };
      }
      return {
        actionKind: "script",
        scriptCode: `// ${name}\nconst dbId = "ai-studio-iraqicodershubv2-c2936688-472a-4ef3-9093-9e19b38b83b0";\nconsole.log("[DB] فحص قاعدة البيانات:", dbId, "| الوحدة:", "${name}");`,
      };
    },
  },
  {
    category: "server",
    categoryLabel: "السيرفر والـ API",
    count: 160,
    featured: [
      {
        name: "فحص نواة الـ 6 ملفات المدمجة (/api/extension/embedded-core)",
        description: "التأكد من استجابة خادم Express لنواة الإضافة المدمجة",
        actionKind: "api-probe",
        apiRoute: "/api/extension/embedded-core",
      },
      {
        name: "فحص مسار حزمة الإضافة (/api/extension/package)",
        description: "التحقق من إعدادات الحزمة ورابط MediaFire الرسمي",
        actionKind: "api-probe",
        apiRoute: "/api/extension/package",
      },
      {
        name: "فحص تحديثات المنصة الحية (/api/updates)",
        description: "استرجاع جميع التحديثات العامة والخاصة المخزنة بالخادم",
        actionKind: "api-probe",
        apiRoute: "/api/updates",
      },
      {
        name: "فحص حالة جلسة الاقتران IRAQI-CODE-777",
        description: "استعلام مباشر لحالة الاقتران على الخادم",
        actionKind: "api-probe",
        apiRoute: "/api/extension/pairing/status/IRAQI-CODE-777",
      },
    ],
    verbs: ["اختبار", "قياس", "مراقبة", "تشخيص", "تحليل", "ضغط"],
    subjects: [
      "بوابة Express على المنفذ 3000",
      "وسيط Vite في بيئة التطوير",
      "نقطة /api/gemini/generate-update",
      "نقطة /api/gemini/iraqi-bot",
      "نقطة /api/extension/pairing/verify",
      "رؤوس الاستجابة HTTP Headers",
      "زمن الاستجابة Latency Tracker",
      "سجل الطلبات المتزامنة",
      "توصيف المسارات المحمية",
      "سلامة الجلسات والتوكنات",
    ],
    makeAction: (idx, name) => {
      const routes = [
        "/api/extension/embedded-core",
        "/api/directory/people",
        "/api/role-requests",
        "/api/updates",
        "/api/extension/package",
      ];
      if (idx % 2 === 0) {
        return {
          actionKind: "api-probe",
          apiRoute: routes[idx % routes.length],
        };
      }
      return {
        actionKind: "script",
        scriptCode: `// ${name}\nconsole.log("[SERVER] تم تشغيل اختبار الخادم:", "${name}", "| التوقيت:", new Date().toISOString());`,
      };
    },
  },
  {
    category: "bots",
    categoryLabel: "وحدات نشر البوتات",
    count: 160,
    featured: [
      {
        name: "فتح بوت Iraqi Coders Pro داخل المحرر السري",
        description: "تحميل سكربت تشغيل البوتات التفاعلي بدون روت للتجربة والنشر",
        actionKind: "open-editor",
        scriptCode: `// وحدة نشر البوت — عراقي كودرز Cyber-Admin\nconst bot = {\n  name: "IraqiMasterBot",\n  owner: "amirbaqir226",\n  version: "26.5",\n  status: "ONLINE"\n};\nconsole.log("تم نشر البوت بنجاح:", JSON.stringify(bot));`,
      },
      {
        name: "تشغيل وحدة المساعد الذكي Iraqi Bots",
        description: "الانتقال إلى واجهة الدردشة البرمجية المدمجة",
        actionKind: "teleport",
        teleportTarget: "assistant",
      },
      {
        name: "نشر بوت إدارة الرتب والترحيب التلقائي",
        description: "تنفيذ وحدة ترحيب وفحص صلاحيات الأعضاء الجدد",
        actionKind: "script",
        scriptCode: `const members = ["@amirbaqir226", "@iraqi_dev"];\nconsole.log("[BOT DEPLOY] تفعيل الحراسة والترحيب لـ", members.join(", "));`,
      },
    ],
    verbs: ["نشر", "تجهيز", "تهيئة", "ترقية", "جدولة", "توصيل"],
    subjects: [
      "بوت ردود المنتدى التلقائي",
      "بوت فحص أكواد Luau",
      "بوت بناء إضافات ماينكرافت",
      "بوت مراقبة الخوادم 24/7",
      "بوت إشعارات طلبات الإدارة",
      "وحدة Webhook لربط الفرق",
      "بوت النسخ الاحتياطي السحابي",
      "محرك أوامر Slash Commands",
      "بوت تحويل النقاط والعملات",
      "بوت فحص DOM والاقتران",
    ],
    makeAction: (idx, name) => {
      if (idx % 4 === 0) {
        return {
          actionKind: "open-editor",
          scriptCode: `// ${name}\nconst deployConfig = { module: "${name}", owner: "amirbaqir226", autoRestart: true };\nconsole.log("جاهز للنشر:", JSON.stringify(deployConfig, null, 2));`,
        };
      }
      return {
        actionKind: "script",
        scriptCode: `// ${name}\nconsole.log("[BOT MODULE] تشغيل وحدة:", "${name}", "| المالك: amirbaqir226");`,
      };
    },
  },
  {
    category: "scripts",
    categoryLabel: "منفّذ السكربتات",
    count: 160,
    featured: [
      {
        name: "فتح محرر الأكواد السري (بيئة بدون روت)",
        description: "تشغيل IDE الكامل لكتابة وتجربة JS و HTML و Luau و JSON",
        actionKind: "open-editor",
      },
      {
        name: "تنفيذ فحص DOM للشاشة الحية الآن",
        description: "تعداد العناصر النشطة وفحص رموز الاقتران على الصفحة",
        actionKind: "script",
        scriptCode: `const total = document.querySelectorAll("*").length;\nconst pairEl = document.querySelector("[data-live-pairing-code]");\nconsole.log("[DOM] إجمالي العناصر:", total, "| رمز الشاشة:", pairEl?.textContent?.trim() || "غير ظاهر");`,
      },
      {
        name: "قياس استهلاك الذاكرة والأداء الحي",
        description: "قراءة سرعة استجابة الواجهة وتوقيت التحميل",
        actionKind: "script",
        scriptCode: `console.log("[PERF] عرض النافذة:", window.innerWidth + "x" + window.innerHeight, "| المسار:", location.pathname);`,
      },
    ],
    verbs: ["تنفيذ", "تجميع", "فحص", "تحويل", "ضغط", "اختبار"],
    subjects: [
      "سكربت تحليل DOM المباشر",
      "محول صيغ JSON إلى TypeScript",
      "منشئ قوالب HTML5 RTL",
      "مدقق ثغرات XSS السريع",
      "محاكي استجابة API محلي",
      "مولد معرّفات UUID v4",
      "مختبر تعابير Regex البرمجية",
      "أداة تشفير وفك Base64",
      "سكربت مراقبة أحداث PostMessage",
      "محلل بنية Manifest v3",
    ],
    makeAction: (idx, name) => {
      if (idx % 3 === 0) {
        return {
          actionKind: "open-editor",
          scriptCode: `// ${name}\nfunction runTask() {\n  const id = "TASK-${idx + 1}";\n  console.log("تم تشغيل المهمة:", id, "${name}");\n  return true;\n}\nrunTask();`,
        };
      }
      return {
        actionKind: "script",
        scriptCode: `// ${name}\nconst started = Date.now();\nconsole.log("[EXEC] ${name} -> نجح التنفيذ في", (Date.now() - started) + "ms");`,
      };
    },
  },
  {
    category: "security",
    categoryLabel: "الصلاحيات والأمان",
    count: 130,
    featured: [
      {
        name: "التحقق من صلاحيات Master Admin (amirbaqir226)",
        description: "تأكيد الصلاحيات العليا غير القابلة للكسر للمالك والمطور الرئيسي",
        actionKind: "script",
        scriptCode: `console.log("[MASTER ADMIN] الحساب المعتمد: amirbaqir226 | الصلاحيات: Super-Admin + Supervisor + Lead Developer");`,
      },
      {
        name: "فتح إعدادات خيارات المطورين وسجلات النظام",
        description: "مراجعة سجلات AUTH و CLOUD و FIRESTORE وتصديرها",
        actionKind: "open-dev-modal",
      },
    ],
    verbs: ["تدقيق", "تحصين", "تحقق", "مراجعة", "تفعيل", "حماية"],
    subjects: [
      "هوية Master Admin amirbaqir226",
      "جلسات المصادقة السحابية",
      "قنوات PostMessage للإضافة",
      "سياسات Sandbox للإطارات",
      "سجل محاولات الاقتران",
      "صلاحيات المشرفين والمطورين",
      "بوابة التحقق من الطلبات",
      "نظافة المدخلات Sanitization",
    ],
    makeAction: (idx, name) => {
      if (idx % 4 === 0) return { actionKind: "open-dev-modal" };
      return {
        actionKind: "script",
        scriptCode: `// ${name}\nconsole.log("[SECURITY] فحص ناجح:", "${name}", "| Master ID: amirbaqir226");`,
      };
    },
  },
  {
    category: "engines",
    categoryLabel: "الألعاب والمصانع",
    count: 130,
    featured: [
      {
        name: "فتح مصنع الألعاب وتطبيقات APK (استوديو /)",
        description: "بناء وتصدير حزم .mcaddon و APK ومشاريع Roblox Luau",
        actionKind: "open-studio",
      },
      {
        name: "توليد كود مصنع Iraqi Coders Mega Factory",
        description: "فتح إعدادات المصنع النيون السايبر في المحرر السري",
        actionKind: "open-editor",
        scriptCode: `{\n  "factory": "Iraqi Coders Mega Factory",\n  "theme": "Cyberpunk Neon",\n  "author": "amirbaqir226",\n  "format": ".mcaddon"\n}`,
      },
    ],
    verbs: ["بناء", "توليد", "تصدير", "معايرة", "تطوير", "برمجة"],
    subjects: [
      "حزمة Iraqi Coders Mega Factory",
      "حزمة Factory A الصناعية",
      "بنية Behavior Pack JSON",
      "بنية Resource Pack Geometry",
      "نظام عملات Roblox DataStore",
      "حلبة قتال Luau متقدمة",
      "قالب WebView APK جاهز",
      "مؤثرات الجسيمات ثلاثية الأبعاد",
    ],
    makeAction: (idx, name) => {
      if (idx % 4 === 0) return { actionKind: "open-studio" };
      if (idx % 3 === 0) {
        return {
          actionKind: "open-editor",
          scriptCode: `-- ${name}\nlocal config = { author = "amirbaqir226", studio = "Iraqi Coders v26.5" }\nprint("تشغيل:", "${name}")`,
        };
      }
      return {
        actionKind: "script",
        scriptCode: `// ${name}\nconsole.log("[ENGINE] جاهز للتصدير:", "${name}");`,
      };
    },
  },
];

let cachedTools: CyberAdminTool[] | null = null;

export function getCyberAdminToolsRegistry(): CyberAdminTool[] {
  if (cachedTools) return cachedTools;

  const list: CyberAdminTool[] = [];
  let globalCounter = 1;

  for (const seed of SEEDS) {
    const startFeatured = seed.featured;
    for (const item of startFeatured) {
      const code = `TOOL-${String(globalCounter).padStart(4, "0")}`;
      list.push({
        id: `cyber-tool-${globalCounter}`,
        code,
        category: seed.category,
        categoryLabel: seed.categoryLabel,
        ...item,
      });
      globalCounter += 1;
    }

    const remaining = seed.count - startFeatured.length;
    for (let i = 0; i < remaining; i++) {
      const verb = seed.verbs[i % seed.verbs.length];
      const subject =
        seed.subjects[Math.floor(i / seed.verbs.length) % seed.subjects.length];
      const variant = Math.floor(
        i / (seed.verbs.length * seed.subjects.length)
      );
      const name =
        variant === 0
          ? `${verb} ${subject}`
          : `${verb} ${subject} · وحدة ${variant + 1}`;
      const code = `TOOL-${String(globalCounter).padStart(4, "0")}`;
      const action = seed.makeAction(i, name);

      list.push({
        id: `cyber-tool-${globalCounter}`,
        code,
        name,
        category: seed.category,
        categoryLabel: seed.categoryLabel,
        description: `أداة رقم ${code} ضمن ${seed.categoryLabel} — تنفيذ مباشر لـ «${name}».`,
        ...action,
      });
      globalCounter += 1;
    }
  }

  cachedTools = list;
  return list;
}
