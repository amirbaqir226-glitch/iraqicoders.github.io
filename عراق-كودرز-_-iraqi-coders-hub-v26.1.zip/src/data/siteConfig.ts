import {
  CommunityChannelLink,
  ProgrammingLanguageId,
  ShopCategoryId,
  ShopProduct,
  UserRole,
} from "../types";

/**
 * ============================================================================
 * ملف الإعدادات المركزي للمنصة (Central Platform Configuration)
 * ----------------------------------------------------------------------------
 * يمكنك من هنا تعديل أو إضافة أو حذف:
 * 1) روابط البوت والموقع الأساسية
 * 2) روابط المجتمع الرسمية (تليجرام، واتساب، دسكورد)
 * 3) عناصر ومنتجات وخدمات المتجر، الأسعار، العروض الخاصة، وأكواد الخصم
 * 4) روابط شريط التنقل الرئيسي
 * ============================================================================
 */

export const SITE_INFO = {
  brandName: "عراقي كودرز",
  englishBrandName: "Iraqi Coders",
  version: "26.5",
  masterAdminId: "amirbaqir226",
  masterAdminEmail: "amirbaqir226@gmail.com",
  botExternalUrl:
    "https://gemini.google.com/gem/1znq63_oZEnze9exf05KISQyKePfMasTl?usp=sharing",
  botButtonLabel: "Talk to Iraqi Bots",
} as const;

export const WHATSAPP_OWNER_PHONE = "+9647762110049";
export const WHATSAPP_OWNER_URL = "https://wa.me/9647762110049";
export const SECRET_FULL_DISCOUNT_CODE = "امير 2026";
export const REQUIRED_INVOICE_SIGNATURE = "/§§★★@}";

/**
 * روابط المجتمع والتواصل الرسمية
 */
export const COMMUNITY_CHANNELS: CommunityChannelLink[] = [
  {
    id: "telegram",
    name: "قناة ومجتمع تليجرام",
    englishName: "Telegram",
    handleOrTag: "@IraqKodi",
    description:
      "تحديثات المنصة الفورية، نشر الأكواد الجاهزة، متابعة الطلبات، والدعم السريع للمطورين.",
    ctaLabel: "انضم عبر تليجرام",
    url: "https://t.me/IraqKodi",
    accentColor: "sky",
  },
  {
    id: "whatsapp",
    name: "تواصل واتساب المباشر",
    englishName: "WhatsApp",
    handleOrTag: WHATSAPP_OWNER_PHONE,
    description:
      "تواصل مباشر عبر الرقم +9647762110049 لتأكيد طلبات الشراء، توقيع الفواتير، والدعم الفوري.",
    ctaLabel: "تواصل عبر واتساب",
    url: WHATSAPP_OWNER_URL,
    accentColor: "emerald",
  },
  {
    id: "discord",
    name: "سيرفر دسكورد المطورين",
    englishName: "Discord",
    handleOrTag: "discord.gg/Ezmt3yRwp",
    description:
      "غرف برمجة مباشرة، مشاركة مشاريع Roblox و Minecraft، واستلام الطلبات والدعم الفني.",
    ctaLabel: "ادخل سيرفر دسكورد",
    url: "https://discord.gg/Ezmt3yRwp",
    accentColor: "indigo",
  },
];

export interface NavLinkConfigItem {
  label: string;
  href: string;
  external?: boolean;
}

export const NAV_LINKS_CONFIG: NavLinkConfigItem[] = [
  { label: "الرئيسية", href: "#hero" },
  { label: "التحديات", href: "#challenges" },
  { label: "انشئ كل شيء", href: "#omni-studio" },
  { label: "المتجر والبيع", href: "#shop" },
  { label: "محرر الكود", href: "#playground" },
  { label: "التواصل", href: "#contact-channels" },
];

export const SHOP_SETTINGS = {
  sectionId: "shop",
  title: "متجر عراقي كودرز والخدمات البرمجية",
  subtitle:
    "اقتنِ أنظمة ألعاب جاهزة، قوالب مواقع وتطبيقات، أو اطلب تطوير مشروعك الخاص مع حساب فوري للإجمالي وتأكيد مباشر عبر قنواتنا الرسمية.",
  iqdPerUsd: 1500,
  promoCodes: [
    { code: "IRAQ26", discountPercent: 10, label: "خصم ترحيبي 10%" },
    { code: "CODERS20", discountPercent: 20, label: "خصم المطورين 20%" },
  ],
  categories: [
    { id: "all" as ShopCategoryId, label: "الكل" },
    { id: "web" as ShopCategoryId, label: "مواقع وتطبيقات" },
    { id: "games" as ShopCategoryId, label: "ألعاب ومودات" },
    { id: "services" as ShopCategoryId, label: "خدمات برمجية" },
    { id: "tools" as ShopCategoryId, label: "أدوات مطورين" },
  ],
} as const;

export function formatIqdPrice(usdAmount: number): string {
  const iqd = Math.round(usdAmount * SHOP_SETTINGS.iqdPerUsd);
  return `${iqd.toLocaleString("en-US")} د.ع`;
}

export function formatUsdPrice(usdAmount: number): string {
  return `$${usdAmount % 1 === 0 ? usdAmount.toFixed(0) : usdAmount.toFixed(2)}`;
}

/**
 * ============================================================================
 * إعدادات نشر المنتجات الخاصة والصلاحيات المسموحة (Shop Publishing RBAC)
 * ----------------------------------------------------------------------------
 * قائمة الرتب المسموح لها برؤية واستخدام تبويب «انشر منتجك الخاص»:
 * المطور (developer)، المشرف (moderator)، والمسؤول (admin)
 * ============================================================================
 */
export const SHOP_PUBLISH_SETTINGS = {
  tabLabel: "انشر منتجك الخاص",
  allowedRoles: [
    "developer",
    "moderator",
    "director",
    "admin",
  ] as readonly UserRole[],
  roleLabels: {
    developer: "مطور (Developer)",
    moderator: "مشرف (Moderator)",
    director: "مدير (Director)",
    admin: "مسؤول (Admin)",
    user: "مستخدم عادي",
  } as Record<UserRole, string>,
  defaultDeliveryTime: "تسليم فوري عبر التواصل",
  defaultAvailabilityLabel: "متوفر الآن · منتج منشور",
  maxCustomProducts: 50,
} as const;

/**
 * دالة التحقق المركزية من صلاحية نشر منتج جديد داخل نافذة السلة والمتجر
 */
export function canPublishShopProduct(
  role: UserRole | string | null | undefined
): boolean {
  if (!role) return false;
  return SHOP_PUBLISH_SETTINGS.allowedRoles.includes(role as UserRole);
}

/**
 * ============================================================================
 * الترحيب حسب الرتبة (المستشار العام) وصلاحيات قسم التحديات وبيئة البيتا
 * ============================================================================
 */
export function getGreetingForRole(role: UserRole): {
  title: string;
  advisorTitle: string;
  badgeText: string;
} {
  if (role === "admin") {
    return {
      title: "مرحبا بك يا مسؤول الموقع يا رافع الراس",
      advisorTitle: "المستشار العام · تحية المسؤول الأعلى",
      badgeText: "مسؤول الموقع",
    };
  }
  if (role === "director" || role === "moderator") {
    return {
      title: "مرحبا بك يا مديرنا",
      advisorTitle: "المستشار العام · تحية المدير والمشرف",
      badgeText: role === "director" ? "المدير" : "المشرف / المدير",
    };
  }
  if (role === "developer") {
    return {
      title: "مرحبا بعودتك يا مطورنا",
      advisorTitle: "المستشار العام · تحية المطورين",
      badgeText: "مطور معتمد",
    };
  }
  return {
    title: "مرحبا",
    advisorTitle: "المستشار العام · ترحيب الزوار والأعضاء",
    badgeText: "عضو / زائر",
  };
}

export const CHALLENGE_ACCESS_SETTINGS = {
  allowedRoles: ["developer", "director", "admin"] as readonly UserRole[],
} as const;

export function canCreateChallenge(
  role: UserRole | string | null | undefined
): boolean {
  if (!role) return false;
  return CHALLENGE_ACCESS_SETTINGS.allowedRoles.includes(role as UserRole);
}

export const REQUIRED_CODE_SEAL = "Iraqi Coders  1329";

export interface BetaLanguageOption {
  id: ProgrammingLanguageId;
  name: string;
  extension: string;
  tagline: string;
  sampleCode: string;
}

export const BETA_PROGRAMMING_LANGUAGES: BetaLanguageOption[] = [
  {
    id: "python",
    name: "Python",
    extension: "py",
    tagline: "ذكاء اصطناعي، أتمتة، وألعاب بايثون سريعة",
    sampleCode: `# مشروع بايثون من عراقي كودرز\ndef start_game():\n    title = "مغامرة بغداد"\n    score = 100\n    print("تم تشغيل:", title, "النقاط:", score)\n\nstart_game()\n${REQUIRED_CODE_SEAL}`,
  },
  {
    id: "java",
    name: "Java",
    extension: "java",
    tagline: "تطبيقات أندرويد وأنظمة كائنية التوجه",
    sampleCode: `public class IraqiApp {\n  public static void main(String[] args) {\n    String appName = "تطبيق عراقي كودرز";\n    System.out.println("تشغيل: " + appName);\n  }\n}\n${REQUIRED_CODE_SEAL}`,
  },
  {
    id: "groovy",
    name: "Groovy",
    extension: "groovy",
    tagline: "سكربتات Gradle وأتمتة بناء Android و Jenkins",
    sampleCode: `def projectTitle = "محرك ألعاب كروك"\nprintln "تهيئة البناء السريع: $projectTitle"\n[1, 2, 3].each { level -> println "مستوى جاهز: $level" }\n${REQUIRED_CODE_SEAL}`,
  },
  {
    id: "luau",
    name: "Roblox Luau",
    extension: "luau",
    tagline: "سكربتات ألعاب Roblox ثلاثية الأبعاد",
    sampleCode: `local Players = game:GetService("Players")\nprint("مرحباً في ماب عراقي كودرز!")\n${REQUIRED_CODE_SEAL}`,
  },
  {
    id: "javascript",
    name: "JavaScript / Web",
    extension: "js",
    tagline: "ألعاب المتصفح وواجهات الويب التفاعلية",
    sampleCode: `const appTitle = "تطبيق ويب عراقي كودرز";\nconsole.log("تم التشغيل بنجاح:", appTitle);\n${REQUIRED_CODE_SEAL}`,
  },
  {
    id: "cpp",
    name: "C++",
    extension: "cpp",
    tagline: "محركات ألعاب عالية الأداء ورسوميات 3D",
    sampleCode: `#include <iostream>\nint main() {\n  std::cout << "Iraqi Coders Engine Ready!" << std::endl;\n  return 0;\n}\n${REQUIRED_CODE_SEAL}`,
  },
];

/**
 * قائمة منتجات وعناصر وخدمات المتجر القابلة للتعديل بسهولة
 */
export const SHOP_PRODUCTS: ShopProduct[] = [
  {
    id: "prod-vip-subscription",
    title: "اشتراك VIP الرسمي (إخفاء الإعلانات + مزايا النخبة)",
    category: "tools",
    categoryLabel: "عضوية VIP",
    description:
      "اشتراك VIP الرسمي لإزالة جميع المساحات الإعلانية من الموقع بالكامل، مع شارة التميز ودعم أولوية الطلبات.",
    features: [
      "إخفاء جميع الإعلانات تلقائياً وفوراً",
      "أولوية تنفيذ طلبات المتجر والدعم الفني",
      "تفعيل دائم مرتبط بحسابك داخل المنصة",
    ],
    priceUsd: 9,
    originalPriceUsd: 15,
    availability: "special_offer",
    availabilityLabel: "عرض VIP · خصم 40%",
    deliveryTime: "تفعيل فوري بعد التأكيد",
    accentColor: "amber",
  },
  {
    id: "prod-fullstack-store-web",
    title: "باقة موقع ومتجر إلكتروني متكامل",
    category: "web",
    categoryLabel: "مواقع وتطبيقات",
    description:
      "تصميم وبرمجة موقع ويب سريع ومتجاوب للموبايل والكمبيوتر مع سلة تسوق ولوحة إدارة وربط Firebase.",
    features: [
      "تصميم عربي RTL احترافي متجاوب بالكامل",
      "سلة مشتريات وحساب أسعار تلقائي",
      "لوحة تعديل سهلة لإضافة المنتجات والروابط",
    ],
    priceUsd: 45,
    originalPriceUsd: 65,
    availability: "special_offer",
    availabilityLabel: "عرض خاص · خصم 30%",
    deliveryTime: "تسليم خلال 48 ساعة",
    accentColor: "emerald",
  },
  {
    id: "prod-roblox-luau-system",
    title: "حزمة أنظمة Roblox Luau الاحترافية",
    category: "games",
    categoryLabel: "ألعاب ومودات",
    description:
      "مجموعة سكربتات كاملة تشمل نظام المتجر داخل اللعبة، حماية Anti-Cheat، وحفظ بيانات اللاعبين DataStore.",
    features: [
      "نظام حفظ بيانات آمن بدون فقدان",
      "حماية ضد التلاعب بالسرعة والعملات",
      "واجهة متجر ماب متكاملة وجاهزة للربط",
    ],
    priceUsd: 18,
    originalPriceUsd: 25,
    availability: "special_offer",
    availabilityLabel: "عرض خاص",
    deliveryTime: "تسليم فوري",
    accentColor: "violet",
  },
  {
    id: "prod-minecraft-bedrock-pack",
    title: "مود وحزمة المصانع الذكية — Minecraft Bedrock",
    category: "games",
    categoryLabel: "ألعاب ومودات",
    description:
      "إضافة (.mcaddon) متكاملة تضم آلات توليد موارد، سيوف مخصصة، وقوائم تفاعلية بدون أي أخطاء.",
    features: [
      "ملفات Behavior & Resource Pack جاهزة",
      "متوافق مع أحدث إصدارات Minecraft",
      "دعم التعديل وإضافة عناصر جديدة بسهولة",
    ],
    priceUsd: 12,
    availability: "available",
    availabilityLabel: "متوفر الآن",
    deliveryTime: "تسليم فوري",
    accentColor: "emerald",
  },
  {
    id: "prod-android-apk-builder",
    title: "خدمة تحويل وتجهيز تطبيق أندرويد APK",
    category: "services",
    categoryLabel: "خدمات برمجية",
    description:
      "بناء وتغليف موقعك أو مشروعك إلى تطبيق Android APK جاهز للتثبيت مع أيقونة مخصصة وإشعارات.",
    features: [
      "تهيئة ملفات AndroidManifest وصلاحيات التطبيق",
      "سرعة عالية وتوافق مع الهواتف الحديثة",
      "اختبار شامل قبل التسليم النهائي",
    ],
    priceUsd: 30,
    availability: "available",
    availabilityLabel: "متوفر الآن",
    deliveryTime: "تسليم خلال 24 ساعة",
    accentColor: "sky",
  },
  {
    id: "prod-firebase-backend-setup",
    title: "خدمة إعداد Firebase وقواعد الأمان والسيرفر",
    category: "services",
    categoryLabel: "خدمات برمجية",
    description:
      "ربط مشروعك بقاعدة بيانات Firestore ومصادقة Google وكتابة قواعد حماية محكمة للبيانات.",
    features: [
      "ضبط Authentication وتسجيل دخول آمن",
      "كتابة قواعد Firestore Rules ضد الاختراق",
      "مزامنة لحظية للمستخدمين والطلبات",
    ],
    priceUsd: 25,
    availability: "limited",
    availabilityLabel: "حجز محدود هذا الأسبوع",
    deliveryTime: "تسليم خلال 24 ساعة",
    accentColor: "amber",
  },
  {
    id: "prod-dev-vip-toolkit",
    title: "حزمة أدوات المطور العراقي الشاملة",
    category: "tools",
    categoryLabel: "أدوات مطورين",
    description:
      "مكتبة قوالب ويب، مكونات React، إضافات متصفح، وسكربتات أتمتة لتسريع بناء مشاريعك التجارية.",
    features: [
      "أكثر من 25 قالباً جاهزاً قابلاً للتعديل",
      "دعم كامل للوضع الليلي و Tailwind CSS",
      "تحديثات مجانية مستمرة عبر تليجرام",
    ],
    priceUsd: 15,
    availability: "available",
    availabilityLabel: "متوفر الآن",
    deliveryTime: "تسليم فوري",
    accentColor: "violet",
  },
];

/**
 * ============================================================================
 * إعدادات نظام الإعلانات وشبكات الإعلان الخارجية (Ad Networks & Slots)
 * ----------------------------------------------------------------------------
 * يمكن للمسؤول تعديل معرف شبكة Google AdSense أو نصوص البنرات أو تعطيلها من هنا
 * ============================================================================
 */
export interface AdSlotConfig {
  id: string;
  placement: "top-leaderboard" | "mid-infeed";
  networkLabel: string;
  googleAdSlotId: string;
  sponsorName: string;
  headline: string;
  description: string;
  ctaLabel: string;
  ctaHref: string;
  ctaExternal?: boolean;
  accent: "emerald" | "violet";
}

export const AD_SYSTEM_CONFIG = {
  enabled: true,
  googleAdClient: "ca-pub-iraqicoders-v26",
  slots: [
    {
      id: "ad-top-leaderboard",
      placement: "top-leaderboard",
      networkLabel: "Google AdSense · Leaderboard",
      googleAdSlotId: "SLOT-72890-TOP",
      sponsorName: "شبكة المطورين والخدمات السحابية",
      headline: "استضافة مشاريعك وبناء تطبيقاتك باحترافية مع باقات عراقي كودرز",
      description:
        "احصل على استضافة سريعة، قوالب مواقع جاهزة، أو اشترك في عضوية VIP لإخفاء جميع الإعلانات فوراً.",
      ctaLabel: "استكشف عروض المتجر",
      ctaHref: "#shop",
      ctaExternal: false,
      accent: "emerald",
    },
    {
      id: "ad-mid-infeed",
      placement: "mid-infeed",
      networkLabel: "Google AdSense · In-Feed Banner",
      googleAdSlotId: "SLOT-46860-MID",
      sponsorName: "شركاء التعليم والبرمجة · Iraqi Coders Ads",
      headline: "انضم لقناة تليجرام الرسمية لمتابعة المسابقات والأكواد المجانية يومياً",
      description:
        "مساحة إعلانية منظمة تظهر للمستخدمين العاديين فقط وتختفي تلقائياً للمشرفين ومشتركي VIP ومفعّلي DNS.",
      ctaLabel: "انضم عبر تليجرام",
      ctaHref: "https://t.me/IraqKodi",
      ctaExternal: true,
      accent: "violet",
    },
  ] as AdSlotConfig[],
} as const;

