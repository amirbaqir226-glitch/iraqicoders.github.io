import heroBannerImg from "../assets/images/hero_iraqi_coders_1794740160547.jpg";
import robloxCoverImg from "../assets/images/project_roblox_luau_1794740161020.jpg";
import minecraftCoverImg from "../assets/images/project_minecraft_addon_1794740160137.jpg";
import devAvatarImg from "../assets/images/avatar_developer_iraq_1794740161460.jpg";
import siteIdentityEmblemImg from "../assets/images/site_identity_emblem_1795373010415.jpg";
import devHammerEmblemImg from "../assets/images/developer_hammer_emblem_1795373011577.jpg";
import {
  FACTORY_BP_MANIFEST,
  FACTORY_MAIN_SCRIPT,
} from "../services/minecraftFactoryPack";
import {
  ChallengeItem,
  CloudFileItem,
  ForumPost,
  PlaygroundTemplate,
  ProjectItem,
  PublishedMiniProject,
  SchoolUpdateItem,
  StoreItem,
} from "../types";

export const DEFAULT_DEVELOPER_AVATAR = devAvatarImg;

export const HERO_BANNER_IMAGE = heroBannerImg;

export const SITE_IDENTITY_EMBLEM = siteIdentityEmblemImg;

export const DEV_HAMMER_EMBLEM = devHammerEmblemImg;

export const PRESET_AVATARS: { id: string; label: string; url: string }[] = [
  {
    id: "avatar-dev",
    label: "المطور العراقي",
    url: devAvatarImg,
  },
  {
    id: "avatar-cyber",
    label: "مبرمج النيون",
    url: `data:image/svg+xml;utf8,${encodeURIComponent(
      '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120"><defs><linearGradient id="g1" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#7c3aed"/><stop offset="100%" stop-color="#10b981"/></linearGradient></defs><rect width="120" height="120" rx="60" fill="#0B0F19"/><circle cx="60" cy="60" r="54" fill="url(#g1)" opacity="0.24"/><path d="M40 48 L26 60 L40 72 M80 48 L94 60 L80 72 M66 40 L54 80" stroke="#34d399" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" fill="none"/></svg>'
    )}`,
  },
  {
    id: "avatar-electric",
    label: "برق بغداد",
    url: `data:image/svg+xml;utf8,${encodeURIComponent(
      '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120"><rect width="120" height="120" rx="60" fill="#0F172A"/><circle cx="60" cy="60" r="52" fill="#f59e0b" opacity="0.18"/><path d="M66 22 L38 64 H58 L52 98 L84 54 H63 Z" fill="#fbbf24" stroke="#38bdf8" stroke-width="3" stroke-linejoin="round"/></svg>'
    )}`,
  },
  {
    id: "avatar-halloween",
    label: "فانوس الهالوين",
    url: `data:image/svg+xml;utf8,${encodeURIComponent(
      '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120"><rect width="120" height="120" rx="60" fill="#180D24"/><circle cx="60" cy="64" r="36" fill="#ea580c"/><rect x="55" y="20" width="10" height="14" rx="3" fill="#22c55e"/><polygon points="44,54 52,62 38,62" fill="#180D24"/><polygon points="76,54 82,62 68,62" fill="#180D24"/><path d="M42 74 Q60 88 78 74" stroke="#180D24" stroke-width="6" fill="none" stroke-linecap="round"/></svg>'
    )}`,
  },
];

export const STORE_ITEMS: StoreItem[] = [
  {
    id: "skin-gold-frame",
    name: "إطار المطور الذهبي",
    description: "إطار ذهبي متوهج حول صورتك الشخصية في الشريط العلوي والمنتدى.",
    priceCoins: 80,
    category: "skin",
    previewColor: "#F59E0B",
  },
  {
    id: "skin-baghdad-neon",
    name: "هالة نيون دجلة",
    description: "هالة مزدوجة بالبنفسجي والأخضر الزمردي لهويتك البرمجية.",
    priceCoins: 150,
    category: "skin",
    previewColor: "#10B981",
  },
  {
    id: "item-vip-badge",
    name: "شارة مبرمج نخبة عراقي (VIP)",
    description:
      "شارة فخرية بجانب اسمك مع تفعيل عضوية VIP لإخفاء جميع الإعلانات تلقائياً.",
    priceCoins: 240,
    category: "tool",
    previewColor: "#8B5CF6",
  },
  {
    id: "item-vip-subscription",
    name: "اشتراك VIP بدون إعلانات (بالعملات)",
    description:
      "عضوية VIP خاصة تخفي جميع المساحات الإعلانية والبنرات من الموقع بالكامل.",
    priceCoins: 200,
    category: "tool",
    previewColor: "#F59E0B",
  },
  {
    id: "item-apk-pro-template",
    name: "قالب ألعاب APK الاحترافي",
    description: "يفتح قوالب ألعاب وتطبيقات متقدمة داخل محرر الكود السري (/).",
    priceCoins: 180,
    category: "tool",
    previewColor: "#38BDF8",
  },
  {
    id: "theme-halloween-pack",
    name: "حزمة زينة الهالوين الملكية",
    description: "فتح زينة الهالوين التفاعلية مع فوانيس وخيوط عنكبوت متوهجة.",
    priceCoins: 100,
    category: "theme",
    previewColor: "#EA580C",
  },
  {
    id: "theme-electric-pack",
    name: "حزمة زينة الكهرباء 220V",
    description: "تأثيرات شرارات الطاقة العراقية ومولد الوطنية في واجهة الموقع.",
    priceCoins: 120,
    category: "theme",
    previewColor: "#FBBF24",
  },
];

export const INITIAL_PUBLIC_CLOUD_FILES: CloudFileItem[] = [
  {
    id: "cloud-pub-baghdad-runner",
    ownerId: "community-baghdad-studio",
    ownerName: "ستوديو دجلة للألعاب",
    ownerHandle: "@tigris_games",
    title: "لعبة سباق بغداد السريع — حزمة ويب كاملة (ZIP)",
    description:
      "أرشيف ZIP متكامل يضم index.html و styles.css و script.js لتشغيل لعبة سباق بغداد السريع في المتصفح.",
    fileName: "baghdad_runner_web_game.zip",
    fileType: "web",
    fileSizeBytes: 3420,
    visibility: "public",
    downloads: 345,
    createdAt: "منذ يومين",
    content: `<div style="text-align:center;padding:24px;font-family:Cairo,sans-serif">
  <h3>سباق بغداد السريع — اضغط مسافة للقفز</h3>
  <canvas id="game" width="480" height="240" style="border:2px solid #8b5cf6;border-radius:14px;background:#111827"></canvas>
</div>
<script>
  const c = document.getElementById('game'), ctx = c.getContext('2d');
  let y = 180, vy = 0, obsX = 480, score = 0;
  window.addEventListener('keydown', e => { if (e.code === 'Space' && y >= 180) vy = -11; });
  setInterval(() => {
    ctx.clearRect(0,0,480,240);
    vy += 0.6; y = Math.min(180, y + vy);
    obsX -= 5; if (obsX < -20) { obsX = 480; score++; }
    ctx.fillStyle = '#34d399'; ctx.fillRect(60, y, 28, 28);
    ctx.fillStyle = '#f43f5e'; ctx.fillRect(obsX, 184, 20, 24);
    ctx.fillStyle = '#fff'; ctx.fillText('النقاط: ' + score, 20, 28);
  }, 20);
</script>`,
  },
  {
    id: "cloud-pub-iraqi-tools-apk",
    ownerId: "community-basra-mobile",
    ownerName: "مصطفى البصراوي",
    ownerHandle: "@basra_apk",
    title: "تطبيق أدوات المطور العراقي للأندرويد (APK)",
    description:
      "حزمة APK قياسية بصيغة أرشيف حقيقية تضم AndroidManifest.xml و assets/www/index.html للتشغيل والتطوير.",
    fileName: "iraqi_coders_toolkit_v26.apk",
    fileType: "apk",
    fileSizeBytes: 4860,
    visibility: "public",
    downloads: 589,
    createdAt: "منذ 3 أيام",
    content: `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"/><meta name="viewport" content="width=device-width,initial-scale=1.0"/><title>أدوات المطور العراقي</title></head><body style="margin:0;background:#0B0F19;color:#F1F5F9;font-family:Cairo,sans-serif;padding:24px"><h2>أدوات المطور العراقي v26.5</h2><p>تطبيق أدوات الشبكة وحسابات Firebase.</p></body></html>`,
  },
  {
    id: "cloud-pub-luau-anticheat",
    ownerId: "community-erbil-luau",
    ownerName: "أحمد الركابي",
    ownerHandle: "@ahmad_luau",
    title: "وحدة حماية السرعة والانتقال السريع — Roblox Luau",
    description:
      "سكربت خادم جاهز لاكتشاف تجاوزات سرعة اللاعبين في مابات Roblox مع إشعار فوري للإدارة وتسجيل المخالفة.",
    fileName: "IraqiAntiCheat_v26.lua",
    fileType: "code",
    fileSizeBytes: 1420,
    visibility: "public",
    downloads: 428,
    createdAt: "منذ 6 ساعات",
    content: `-- عراقي كودرز — وحدة الحماية من اختراق السرعة (Luau)
local Players = game:GetService("Players")
local MAX_STUDS_PER_SEC = 42

Players.PlayerAdded:Connect(function(player)
    player.CharacterAdded:Connect(function(char)
        local root = char:WaitForChild("HumanoidRootPart")
        local lastPos = root.Position
        task.spawn(function()
            while char.Parent do
                task.wait(1)
                local dist = (root.Position - lastPos).Magnitude
                if dist > MAX_STUDS_PER_SEC then
                    root.CFrame = CFrame.new(lastPos)
                else
                    lastPos = root.Position
                end
            end
        end)
    end)
end)`,
  },
  {
    id: "cloud-pub-minecraft-factories-mcaddon",
    ownerId: "community-kirkuk-mc",
    ownerName: "فريق عراقي كودرز",
    ownerHandle: "@iraqicoders_mc",
    title: "توسعة مصانع عراقي كودرز ومصنع A العملاق (.mcaddon)",
    description:
      "تضيف «مصنع آيرون كودرز الكبير» بنظام RGB و «مصنع A الكبير» عند نقطة البداية مع 5 بلوكات مخصصة ووحدات تصنيع آلي متوافقة مع أندرويد 14.",
    fileName: "iraqi_coders_factories_v26.mcaddon",
    fileType: "minecraft",
    fileSizeBytes: 18450,
    visibility: "public",
    downloads: 612,
    createdAt: "الآن",
    content: FACTORY_MAIN_SCRIPT,
  },
  {
    id: "cloud-pub-minecraft-factories-mcworld",
    ownerId: "community-kirkuk-mc",
    ownerName: "فريق عراقي كودرز",
    ownerHandle: "@iraqicoders_mc",
    title: "عالم المصانع الصناعية الجاهز (.mcworld — Android 14)",
    description:
      "ملف عالم Bedrock جاهز للاستيراد فوراً يضم المصنعين في نقطة البداية مع الحزم المفعّلة تلقائياً (Behavior + Resource Packs).",
    fileName: "iraqi_coders_factories_world.mcworld",
    fileType: "minecraft",
    fileSizeBytes: 19620,
    visibility: "public",
    downloads: 488,
    createdAt: "الآن",
    content: FACTORY_BP_MANIFEST,
  },
  {
    id: "cloud-pub-minecraft-hud",
    ownerId: "community-najaf-mc",
    ownerName: "زينب العبيدي",
    ownerHandle: "@zainab_mc",
    title: "حزمة المعركة العربية لـ Minecraft Bedrock (.mcaddon)",
    description:
      "ملف .mcaddon حقيقي بصيغة ZIP قياسية مع behavior_pack و resource_pack و manifest.json صالح للاستيراد بدون أخطاء.",
    fileName: "arabic_combat_hud.mcaddon",
    fileType: "minecraft",
    fileSizeBytes: 3120,
    visibility: "public",
    downloads: 294,
    createdAt: "أمس",
    content: `import { world } from "@minecraft/server";

world.afterEvents.entityHitEntity.subscribe((ev) => {
  ev.damagingEntity?.onScreenDisplay?.setActionBar("§aعراقي كودرز: إصابة دقيقة!");
});`,
  },
];

export const INITIAL_PROJECTS: ProjectItem[] = [
  {
    id: "proj-minecraft-mega-factories",
    title: "توسعة عالم المصانع: Iraqi Coders Mega Factory & Factory A",
    category: "minecraft",
    categoryLabel: "Minecraft Add-on",
    author: "إدارة Iraqi Coders",
    city: "كركوك",
    version: "v26.5",
    downloads: 1640,
    summary:
      "توسعة كاملة لـ Minecraft Bedrock 1.21+ (أندرويد 14 بدون تقطيع) تولّد مصنع آيرون كودرز RGB ومصنع A الكبير عند نقطة البداية مع بلوكات وخزن وأدوات تفاعلية.",
    imageUrl: minecraftCoverImg,
    fileName: "iraqi_coders_factories_manifest.json",
    language: "json",
    installSteps: [
      "نزّل حزمة iraqi_coders_factories_v26.mcaddon أو ملف العالم .mcworld من سحابة عراقي كودرز.",
      "على أندرويد 14 افتح الملف مباشرة بواسطة Minecraft ليتم استيراد حزمتي السلوك والموارد تلقائياً.",
      "ادخل العالم وستبدأ عملية بناء المصنعين عند نقطة السباون عبر system.runJob بسرعة 60 إطار/ثانية.",
    ],
    codePreview: FACTORY_BP_MANIFEST,
  },
  {
    id: "proj-roblox-baghdad-arena",
    title: "نظام القتال السريع وحماية البيانات — Luau",
    category: "roblox",
    categoryLabel: "Roblox (Luau)",
    author: "أحمد الركابي",
    city: "بغداد",
    version: "v2.4",
    downloads: 1420,
    summary:
      "سكربت خادم متكامل بلغة Luau لإدارة نقاط اللاعبين وحفظها عبر DataStoreService مع حماية من التكرار وتأخير الشبكة.",
    imageUrl: robloxCoverImg,
    fileName: "BaghdadArenaCombat.lua",
    language: "lua",
    installSteps: [
      "افتح Roblox Studio وانتقل إلى ServerScriptService.",
      "أنشئ Script جديداً والصق الكود البرمجي المرفق.",
      "تأكد من تفعيل خيار Enable Studio Access to API Services من Game Settings.",
    ],
    codePreview: `--[[
  عراق كودرز — نظام القتال وحفظ البيانات (الإصدار 26.1)
  المطور: أحمد الركابي (بغداد)
]]

local Players = game:GetService("Players")
local DataStoreService = game:GetService("DataStoreService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local ArenaStore = DataStoreService:GetDataStore("IraqiCoders_Arena_v26")
local COOLDOWN_SECONDS = 0.65
local lastStrike = {}

local function loadPlayerStats(player: Player)
    local leaderstats = Instance.new("Folder")
    leaderstats.Name = "leaderstats"
    leaderstats.Parent = player

    local points = Instance.new("IntValue")
    points.Name = "Points"
    points.Value = 0
    points.Parent = leaderstats

    local success, savedData = pcall(function()
        return ArenaStore:GetAsync("player_" .. tostring(player.UserId))
    end)

    if success and type(savedData) == "table" then
        points.Value = savedData.Points or 0
    end
end

local function savePlayerStats(player: Player)
    local leaderstats = player:FindFirstChild("leaderstats")
    if not leaderstats then return end
    local points = leaderstats:FindFirstChild("Points")
    if not points then return end

    pcall(function()
        ArenaStore:SetAsync("player_" .. tostring(player.UserId), {
            Points = points.Value,
            UpdatedAt = os.time(),
        })
    end)
end

Players.PlayerAdded:Connect(loadPlayerStats)
Players.PlayerRemoving:Connect(savePlayerStats)

print("[IraqiCoders] تم تشغيل نظام الساحة بنجاح")`,
  },
  {
    id: "proj-minecraft-ur-ziggurat",
    title: "حزمة زقورة أور والإضاءة الديناميكية — Bedrock Add-on",
    category: "minecraft",
    categoryLabel: "Minecraft Add-on",
    author: "زينب العبيدي",
    city: "البصرة",
    version: "v1.8",
    downloads: 985,
    summary:
      "إضافة متوافقة مع Minecraft Bedrock 1.21 تضيف كتل معمارية مستوحاة من الحضارة الرافدينية مع فوانيس زمردية تفاعلية.",
    imageUrl: minecraftCoverImg,
    fileName: "ur_ziggurat_addon_manifest.json",
    language: "json",
    installSteps: [
      "أنشئ مجلد الحزمة داخل com.mojang/behavior_packs.",
      "احفظ ملف manifest.json داخل المجلد الرئيسي للحزمة.",
      "فعّل الحزمة من إعدادات العالم تحت قسم Behavior Packs و Experiments.",
    ],
    codePreview: `{
  "format_version": 2,
  "header": {
    "name": "حزمة زقورة أور — عراق كودرز",
    "description": "إضافة معمارية رافدينية مع بلوكات مضيئة وسكربتات تفاعلية",
    "uuid": "8c4b9120-26a1-4b88-9e12-104920260001",
    "version": [1, 8, 0],
    "min_engine_version": [1, 21, 0]
  },
  "modules": [
    {
      "description": "وحدة السلوك الأساسية لبلوكات الزقورة",
      "type": "data",
      "uuid": "8c4b9120-26a1-4b88-9e12-104920260002",
      "version": [1, 8, 0]
    },
    {
      "description": "سكربت الإضاءة التفاعلية",
      "type": "script",
      "language": "javascript",
      "uuid": "8c4b9120-26a1-4b88-9e12-104920260003",
      "entry": "scripts/ziggurat_lantern.js",
      "version": [1, 8, 0]
    }
  ],
  "dependencies": [
    {
      "module_name": "@minecraft/server",
      "version": "1.14.0"
    }
  ]
}`,
  },
  {
    id: "proj-roblox-marketplace-ui",
    title: "متجر العملات وتأثيرات النيون — Roblox Client",
    category: "roblox",
    categoryLabel: "Roblox (Luau)",
    author: "مصطفى الجبوري",
    city: "أربيل",
    version: "v3.0",
    downloads: 1190,
    summary:
      "وحدة واجهة مستخدم متجاوبة للعميل باستخدام TweenService مع تأثيرات انتقال ناعمة وصوت نقر احترافي.",
    imageUrl: robloxCoverImg,
    fileName: "NeonShopController.lua",
    language: "lua",
    installSteps: [
      "ضع الملف كـ LocalScript داخل ScreenGui في StarterGui.",
      "اربط زر الفتح بالمتغير toggleButton.",
      "اختبر الحركة عبر وضع Play Test.",
    ],
    codePreview: `--[[
  وحدة التحكم بالمتجر — عراق كودرز
  تستخدم TweenService لحركة انسيابية بسرعة 60 إطار/ثانية
]]

local TweenService = game:GetService("TweenService")
local shopFrame = script.Parent:WaitForChild("ShopFrame")
local toggleButton = script.Parent:WaitForChild("ToggleButton")

local isOpen = false
local tweenInfo = TweenInfo.new(0.28, Enum.EasingStyle.Quint, Enum.EasingDirection.Out)

local function setShopState(open: boolean)
    isOpen = open
    local targetPosition = if open
        then UDim2.fromScale(0.5, 0.5)
        else UDim2.fromScale(0.5, 1.35)
    TweenService:Create(shopFrame, tweenInfo, { Position = targetPosition }):Play()
end

toggleButton.MouseButton1Click:Connect(function()
    setShopState(not isOpen)
end)`,
  },
  {
    id: "proj-minecraft-npc-trader",
    title: "تاجر دجلة الذكي — Minecraft Script API",
    category: "minecraft",
    categoryLabel: "Minecraft Add-on",
    author: "حسين الساعدي",
    city: "النجف",
    version: "v1.5",
    downloads: 760,
    summary:
      "سكربت @minecraft/server لإنشاء تاجر متجول يبيع أدوات مطورة مقابل الزمرد مع حوار تفاعلي عربي.",
    imageUrl: minecraftCoverImg,
    fileName: "tigris_trader_behavior.js",
    language: "javascript",
    installSteps: [
      "أضف السكربت داخل مجلد scripts/ في حزمة السلوك.",
      "استدعِ الملف داخل manifest.json.",
      "اقترب من التاجر واضغط تفاعل لتشغيل نافذة ActionFormData.",
    ],
    codePreview: `import { world } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";

world.afterEvents.playerInteractWithEntity.subscribe((event) => {
  const { player, target } = event;
  if (target.typeId !== "iraqicoders:tigris_merchant") return;

  const menu = new ActionFormData()
    .title("تاجر دجلة")
    .body("اختر أداة من مقتنيات الورشة العراقية:")
    .button("سيف الرافدين المطور (12 زمرد)")
    .button("فانوس النيون الأخضر (5 زمرد)");

  menu.show(player).then((res) => {
    if (res.canceled) return;
    player.sendMessage("§aتم تسجيل طلبك بنجاح لدى تاجر دجلة!");
  });
});`,
  },
];

export const INITIAL_FORUM_POSTS: ForumPost[] = [
  {
    id: "post-1",
    title: "أفضل هيكلة لحفظ بيانات اللاعبين في Roblox Luau بدون فقدان التقدم",
    content:
      "شاركت اليوم معكم خلاصة تجربتي في بناء خادم لأكثر من 400 لاعب متزامن. أهم نقطة هي استخدام UpdateAsync بدل SetAsync عند تعديل العملات، وإضافة حفظ تلقائي كل 90 ثانية.",
    topic: "roblox",
    topicLabel: "Roblox (Luau)",
    authorName: "أحمد الركابي",
    authorCity: "بغداد",
    authorAvatar: DEFAULT_DEVELOPER_AVATAR,
    createdAt: "منذ ساعتين",
    likes: 34,
    likedByUser: false,
    replies: [
      {
        id: "rep-101",
        authorName: "علي الشمري",
        authorAvatar: DEFAULT_DEVELOPER_AVATAR,
        content: "نصيحة ممتازة! هل استخدمت ProfileService أم كتبت نظام القفل بنفسك؟",
        createdAt: "منذ ساعة",
      },
    ],
  },
  {
    id: "post-2",
    title: "تجربتي مع @minecraft/server-ui لتصميم واجهات عربية متجاوبة في Bedrock",
    content:
      "تمكنت أخيراً من ضبط ترتيب النصوص العربية داخل ActionFormData عبر عزل الرموز والأرقام بعلامات تنسيق واضحة. رفعت قالب الحزمة في قسم المشاريع لتجربته مجاناً.",
    topic: "minecraft",
    topicLabel: "Minecraft Add-on",
    authorName: "زينب العبيدي",
    authorCity: "البصرة",
    authorAvatar: DEFAULT_DEVELOPER_AVATAR,
    createdAt: "منذ 5 ساعات",
    likes: 27,
    likedByUser: false,
    replies: [],
  },
  {
    id: "post-3",
    title: "انطلاق تحدي المطورين العراقيين الأسبوعي — بناء أداة ويب خفيفة في 48 ساعة",
    content:
      "أهلاً بمجتمع عراق كودرز 26.1! جربوا كتابة أداة تفاعلية مصغرة في محرر الكود المباشر أعلى الصفحة وشاركوا أفكاركم هنا لنراجعها سوياً.",
    topic: "web",
    topicLabel: "تطوير الويب",
    authorName: "كرار الموسوي",
    authorCity: "كربلاء",
    authorAvatar: DEFAULT_DEVELOPER_AVATAR,
    createdAt: "أمس",
    likes: 49,
    likedByUser: false,
    replies: [
      {
        id: "rep-102",
        authorName: "نور الهدى",
        authorAvatar: DEFAULT_DEVELOPER_AVATAR,
        content: "مبادرة رائعة، أعمل حالياً على حاسبة استهلاك الخوادم بالـ JavaScript.",
        createdAt: "منذ 18 ساعة",
      },
    ],
  },
];

export const PLAYGROUND_TEMPLATES: PlaygroundTemplate[] = [
  {
    id: "tpl-baghdad-card",
    name: "بطاقة مطور تفاعلية",
    description: "بطاقة هوية برمجية بتصميم زجاجي وعداد نقرات مباشر",
    html: `<div class="card" dir="rtl">
  <span class="tag">عراق كودرز · 26.3</span>
  <h2>أهلاً بك في مختبر الكود</h2>
  <p>عدّل هذا النص أو أضف عناصر HTML وشاهد التحديث المباشر فوراً.</p>
  <button id="boostBtn">تحفيز المشروع (<span id="count">0</span>)</button>
</div>`,
    css: `body {
  margin: 0;
  min-height: 100vh;
  display: grid;
  place-items: center;
  background: radial-gradient(circle at top right, #1e1b4b, #0b0f19);
  font-family: 'Cairo', system-ui, sans-serif;
  color: #f8fafc;
}
.card {
  width: min(90%, 380px);
  padding: 28px;
  border-radius: 16px;
  background: rgba(17, 24, 39, 0.8);
  border: 1px solid rgba(139, 92, 246, 0.35);
  box-shadow: 0 20px 50px rgba(0, 0, 0, 0.45);
}
.tag {
  font-size: 12px;
  color: #34d399;
  font-weight: 700;
}
h2 { margin: 10px 0 8px; font-size: 22px; }
p { margin: 0 0 20px; color: #94a3b8; line-height: 1.7; font-size: 14px; }
button {
  width: 100%;
  padding: 11px 16px;
  border: 0;
  border-radius: 10px;
  background: linear-gradient(135deg, #7c3aed, #10b981);
  color: white;
  font-family: inherit;
  font-weight: 700;
  cursor: pointer;
  transition: transform 0.15s ease;
}
button:active { transform: scale(0.98); }`,
    js: `const btn = document.getElementById('boostBtn');
const countEl = document.getElementById('count');
let count = 0;

btn.addEventListener('click', () => {
  count += 1;
  countEl.textContent = String(count);
  console.log('تم تسجيل تفاعل جديد رقم:', count);
});`,
  },
  {
    id: "tpl-countdown",
    name: "مؤقت هاكاثون بغداد",
    description: "عداد وقت رقمي حي باستخدام setInterval",
    html: `<main class="timer-box" dir="rtl">
  <p class="label">الوقت المتبقي لتسليم المشروع</p>
  <div id="clock" class="clock">00:45:00</div>
  <div class="actions">
    <button id="toggle">إيقاف مؤقت</button>
    <button id="reset" class="ghost">إعادة ضبط</button>
  </div>
</main>`,
    css: `body {
  margin: 0;
  min-height: 100vh;
  display: grid;
  place-items: center;
  background: #0b0f19;
  color: #f1f5f9;
  font-family: 'Cairo', system-ui, sans-serif;
}
.timer-box {
  text-align: center;
  padding: 32px;
  border-radius: 16px;
  background: #111827;
  border: 1px solid rgba(255,255,255,0.08);
}
.label { color: #94a3b8; margin: 0 0 12px; font-size: 14px; }
.clock {
  font-family: monospace;
  font-size: 42px;
  font-weight: 700;
  color: #34d399;
  letter-spacing: 2px;
  margin-bottom: 20px;
}
.actions { display: flex; gap: 10px; justify-content: center; }
button {
  padding: 9px 18px;
  border-radius: 8px;
  border: none;
  background: #7c3aed;
  color: white;
  font-family: inherit;
  font-weight: 600;
  cursor: pointer;
}
button.ghost {
  background: transparent;
  border: 1px solid #334155;
  color: #cbd5e1;
}`,
    js: `let seconds = 45 * 60;
let running = true;
const clock = document.getElementById('clock');
const toggle = document.getElementById('toggle');
const reset = document.getElementById('reset');

function render() {
  const h = String(Math.floor(seconds / 3600)).padStart(2, '0');
  const m = String(Math.floor((seconds % 3600) / 60)).padStart(2, '0');
  const s = String(seconds % 60).padStart(2, '0');
  clock.textContent = h + ':' + m + ':' + s;
}

setInterval(() => {
  if (running && seconds > 0) {
    seconds--;
    render();
  }
}, 1000);

toggle.onclick = () => {
  running = !running;
  toggle.textContent = running ? 'إيقاف مؤقت' : 'استئناف';
};

reset.onclick = () => {
  seconds = 45 * 60;
  render();
  console.log('تمت إعادة ضبط المؤقت');
};`,
  },
  {
    id: "tpl-luau-calc",
    name: "حاسبة توازن Roblox",
    description: "محاكاة سريعة لحساب ضرر السلاح ومستوى اللاعب",
    html: `<section class="panel" dir="rtl">
  <h3>حاسبة توازن الأسلحة — Luau</h3>
  <label>مستوى اللاعب: <strong id="lvlVal">15</strong></label>
  <input id="lvl" type="range" min="1" max="100" value="15" />
  <div class="result">الضرر المحسوب: <span id="dmg">85</span> HP</div>
</section>`,
    css: `body {
  margin: 0;
  min-height: 100vh;
  display: grid;
  place-items: center;
  background: #0b0f19;
  color: #e2e8f0;
  font-family: 'Cairo', system-ui, sans-serif;
}
.panel {
  width: min(88%, 360px);
  padding: 24px;
  border-radius: 14px;
  background: #131a2a;
  border: 1px solid rgba(16, 185, 129, 0.3);
}
h3 { margin: 0 0 16px; font-size: 18px; }
input { width: 100%; margin: 12px 0 18px; accent-color: #8b5cf6; }
.result {
  padding: 12px;
  border-radius: 8px;
  background: rgba(16, 185, 129, 0.12);
  color: #34d399;
  font-weight: 700;
  text-align: center;
}`,
    js: `const slider = document.getElementById('lvl');
const lvlVal = document.getElementById('lvlVal');
const dmg = document.getElementById('dmg');

function update() {
  const level = Number(slider.value);
  const power = Math.round(25 + level * 4);
  lvlVal.textContent = String(level);
  dmg.textContent = String(power);
}

slider.addEventListener('input', update);
update();`,
  },
  {
    id: "tpl-saas-dashboard",
    name: "لوحة تحكم SaaS وتحليلات حية",
    description: "داشبورد تفاعلي مع رسم بياني بالأعمدة وإضافة بيانات فورية",
    html: `<main class="dash" dir="rtl">
  <header class="dash-head">
    <div>
      <h2>لوحة أداء المشاريع والطلبات</h2>
      <p>أضف أرقام المبيعات أو الزيارات وشاهد التحديث الفوري للرسم البياني</p>
    </div>
    <button id="addMetricBtn">+ إضافة يوم جديد</button>
  </header>
  <section class="kpis">
    <div class="kpi"><span>إجمالي الطلبات</span><strong id="kpiTotal">0</strong></div>
    <div class="kpi"><span>أعلى يوم</span><strong id="kpiMax">0</strong></div>
    <div class="kpi"><span>متوسط النمو</span><strong id="kpiAvg">0</strong></div>
  </section>
  <section id="chart" class="chart"></section>
</main>`,
    css: `body{margin:0;min-height:100vh;background:#080c15;color:#f8fafc;font-family:'Cairo',system-ui,sans-serif;padding:20px;}
.dash{max-width:740px;margin:0 auto;background:#0f172a;border:1px solid rgba(255,255,255,.1);border-radius:16px;padding:20px;}
.dash-head{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:16px;}
h2{margin:0;font-size:18px;} p{margin:4px 0 0;color:#94a3b8;font-size:12px;}
button{background:#10b981;color:#052e16;border:0;border-radius:10px;padding:9px 14px;font-family:inherit;font-weight:800;cursor:pointer;}
.kpis{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:18px;}
.kpi{background:#090d16;border:1px solid rgba(255,255,255,.08);border-radius:12px;padding:12px;}
.kpi span{display:block;font-size:11px;color:#94a3b8;} .kpi strong{font-size:20px;color:#34d399;font-variant-numeric:tabular-nums;}
.chart{display:flex;align-items:flex-end;gap:10px;height:150px;background:#070b14;border:1px solid rgba(255,255,255,.08);border-radius:12px;padding:14px;}
.bar-wrap{flex:1;display:flex;flex-direction:column;align-items:center;gap:6px;height:100%;justify-content:flex-end;}
.bar{width:100%;background:linear-gradient(180deg,#8b5cf6,#10b981);border-radius:6px 6px 2px 2px;transition:height .25s;}
.bar-wrap span{font-size:10px;color:#94a3b8;}`,
    js: `const days = [
  { label: 'السبت', val: 42 },
  { label: 'الأحد', val: 68 },
  { label: 'الإثنين', val: 55 },
  { label: 'الثلاثاء', val: 84 },
  { label: 'الأربعاء', val: 92 }
];
const chart = document.getElementById('chart');
function render() {
  const max = Math.max(...days.map(d => d.val), 1);
  const total = days.reduce((s, d) => s + d.val, 0);
  document.getElementById('kpiTotal').textContent = String(total);
  document.getElementById('kpiMax').textContent = String(max);
  document.getElementById('kpiAvg').textContent = String(Math.round(total / days.length));
  chart.innerHTML = days.map(d => \`
    <div class="bar-wrap">
      <div class="bar" style="height:\${Math.round((d.val / max) * 100)}%"></div>
      <span>\${d.label} (\${d.val})</span>
    </div>
  \`).join('');
}
document.getElementById('addMetricBtn').onclick = () => {
  const val = 35 + Math.floor(Math.random() * 75);
  days.push({ label: 'يوم ' + (days.length + 1), val });
  if (days.length > 8) days.shift();
  console.log('تمت إضافة قيمة جديدة:', val);
  render();
};
render();`,
  },
  {
    id: "tpl-ecommerce-site",
    name: "موقع متجر إلكتروني بسلة",
    description: "واجهة متجر متجاوب مع إضافة منتجات وحساب الفاتورة",
    html: `<section class="shop" dir="rtl">
  <header class="bar">
    <strong>متجر المبرمجين</strong>
    <span class="cart-pill">السلة: <b id="itemsCount">0</b> | <b id="totalPrice">0</b> $</span>
  </header>
  <div id="grid" class="grid"></div>
</section>`,
    css: `body{margin:0;background:#080c15;color:#f8fafc;font-family:'Cairo',sans-serif;padding:18px;}
.shop{max-width:720px;margin:0 auto;}
.bar{display:flex;justify-content:space-between;align-items:center;background:#111827;border:1px solid rgba(255,255,255,.1);padding:12px 16px;border-radius:12px;margin-bottom:14px;}
.cart-pill{font-size:12px;color:#34d399;}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:12px;}
.prod{background:#0f172a;border:1px solid rgba(255,255,255,.1);border-radius:12px;padding:14px;display:flex;flex-direction:column;justify-content:space-between;gap:10px;}
.prod h4{margin:0;font-size:14px;} .prod small{color:#94a3b8;font-size:12px;}
button{background:#7c3aed;color:#fff;border:0;border-radius:8px;padding:8px;font-family:inherit;font-weight:700;cursor:pointer;}`,
    js: `const catalog = [
  { name: 'لوحة مفاتيح ميكانيكية', price: 49 },
  { name: 'قالب موقع SaaS عربي', price: 29 },
  { name: 'حزمة أدوات مطور API', price: 39 }
];
let count = 0, sum = 0;
document.getElementById('grid').innerHTML = catalog.map((p, idx) => \`
  <div class="prod">
    <div><h4>\${p.name}</h4><small>السعر: \${p.price} $</small></div>
    <button onclick="buy(\${idx})">أضف للسلة</button>
  </div>
\`).join('');
window.buy = (i) => {
  count++; sum += catalog[i].price;
  document.getElementById('itemsCount').textContent = String(count);
  document.getElementById('totalPrice').textContent = String(sum);
  console.log('تمت إضافة:', catalog[i].name);
};`,
  },
  {
    id: "tpl-dev-calculator",
    name: "حاسبة المبرمج (Decimal / Hex / Binary)",
    description: "محوّل فوري للأرقام بين العشري والثنائي والست عشري",
    html: `<div class="conv" dir="rtl">
  <h3>محوّل أنظمة الأعداد للمبرمجين</h3>
  <input id="decInput" type="number" value="255" placeholder="أدخل رقماً عشرياً..." />
  <div class="rows" dir="ltr">
    <div><small>BINARY</small><code id="binOut">11111111</code></div>
    <div><small>HEX</small><code id="hexOut">0xFF</code></div>
    <div><small>OCTAL</small><code id="octOut">0o377</code></div>
  </div>
</div>`,
    css: `body{margin:0;min-height:100vh;display:grid;place-items:center;background:#080c15;color:#f8fafc;font-family:'Cairo',sans-serif;}
.conv{width:min(92%,400px);background:#0f172a;border:1px solid rgba(56,189,248,.35);border-radius:16px;padding:22px;}
h3{margin:0 0 12px;font-size:16px;color:#38bdf8;}
input{width:100%;box-sizing:border-box;background:#070b14;border:1px solid rgba(255,255,255,.15);border-radius:10px;padding:10px 12px;color:#fff;font-family:monospace;font-size:16px;margin-bottom:14px;}
.rows{display:grid;gap:8px;}
.rows div{display:flex;justify-content:space-between;align-items:center;background:#070b14;border:1px solid rgba(255,255,255,.08);border-radius:10px;padding:10px 12px;}
small{font-size:10px;color:#94a3b8;font-weight:700;} code{color:#34d399;font-size:13px;font-weight:700;}`,
    js: `const inp = document.getElementById('decInput');
function convert() {
  const n = Math.max(0, Math.floor(Number(inp.value) || 0));
  document.getElementById('binOut').textContent = n.toString(2);
  document.getElementById('hexOut').textContent = '0x' + n.toString(16).toUpperCase();
  document.getElementById('octOut').textContent = '0o' + n.toString(8);
}
inp.addEventListener('input', convert);
convert();`,
  },
];

export const INITIAL_CHALLENGES: ChallengeItem[] = [
  {
    id: "chal-admin-1",
    title: "تحدي أمان وقوة خوادم عراقي كودرز",
    question:
      "في بيئة Roblox Luau، هل استخدام UpdateAsync لتحديث عملات اللاعبين أكثر أماناً من SetAsync لمنع ضياع البيانات عند الضغط؟",
    codeSnippet: `Store:UpdateAsync("coins_" .. userId, function(old)\n  return (old or 0) + reward\nend)`,
    buttonALabel: "نعم",
    buttonBLabel: "لا",
    correctButton: "A",
    publisherName: "أمير باقر",
    publisherHandle: "@amirbaqir226",
    publisherAvatar: SITE_IDENTITY_EMBLEM,
    publisherRole: "admin",
    createdAt: "منذ ساعة",
    comments: [
      {
        id: "cc-1",
        authorName: "أحمد الركابي",
        authorRole: "developer",
        content: "أكيد UpdateAsync تمنع الكتابة الفوقية وتعتبر الأفضل احترافياً!",
        createdAt: "منذ 30 دقيقة",
      },
    ],
  },
  {
    id: "chal-dev-1",
    title: "اختبار بيئة المطور السريع (.mcaddon)",
    question:
      "هل يصح تشغيل حزمة Minecraft Bedrock بأندرويد 14 إذا كان ملف manifest.json لا يحتوي على رقم إصدار min_engine_version؟",
    codeSnippet: `"min_engine_version": [1, 21, 0]`,
    buttonALabel: "نعم يشتغل بدون مشاكل",
    buttonBLabel: "لا، لازم يُحدّد min_engine_version",
    correctButton: "B",
    publisherName: "أحمد الركابي",
    publisherHandle: "@ahmad_luau",
    publisherAvatar: DEV_HAMMER_EMBLEM,
    publisherRole: "developer",
    createdAt: "منذ 3 ساعات",
    comments: [],
  },
];

export const INITIAL_SCHOOL_UPDATES: SchoolUpdateItem[] = [
  {
    id: "sch-maysoon-1",
    title: "تحديث خاص لمدرسة ميسون للبنين في المدينة",
    badge: "مدرسة ميسون للبنين",
    details:
      "تم فتح مختبر البرمجة والتطبيقات المصغرة لطلبة مدرسة ميسون للبنين في المدينة مع دعم لغات Python و Java و Luau وتجارب الألعاب التفاعلية ومسابقات الأسبوع.",
    authorName: "إدارة عراقي كودرز",
    createdAt: "اليوم",
  },
  {
    id: "sch-maysoon-2",
    title: "مسابقة تطبيقات الطلبة (بصيغة .krok الجاهزة)",
    badge: "نشاط طلابي",
    details:
      "يمكن لطلبة مدرسة ميسون بناء مشاريعهم بمساعدة قسم المطورين وتحويلها فوراً إلى نسخ مصغرة داخل الموقع أو ملفات .krok للتطبيقات.",
    authorName: "قسم المشاريع المدرسية",
    createdAt: "الأسبوع الحالي",
  },
];

export const INITIAL_PUBLISHED_MINI_APPS: PublishedMiniProject[] = [
  {
    id: "mini-pubg-lite-beta",
    title: "ميدان بغداد الملكي (لعبة أكشن سريعة)",
    description:
      "لعبة مصغرة مستوحاة من أسلوب البقاء والتصويب مع حركة سلسة ومواجهة الخصوم داخل الخريطة.",
    kind: "game",
    language: "python",
    is3D: false,
    code: `# لعبة ميدان بغداد المصغرة\nplayer_hp = 100\nenemies = 5\nprint("استعد للمعركة! الأعداء:", enemies)\nIraqi Coders  1329`,
    authorName: "أمير باقر",
    authorHandle: "@amirbaqir226",
    authorRole: "admin",
    createdAt: "النسخة التجريبية",
  },
  {
    id: "mini-maysoon-calculator",
    title: "تطبيق منظم دروس ومعدل مدرسة ميسون",
    description:
      "تطبيق مصغر جاهز لطلبة مدرسة ميسون للبنين لحساب المعدل الدراسي وتنظيم مهام البرمجة اليومية.",
    kind: "app",
    language: "java",
    is3D: false,
    code: `// منظم درجات مدرسة ميسون للبنين\nconst school = "مدرسة ميسون للبنين في المدينة";\nconsole.log("أهلاً بكم في تطبيق:", school);\nIraqi Coders  1329`,
    authorName: "فريق التطوير",
    authorHandle: "@iraqicoders_dev",
    authorRole: "developer",
    createdAt: "النسخة التجريبية",
  },
];

