import React, { useEffect, useMemo, useState } from "react";
import {
  Check,
  CloudUpload,
  Code2,
  Copy,
  FileArchive,
  FileCode2,
  Gamepad2,
  Globe,
  Layers,
  Loader2,
  Monitor,
  Play,
  Puzzle,
  RefreshCw,
  Server,
  Smartphone,
  Sparkles,
  Tablet,
  Terminal,
  Wand2,
} from "lucide-react";
import { saveCloudBinaryBlob } from "../services/blobStore";
import {
  buildAndroidApkBlob,
  buildZipArchive,
} from "../services/packageBuilder";
import { CloudFileItem, UserProfile } from "../types";
import { GeneratedCodeBundle } from "./AssistantSection";

export type OmniCreationCategory =
  | "website"
  | "webapp"
  | "mobile-app"
  | "game"
  | "extension"
  | "backend-api"
  | "luau-mc";

export interface OmniExtraFile {
  name: string;
  language: string;
  content: string;
}

export interface OmniProjectData {
  title: string;
  summary: string;
  stackBadge: string;
  html: string;
  css: string;
  js: string;
  extraFiles: OmniExtraFile[];
}

interface OmniCreatorStudioProps {
  user: UserProfile | null;
  onInjectToPlayground: (bundle: GeneratedCodeBundle) => void;
  onOpenInSecretEditor: (file: { name: string; content: string }) => void;
  onSaveToCloud: (item: CloudFileItem) => void;
  onCodeRun: () => void;
  onShowToast: (msg: string) => void;
}

interface CategoryDef {
  id: OmniCreationCategory;
  label: string;
  shortDesc: string;
  icon: React.ComponentType<{ className?: string }>;
  presets: string[];
}

const CATEGORIES: CategoryDef[] = [
  {
    id: "website",
    label: "مواقع ويب كاملة",
    shortDesc: "متاجر، بورتفوليو، وصفحات هبوط",
    icon: Globe,
    presets: [
      "متجر إلكتروني عراقي للإلكترونيات مع سلة مشتريات",
      "موقع شركة برمجيات وتصميم في بغداد",
      "منصة دورات برمجية عربية حديثة",
    ],
  },
  {
    id: "webapp",
    label: "تطبيقات ولوحات تحكم",
    shortDesc: "أدوات إدارة، مالية، ومشاريع SaaS",
    icon: Layers,
    presets: [
      "لوحة تحكم مالية لإدارة المصاريف والأرباح",
      "تطبيق كانبان لتنظيم مهام الفريق البرمجي",
      "محول عملات وحاسبة فواتير ذكية",
    ],
  },
  {
    id: "mobile-app",
    label: "تطبيقات موبايل APK",
    shortDesc: "واجهات هاتف وتصدير أندرويد APK",
    icon: Smartphone,
    presets: [
      "تطبيق محفظة رقمية وخدمات دفع للموبايل",
      "تطبيق متابعة اللياقة والخطوات اليومية",
      "تطبيق دليل ومطاعم بغداد للموبايل",
    ],
  },
  {
    id: "game",
    label: "ألعاب تفاعلية 2D",
    shortDesc: "ألعاب Canvas 60FPS وتحكم لمسي",
    icon: Gamepad2,
    presets: [
      "لعبة سفينة فضاء وتفادي النيازك بسرعة 60FPS",
      "لعبة لغز الألوان والذاكرة السريعة",
      "لعبة ضرب الأهداف الفضائية",
    ],
  },
  {
    id: "extension",
    label: "إضافات المتصفح",
    shortDesc: "حزم Chrome / Edge Manifest V3",
    icon: Puzzle,
    presets: [
      "إضافة متصفح لحفظ الملاحظات السريعة على أي موقع",
      "إضافة لفحص ألوان وخطوط صفحات الويب",
      "إضافة الوضع الداكن الذكي للمتصفح",
    ],
  },
  {
    id: "backend-api",
    label: "خوادم Backend & API",
    shortDesc: "مسارات Express REST ومحاكاة JSON",
    icon: Server,
    presets: [
      "خادم REST API لإدارة الطلبات والمستخدمين",
      "خدمة تقصير الروابط مع إحصائيات الزيارات",
      "خادم بوت إشعارات ومهام مجدولة",
    ],
  },
  {
    id: "luau-mc",
    label: "Roblox & Minecraft",
    shortDesc: "سكربتات Luau ومودات Bedrock",
    icon: Code2,
    presets: [
      "نظام رتب ومتجر عملات للاعبي Roblox Luau",
      "سكربت حماية وأوامر إدارة لـ Minecraft Bedrock",
      "نظام مهام يومية ومكافآت في السيرفر",
    ],
  },
];

const INITIAL_OMNI_PROJECT: OmniProjectData = {
  title: "منصة ومتجر دجلة الرقمي التفاعلي",
  summary:
    "نموذج موقع وتطبيق متكامل يعمل فوراً مع سلة مشتريات، بحث فوري، ووضع ليلي/نهاري.",
  stackBadge: "HTML5 · CSS3 · JavaScript",
  html: `<div class="store-shell" dir="rtl">
  <header class="nav">
    <div class="brand">متجر وتطبيق دجلة الرقمي</div>
    <div class="nav-actions">
      <input id="searchBox" type="search" placeholder="ابحث عن منتج أو أداة..." />
      <button id="themeToggle" class="ghost-btn">تبديل المظهر</button>
      <button id="checkoutBtn" class="primary-btn">السلة (<span id="cartQty">0</span>)</button>
    </div>
  </header>

  <section class="hero-card">
    <div>
      <p class="kicker">مبني عبر استوديو انشئ كل شيء · عراقي كودرز</p>
      <h1>أنشئ متاجر، تطبيقات، وأنظمة برمجية كاملة في ثوانٍ</h1>
      <p class="lead">جرّب التصفية المباشرة، إضافة المنتجات، وتحديث الإجمالي في الوقت الحقيقي أو حوّل هذا المشروع إلى APK و ZIP فوراً.</p>
    </div>
    <div class="kpi-box">
      <span>إجمالي السلة</span>
      <strong id="cartTotal">0 د.ع</strong>
    </div>
  </section>

  <section id="catalogGrid" class="catalog"></section>
  <div id="liveNotice" class="notice"></div>
</div>`,
  css: `:root {
  --bg: #080d18;
  --surface: #111829;
  --border: rgba(255, 255, 255, 0.1);
  --text: #f8fafc;
  --muted: #94a3b8;
  --accent: #10b981;
}
body.light-ui {
  --bg: #f1f5f9;
  --surface: #ffffff;
  --border: rgba(15, 23, 42, 0.12);
  --text: #0f172a;
  --muted: #475569;
  --accent: #6d28d9;
}
* { box-sizing: border-box; }
body {
  margin: 0;
  background: var(--bg);
  color: var(--text);
  font-family: 'Cairo', system-ui, sans-serif;
  transition: background 0.2s, color 0.2s;
}
.store-shell { max-width: 980px; margin: 0 auto; padding: 18px; }
.nav {
  display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center; gap: 10px;
  padding: 12px 16px; border-radius: 14px; background: var(--surface); border: 1px solid var(--border);
}
.brand { font-weight: 800; font-size: 15px; }
.nav-actions { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; }
.nav-actions input {
  background: var(--bg); border: 1px solid var(--border); color: var(--text);
  border-radius: 9px; padding: 8px 12px; font-family: inherit; font-size: 12px;
}
.primary-btn {
  background: var(--accent); color: #fff; border: 0; border-radius: 9px;
  padding: 8px 14px; font-family: inherit; font-weight: 700; font-size: 12px; cursor: pointer;
}
.ghost-btn {
  background: transparent; color: var(--text); border: 1px solid var(--border);
  border-radius: 9px; padding: 8px 12px; font-family: inherit; font-weight: 700; font-size: 12px; cursor: pointer;
}
.hero-card {
  margin: 16px 0; padding: 20px; border-radius: 16px; background: var(--surface);
  border: 1px solid var(--border); display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center; gap: 16px;
}
.kicker { margin: 0 0 6px; font-size: 11px; color: var(--accent); font-weight: 700; }
.hero-card h1 { margin: 0 0 8px; font-size: 20px; line-height: 1.4; }
.lead { margin: 0; max-width: 540px; font-size: 12px; color: var(--muted); line-height: 1.7; }
.kpi-box {
  background: var(--bg); border: 1px solid var(--border); border-radius: 12px; padding: 14px 18px; min-width: 170px;
}
.kpi-box span { display: block; font-size: 11px; color: var(--muted); }
.kpi-box strong { font-size: 18px; color: var(--accent); font-variant-numeric: tabular-nums; }
.catalog { display: grid; grid-template-columns: repeat(auto-fit, minmax(210px, 1fr)); gap: 12px; }
.item-card {
  background: var(--surface); border: 1px solid var(--border); border-radius: 14px;
  padding: 16px; display: flex; flex-direction: column; justify-content: space-between; gap: 12px;
}
.item-card h3 { margin: 0 0 4px; font-size: 14px; }
.item-card p { margin: 0; font-size: 12px; color: var(--muted); line-height: 1.6; }
.item-foot { display: flex; justify-content: space-between; align-items: center; gap: 8px; }
.price { font-weight: 800; font-size: 13px; color: var(--accent); }
.notice {
  position: fixed; bottom: 14px; right: 14px; background: var(--accent); color: #fff;
  padding: 10px 14px; border-radius: 10px; font-size: 12px; font-weight: 700; display: none;
}`,
  js: `const products = [
  { id: 1, name: "قالب متجر إلكتروني Pro", desc: "واجهة عربية كاملة مع إدارة سلة وطلبات", price: 45000 },
  { id: 2, name: "حزمة تطبيق موبايل APK", desc: "ملف أندرويد جاهز للتجربة والنشر", price: 75000 },
  { id: 3, name: "خادم API + قاعدة بيانات", desc: "نقاط نهاية سريعة لإدارة البيانات", price: 90000 },
  { id: 4, name: "سكربت متجر Roblox Luau", desc: "نظام عملات ومهام يومية آمن", price: 35000 }
];
let cartQty = 0;
let cartTotal = 0;
const grid = document.getElementById('catalogGrid');
const searchBox = document.getElementById('searchBox');
const notice = document.getElementById('liveNotice');

function showMsg(txt) {
  notice.textContent = txt;
  notice.style.display = 'block';
  clearTimeout(window._nt);
  window._nt = setTimeout(() => { notice.style.display = 'none'; }, 2200);
}

function renderCatalog(filter = "") {
  const q = filter.trim().toLowerCase();
  const list = products.filter(p => !q || p.name.toLowerCase().includes(q) || p.desc.toLowerCase().includes(q));
  grid.innerHTML = list.map(p => \`
    <article class="item-card">
      <div>
        <h3>\${p.name}</h3>
        <p>\${p.desc}</p>
      </div>
      <div class="item-foot">
        <span class="price">\${p.price.toLocaleString('en-US')} د.ع</span>
        <button class="primary-btn" onclick="addProduct(\${p.id})">إضافة</button>
      </div>
    </article>
  \`).join('') || '<p style="color:#94a3b8">لا توجد نتائج مطابقة.</p>';
}

window.addProduct = (id) => {
  const item = products.find(p => p.id === id);
  if (!item) return;
  cartQty += 1;
  cartTotal += item.price;
  document.getElementById('cartQty').textContent = String(cartQty);
  document.getElementById('cartTotal').textContent = cartTotal.toLocaleString('en-US') + ' د.ع';
  showMsg('تمت إضافة: ' + item.name);
  console.log('إضافة للسلة:', item.name, '| الإجمالي:', cartTotal);
};

searchBox.addEventListener('input', (e) => renderCatalog(e.target.value));
document.getElementById('themeToggle').onclick = () => document.body.classList.toggle('light-ui');
document.getElementById('checkoutBtn').onclick = () => showMsg('عدد المنتجات: ' + cartQty + ' · الإجمالي: ' + cartTotal.toLocaleString('en-US') + ' د.ع');
renderCatalog();`,
  extraFiles: [
    {
      name: "project.manifest.json",
      language: "json",
      content: JSON.stringify(
        {
          studio: "Iraqi Coders Omni Creator",
          version: "26.5",
          targets: ["Web ZIP", "Android APK", "Cloud Hub", "Secret IDE"],
        },
        null,
        2
      ),
    },
  ],
};

function buildFullHtmlDocument(project: OmniProjectData): string {
  return `<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${project.title}</title>
  <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&display=swap" rel="stylesheet" />
  <style>${project.css}</style>
</head>
<body>
${project.html}
<script>
  (function() {
    const emit = (level, args) => {
      try {
        window.parent.postMessage({
          source: 'iraqi-omni-studio',
          level,
          text: args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' ')
        }, '*');
      } catch (e) {}
    };
    const origLog = console.log;
    const origErr = console.error;
    console.log = (...args) => { emit('log', args); origLog.apply(console, args); };
    console.error = (...args) => { emit('error', args); origErr.apply(console, args); };
    window.onerror = (msg) => emit('error', [msg]);
    try {
      ${project.js}
    } catch (err) {
      emit('error', [err && err.message ? err.message : String(err)]);
    }
  })();
</script>
</body>
</html>`;
}

export const OmniCreatorStudio: React.FC<OmniCreatorStudioProps> = ({
  user,
  onInjectToPlayground,
  onOpenInSecretEditor,
  onSaveToCloud,
  onCodeRun,
  onShowToast,
}) => {
  const [selectedCategory, setSelectedCategory] =
    useState<OmniCreationCategory>("website");
  const [prompt, setPrompt] = useState("");
  const [project, setProject] =
    useState<OmniProjectData>(INITIAL_OMNI_PROJECT);
  const [activeFileTab, setActiveFileTab] = useState<string>("index.html");
  const [viewport, setViewport] = useState<"desktop" | "tablet" | "mobile">(
    "desktop"
  );
  const [generating, setGenerating] = useState(false);
  const [engineUsed, setEngineUsed] = useState<string>("جاهز للتشغيل الفوري");
  const [runNonce, setRunNonce] = useState(0);
  const [copiedFile, setCopiedFile] = useState(false);
  const [consoleLogs, setConsoleLogs] = useState<
    { id: string; level: "log" | "error"; text: string }[]
  >([]);

  const activeCategoryDef = useMemo(
    () =>
      CATEGORIES.find((c) => c.id === selectedCategory) || CATEGORIES[0],
    [selectedCategory]
  );

  const srcDoc = useMemo(() => buildFullHtmlDocument(project), [project]);

  useEffect(() => {
    const onMsg = (ev: MessageEvent) => {
      if (ev.data?.source !== "iraqi-omni-studio") return;
      setConsoleLogs((prev) => [
        ...prev.slice(-14),
        {
          id: `${Date.now()}-${Math.random()}`,
          level: ev.data.level === "error" ? "error" : "log",
          text: String(ev.data.text || ""),
        },
      ]);
    };
    window.addEventListener("message", onMsg);
    return () => window.removeEventListener("message", onMsg);
  }, []);

  const fileTabs = useMemo(() => {
    const base = [
      { name: "index.html", language: "html", content: project.html },
      { name: "styles.css", language: "css", content: project.css },
      { name: "app.js", language: "javascript", content: project.js },
    ];
    return [...base, ...project.extraFiles];
  }, [project]);

  const currentFile =
    fileTabs.find((f) => f.name === activeFileTab) || fileTabs[0];

  const handleEditActiveFile = (nextContent: string) => {
    if (!currentFile) return;
    if (currentFile.name === "index.html") {
      setProject((p) => ({ ...p, html: nextContent }));
    } else if (currentFile.name === "styles.css") {
      setProject((p) => ({ ...p, css: nextContent }));
    } else if (currentFile.name === "app.js") {
      setProject((p) => ({ ...p, js: nextContent }));
    } else {
      setProject((p) => ({
        ...p,
        extraFiles: p.extraFiles.map((ef) =>
          ef.name === currentFile.name ? { ...ef, content: nextContent } : ef
        ),
      }));
    }
  };

  const handleGenerateOmniProject = async (
    customPrompt?: string,
    overrideCategory?: OmniCreationCategory
  ) => {
    const targetCategory = overrideCategory || selectedCategory;
    const text = (customPrompt ?? prompt).trim();
    if (!text) {
      onShowToast("اكتب فكرة الموقع أو التطبيق أو الأداة التي تريد بناءها أولاً.");
      return;
    }

    setGenerating(true);
    setConsoleLogs([]);
    try {
      const res = await fetch("/api/gemini/omni-create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: text, category: targetCategory }),
      });
      const data = (await res.json()) as {
        project?: OmniProjectData;
        model?: string;
        error?: string;
      };
      if (!data.project) {
        throw new Error(data.error || "تعذر بناء المشروع");
      }
      setProject(data.project);
      setActiveFileTab("index.html");
      setRunNonce((n) => n + 1);
      setEngineUsed(
        data.model === "gemini-4-hydrogen"
          ? "تم البناء عبر Gemini AI"
          : "تم البناء عبر المحرك الذكي السريع"
      );
      if (targetCategory === "mobile-app") {
        setViewport("mobile");
      } else {
        setViewport("desktop");
      }
      onCodeRun();
      onShowToast(`تم إنشاء «${data.project.title}» وتشغيل المعاينة الحية!`);
    } catch {
      onShowToast("حدث خطأ أثناء الاتصال بخادم البناء، حاول مرة أخرى.");
    } finally {
      setGenerating(false);
    }
  };

  const handleExportZip = () => {
    const cleanBase =
      project.title
        .replace(/[^\w\u0600-\u06FF-]+/g, "_")
        .replace(/^_+|_+$/g, "") || "iraqi_omni_project";
    const fullIndex = `<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${project.title}</title>
  <link rel="stylesheet" href="./styles.css" />
</head>
<body>
${project.html}
<script src="./app.js"></script>
</body>
</html>`;

    const entries = [
      { path: "index.html", data: fullIndex },
      { path: "styles.css", data: project.css },
      { path: "app.js", data: project.js },
      ...project.extraFiles.map((ef) => ({
        path: ef.name,
        data: ef.content,
      })),
    ];

    const bytes = buildZipArchive(entries);
    const blob = new Blob([bytes.buffer as ArrayBuffer], {
      type: "application/zip",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${cleanBase}.zip`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    onShowToast(`تم تصدير أرشيف المشروع الكامل (${cleanBase}.zip) بنجاح!`);
  };

  const handleExportApk = async () => {
    const cleanBase =
      project.title
        .replace(/[^\w\u0600-\u06FF-]+/g, "_")
        .replace(/^_+|_+$/g, "") || "iraqi_omni_app";
    const built = buildAndroidApkBlob({
      title: project.title,
      packageId: `iq.coders.omni.${Date.now().toString().slice(-4)}`,
      author: user?.name || "مطور عراقي كودرز",
      htmlContent: buildFullHtmlDocument(project),
    });
    const url = URL.createObjectURL(built.blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${cleanBase}.apk`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    onShowToast(`تم تغليف وتنزيل تطبيق الأندرويد (${cleanBase}.apk)!`);
  };

  const handleSaveProjectToCloud = async (visibility: "private" | "public") => {
    const id = `omni-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const cleanBase =
      project.title
        .replace(/[^\w\u0600-\u06FF-]+/g, "_")
        .replace(/^_+|_+$/g, "") || "iraqi_omni_site";
    const fullDoc = buildFullHtmlDocument(project);
    const bytes = buildZipArchive([
      { path: "index.html", data: fullDoc },
      { path: "styles.css", data: project.css },
      { path: "app.js", data: project.js },
      ...project.extraFiles.map((ef) => ({ path: ef.name, data: ef.content })),
    ]);
    const blob = new Blob([bytes.buffer as ArrayBuffer], {
      type: "application/zip",
    });
    await saveCloudBinaryBlob(id, blob);

    const cloudItem: CloudFileItem = {
      id,
      ownerId: user?.id || "local-guest-dev",
      ownerName: user?.name || "مطور عراقي كودرز",
      ownerHandle: user?.handle || "@iraqi_dev",
      title: project.title,
      description: `${project.summary} (${project.stackBadge})`,
      fileName: `${cleanBase}.zip`,
      fileType: selectedCategory === "mobile-app" ? "apk" : "web",
      fileSizeBytes: blob.size,
      content: fullDoc,
      visibility,
      downloads: 0,
      createdAt: "الآن",
    };
    onSaveToCloud(cloudItem);
    onShowToast(
      `تم حفظ «${project.title}» في ${
        visibility === "public" ? "سحابات الناس" : "سحابتك الخاصة"
      }!`
    );
  };

  const handleCopyActiveFile = async () => {
    if (!currentFile) return;
    try {
      await navigator.clipboard.writeText(currentFile.content);
      setCopiedFile(true);
      window.setTimeout(() => setCopiedFile(false), 1600);
    } catch {
      // Safe no-op
    }
  };

  const previewWidthClass =
    viewport === "mobile"
      ? "max-w-[390px]"
      : viewport === "tablet"
      ? "max-w-[768px]"
      : "max-w-full";

  return (
    <section
      id="omni-studio"
      className="scroll-mt-24 border-b border-white/10 py-14 lg:py-20"
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 space-y-6">
        {/* Section Header */}
        <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <div className="mb-2 flex flex-wrap items-center gap-2 text-xs font-bold text-slate-400">
              <span className="text-emerald-400">استوديو الخلق الشامل</span>
              <span aria-hidden="true">·</span>
              <span>مواقع · تطبيقات · موبايل APK · ألعاب · API · إضافات</span>
            </div>
            <h2 className="text-2xl font-extrabold text-white sm:text-3xl">
              انشئ كل شيء في مكان واحد
            </h2>
            <p className="mt-2 max-w-2xl text-sm leading-relaxed text-slate-400">
              صف ما تريد بناءه أو اختر قالباً فورياً ليقوم المحرك بتوليد الشيفرة
              المتعددة الملفات مع معاينة متجاوبة، تصدير ZIP و APK، وحفظ مباشر في
              مركز البيانات.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 text-xs font-bold text-slate-300">
            <span>{project.stackBadge}</span>
            <span aria-hidden="true">·</span>
            <span className="text-emerald-300">{engineUsed}</span>
          </div>
        </div>

        {/* Creation Category Selector */}
        <div
          role="tablist"
          aria-label="فئات الإنشاء والبرمجة"
          className="grid grid-cols-2 gap-2.5 sm:grid-cols-4 lg:grid-cols-7"
        >
          {CATEGORIES.map((cat) => {
            const Icon = cat.icon;
            const active = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                type="button"
                role="tab"
                aria-selected={active}
                onClick={() => setSelectedCategory(cat.id)}
                className={`flex flex-col items-start gap-1.5 rounded-xl border p-3 text-right transition-colors cursor-pointer ${
                  active
                    ? "border-emerald-400/60 bg-emerald-500/15 text-white"
                    : "border-white/10 bg-[#0E1424] text-slate-300 hover:border-white/25 hover:text-white"
                }`}
              >
                <Icon
                  className={`h-4 w-4 ${
                    active ? "text-emerald-300" : "text-slate-400"
                  }`}
                />
                <span className="text-xs font-extrabold leading-snug">
                  {cat.label}
                </span>
                <span className="text-[11px] text-slate-400 line-clamp-1">
                  {cat.shortDesc}
                </span>
              </button>
            );
          })}
        </div>

        {/* Prompt Composer + Presets */}
        <div className="glass-surface rounded-2xl border border-white/10 p-4 sm:p-5 space-y-3.5">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              void handleGenerateOmniProject();
            }}
            className="flex flex-col gap-2.5 sm:flex-row"
          >
            <input
              id="omni-studio-prompt"
              type="text"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder={`اكتب طلبك ضمن قسم (${activeCategoryDef.label}): مثلاً «${activeCategoryDef.presets[0]}»...`}
              className="h-12 flex-1 rounded-xl border border-white/15 bg-[#080C15] px-4 text-sm text-white placeholder:text-slate-500 focus:border-emerald-400 focus:outline-none"
            />
            <button
              type="submit"
              disabled={generating}
              className="inline-flex h-12 items-center justify-center gap-2 rounded-xl bg-gradient-to-l from-violet-600 to-emerald-600 px-6 text-xs font-extrabold text-white shadow-lg transition-opacity hover:opacity-95 disabled:opacity-60 whitespace-nowrap shrink-0 cursor-pointer"
            >
              {generating ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span>جاري البناء...</span>
                </>
              ) : (
                <>
                  <Wand2 className="h-4 w-4" />
                  <span>بناء المشروع الآن</span>
                </>
              )}
            </button>
          </form>

          <div className="flex flex-wrap items-center gap-2">
            <span className="inline-flex items-center gap-1 text-[11px] font-bold text-slate-400">
              <Sparkles className="h-3.5 w-3.5 text-emerald-400" />
              <span>أفكار جاهزة:</span>
            </span>
            {activeCategoryDef.presets.map((preset) => (
              <button
                key={preset}
                type="button"
                disabled={generating}
                onClick={() => {
                  setPrompt(preset);
                  void handleGenerateOmniProject(preset, selectedCategory);
                }}
                className="rounded-lg border border-white/10 bg-[#0B1120] px-3 py-1.5 text-xs font-semibold text-slate-200 transition-colors hover:border-emerald-400/50 hover:text-emerald-200 whitespace-nowrap shrink-0 cursor-pointer"
              >
                {preset}
              </button>
            ))}
          </div>
        </div>

        {/* Multi-File Workbench & Responsive Preview */}
        <div className="glass-surface overflow-hidden rounded-2xl border border-white/10">
          {/* Action & Export Toolbar */}
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 bg-[#0E1424] px-4 py-3">
            <div className="min-w-0">
              <h3 className="truncate text-sm font-extrabold text-white">
                {project.title}
              </h3>
              <p className="truncate text-[11px] text-slate-400">
                {project.summary}
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  setRunNonce((n) => n + 1);
                  onCodeRun();
                }}
                className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-extrabold text-white hover:bg-emerald-500 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <RefreshCw className="h-3.5 w-3.5" />
                <span>تحديث التشغيل</span>
              </button>

              <button
                type="button"
                onClick={() =>
                  onInjectToPlayground({
                    id: Date.now(),
                    label: project.title,
                    html: project.html,
                    css: project.css,
                    js: project.js,
                  })
                }
                className="inline-flex items-center gap-1.5 rounded-lg border border-violet-400/40 bg-violet-500/15 px-3 py-1.5 text-xs font-bold text-violet-200 hover:bg-violet-500/25 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Play className="h-3.5 w-3.5" />
                <span>إرسال لمحرر الكود</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  if (currentFile) {
                    onOpenInSecretEditor({
                      name: currentFile.name,
                      content: currentFile.content,
                    });
                  }
                }}
                className="inline-flex items-center gap-1.5 rounded-lg border border-sky-400/40 bg-sky-500/15 px-3 py-1.5 text-xs font-bold text-sky-200 hover:bg-sky-500/25 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Code2 className="h-3.5 w-3.5" />
                <span>فتح في المحرر السري</span>
              </button>

              <button
                type="button"
                onClick={handleExportZip}
                className="inline-flex items-center gap-1.5 rounded-lg border border-white/15 bg-white/5 px-3 py-1.5 text-xs font-bold text-slate-200 hover:bg-white/10 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <FileArchive className="h-3.5 w-3.5 text-amber-300" />
                <span>تصدير .zip</span>
              </button>

              <button
                type="button"
                onClick={() => void handleExportApk()}
                className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-400/40 bg-emerald-500/10 px-3 py-1.5 text-xs font-bold text-emerald-200 hover:bg-emerald-500/20 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Smartphone className="h-3.5 w-3.5" />
                <span>تصدير .apk</span>
              </button>

              <button
                type="button"
                onClick={() => void handleSaveProjectToCloud("private")}
                className="inline-flex items-center gap-1.5 rounded-lg border border-cyan-400/40 bg-cyan-500/15 px-3 py-1.5 text-xs font-bold text-cyan-200 hover:bg-cyan-500/25 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <CloudUpload className="h-3.5 w-3.5" />
                <span>حفظ بالسحابة</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12">
            {/* Left/Start Column: Multi-File Code Editor */}
            <div className="flex flex-col border-b border-white/10 bg-[#070B14] lg:col-span-6 lg:border-b-0 lg:border-l">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 bg-[#0B1120] px-3 py-2">
                <div className="flex flex-wrap items-center gap-1" dir="ltr">
                  {fileTabs.map((file) => {
                    const active = file.name === currentFile?.name;
                    return (
                      <button
                        key={file.name}
                        type="button"
                        onClick={() => setActiveFileTab(file.name)}
                        className={`inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1 font-mono text-xs font-bold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                          active
                            ? "bg-violet-600 text-white"
                            : "text-slate-400 hover:bg-white/5 hover:text-white"
                        }`}
                      >
                        <FileCode2 className="h-3 w-3" />
                        <span>{file.name}</span>
                      </button>
                    );
                  })}
                </div>

                <button
                  type="button"
                  onClick={() => void handleCopyActiveFile()}
                  className="inline-flex items-center gap-1 rounded-lg border border-white/10 bg-white/5 px-2.5 py-1 text-[11px] font-bold text-slate-300 hover:text-white whitespace-nowrap shrink-0 cursor-pointer"
                >
                  {copiedFile ? (
                    <>
                      <Check className="h-3 w-3 text-emerald-400" />
                      <span>تم النسخ</span>
                    </>
                  ) : (
                    <>
                      <Copy className="h-3 w-3" />
                      <span>نسخ الملف</span>
                    </>
                  )}
                </button>
              </div>

              <textarea
                dir="ltr"
                spellCheck={false}
                value={currentFile?.content || ""}
                onChange={(e) => handleEditActiveFile(e.target.value)}
                aria-label={`تحرير ${currentFile?.name || "الكود"}`}
                className="h-[410px] w-full resize-none bg-transparent p-4 font-mono text-[13px] leading-6 text-slate-100 focus:outline-none"
              />
            </div>

            {/* Right/End Column: Responsive Preview Stage + Console */}
            <div className="flex flex-col bg-[#060912] lg:col-span-6">
              <div className="flex items-center justify-between border-b border-white/10 bg-[#0B1120] px-4 py-2 text-xs">
                <span className="font-bold text-slate-200">
                  المعاينة الحية المتجاوبة
                </span>

                <div className="inline-flex items-center gap-1 rounded-lg border border-white/10 bg-[#070B14] p-0.5">
                  {(
                    [
                      { id: "desktop", label: "حاسوب", icon: Monitor },
                      { id: "tablet", label: "تابلت", icon: Tablet },
                      { id: "mobile", label: "موبايل", icon: Smartphone },
                    ] as const
                  ).map((v) => {
                    const VIcon = v.icon;
                    return (
                      <button
                        key={v.id}
                        type="button"
                        onClick={() => setViewport(v.id)}
                        className={`inline-flex items-center gap-1 rounded-md px-2 py-1 text-[11px] font-bold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                          viewport === v.id
                            ? "bg-emerald-600 text-white"
                            : "text-slate-400 hover:text-white"
                        }`}
                      >
                        <VIcon className="h-3 w-3" />
                        <span>{v.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="flex flex-1 items-center justify-center bg-[#04070D] p-2 overflow-auto">
                <iframe
                  key={runNonce}
                  title={project.title}
                  srcDoc={srcDoc}
                  sandbox="allow-scripts"
                  className={`h-[340px] w-full rounded-lg border border-white/10 bg-[#080D18] transition-all duration-200 ${previewWidthClass}`}
                />
              </div>

              {/* Console Output */}
              <div className="border-t border-white/10 bg-[#080C15] px-4 py-2">
                <div className="mb-1 flex items-center justify-between text-[11px] text-slate-400">
                  <span className="inline-flex items-center gap-1.5 font-bold text-slate-300">
                    <Terminal className="h-3.5 w-3.5 text-emerald-400" />
                    <span>مخرجات التشغيل (Console)</span>
                  </span>
                  {consoleLogs.length > 0 && (
                    <button
                      type="button"
                      onClick={() => setConsoleLogs([])}
                      className="hover:text-white cursor-pointer"
                    >
                      مسح
                    </button>
                  )}
                </div>
                <div
                  dir="ltr"
                  className="h-12 overflow-y-auto font-mono text-[11px] space-y-0.5"
                >
                  {consoleLogs.length === 0 ? (
                    <div className="text-slate-500">
                      المشروع يعمل — أي مخرجات console.log ستظهر هنا مباشرة.
                    </div>
                  ) : (
                    consoleLogs.map((entry) => (
                      <div
                        key={entry.id}
                        className={
                          entry.level === "error"
                            ? "text-rose-400"
                            : "text-emerald-300"
                        }
                      >
                        &gt; {entry.text}
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
