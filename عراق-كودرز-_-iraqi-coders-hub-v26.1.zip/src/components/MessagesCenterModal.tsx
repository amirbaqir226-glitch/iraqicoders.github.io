import React, { useEffect, useMemo, useState } from "react";
import {
  Bell,
  BellRing,
  CheckCircle2,
  Inbox,
  Mail,
  RefreshCw,
  Send,
  ShieldCheck,
  X,
} from "lucide-react";
import { getGmailAccessToken, setGmailAccessToken } from "../config/firebase";
import {
  authorizeGmailViaGooglePopup,
  escapeHtml,
  fetchGmailMessages,
  GmailMessageSummary,
} from "../services/gmailService";
import {
  GmailConfirmRequest,
  PlatformMessageRecord,
  UserProfile,
} from "../types";

interface MessagesCenterModalProps {
  isOpen: boolean;
  user: UserProfile | null;
  platformMessages: PlatformMessageRecord[];
  gmailAlertsEnabled: boolean;
  onToggleGmailAlerts: (enabled: boolean) => void;
  onClose: () => void;
  onRequestSendGmail: (req: GmailConfirmRequest) => void;
  onSaveLocalPlatformMessage: (msg: PlatformMessageRecord) => void;
  onShowToast: (msg: string) => void;
}

export const MessagesCenterModal: React.FC<MessagesCenterModalProps> = ({
  isOpen,
  user,
  platformMessages,
  gmailAlertsEnabled,
  onToggleGmailAlerts,
  onClose,
  onRequestSendGmail,
  onSaveLocalPlatformMessage,
  onShowToast,
}) => {
  const [activeFolder, setActiveFolder] = useState<"incoming" | "outgoing" | "compose">("incoming");
  const [gmailInbox, setGmailInbox] = useState<GmailMessageSummary[]>([]);
  const [gmailSent, setGmailSent] = useState<GmailMessageSummary[]>([]);
  const [loadingGmail, setLoadingGmail] = useState(false);
  const [gmailError, setGmailError] = useState("");
  const [gmailConnected, setGmailConnected] = useState<boolean>(() =>
    Boolean(getGmailAccessToken())
  );

  // Compose state
  const [composeTo, setComposeTo] = useState(user?.email || "");
  const [composeSubject, setComposeSubject] = useState("");
  const [composeBody, setComposeBody] = useState("");

  const syncRealGmail = async () => {
    const token = getGmailAccessToken();
    if (!token) {
      setGmailConnected(false);
      return;
    }
    setGmailConnected(true);
    setLoadingGmail(true);
    setGmailError("");
    try {
      const [inbox, sent] = await Promise.all([
        fetchGmailMessages("INBOX", 12),
        fetchGmailMessages("SENT", 12),
      ]);
      setGmailInbox(inbox);
      setGmailSent(sent);
    } catch (err) {
      setGmailError(
        err instanceof Error ? err.message : "تعذر جلب رسائل Gmail."
      );
    } finally {
      setLoadingGmail(false);
    }
  };

  useEffect(() => {
    if (!isOpen) return;
    if (getGmailAccessToken()) {
      void syncRealGmail();
    } else {
      setGmailConnected(false);
    }
  }, [isOpen]);

  const handleConnectGoogleGmail = async () => {
    setGmailError("");
    setLoadingGmail(true);
    try {
      const result = await authorizeGmailViaGooglePopup();
      if (!result.token) {
        setGmailError("تعذر تفعيل صلاحية Gmail، حاول مرة أخرى.");
        return;
      }
      setGmailAccessToken(result.token);
      setGmailConnected(true);
      onToggleGmailAlerts(true);
      await syncRealGmail();
      onShowToast("تم ربط Gmail وتفعيل إشعارات البريد الإلكتروني بنجاح!");
    } catch (err) {
      setGmailError(
        err instanceof Error ? err.message : "تم إلغاء التفويض من Google."
      );
    } finally {
      setLoadingGmail(false);
    }
  };

  const incomingMessages = useMemo(
    () => platformMessages.filter((m) => m.direction === "incoming"),
    [platformMessages]
  );
  const outgoingMessages = useMemo(
    () => platformMessages.filter((m) => m.direction === "outgoing"),
    [platformMessages]
  );

  if (!isOpen) return null;

  const handleComposeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const to = composeTo.trim();
    const subject = composeSubject.trim();
    const body = composeBody.trim();
    if (!to || !to.includes("@") || !subject || !body) {
      onShowToast("أدخل بريد المستلم وعنوان ونص الرسالة.");
      return;
    }

    const htmlBody = `<div dir="rtl" style="font-family:Tahoma,Arial,sans-serif;background:#0B0F19;color:#F8FAFC;padding:24px;border-radius:16px;border:1px solid #10B981;">
      <h2 style="color:#34D399;margin:0 0 12px 0;">${escapeHtml(subject)}</h2>
      <p style="font-size:15px;line-height:1.7;color:#E2E8F0;white-space:pre-line;">${escapeHtml(body)}</p>
      <hr style="border:none;border-top:1px solid #1E293B;margin:18px 0;"/>
      <p style="font-size:12px;color:#94A3B8;">مرسلة من منصة عراقي كودرز · Iraqi Coders</p>
    </div>`;

    // Record outgoing in platform list too
    onSaveLocalPlatformMessage({
      id: `out-${Date.now()}`,
      direction: "outgoing",
      source: "gmail",
      senderEmail: user?.email || "amirbaqir226@gmail.com",
      senderName: user?.name || "عضو عراقي كودرز",
      recipientEmail: to,
      recipientIdentifier: to,
      subject,
      body,
      sentViaGmail: true,
      gmailSynced: true,
      read: true,
      createdAt: new Date().toISOString(),
    });

    onRequestSendGmail({
      to,
      subject,
      htmlBody,
      previewText: body,
    });
    setComposeSubject("");
    setComposeBody("");
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="messages-center-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="flex max-h-[90vh] w-full max-w-3xl flex-col overflow-hidden rounded-3xl border border-sky-400/40 bg-[#0D1424] shadow-2xl"
      >
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 bg-[#0A101E] px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl border border-sky-400/45 bg-sky-500/15 text-sky-300">
              <Mail className="h-5 w-5" />
            </div>
            <div>
              <h2
                id="messages-center-title"
                className="text-lg font-extrabold text-white"
              >
                تحقق من الرسائل وإشعارات Gmail
              </h2>
              <p className="text-xs text-slate-400">
                الرسائل الواردة والصادرة وتنبيهات البريد الإلكتروني المرتبط بالحساب
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="إغلاق مركز الرسائل"
            className="inline-flex h-9 w-9 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-slate-300 hover:text-white cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Gmail Connection + Email Alerts Bar */}
        <div className="border-b border-white/10 bg-[#080C15] px-6 py-3.5 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 text-xs">
            <span
              className={`inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1 font-extrabold ${
                gmailConnected
                  ? "border-emerald-400/50 bg-emerald-500/15 text-emerald-300"
                  : "border-amber-400/45 bg-amber-500/15 text-amber-200"
              }`}
            >
              {gmailConnected ? (
                <>
                  <CheckCircle2 className="h-3.5 w-3.5" />
                  <span>Gmail متصل ومفعّل</span>
                </>
              ) : (
                <>
                  <Bell className="h-3.5 w-3.5" />
                  <span>اربط Gmail لعرض بريدك الحقيقي</span>
                </>
              )}
            </span>

            {user?.email && (
              <span dir="ltr" className="font-mono text-slate-300 hidden sm:inline">
                {user.email}
              </span>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => {
                const next = !gmailAlertsEnabled;
                onToggleGmailAlerts(next);
                onShowToast(
                  next
                    ? "تم تفعيل إشعارات البريد الإلكتروني (Gmail) لحسابك."
                    : "تم إيقاف إشعارات البريد الإلكتروني."
                );
              }}
              className={`inline-flex items-center gap-1.5 rounded-xl border px-3 py-1.5 text-xs font-extrabold cursor-pointer ${
                gmailAlertsEnabled
                  ? "border-emerald-400/50 bg-emerald-500/20 text-emerald-200"
                  : "border-white/15 bg-white/5 text-slate-300"
              }`}
            >
              <BellRing className="h-3.5 w-3.5" />
              <span>
                {gmailAlertsEnabled ? "إشعارات Gmail: مفعّلة ✓" : "تفعيل إشعارات Gmail"}
              </span>
            </button>

            {gmailConnected ? (
              <button
                type="button"
                disabled={loadingGmail}
                onClick={() => void syncRealGmail()}
                className="inline-flex items-center gap-1.5 rounded-xl border border-sky-400/45 bg-sky-500/15 px-3 py-1.5 text-xs font-extrabold text-sky-200 hover:bg-sky-500/25 cursor-pointer"
              >
                <RefreshCw
                  className={`h-3.5 w-3.5 ${loadingGmail ? "animate-spin" : ""}`}
                />
                <span>تحديث Gmail</span>
              </button>
            ) : (
              <button
                type="button"
                disabled={loadingGmail}
                onClick={() => void handleConnectGoogleGmail()}
                className="inline-flex items-center gap-1.5 rounded-xl bg-violet-600 px-3.5 py-1.5 text-xs font-extrabold text-white hover:bg-violet-500 cursor-pointer"
              >
                <ShieldCheck className="h-3.5 w-3.5" />
                <span>تفعيل ومزامنة Gmail</span>
              </button>
            )}
          </div>
        </div>

        {/* Folder Switcher */}
        <div className="flex gap-2 border-b border-white/10 bg-[#0D1424] px-6 py-3">
          <button
            type="button"
            onClick={() => setActiveFolder("incoming")}
            className={`inline-flex items-center gap-1.5 rounded-xl border px-3.5 py-2 text-xs font-extrabold cursor-pointer ${
              activeFolder === "incoming"
                ? "border-emerald-400 bg-emerald-600/25 text-emerald-200"
                : "border-white/10 bg-white/5 text-slate-300"
            }`}
          >
            <Inbox className="h-3.5 w-3.5" />
            <span>الرسائل الواردة ({incomingMessages.length + gmailInbox.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveFolder("outgoing")}
            className={`inline-flex items-center gap-1.5 rounded-xl border px-3.5 py-2 text-xs font-extrabold cursor-pointer ${
              activeFolder === "outgoing"
                ? "border-sky-400 bg-sky-600/25 text-sky-200"
                : "border-white/10 bg-white/5 text-slate-300"
            }`}
          >
            <Send className="h-3.5 w-3.5" />
            <span>الرسائل الصادرة ({outgoingMessages.length + gmailSent.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveFolder("compose")}
            className={`inline-flex items-center gap-1.5 rounded-xl border px-3.5 py-2 text-xs font-extrabold cursor-pointer ${
              activeFolder === "compose"
                ? "border-violet-400 bg-violet-600/25 text-violet-200"
                : "border-white/10 bg-white/5 text-slate-300"
            }`}
          >
            <Mail className="h-3.5 w-3.5" />
            <span>إرسال رسالة Gmail</span>
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {gmailError && (
            <div className="rounded-xl border border-rose-500/40 bg-rose-500/15 px-4 py-2.5 text-xs font-bold text-rose-200">
              {gmailError}
            </div>
          )}

          {activeFolder === "incoming" && (
            <div className="space-y-4">
              {gmailInbox.length > 0 && (
                <div className="space-y-2.5">
                  <h3 className="text-xs font-extrabold text-emerald-300">
                    صندوق البريد الوارد الحقيقي (Google Gmail INBOX):
                  </h3>
                  {gmailInbox.map((gm) => (
                    <div
                      key={gm.id}
                      className="rounded-2xl border border-emerald-400/30 bg-[#080C15] p-4 space-y-1.5"
                    >
                      <div className="flex items-center justify-between gap-2 text-[11px]">
                        <span className="rounded bg-emerald-500/20 px-2 py-0.5 font-bold text-emerald-300">
                          Gmail وارد
                        </span>
                        <span dir="ltr" className="font-mono text-slate-400 truncate max-w-[240px]">
                          {gm.from}
                        </span>
                      </div>
                      <h4 className="text-sm font-extrabold text-white">
                        {gm.subject}
                      </h4>
                      <p className="text-xs leading-relaxed text-slate-300">
                        {gm.snippet}
                      </p>
                    </div>
                  ))}
                </div>
              )}

              <div className="space-y-2.5">
                <h3 className="text-xs font-extrabold text-sky-300">
                  رسائل وإشعارات الرتب داخل عراقي كودرز:
                </h3>
                {incomingMessages.length === 0 ? (
                  <p className="rounded-2xl border border-dashed border-white/15 p-5 text-center text-xs text-slate-400">
                    لا توجد إشعارات منصة واردة حالياً.
                  </p>
                ) : (
                  incomingMessages.map((msg) => (
                    <div
                      key={msg.id}
                      className="rounded-2xl border border-white/10 bg-[#080C15] p-4 space-y-1.5"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2 text-[11px]">
                        <span className="font-bold text-sky-300">
                          من: {msg.senderName} ({msg.senderEmail})
                        </span>
                        <span className="text-slate-500">
                          {new Date(msg.createdAt).toLocaleString("ar-IQ")}
                        </span>
                      </div>
                      <h4 className="text-sm font-extrabold text-white">
                        {msg.subject}
                      </h4>
                      <p className="text-xs leading-relaxed text-emerald-200 font-bold">
                        {msg.body}
                      </p>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {activeFolder === "outgoing" && (
            <div className="space-y-4">
              {gmailSent.length > 0 && (
                <div className="space-y-2.5">
                  <h3 className="text-xs font-extrabold text-sky-300">
                    البريد الصادر الحقيقي (Google Gmail SENT):
                  </h3>
                  {gmailSent.map((gm) => (
                    <div
                      key={gm.id}
                      className="rounded-2xl border border-sky-400/30 bg-[#080C15] p-4 space-y-1.5"
                    >
                      <div className="flex items-center justify-between gap-2 text-[11px]">
                        <span className="rounded bg-sky-500/20 px-2 py-0.5 font-bold text-sky-300">
                          Gmail صادر
                        </span>
                        <span dir="ltr" className="font-mono text-slate-400 truncate max-w-[240px]">
                          إلى: {gm.to || "مستلم"}
                        </span>
                      </div>
                      <h4 className="text-sm font-extrabold text-white">
                        {gm.subject}
                      </h4>
                      <p className="text-xs leading-relaxed text-slate-300">
                        {gm.snippet}
                      </p>
                    </div>
                  ))}
                </div>
              )}

              <div className="space-y-2.5">
                <h3 className="text-xs font-extrabold text-violet-300">
                  سجل الرسائل الصادرة من المنصة:
                </h3>
                {outgoingMessages.length === 0 ? (
                  <p className="rounded-2xl border border-dashed border-white/15 p-5 text-center text-xs text-slate-400">
                    لم تُرسل أي رسائل صادرة في هذه الجلسة بعد.
                  </p>
                ) : (
                  outgoingMessages.map((msg) => (
                    <div
                      key={msg.id}
                      className="rounded-2xl border border-white/10 bg-[#080C15] p-4 space-y-1.5"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2 text-[11px]">
                        <span dir="ltr" className="font-mono text-amber-300">
                          إلى: {msg.recipientEmail || msg.recipientIdentifier}
                        </span>
                        <span className="text-slate-500">
                          {msg.gmailSynced || msg.sentViaGmail ? "مزامنة Gmail ✓" : "رسالة منصة"}
                        </span>
                      </div>
                      <h4 className="text-sm font-extrabold text-white">
                        {msg.subject}
                      </h4>
                      <p className="text-xs leading-relaxed text-slate-300">
                        {msg.body}
                      </p>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {activeFolder === "compose" && (
            <form onSubmit={handleComposeSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  البريد الإلكتروني للمستلم
                </label>
                <input
                  type="email"
                  dir="ltr"
                  required
                  value={composeTo}
                  onChange={(e) => setComposeTo(e.target.value)}
                  placeholder="member@gmail.com"
                  className="h-11 w-full rounded-xl border border-white/15 bg-[#080C15] px-3.5 font-mono text-xs text-white focus:border-violet-400 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  عنوان الرسالة
                </label>
                <input
                  type="text"
                  required
                  value={composeSubject}
                  onChange={(e) => setComposeSubject(e.target.value)}
                  placeholder="تواصل من منصة عراقي كودرز"
                  className="h-11 w-full rounded-xl border border-white/15 bg-[#080C15] px-3.5 text-xs text-white focus:border-violet-400 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  نص الرسالة
                </label>
                <textarea
                  rows={4}
                  required
                  value={composeBody}
                  onChange={(e) => setComposeBody(e.target.value)}
                  placeholder="اكتب رسالتك هنا..."
                  className="w-full rounded-xl border border-white/15 bg-[#080C15] p-3.5 text-xs text-white focus:border-violet-400 focus:outline-none"
                />
              </div>

              <button
                type="submit"
                className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-l from-violet-600 to-emerald-600 py-3 text-xs font-extrabold text-white hover:opacity-95 cursor-pointer"
              >
                <Send className="h-4 w-4" />
                <span>معاينة وإرسال عبر تطبيق Gmail</span>
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
