import React, { useEffect, useMemo, useState } from "react";
import {
  Activity,
  Bot,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  Code2,
  Copy,
  Crown,
  Database,
  Eye,
  FileCode,
  Link2,
  Monitor,
  Palette,
  Play,
  Rocket,
  Search,
  Send,
  Server,
  Settings,
  ShieldCheck,
  Terminal,
  X,
  XCircle,
} from "lucide-react";
import {
  CYBER_TOOL_CATEGORIES,
  CyberAdminTool,
  CyberToolCategoryId,
  getCyberAdminToolsRegistry,
} from "../data/cyberAdminToolsRegistry";
import { EMBEDDED_EXTENSION_CONFIG } from "../data/embeddedExtensionFiles";
import {
  ExtensionPairingSession,
  ThemeDecoration,
  UnpackedExtensionPackage,
  UserProfile,
  UserRole,
} from "../types";

interface FloatingExtensionBridgeOverlayProps {
  pkg: UnpackedExtensionPackage;
  pairingSession: ExtensionPairingSession | null;
  user?: UserProfile | null;
  userRole: UserRole;
  isAdminPrivileged: boolean;
  isMasterAdmin?: boolean;
  themeDecoration: ThemeDecoration;
  previewVersion: number;
  desktopMode: boolean;
  extensionMode: boolean;
  onChangeTheme: (theme: ThemeDecoration) => void;
  onChangePreviewVersion: (nextVersion: number) => void;
  onToggleDesktopMode: (enabled: boolean) => void;
  onToggleExtensionMode: (enabled: boolean) => void;
  onOpenSecretCodeEditor: (initialFile?: {
    name: string;
    content: string;
  }) => void;
  onOpenSecretStudio: () => void;
  onOpenDeveloperOptions: () => void;
  onOpenAdminModal: () => void;
  onScanAndPairFromScreen: (
    code: string,
    extensionName: string
  ) => Promise<boolean>;
  onClose: () => void;
  onTeleport: (targetId: string) => void;
  onShowToast: (msg: string) => void;
}

type CyberTab = "cyber-admin" | "server-db" | "popup" | "files" | "pairing";

const TOOLS_PER_PAGE = 12;

export const FloatingExtensionBridgeOverlay: React.FC<
  FloatingExtensionBridgeOverlayProps
> = ({
  pkg,
  pairingSession,
  user,
  userRole,
  isAdminPrivileged,
  isMasterAdmin = false,
  themeDecoration,
  previewVersion,
  desktopMode,
  extensionMode,
  onChangeTheme,
  onChangePreviewVersion,
  onToggleDesktopMode,
  onToggleExtensionMode,
  onOpenSecretCodeEditor,
  onOpenSecretStudio,
  onOpenDeveloperOptions,
  onOpenAdminModal,
  onScanAndPairFromScreen,
  onClose,
  onTeleport,
  onShowToast,
}) => {
  const [minimized, setMinimized] = useState(false);
  const [activeTab, setActiveTab] = useState<CyberTab>("cyber-admin");
  const [codeInput, setCodeInput] = useState(
    pairingSession?.code || "IRAQI-CODE-777"
  );
  const [submitting, setSubmitting] = useState(false);
  const [scanError, setScanError] = useState("");
  const [selectedFileIndex, setSelectedFileIndex] = useState(0);
  const [copiedFile, setCopiedFile] = useState(false);

  // 1,050+ Tools Explorer State
  const allTools = useMemo(() => getCyberAdminToolsRegistry(), []);
  const [selectedCategory, setSelectedCategory] = useState<
    "all" | CyberToolCategoryId
  >("all");
  const [toolSearch, setToolSearch] = useState("");
  const [toolPage, setToolPage] = useState(0);

  // Custom Script Executor & Console Output
  const [customScript, setCustomScript] = useState(
    `// منفّذ السكربتات السري — Cyber-Admin (amirbaqir226)\nconst status = { master: "amirbaqir226", version: "${previewVersion.toFixed(
      1
    )}", toolsLoaded: ${allTools.length} };\nconsole.log("جاهز للتنفيذ الفوري:", JSON.stringify(status));`
  );
  const [execLogs, setExecLogs] = useState<string[]>([
    `[SYSTEM] تم تهيئة لوحة Cyber-Admin (${allTools.length} أداة فعالة بدون قيود).`,
  ]);
  const [apiProbeOutput, setApiProbeOutput] = useState<string>("");
  const [probingRoute, setProbingRoute] = useState<string>("");

  const activeFile = pkg.files[selectedFileIndex] || pkg.files[0];
  const hasPrivilegedAccess =
    isMasterAdmin ||
    isAdminPrivileged ||
    userRole === "admin" ||
    userRole === "developer";

  const filteredTools = useMemo(() => {
    const q = toolSearch.trim().toLowerCase();
    return allTools.filter((t) => {
      if (selectedCategory !== "all" && t.category !== selectedCategory) {
        return false;
      }
      if (!q) return true;
      return (
        t.name.toLowerCase().includes(q) ||
        t.code.toLowerCase().includes(q) ||
        t.description.toLowerCase().includes(q) ||
        t.categoryLabel.toLowerCase().includes(q)
      );
    });
  }, [allTools, selectedCategory, toolSearch]);

  const totalPages = Math.max(
    1,
    Math.ceil(filteredTools.length / TOOLS_PER_PAGE)
  );
  const safePage = Math.min(toolPage, totalPages - 1);
  const visibleTools = filteredTools.slice(
    safePage * TOOLS_PER_PAGE,
    (safePage + 1) * TOOLS_PER_PAGE
  );

  // Listen to embedded popup.js activating the floating dashboard directly
  useEffect(() => {
    const onMessage = (event: MessageEvent) => {
      if (event.data?.type === "IRAQI_EMBEDDED_POPUP_ACTIVATE_BRIDGE") {
        setActiveTab("cyber-admin");
        onToggleExtensionMode(true);
        onShowToast(
          "تم استلام أمر التفعيل من popup.js — الشاشة العائمة مفتوحة الآن!"
        );
      }
    };
    window.addEventListener("message", onMessage);
    return () => window.removeEventListener("message", onMessage);
  }, [onToggleExtensionMode, onShowToast]);

  const appendExecLog = (line: string) => {
    setExecLogs((prev) =>
      [`[${new Date().toLocaleTimeString("en-GB")}] ${line}`, ...prev].slice(
        0,
        30
      )
    );
  };

  const runCustomScriptString = (source: string, label = "Custom Script") => {
    const captured: string[] = [];
    const mockConsole = {
      log: (...args: unknown[]) =>
        captured.push(
          args
            .map((a) => (typeof a === "object" ? JSON.stringify(a) : String(a)))
            .join(" ")
        ),
      warn: (...args: unknown[]) =>
        captured.push("WARN: " + args.map(String).join(" ")),
      error: (...args: unknown[]) =>
        captured.push("ERR: " + args.map(String).join(" ")),
    };
    try {
      const fn = new Function("console", source);
      const result = fn(mockConsole);
      if (captured.length > 0) {
        captured.forEach((msg) => appendExecLog(`${label}: ${msg}`));
      } else if (result !== undefined) {
        appendExecLog(`${label} => ${String(result)}`);
      } else {
        appendExecLog(`${label}: تم التنفيذ بنجاح.`);
      }
    } catch (err) {
      appendExecLog(
        `${label} خطأ: ${err instanceof Error ? err.message : String(err)}`
      );
    }
  };

  const handleProbeApiRoute = async (route: string) => {
    setProbingRoute(route);
    const start = performance.now();
    try {
      const res = await fetch(route);
      const elapsed = Math.round(performance.now() - start);
      const text = await res.text();
      let formatted = text;
      try {
        formatted = JSON.stringify(JSON.parse(text), null, 2);
      } catch {
        // Keep raw text
      }
      const headerLine = `GET ${route} -> HTTP ${res.status} (${elapsed}ms)`;
      setApiProbeOutput(`${headerLine}\n\n${formatted.slice(0, 3500)}`);
      appendExecLog(headerLine);
      onShowToast(`تم فحص ${route} (${res.status}) في ${elapsed}ms`);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "فشل الاتصال";
      setApiProbeOutput(`GET ${route} -> ERROR: ${msg}`);
      appendExecLog(`خطأ فحص ${route}: ${msg}`);
    } finally {
      setProbingRoute("");
    }
  };

  const handleExecuteTool = (tool: CyberAdminTool) => {
    switch (tool.actionKind) {
      case "theme": {
        if (tool.themeTarget) {
          onChangeTheme(tool.themeTarget);
          appendExecLog(`[${tool.code}] تم تبديل الثيم إلى: ${tool.themeTarget}`);
          onShowToast(`تم تشغيل ${tool.name}`);
        }
        break;
      }
      case "version": {
        if (tool.versionTarget) {
          onChangePreviewVersion(tool.versionTarget);
          appendExecLog(
            `[${tool.code}] تم تحويل الإصدار إلى v${tool.versionTarget.toFixed(1)}`
          );
          onShowToast(`تم التحويل إلى v${tool.versionTarget.toFixed(1)}`);
        }
        break;
      }
      case "layout": {
        onToggleDesktopMode(!desktopMode);
        appendExecLog(`[${tool.code}] تبديل وضع سطح المكتب: ${!desktopMode}`);
        break;
      }
      case "api-probe": {
        if (tool.apiRoute) {
          setActiveTab("server-db");
          void handleProbeApiRoute(tool.apiRoute);
        }
        break;
      }
      case "open-editor": {
        onOpenSecretCodeEditor({
          name: `${tool.code.toLowerCase()}.js`,
          content:
            tool.scriptCode ||
            `// ${tool.name}\nconsole.log("تشغيل أداة ${tool.code}");`,
        });
        appendExecLog(`[${tool.code}] فُتحت في محرر الأكواد السري.`);
        break;
      }
      case "open-studio": {
        onOpenSecretStudio();
        appendExecLog(`[${tool.code}] تم فتح استوديو المصانع و APK (/).`);
        break;
      }
      case "open-dev-modal": {
        onOpenDeveloperOptions();
        appendExecLog(`[${tool.code}] تم فتح خيارات المطورين وقاعدة البيانات.`);
        break;
      }
      case "teleport": {
        if (tool.teleportTarget) {
          onTeleport(tool.teleportTarget);
          appendExecLog(`[${tool.code}] انتقال فوري إلى #${tool.teleportTarget}`);
        }
        break;
      }
      case "script":
      default: {
        const snippet =
          tool.scriptCode ||
          `console.log("[${tool.code}] تنفيذ: ${tool.name}");`;
        setCustomScript(snippet);
        runCustomScriptString(snippet, tool.code);
        onShowToast(`تم تنفيذ ${tool.code}: ${tool.name}`);
        break;
      }
    }
  };

  const handleSendFromFloatingUi = async (e: React.FormEvent) => {
    e.preventDefault();
    const target = codeInput.trim().toUpperCase();
    if (!target) return;
    setScanError("");
    setSubmitting(true);
    try {
      const ok = await onScanAndPairFromScreen(target, pkg.extensionName);
      if (!ok) {
        setScanError(
          `لم يتم العثور على الرمز «${target}» معروضاً على الشاشة الحية حالياً.`
        );
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleCopyActiveFile = async () => {
    if (!activeFile) return;
    try {
      await navigator.clipboard.writeText(activeFile.content);
      setCopiedFile(true);
      window.setTimeout(() => setCopiedFile(false), 1600);
      onShowToast(`تم نسخ محتوى ${activeFile.path}`);
    } catch {
      // Safe no-op
    }
  };

  return (
    <div
      id="iraqi-admin-floating-panel"
      role="region"
      aria-label="لوحة التحكم العائمة Cyber-Admin — جسر ما بيا حيل"
      className="fixed top-14 left-1/2 z-50 w-[96%] max-w-5xl -translate-x-1/2 rounded-2xl border border-sky-400/60 bg-[#080F1E]/95 shadow-[0_24px_64px_rgba(2,6,23,0.94)] backdrop-blur-xl"
    >
      {/* Top Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 px-4 py-2.5">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl border border-sky-400/45 bg-sky-500/20 text-sky-300">
            {isMasterAdmin ? (
              <Crown className="h-4 w-4 text-amber-300" />
            ) : (
              <ShieldCheck className="h-4 w-4" />
            )}
          </div>
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <span className="truncate text-xs sm:text-sm font-extrabold text-white">
                {pkg.extensionName} — لوحة Cyber-Admin
              </span>
              <span className="font-mono text-[11px] font-bold text-emerald-300">
                {allTools.length.toLocaleString("en-US")}+ أداة
              </span>
              {isMasterAdmin && (
                <span
                  dir="ltr"
                  className="inline-flex items-center gap-1 rounded border border-amber-400/45 bg-amber-500/15 px-2 py-0.5 font-mono text-[10px] font-extrabold text-amber-200"
                >
                  MASTER: amirbaqir226
                </span>
              )}
            </div>
            <p className="truncate text-[11px] text-slate-400">
              {user?.name || "أمير باقر"} · نواة الـ 6 ملفات المدمجة (v{pkg.version}) · تحكم مباشر بدون رمز اقتران
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          <button
            type="button"
            onClick={() => setMinimized((prev) => !prev)}
            title={minimized ? "توسيع اللوحة العائمة" : "تصغير اللوحة العائمة"}
            className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-white/10 bg-white/5 text-slate-300 hover:bg-white/10 hover:text-white cursor-pointer"
          >
            {minimized ? (
              <ChevronDown className="h-4 w-4" />
            ) : (
              <ChevronUp className="h-4 w-4" />
            )}
          </button>
          <button
            type="button"
            onClick={onClose}
            aria-label="إغلاق لوحة Cyber-Admin العائمة"
            className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-rose-500/30 bg-rose-500/10 text-rose-300 hover:bg-rose-500/20 cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>

      {!minimized && (
        <div className="p-4 space-y-3.5 max-h-[78vh] overflow-y-auto">
          {/* Navigation Tabs */}
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="inline-flex flex-wrap items-center gap-1 rounded-xl border border-white/10 bg-[#060A13] p-1">
              <button
                type="button"
                onClick={() => setActiveTab("cyber-admin")}
                className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-extrabold transition-colors cursor-pointer ${
                  activeTab === "cyber-admin"
                    ? "bg-sky-600 text-white"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                <ShieldCheck className="h-3.5 w-3.5" />
                <span>أدوات Cyber-Admin ({allTools.length})</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveTab("server-db")}
                className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-extrabold transition-colors cursor-pointer ${
                  activeTab === "server-db"
                    ? "bg-amber-600 text-white"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                <Server className="h-3.5 w-3.5" />
                <span>قواعد البيانات والسيرفر</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveTab("popup")}
                className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-extrabold transition-colors cursor-pointer ${
                  activeTab === "popup"
                    ? "bg-violet-600 text-white"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                <Eye className="h-3.5 w-3.5" />
                <span>popup.html</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveTab("files")}
                className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-extrabold transition-colors cursor-pointer ${
                  activeTab === "files"
                    ? "bg-emerald-600 text-white"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                <FileCode className="h-3.5 w-3.5" />
                <span>الملفات ({pkg.files.length})</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveTab("pairing")}
                className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-extrabold transition-colors cursor-pointer ${
                  activeTab === "pairing"
                    ? "bg-blue-600 text-white"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                <Link2 className="h-3.5 w-3.5" />
                <span>فحص الشاشة</span>
              </button>
            </div>

            <span
              data-dom-scan-ignore="true"
              className="text-xs font-extrabold text-emerald-300"
            >
              {isMasterAdmin
                ? "صلاحيات Master Admin العليا (Super-Admin + Dev)"
                : hasPrivilegedAccess
                ? "تحكم المدير والمطور مفعّل"
                : "وضع المعاينة التفاعلية"}
            </span>
          </div>

          {/* Tab 1: Full Cyber-Admin Dashboard with 1,050+ Tools + Script Executor */}
          {activeTab === "cyber-admin" && (
            <div className="space-y-3" data-dom-scan-ignore="true">
              {/* Quick Controls Row: Theme Switchers + Version + Modes */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-3">
                <div className="lg:col-span-5 rounded-xl border border-white/10 bg-[#0C1324] p-3 space-y-2">
                  <div className="flex items-center gap-1.5 text-xs font-extrabold text-sky-300">
                    <Palette className="h-3.5 w-3.5" />
                    <span>مغيّر الثيمات الفوري</span>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                    {(
                      [
                        { id: "default", label: "الأساسي" },
                        { id: "cyber", label: "سايبر" },
                        { id: "electric", label: "كهربائي" },
                        { id: "halloween", label: "هالوين" },
                      ] as const
                    ).map((th) => (
                      <button
                        key={th.id}
                        type="button"
                        onClick={() => {
                          onChangeTheme(th.id);
                          appendExecLog(`[THEME] تفعيل ثيم: ${th.label}`);
                          onShowToast(`تم تفعيل ثيم ${th.label} فوراً!`);
                        }}
                        className={`rounded-lg border px-2 py-1.5 text-[11px] font-bold transition-colors cursor-pointer ${
                          themeDecoration === th.id
                            ? "border-sky-400 bg-sky-600 text-white"
                            : "border-white/10 bg-[#060A13] text-slate-300 hover:border-sky-400/40"
                        }`}
                      >
                        {th.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="lg:col-span-3 rounded-xl border border-white/10 bg-[#0C1324] p-3 space-y-2">
                  <div className="flex items-center gap-1.5 text-xs font-extrabold text-violet-300">
                    <Rocket className="h-3.5 w-3.5" />
                    <span>تبديل الإصدار</span>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {[26.5, 500.0, 999.9].map((ver) => (
                      <button
                        key={ver}
                        type="button"
                        onClick={() => {
                          onChangePreviewVersion(ver);
                          appendExecLog(
                            `[VERSION] تحديث نسخة المعاينة إلى v${ver.toFixed(1)}`
                          );
                          onShowToast(`تم التحويل إلى معاينة v${ver.toFixed(1)}`);
                        }}
                        className={`flex-1 rounded-lg border px-2 py-1.5 font-mono text-[11px] font-bold cursor-pointer ${
                          Math.abs(previewVersion - ver) < 0.05
                            ? "border-violet-400 bg-violet-600 text-white"
                            : "border-white/10 bg-[#060A13] text-slate-300 hover:text-white"
                        }`}
                      >
                        v{ver.toFixed(1)}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="lg:col-span-4 rounded-xl border border-white/10 bg-[#0C1324] p-3 space-y-2">
                  <div className="flex items-center gap-1.5 text-xs font-extrabold text-emerald-300">
                    <Monitor className="h-3.5 w-3.5" />
                    <span>العرض والاختصارات السريعة</span>
                  </div>
                  <div className="grid grid-cols-2 gap-1.5">
                    <button
                      type="button"
                      onClick={() => onToggleDesktopMode(!desktopMode)}
                      className={`rounded-lg border px-2 py-1.5 text-[11px] font-bold cursor-pointer ${
                        desktopMode
                          ? "border-emerald-400 bg-emerald-600/25 text-emerald-200"
                          : "border-white/10 bg-[#060A13] text-slate-300"
                      }`}
                    >
                      {desktopMode ? "سطح المكتب ✓" : "سطح المكتب"}
                    </button>
                    <button
                      type="button"
                      onClick={() => onToggleExtensionMode(!extensionMode)}
                      className={`rounded-lg border px-2 py-1.5 text-[11px] font-bold cursor-pointer ${
                        extensionMode
                          ? "border-blue-400 bg-blue-600/25 text-blue-200"
                          : "border-white/10 bg-[#060A13] text-slate-300"
                      }`}
                    >
                      {extensionMode ? "الإضافة نشطة ✓" : "تفعيل الإضافة"}
                    </button>
                  </div>
                </div>
              </div>

              {/* Direct Module Launchers */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <button
                  type="button"
                  onClick={() => onOpenSecretCodeEditor()}
                  className="inline-flex items-center justify-center gap-1.5 rounded-xl bg-sky-600 px-3 py-2 text-xs font-extrabold text-white hover:bg-sky-500 cursor-pointer"
                >
                  <Code2 className="h-3.5 w-3.5" />
                  <span>محرر الأكواد السري</span>
                </button>
                <button
                  type="button"
                  onClick={() => onTeleport("cloud-hub")}
                  className="inline-flex items-center justify-center gap-1.5 rounded-xl border border-emerald-400/40 bg-emerald-600/20 px-3 py-2 text-xs font-extrabold text-emerald-200 hover:bg-emerald-600/30 cursor-pointer"
                >
                  <Database className="h-3.5 w-3.5" />
                  <span>مركز البيانات</span>
                </button>
                <button
                  type="button"
                  onClick={onOpenSecretStudio}
                  className="inline-flex items-center justify-center gap-1.5 rounded-xl border border-violet-400/40 bg-violet-600/20 px-3 py-2 text-xs font-extrabold text-violet-200 hover:bg-violet-600/30 cursor-pointer"
                >
                  <Terminal className="h-3.5 w-3.5" />
                  <span>استوديو / APK</span>
                </button>
                <button
                  type="button"
                  onClick={
                    hasPrivilegedAccess
                      ? onOpenDeveloperOptions
                      : onOpenAdminModal
                  }
                  className="inline-flex items-center justify-center gap-1.5 rounded-xl border border-amber-400/40 bg-amber-500/15 px-3 py-2 text-xs font-extrabold text-amber-200 hover:bg-amber-500/25 cursor-pointer"
                >
                  <Settings className="h-3.5 w-3.5" />
                  <span>إدارة المستخدمين والـ DB</span>
                </button>
              </div>

              {/* 1,050+ Tools Explorer */}
              <div className="rounded-xl border border-sky-500/35 bg-[#060A13] p-3.5 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <Bot className="h-4 w-4 text-sky-400" />
                    <span className="text-xs font-extrabold text-white">
                      مكتبة الأدوات التنفيذية ({allTools.length.toLocaleString("en-US")} أداة مدمجة)
                    </span>
                  </div>

                  <div className="relative flex-1 min-w-[210px] max-w-xs">
                    <Search className="pointer-events-none absolute right-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
                    <input
                      type="search"
                      value={toolSearch}
                      onChange={(e) => {
                        setToolSearch(e.target.value);
                        setToolPage(0);
                      }}
                      placeholder="ابحث داخل 1,050 أداة أو TOOL-0001..."
                      className="h-8 w-full rounded-lg border border-white/10 bg-[#0C1324] pr-8 pl-2.5 text-[11px] text-white focus:border-sky-400 focus:outline-none"
                    />
                  </div>
                </div>

                {/* Category Filter Tabs */}
                <div className="flex flex-wrap items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedCategory("all");
                      setToolPage(0);
                    }}
                    className={`rounded-lg border px-2.5 py-1 text-[11px] font-bold cursor-pointer ${
                      selectedCategory === "all"
                        ? "border-sky-400 bg-sky-600 text-white"
                        : "border-white/10 bg-[#0C1324] text-slate-300 hover:text-white"
                    }`}
                  >
                    الكل ({allTools.length})
                  </button>
                  {CYBER_TOOL_CATEGORIES.map((cat) => (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => {
                        setSelectedCategory(cat.id);
                        setToolPage(0);
                      }}
                      className={`rounded-lg border px-2.5 py-1 text-[11px] font-bold cursor-pointer ${
                        selectedCategory === cat.id
                          ? "border-emerald-400 bg-emerald-600 text-white"
                          : "border-white/10 bg-[#0C1324] text-slate-300 hover:text-white"
                      }`}
                    >
                      {cat.label} ({cat.count})
                    </button>
                  ))}
                </div>

                {/* Tools Grid (Paginated for instant zero-lag rendering) */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                  {visibleTools.map((tool) => (
                    <div
                      key={tool.id}
                      className="flex flex-col justify-between gap-2 rounded-xl border border-white/10 bg-[#0B1221] p-2.5 hover:border-sky-400/50 transition-colors"
                    >
                      <div>
                        <div className="flex items-center justify-between gap-1 text-[10px] font-mono">
                          <span className="text-sky-300 font-bold">
                            {tool.code}
                          </span>
                          <span className="truncate text-slate-400">
                            {tool.categoryLabel}
                          </span>
                        </div>
                        <p className="mt-1 text-xs font-extrabold text-white line-clamp-1">
                          {tool.name}
                        </p>
                        <p className="mt-0.5 text-[11px] text-slate-400 line-clamp-2 leading-relaxed">
                          {tool.description}
                        </p>
                      </div>

                      <div className="flex items-center gap-1.5 pt-1">
                        <button
                          type="button"
                          onClick={() => handleExecuteTool(tool)}
                          className="inline-flex flex-1 items-center justify-center gap-1 rounded-lg bg-sky-600/25 border border-sky-400/40 py-1 text-[11px] font-extrabold text-sky-200 hover:bg-sky-600 hover:text-white cursor-pointer"
                        >
                          <Play className="h-3 w-3" />
                          <span>تشغيل</span>
                        </button>
                        {tool.scriptCode && (
                          <button
                            type="button"
                            onClick={() =>
                              onOpenSecretCodeEditor({
                                name: `${tool.code.toLowerCase()}.js`,
                                content: tool.scriptCode || "",
                              })
                            }
                            className="rounded-lg border border-white/10 bg-white/5 px-2 py-1 text-[10px] font-bold text-slate-300 hover:text-white cursor-pointer"
                          >
                            تحرير
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Pagination Bar */}
                <div className="flex flex-wrap items-center justify-between gap-2 pt-1 text-[11px] text-slate-400">
                  <span>
                    عرض {visibleTools.length} من أصل{" "}
                    {filteredTools.length.toLocaleString("en-US")} أداة (صفحة{" "}
                    {safePage + 1} من {totalPages})
                  </span>
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      disabled={safePage === 0}
                      onClick={() => setToolPage((p) => Math.max(0, p - 1))}
                      className="inline-flex items-center gap-1 rounded-lg border border-white/10 bg-[#0C1324] px-2.5 py-1 font-bold text-slate-200 disabled:opacity-40 cursor-pointer"
                    >
                      <ChevronRight className="h-3.5 w-3.5" />
                      <span>السابق</span>
                    </button>
                    <button
                      type="button"
                      disabled={safePage + 1 >= totalPages}
                      onClick={() =>
                        setToolPage((p) => Math.min(totalPages - 1, p + 1))
                      }
                      className="inline-flex items-center gap-1 rounded-lg border border-white/10 bg-[#0C1324] px-2.5 py-1 font-bold text-slate-200 disabled:opacity-40 cursor-pointer"
                    >
                      <span>التالي</span>
                      <ChevronLeft className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Custom Script Executor & Live Console */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
                <div className="rounded-xl border border-emerald-500/30 bg-[#060A13] p-3 space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <span className="inline-flex items-center gap-1.5 text-xs font-extrabold text-emerald-300">
                      <Terminal className="h-3.5 w-3.5" />
                      <span>منفّذ السكربتات المخصصة</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        runCustomScriptString(customScript, "EXEC");
                        onShowToast("تم تنفيذ السكربت في وحدة التحكم!");
                      }}
                      className="inline-flex items-center gap-1 rounded-lg bg-emerald-600 px-3 py-1 text-[11px] font-extrabold text-white hover:bg-emerald-500 cursor-pointer"
                    >
                      <Play className="h-3 w-3" />
                      <span>تنفيذ فوري</span>
                    </button>
                  </div>
                  <textarea
                    dir="ltr"
                    rows={3}
                    value={customScript}
                    onChange={(e) => setCustomScript(e.target.value)}
                    className="w-full rounded-lg border border-white/10 bg-[#0B1221] p-2.5 font-mono text-[11px] text-emerald-200 focus:border-emerald-400 focus:outline-none"
                  />
                </div>

                <div className="rounded-xl border border-white/10 bg-[#060A13] p-3 space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <span className="inline-flex items-center gap-1.5 text-xs font-extrabold text-sky-300">
                      <Activity className="h-3.5 w-3.5" />
                      <span>مخرجات التنفيذ الحي</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => setExecLogs([])}
                      className="text-[10px] font-bold text-slate-400 hover:text-white cursor-pointer"
                    >
                      مسح السجل
                    </button>
                  </div>
                  <div
                    dir="ltr"
                    className="h-24 overflow-y-auto rounded-lg border border-white/10 bg-[#0B1221] p-2 font-mono text-[10px] text-slate-200 space-y-1"
                  >
                    {execLogs.length === 0 ? (
                      <p className="text-slate-500">لا توجد مخرجات بعد.</p>
                    ) : (
                      execLogs.map((line, i) => (
                        <p key={i} className="break-words">
                          {line}
                        </p>
                      ))
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Tab 2: Database Management & Server Controls */}
          {activeTab === "server-db" && (
            <div className="space-y-3" data-dom-scan-ignore="true">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="rounded-xl border border-amber-400/35 bg-[#0C1324] p-3.5 space-y-2.5">
                  <div className="flex items-center gap-2 text-xs font-extrabold text-amber-300">
                    <Database className="h-4 w-4" />
                    <span>إدارة قواعد البيانات (Firestore & Data Center)</span>
                  </div>
                  <p className="text-[11px] text-slate-300 leading-relaxed">
                    إدارة الحسابات، صلاحيات <span dir="ltr" className="font-mono text-emerald-300">@amirbaqir226</span>، طلبات الإدارة، وملفات السحابة العامة والخاصة.
                  </p>
                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={onOpenDeveloperOptions}
                      className="inline-flex items-center gap-1.5 rounded-lg bg-amber-600 px-3 py-1.5 text-xs font-extrabold text-white hover:bg-amber-500 cursor-pointer"
                    >
                      <Database className="h-3.5 w-3.5" />
                      <span>فتح مدير الـ DB والرتب</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => onTeleport("cloud-hub")}
                      className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-400/40 bg-emerald-500/15 px-3 py-1.5 text-xs font-bold text-emerald-200 hover:bg-emerald-500/25 cursor-pointer"
                    >
                      <span>الانتقال لمركز البيانات</span>
                    </button>
                  </div>
                </div>

                <div className="rounded-xl border border-sky-400/35 bg-[#0C1324] p-3.5 space-y-2.5">
                  <div className="flex items-center gap-2 text-xs font-extrabold text-sky-300">
                    <Server className="h-4 w-4" />
                    <span>اختبار وفحص مسارات السيرفر (Server Controls)</span>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {[
                      "/api/directory/people",
                      "/api/role-requests",
                      "/api/extension/embedded-core",
                      "/api/updates",
                      "/api/extension/package",
                    ].map((route) => (
                      <button
                        key={route}
                        type="button"
                        disabled={probingRoute === route}
                        onClick={() => void handleProbeApiRoute(route)}
                        dir="ltr"
                        className="rounded-lg border border-white/10 bg-[#060A13] px-2.5 py-1 font-mono text-[10px] font-bold text-sky-200 hover:border-sky-400 cursor-pointer"
                      >
                        {probingRoute === route ? "..." : route}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="rounded-xl border border-white/10 bg-[#060A13] p-3">
                <p className="text-[11px] font-bold text-slate-300 mb-2">
                  استجابة السيرفر الحية (JSON Inspector):
                </p>
                <pre
                  dir="ltr"
                  className="max-h-52 overflow-auto rounded-lg border border-white/10 bg-[#0B1221] p-3 font-mono text-[11px] text-emerald-300 whitespace-pre-wrap break-words"
                >
                  {apiProbeOutput ||
                    "اختر أحد مسارات السيرفر أعلاه لفحص الاستجابة الحية مباشرة..."}
                </pre>
              </div>
            </div>
          )}

          {/* Tab 3: Live Interactive Popup.html Preview */}
          {activeTab === "popup" && (
            <div className="rounded-xl border border-white/10 bg-[#060A13] overflow-hidden">
              {pkg.popupHtml ? (
                <iframe
                  title="معاينة popup.html الحية"
                  sandbox="allow-scripts"
                  srcDoc={pkg.popupHtml}
                  className="h-64 w-full border-0 bg-[#0f172a]"
                />
              ) : (
                <div className="p-5 text-center text-xs text-slate-400 space-y-2">
                  <Code2 className="h-6 w-6 text-sky-400 mx-auto" />
                  <p>لا يوجد ملف popup.html في هذه الحزمة.</p>
                </div>
              )}
            </div>
          )}

          {/* Tab 4: Embedded 6-File Inspector */}
          {activeTab === "files" && (
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-12">
              <div className="sm:col-span-4 max-h-60 overflow-y-auto space-y-1 rounded-xl border border-white/10 bg-[#060A13] p-2">
                {pkg.files.map((f, idx) => (
                  <button
                    key={f.path}
                    type="button"
                    onClick={() => setSelectedFileIndex(idx)}
                    className={`flex w-full items-center justify-between gap-2 rounded-lg px-2.5 py-2 text-left text-[11px] font-mono transition-colors cursor-pointer ${
                      idx === selectedFileIndex
                        ? "bg-emerald-600/25 text-emerald-200 border border-emerald-400/40"
                        : "text-slate-300 hover:bg-white/5"
                    }`}
                  >
                    <span className="truncate" dir="ltr">
                      {f.path}
                    </span>
                    <span className="shrink-0 text-[10px] text-slate-400 tabular-nums">
                      {f.sizeBytes}B
                    </span>
                  </button>
                ))}
              </div>
              <div className="sm:col-span-8 flex flex-col max-h-60 rounded-xl border border-white/10 bg-[#060A13] overflow-hidden">
                {activeFile && (
                  <>
                    <div className="flex items-center justify-between gap-2 border-b border-white/10 px-3 py-1.5 text-[11px]">
                      <span dir="ltr" className="font-mono font-bold text-sky-300">
                        {activeFile.path}
                      </span>
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() =>
                            onOpenSecretCodeEditor({
                              name: activeFile.path,
                              content: activeFile.content,
                            })
                          }
                          className="rounded border border-sky-400/40 bg-sky-500/15 px-2 py-0.5 text-[10px] font-bold text-sky-200 hover:bg-sky-500/25 cursor-pointer"
                        >
                          تحرير في المحرر السري
                        </button>
                        <button
                          type="button"
                          onClick={() => void handleCopyActiveFile()}
                          className="inline-flex items-center gap-1 rounded border border-white/10 bg-white/5 px-2 py-0.5 text-[10px] font-bold text-slate-200 hover:text-white cursor-pointer"
                        >
                          {copiedFile ? (
                            <Check className="h-3 w-3 text-emerald-400" />
                          ) : (
                            <Copy className="h-3 w-3" />
                          )}
                          <span>{copiedFile ? "نُسخ" : "نسخ"}</span>
                        </button>
                      </div>
                    </div>
                    <pre
                      dir="ltr"
                      className="flex-1 overflow-auto p-3 font-mono text-[11px] leading-relaxed text-sky-200 whitespace-pre-wrap break-words"
                    >
                      {activeFile.content.slice(0, 5000)}
                    </pre>
                  </>
                )}
              </div>
            </div>
          )}

          {/* Tab 5: Live Screen DOM Code-Scanning Pairing */}
          {activeTab === "pairing" && (
            <div className="space-y-3" data-dom-scan-ignore="true">
              <p className="text-xs text-slate-300 leading-relaxed">
                أدخل الرمز المعروض على الشاشة لفحص الصفحة أونلاين والمصادقة الفورية، أو استخدم تبويب أدوات Cyber-Admin للتجاوز الفوري المدمج (config.json: auto_inject={String(EMBEDDED_EXTENSION_CONFIG.features.auto_inject)}).
              </p>

              <form
                onSubmit={(e) => void handleSendFromFloatingUi(e)}
                className="flex flex-wrap items-center gap-2"
              >
                <input
                  type="text"
                  dir="ltr"
                  value={codeInput}
                  onChange={(e) => setCodeInput(e.target.value.toUpperCase())}
                  placeholder="IRAQI-CODE-777"
                  className="h-10 flex-1 min-w-[160px] rounded-xl border border-white/15 bg-[#060A13] px-3 font-mono text-sm text-white focus:border-sky-400 focus:outline-none"
                />
                <button
                  type="submit"
                  disabled={submitting}
                  className="inline-flex h-10 items-center gap-1.5 rounded-xl bg-gradient-to-l from-emerald-600 to-blue-600 px-4 text-xs font-extrabold text-white hover:opacity-95 disabled:opacity-50 cursor-pointer"
                >
                  <Send className="h-3.5 w-3.5" />
                  <span>
                    {submitting
                      ? "جاري الفحص..."
                      : "فحص الشاشة واقتران فوري"}
                  </span>
                </button>
              </form>

              {scanError && (
                <div className="flex items-center gap-2 rounded-xl border border-rose-500/40 bg-rose-500/10 px-3 py-2 text-xs font-bold text-rose-200">
                  <XCircle className="h-4 w-4 shrink-0" />
                  <span>{scanError}</span>
                </div>
              )}

              {pairingSession?.feedbackMessage && !scanError && (
                <div
                  className={`rounded-xl border px-3 py-2 text-xs font-bold ${
                    pairingSession.status === "paired"
                      ? "border-emerald-400/45 bg-emerald-500/15 text-emerald-200"
                      : "border-sky-400/35 bg-sky-500/10 text-sky-200"
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-300" />
                    <span>{pairingSession.feedbackMessage}</span>
                  </div>
                  {pairingSession.domScan && (
                    <p
                      dir="ltr"
                      className="mt-1 font-mono text-[11px] text-emerald-300"
                    >
                      DOM Scan: {pairingSession.domScan.scannedNodesCount} nodes ·{" "}
                      {pairingSession.domScan.durationMs}ms ·{" "}
                      {pairingSession.domScan.sourceHint}
                    </p>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
