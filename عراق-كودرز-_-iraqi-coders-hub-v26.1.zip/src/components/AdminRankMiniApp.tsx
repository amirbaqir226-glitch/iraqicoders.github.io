import React, { useState } from "react";
import {
  Award,
  CheckCircle2,
  CreditCard,
  Crown,
  Mail,
  Search,
  Send,
  Shield,
  ShieldCheck,
  UserCheck,
} from "lucide-react";
import { buildRankPromotionEmail } from "../services/gmailService";
import {
  CustomNationalityCard,
  GmailConfirmRequest,
  PlatformMessageRecord,
  UserProfile,
  UserRole,
} from "../types";
import { NationalityDualFacesView } from "./NetworkVoiceNationalityModal";

interface AdminRankMiniAppProps {
  user: UserProfile | null;
  userRole: UserRole;
  allNationalities: CustomNationalityCard[];
  onNationalityLoaded: (card: CustomNationalityCard) => void;
  onAddPlatformMessage: (msg: PlatformMessageRecord) => void;
  onRequestSendGmail: (req: GmailConfirmRequest) => void;
  onShowToast: (msg: string) => void;
}

const RANK_CHOICES: Array<{
  id: "moderator" | "developer" | "admin";
  label: string;
  previewSubject: string;
  previewBody: string;
}> = [
  {
    id: "moderator",
    label: "رتبة مشرف",
    previewSubject: "مرحبا بك، لقد عيناك كمشرف",
    previewBody: "مبروك لقد أصبحت مشرف",
  },
  {
    id: "developer",
    label: "رتبة مطور",
    previewSubject: "مرحبا بك، تم تعيينك كمطور",
    previewBody: "مبروك لقد أصبحت مطور",
  },
  {
    id: "admin",
    label: "رتبة مسؤول",
    previewSubject: "مرحبا بك، تم تعيينك كمسؤول",
    previewBody: "مبروك لقد صرت مسؤول",
  },
];

export const AdminRankMiniApp: React.FC<AdminRankMiniAppProps> = ({
  user,
  userRole,
  allNationalities,
  onNationalityLoaded,
  onAddPlatformMessage,
  onRequestSendGmail,
  onShowToast,
}) => {
  // Strict RBAC guard: completely hidden from regular users
  const isStaff =
    userRole === "admin" ||
    userRole === "developer" ||
    userRole === "moderator" ||
    userRole === "director";

  const [targetIdentifier, setTargetIdentifier] = useState("");
  const [targetRole, setTargetRole] = useState<"moderator" | "developer" | "admin">(
    "moderator"
  );
  const [sendGmailAlert, setSendGmailAlert] = useState(true);
  const [assigning, setAssigning] = useState(false);
  const [fetchingNat, setFetchingNat] = useState(false);
  const [inspectedNationality, setInspectedNationality] =
    useState<CustomNationalityCard | null>(null);
  const [lookupMessage, setLookupMessage] = useState("");
  const [lastResultBanner, setLastResultBanner] = useState("");

  if (!isStaff) {
    return null;
  }

  const findLocalMatch = (rawQuery: string): CustomNationalityCard | null => {
    const q = rawQuery.trim().toLowerCase();
    const cleanQ = q.replace(/^@/, "");
    if (!cleanQ) return null;
    return (
      allNationalities.find((card) => {
        const candidates = [
          card.id,
          card.ownerUid,
          card.ownerHandle,
          card.ownerHandle.replace(/^@/, ""),
          card.ownerEmail,
          card.nationalityCode,
          card.numericId,
          card.fullName,
        ].map((v) => String(v || "").toLowerCase());
        return candidates.some((c) => c === q || c === cleanQ || c.includes(cleanQ));
      }) || null
    );
  };

  // Option: "خذ جنسية الناس"
  const handleTakePeoplesNationality = async () => {
    const query = targetIdentifier.trim();
    setLookupMessage("");

    if (!query) {
      if (allNationalities.length > 0) {
        setInspectedNationality(allNationalities[0]);
        setLookupMessage(
          `تم سحب أحدث جنسية مسجلة (${allNationalities[0].fullName}) — يمكنك البحث بالآيدي أو الإيميل أيضاً.`
        );
      } else {
        setLookupMessage("أدخل آيدي أو معرّف أو رقم أو إيميل العضو أولاً.");
      }
      return;
    }

    setFetchingNat(true);
    try {
      const localCard = findLocalMatch(query);
      if (localCard) {
        setInspectedNationality(localCard);
        setLookupMessage(
          `تم استعراض جنسية «${localCard.fullName}» (${localCard.nationalityCode}) بنجاح.`
        );
        return;
      }

      const res = await fetch(
        `/api/nationalities?lookup=${encodeURIComponent(query)}`
      );
      if (res.ok) {
        const data = (await res.json()) as {
          nationalities?: CustomNationalityCard[];
        };
        if (Array.isArray(data.nationalities) && data.nationalities.length > 0) {
          const found = data.nationalities[0];
          setInspectedNationality(found);
          onNationalityLoaded(found);
          setLookupMessage(
            `تم سحب جنسية «${found.fullName}» من السيرفر (${found.nationalityCode}).`
          );
          return;
        }
      }
      setInspectedNationality(null);
      setLookupMessage(`لم يتم العثور على جنسية مطابقة للمعرّف «${query}».`);
    } catch {
      setLookupMessage("تعذر الاتصال بالسيرفر أثناء سحب الجنسية.");
    } finally {
      setFetchingNat(false);
    }
  };

  const handleAssignRank = async (e: React.FormEvent) => {
    e.preventDefault();
    const idTrimmed = targetIdentifier.trim();
    if (!idTrimmed) {
      onShowToast("أدخل آيدي / معرّف / رقم / إيميل الشخص أولاً.");
      return;
    }

    setAssigning(true);
    setLastResultBanner("");
    try {
      const res = await fetch("/api/roles/assign", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          assignerRole: userRole,
          assignerEmail: user?.email || "amirbaqir226@gmail.com",
          assignerName: user?.name || "إدارة عراقي كودرز",
          identifier: idTrimmed,
          targetRole,
          gmailSynced: sendGmailAlert,
        }),
      });

      const data = (await res.json()) as {
        person?: {
          displayName: string;
          handle: string;
          email: string;
          role: string;
        };
        nationality?: CustomNationalityCard | null;
        messageRecord?: PlatformMessageRecord;
        error?: string;
      };

      if (!res.ok) {
        onShowToast(data.error || "تعذر تنفيذ التعيين الإداري.");
        return;
      }

      if (data.nationality) {
        onNationalityLoaded(data.nationality);
        setInspectedNationality(data.nationality);
      }

      const resolvedRecipientEmail =
        (idTrimmed.includes("@") && idTrimmed.includes(".")
          ? idTrimmed
          : data.nationality?.ownerEmail || data.person?.email || "") || "";

      const emailPayload = buildRankPromotionEmail({
        recipientName: data.person?.displayName || idTrimmed,
        recipientEmail: resolvedRecipientEmail || "member@iraqicoders.iq",
        rank: targetRole,
        assignerName: user?.name || "إدارة عراقي كودرز",
      });

      if (data.messageRecord) {
        onAddPlatformMessage(data.messageRecord);
      }

      setLastResultBanner(
        `تم تعيين «${data.person?.displayName || idTrimmed}» إلى ${
          RANK_CHOICES.find((r) => r.id === targetRole)?.label
        }: «${emailPayload.greetingLine} — ${emailPayload.congratsLine}»`
      );
      onShowToast("تم منح الرتبة وتحديث سجل المستخدم (متصل/غير متصل) بنجاح!");

      if (
        sendGmailAlert &&
        resolvedRecipientEmail.includes("@") &&
        !resolvedRecipientEmail.endsWith("@iraqicoders.iq")
      ) {
        onRequestSendGmail({
          to: resolvedRecipientEmail,
          subject: emailPayload.subject,
          htmlBody: emailPayload.htmlBody,
          textBody: emailPayload.textBody,
          previewText: `${emailPayload.greetingLine}\n${emailPayload.congratsLine}`,
          rankAssigned: targetRole,
          targetIdentifier: idTrimmed,
        });
      }
    } catch {
      onShowToast("حدث خطأ أثناء الاتصال بخادم تعيين الرتب.");
    } finally {
      setAssigning(false);
    }
  };

  const selectedRankMeta = RANK_CHOICES.find((r) => r.id === targetRole)!;

  return (
    <div className="rounded-3xl border-2 border-amber-400/50 bg-gradient-to-br from-[#1A1308] via-[#0F1424] to-[#0A1918] p-5 sm:p-6 shadow-2xl space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 pb-4">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl border border-amber-400/50 bg-amber-500/15 text-amber-300">
            <Crown className="h-5 w-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base sm:text-lg font-extrabold text-white">
                التطبيق المصغر الإداري للرتب والجنسيات
              </h3>
              <span className="rounded-md border border-amber-400/45 bg-amber-500/15 px-2 py-0.5 text-[10px] font-extrabold text-amber-200">
                حصري: مسؤول / مطور / مشرف
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              إدارة رتب أي شخص (متصل أو غير متصل) بالآيدي أو المعرّف أو الرقم أو الإيميل وسحب بطاقة «خذ جنسية الناس»
            </p>
          </div>
        </div>
      </div>

      {/* Input Row + Quick "خذ جنسية الناس" Lookup */}
      <form onSubmit={(e) => void handleAssignRank(e)} className="space-y-4">
        <div className="grid grid-cols-1 gap-3 md:grid-cols-12">
          <div className="md:col-span-7">
            <label className="block text-xs font-bold text-slate-300 mb-1.5">
              أدخل آيدي / معرّف (@handle) / رقم / بريد إلكتروني لأي مستخدم
            </label>
            <input
              type="text"
              dir="ltr"
              value={targetIdentifier}
              onChange={(e) => setTargetIdentifier(e.target.value)}
              placeholder="@username or uid or 123456 or user@gmail.com"
              className="h-11 w-full rounded-xl border border-white/15 bg-[#080C15] px-4 font-mono text-xs text-white placeholder:text-slate-500 focus:border-amber-400 focus:outline-none"
            />
          </div>

          <div className="md:col-span-5 flex items-end gap-2">
            <button
              type="button"
              disabled={fetchingNat}
              onClick={() => void handleTakePeoplesNationality()}
              className="inline-flex h-11 flex-1 items-center justify-center gap-2 rounded-xl border border-sky-400/50 bg-sky-500/20 px-4 text-xs font-extrabold text-sky-200 hover:bg-sky-500/30 cursor-pointer"
            >
              <Search className="h-4 w-4" />
              <span>{fetchingNat ? "جاري السحب..." : "خذ جنسية الناس"}</span>
            </button>
          </div>
        </div>

        {/* Rank Selection Buttons */}
        <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-3">
          {RANK_CHOICES.map((rank) => {
            const active = targetRole === rank.id;
            return (
              <button
                key={rank.id}
                type="button"
                onClick={() => setTargetRole(rank.id)}
                className={`rounded-2xl border p-3.5 text-right transition-all cursor-pointer ${
                  active
                    ? "border-emerald-400 bg-emerald-500/20 text-white shadow-lg"
                    : "border-white/10 bg-[#080C15] text-slate-300 hover:border-white/25"
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-extrabold">{rank.label}</span>
                  {rank.id === "admin" ? (
                    <Crown className="h-4 w-4 text-amber-400" />
                  ) : rank.id === "developer" ? (
                    <Award className="h-4 w-4 text-emerald-400" />
                  ) : (
                    <Shield className="h-4 w-4 text-sky-400" />
                  )}
                </div>
                <p className="mt-1.5 text-[11px] text-emerald-300 font-bold">
                  «{rank.previewSubject}»
                </p>
                <p className="text-[11px] text-slate-400">{rank.previewBody}</p>
              </button>
            );
          })}
        </div>

        {/* Live Gmail Message Preview + Toggle */}
        <div className="rounded-2xl border border-emerald-400/30 bg-[#080C15] p-3.5 flex flex-wrap items-center justify-between gap-3">
          <div className="space-y-0.5 text-xs">
            <p className="font-extrabold text-emerald-300 flex items-center gap-1.5">
              <Mail className="h-3.5 w-3.5" />
              <span>معاينة الإشعار المرسل لتطبيق Gmail والرسائل:</span>
            </p>
            <p className="text-slate-200">
              {selectedRankMeta.previewSubject} —{" "}
              <strong className="text-amber-200">{selectedRankMeta.previewBody}</strong>
            </p>
          </div>

          <label className="inline-flex items-center gap-2 text-xs font-bold text-slate-200 cursor-pointer">
            <input
              type="checkbox"
              checked={sendGmailAlert}
              onChange={(e) => setSendGmailAlert(e.target.checked)}
              className="h-4 w-4 accent-emerald-500 rounded"
            />
            <span>إرسال رسالة عبر تطبيق Gmail الحقيقي</span>
          </label>
        </div>

        <button
          type="submit"
          disabled={assigning}
          className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-l from-amber-500 to-emerald-600 py-3 text-xs font-extrabold text-white shadow-lg hover:opacity-95 disabled:opacity-60 cursor-pointer"
        >
          <UserCheck className="h-4 w-4" />
          <Send className="h-3.5 w-3.5" />
          <span>
            {assigning
              ? "جاري منح الرتبة وإعداد الإشعار..."
              : `تعيين كـ ${selectedRankMeta.label} وإرسال التهنئة`}
          </span>
        </button>
      </form>

      {lastResultBanner && (
        <div className="flex items-center gap-2 rounded-xl border border-emerald-400/50 bg-emerald-500/15 px-4 py-3 text-xs font-bold text-emerald-200">
          <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-400" />
          <span>{lastResultBanner}</span>
        </div>
      )}

      {lookupMessage && (
        <div className="rounded-xl border border-sky-400/40 bg-sky-500/10 px-4 py-2.5 text-xs font-bold text-sky-200">
          {lookupMessage}
        </div>
      )}

      {/* Quick List of Issued Nationalities for Instant Inspection */}
      {allNationalities.length > 0 && (
        <div className="space-y-2">
          <p className="text-xs font-extrabold text-slate-300 flex items-center gap-1.5">
            <CreditCard className="h-3.5 w-3.5 text-sky-400" />
            <span>سجل الجنسيات المنشأة ({allNationalities.length}) — اضغط للمعاينة:</span>
          </p>
          <div className="flex flex-wrap gap-2">
            {allNationalities.map((nat) => (
              <button
                key={nat.id}
                type="button"
                onClick={() => {
                  setInspectedNationality(nat);
                  setTargetIdentifier(nat.ownerEmail || nat.ownerHandle || nat.nationalityCode);
                }}
                className={`inline-flex items-center gap-1.5 rounded-xl border px-3 py-1.5 text-[11px] font-bold cursor-pointer ${
                  inspectedNationality?.id === nat.id
                    ? "border-sky-400 bg-sky-500/20 text-sky-100"
                    : "border-white/15 bg-[#080C15] text-slate-300 hover:border-sky-400/40"
                }`}
              >
                <ShieldCheck className="h-3.5 w-3.5 text-emerald-400" />
                <span>{nat.fullName}</span>
                <span className="font-mono text-[10px] text-amber-300">
                  ({nat.nationalityCode})
                </span>
              </button>
            ))}
          </div>
        </div>
      )}

      {inspectedNationality && (
        <div className="space-y-2 pt-2 border-t border-white/10">
          <div className="flex items-center justify-between">
            <span className="text-xs font-extrabold text-sky-300">
              بطاقة «خذ جنسية الناس» الكاملة (الواجهة الأمامية والخلفية):
            </span>
            <button
              type="button"
              onClick={() => setInspectedNationality(null)}
              className="text-[11px] font-bold text-slate-400 hover:text-white cursor-pointer"
            >
              إخفاء البطاقة
            </button>
          </div>
          <NationalityDualFacesView card={inspectedNationality} />
        </div>
      )}
    </div>
  );
};
