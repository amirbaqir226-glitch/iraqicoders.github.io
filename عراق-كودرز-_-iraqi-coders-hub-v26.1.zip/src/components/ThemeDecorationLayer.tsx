import React from "react";
import { ThemeDecoration } from "../types";

export interface ThemeMeta {
  id: ThemeDecoration;
  label: string;
  subtitle: string;
  accentHex: string;
  badgeText: string;
}

export const THEME_OPTIONS: ThemeMeta[] = [
  {
    id: "default",
    label: "الوضع الليلي الأصلي",
    subtitle: "تصميم #0B0F19 الكلاسيكي مع إضاءة بنفسجية وزمردية متوازنة",
    accentHex: "#8B5CF6",
    badgeText: "قياسي",
  },
  {
    id: "halloween",
    label: "زينة الهالوين",
    subtitle: "فوانيس برتقالية متوهجة وخيوط عنكبوت خفيفة في زوايا الواجهة",
    accentHex: "#F97316",
    badgeText: "موسمي",
  },
  {
    id: "cyber",
    label: "زينة البرمجة",
    subtitle: "شبكة أكواد خضراء ومؤشرات طرفية بأسلوب المطورين المحترفين",
    accentHex: "#10B981",
    badgeText: "Code",
  },
  {
    id: "electric",
    label: "زينة الكهرباء العراقية",
    subtitle: "شرارات كهربائية نيونية وأسلاك طاقة مستوحاة من شبكات بغداد",
    accentHex: "#FBBF24",
    badgeText: "220V",
  },
  {
    id: "fantasy",
    label: "عالم الخيال والحلويات",
    subtitle: "غيوم متوهجة وأجواء سكاكر وحلويات تفاعلية حالمة فوق الواجهة",
    accentHex: "#F472B6",
    badgeText: "Fantasy",
  },
];

interface ThemeDecorationLayerProps {
  theme: ThemeDecoration;
}

const FANTASY_SWEETS = [
  { id: "sw1", x: "8%", y: "18%", kind: "candy", color: "#F472B6", delay: "0s" },
  { id: "sw2", x: "22%", y: "72%", kind: "donut", color: "#38BDF8", delay: "0.7s" },
  { id: "sw3", x: "78%", y: "24%", kind: "lollipop", color: "#C084FC", delay: "1.2s" },
  { id: "sw4", x: "88%", y: "66%", kind: "star", color: "#FBBF24", delay: "0.4s" },
  { id: "sw5", x: "48%", y: "84%", kind: "candy", color: "#34D399", delay: "1.6s" },
];

export const FantasyTopCloud: React.FC<{ className?: string }> = ({
  className = "",
}) => (
  <svg
    viewBox="0 0 80 34"
    aria-hidden="true"
    className={`pointer-events-none select-none drop-shadow-[0_0_8px_rgba(244,114,182,0.55)] ${className}`}
    fill="none"
  >
    <path
      d="M18 29H63C69.6 29 75 24 75 18C75 12.6 70.7 8.1 65.1 7.4C62.8 3.1 58.1 0.5 52.8 0.5C47.7 0.5 43.2 3 40.8 7C38.6 5.4 35.9 4.5 33 4.5C25.5 4.5 19.5 10.2 19.5 17.3C19.5 17.7 19.5 18 19.6 18.4C14.1 19 10 22.8 10 27.2C10 28.2 13.5 29 18 29Z"
      fill="url(#fantasyCloudGrad)"
      fillOpacity="0.92"
    />
    <defs>
      <linearGradient id="fantasyCloudGrad" x1="10" y1="0" x2="75" y2="29" gradientUnits="userSpaceOnUse">
        <stop stopColor="#FDF2F8" />
        <stop offset="0.55" stopColor="#FBCFE8" />
        <stop offset="1" stopColor="#BAE6FD" />
      </linearGradient>
    </defs>
  </svg>
);

export const ThemeDecorationLayer: React.FC<ThemeDecorationLayerProps> = ({
  theme,
}) => {
  if (theme === "default") {
    return null;
  }

  return (
    <div
      aria-hidden="true"
      className="pointer-events-none fixed inset-0 z-10 overflow-hidden"
    >
      {theme === "halloween" && (
        <>
          <div className="absolute -top-24 -right-24 h-80 w-80 rounded-full bg-orange-600/14 blur-3xl" />
          <div className="absolute bottom-0 left-0 h-72 w-72 rounded-full bg-purple-700/16 blur-3xl" />

          {/* Corner Cobweb SVG Right */}
          <svg
            viewBox="0 0 180 180"
            className="absolute top-14 right-0 h-36 w-36 text-orange-300/20"
            fill="none"
          >
            <path
              d="M180 0 L0 0 M180 0 L15 65 M180 0 L50 115 M180 0 L105 155 M180 0 L180 180"
              stroke="currentColor"
              strokeWidth="1.2"
            />
            <path
              d="M140 0 Q132 32 108 55 Q80 78 40 85"
              stroke="currentColor"
              strokeWidth="1"
            />
            <path
              d="M95 0 Q88 55 58 90 Q35 118 0 125"
              stroke="currentColor"
              strokeWidth="1"
            />
          </svg>

          {/* Subtle Glowing Pumpkin Corner Badge */}
          <div className="absolute bottom-5 right-5 flex items-center gap-2 rounded-xl border border-orange-500/30 bg-[#1B100A]/80 px-3 py-2 text-xs font-bold text-orange-300 backdrop-blur-sm">
            <svg viewBox="0 0 32 32" className="h-5 w-5" fill="none">
              <circle cx="16" cy="18" r="11" fill="#EA580C" />
              <rect x="14" y="4" width="4" height="5" rx="1.5" fill="#22C55E" />
              <polygon points="11,15 14,18 9,18" fill="#180D24" />
              <polygon points="21,15 23,18 18,18" fill="#180D24" />
              <path
                d="M11 22 Q16 25 21 22"
                stroke="#180D24"
                strokeWidth="2"
                strokeLinecap="round"
              />
            </svg>
            <span>وضع الهالوين</span>
          </div>
        </>
      )}

      {theme === "cyber" && (
        <>
          <div
            className="absolute inset-0 opacity-[0.07]"
            style={{
              backgroundImage:
                "linear-gradient(to right, rgba(16,185,129,0.35) 1px, transparent 1px), linear-gradient(to bottom, rgba(16,185,129,0.25) 1px, transparent 1px)",
              backgroundSize: "48px 48px",
            }}
          />
          <div className="absolute top-16 left-6 font-mono text-[11px] leading-5 text-emerald-400/25 select-none hidden md:block">
            <div>const hub = &quot;IRAQI_CODERS_26.5&quot;;</div>
            <div>firebase.sync(&#123; mode: &quot;CYBER&quot; &#125;);</div>
            <div>status =&gt; OK [200]</div>
          </div>
          <div className="absolute bottom-5 right-5 rounded-xl border border-emerald-500/35 bg-[#071512]/80 px-3 py-1.5 font-mono text-xs font-bold text-emerald-300 backdrop-blur-sm">
            &lt;/&gt; CYBER_DEV_MODE
          </div>
        </>
      )}

      {theme === "electric" && (
        <>
          <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-l from-amber-400 via-cyan-400 to-amber-500 opacity-75" />
          <div className="absolute -top-20 left-10 h-72 w-72 rounded-full bg-amber-400/12 blur-3xl" />
          <div className="absolute bottom-10 right-10 h-64 w-64 rounded-full bg-cyan-400/10 blur-3xl" />

          {/* Baghdad Power Lines & Lightning Arcs */}
          <svg
            viewBox="0 0 360 90"
            className="absolute top-12 left-4 h-20 w-72 text-amber-400/35"
            fill="none"
          >
            <path
              d="M0 15 Q90 48 180 22 T360 30"
              stroke="currentColor"
              strokeWidth="1.4"
            />
            <path
              d="M0 32 Q110 66 210 38 T360 44"
              stroke="#38BDF8"
              strokeOpacity="0.45"
              strokeWidth="1.2"
            />
            <path
              d="M192 8 L176 36 H190 L182 60 L204 28 H189 Z"
              fill="#FBBF24"
              fillOpacity="0.55"
            />
          </svg>

          <div className="absolute bottom-5 right-5 flex items-center gap-2 rounded-xl border border-amber-400/40 bg-[#171307]/85 px-3 py-1.5 text-xs font-extrabold text-amber-300 backdrop-blur-sm">
            <span className="h-2 w-2 rounded-full bg-amber-400 animate-pulse" />
            <span>مولدة الوطنية · 220V مستقرة</span>
          </div>
        </>
      )}

      {theme === "fantasy" && (
        <>
          <div className="absolute -top-24 right-1/4 h-96 w-96 rounded-full bg-pink-500/20 blur-3xl" />
          <div className="absolute top-1/3 -left-16 h-80 w-80 rounded-full bg-sky-400/18 blur-3xl" />
          <div className="absolute bottom-0 right-10 h-80 w-80 rounded-full bg-purple-500/18 blur-3xl" />

          {/* Floating Fantasy Candies & Sweets */}
          {FANTASY_SWEETS.map((sweet) => (
            <div
              key={sweet.id}
              style={{
                left: sweet.x,
                top: sweet.y,
                animationDelay: sweet.delay,
              }}
              className="absolute animate-bounce opacity-65"
            >
              {sweet.kind === "lollipop" ? (
                <svg viewBox="0 0 40 54" className="h-11 w-9" fill="none">
                  <rect x="18" y="26" width="4" height="24" rx="2" fill="#FDE68A" />
                  <circle cx="20" cy="16" r="13" fill={sweet.color} />
                  <path
                    d="M13 16 C13 11 27 11 27 16 C27 21 16 22 16 17"
                    stroke="#FFF"
                    strokeWidth="2.5"
                    strokeLinecap="round"
                  />
                </svg>
              ) : sweet.kind === "donut" ? (
                <svg viewBox="0 0 40 40" className="h-10 w-10" fill="none">
                  <circle cx="20" cy="20" r="14" stroke={sweet.color} strokeWidth="9" />
                  <circle cx="15" cy="12" r="2" fill="#FDE047" />
                  <circle cx="26" cy="15" r="2" fill="#F472B6" />
                  <circle cx="20" cy="28" r="2" fill="#34D399" />
                </svg>
              ) : sweet.kind === "star" ? (
                <svg viewBox="0 0 36 36" className="h-8 w-8" fill="none">
                  <polygon
                    points="18,2 22,13 34,13 24,20 28,32 18,25 8,32 12,20 2,13 14,13"
                    fill={sweet.color}
                  />
                </svg>
              ) : (
                <svg viewBox="0 0 48 32" className="h-8 w-12" fill="none">
                  <polygon points="2,8 12,16 2,24" fill="#FDE047" />
                  <polygon points="46,8 36,16 46,24" fill="#FDE047" />
                  <rect x="10" y="6" width="28" height="20" rx="10" fill={sweet.color} />
                  <path d="M18 7 L22 25 M27 7 L31 25" stroke="#FFF" strokeWidth="2.5" />
                </svg>
              )}
            </div>
          ))}

          <div className="absolute bottom-5 right-5 flex items-center gap-2 rounded-xl border border-pink-400/45 bg-[#2A1134]/85 px-3.5 py-1.5 text-xs font-extrabold text-pink-200 backdrop-blur-sm">
            <span className="h-2.5 w-2.5 rounded-full bg-pink-400 animate-ping" />
            <span>عالم الخيال والحلويات مفعّل</span>
          </div>
        </>
      )}
    </div>
  );
};
