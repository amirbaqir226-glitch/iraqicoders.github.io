import React, { useState } from "react";
import { Check, Copy, Download, FolderArchive, Shield, Wrench } from "lucide-react";
import { FIREBASE_HOSTING_SITE } from "../config/firebase";
import { COMMUNITY_CHANNELS, SITE_INFO } from "../data/siteConfig";
import { SocialBrandIcon } from "./CommunityLinksSection";

interface SiteArchiveMeta {
  downloadUrl: string;
  sizeBytes: number;
  fileCount: number;
}

interface SiteArchiveProgress {
  active: boolean;
  percent: number;
  loadedMb: string;
  totalMb: string;
}

interface FooterProps {
  displayVersion: string;
  canExportSiteZip: boolean;
  siteArchiveMeta?: SiteArchiveMeta | null;
  siteArchiveProgress?: SiteArchiveProgress | null;
  onDownloadSiteArchive: () => Promise<void> | void;
  onNotifyDownloadStarted?: (msg: string) => void;
  onOpenAdmin: () => void;
  onShowMaintenance: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  displayVersion,
  canExportSiteZip,
  siteArchiveMeta,
  siteArchiveProgress,
  onDownloadSiteArchive,
  onNotifyDownloadStarted,
  onOpenAdmin,
  onShowMaintenance,
}) => {
  const [downloadingZip, setDownloadingZip] = useState(false);
  const [copiedUrl, setCopiedUrl] = useState(false);

  const handleDownloadClick = async () => {
    if (downloadingZip) return;
    setDownloadingZip(true);
    try {
      await onDownloadSiteArchive();
    } finally {
      setDownloadingZip(false);
    }
  };

  const handleCopyDirectUrl = async () => {
    if (!siteArchiveMeta?.downloadUrl) return;
    try {
      const fullUrl = new URL(
        siteArchiveMeta.downloadUrl,
        window.location.origin
      ).toString();
      await navigator.clipboard.writeText(fullUrl);
      setCopiedUrl(true);
      onNotifyDownloadStarted?.("تم نسخ رابط التنزيل المباشر — الصقه في المتصفح للتنزيل!");
      window.setTimeout(() => setCopiedUrl(false), 2500);
    } catch {
      onNotifyDownloadStarted?.("تعذر نسخ الرابط تلقائياً.");
    }
  };

  const sizeLabel = siteArchiveMeta?.sizeBytes
    ? `${(siteArchiveMeta.sizeBytes / (1024 * 1024)).toFixed(1)} MB`
    : "~11 MB";

  return (
    <footer className="border-t border-white/10 bg-[#080C15] py-10">
      <div className="mx-auto flex max-w-7xl flex-col gap-6 px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex flex-wrap items-center gap-3">
            <span className="text-lg font-extrabold text-white">
              {SITE_INFO.brandName}
            </span>
            <span className="version-glow rounded-md border border-violet-400/45 bg-violet-600/25 px-2.5 py-0.5 text-xs font-extrabold text-emerald-300 tabular-nums">
              الإصدار {displayVersion}
            </span>
            <span className="text-xs text-slate-500">
              · {SITE_INFO.englishBrandName} · {FIREBASE_HOSTING_SITE}
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-4 text-xs font-semibold text-slate-400">
            <a href="#hero" className="hover:text-white transition-colors">
              الرئيسية
            </a>
            <a href="#shop" className="hover:text-emerald-300 transition-colors">
              المتجر والبيع
            </a>
            <a
              href={SITE_INFO.botExternalUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-white transition-colors"
            >
              {SITE_INFO.botButtonLabel}
            </a>
            <a href="#playground" className="hover:text-white transition-colors">
              محرر الكود
            </a>
            <a href="#community" className="hover:text-white transition-colors">
              المجتمع والمشاريع
            </a>

            <button
              type="button"
              onClick={onShowMaintenance}
              className="inline-flex items-center gap-1.5 rounded-lg border border-sky-500/30 bg-sky-500/10 px-3 py-1.5 text-xs font-bold text-sky-300 transition-colors hover:bg-sky-500/20 cursor-pointer"
            >
              <Wrench className="h-3.5 w-3.5" />
              <span>شاشة الصيانة</span>
            </button>

            <button
              type="button"
              onClick={onOpenAdmin}
              className="inline-flex items-center gap-1.5 rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-bold text-slate-200 transition-colors hover:border-violet-500/40 hover:text-emerald-300 cursor-pointer"
            >
              <Shield className="h-3.5 w-3.5 text-violet-400" />
              <span>دخول المسؤول</span>
            </button>
          </div>
        </div>

        {/* Official Community & Contact Links Row */}
        <div className="flex flex-wrap items-center justify-between gap-4 border-t border-white/10 pt-5">
          <p className="text-xs text-slate-400">
            القنوات الرسمية للمجتمع والدعم الفني وطلبات المتجر:
          </p>
          <div className="flex flex-wrap items-center gap-2.5">
            {COMMUNITY_CHANNELS.map((ch) => (
              <a
                key={ch.id}
                href={ch.url}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 rounded-xl border border-white/15 bg-white/5 px-3.5 py-2 text-xs font-bold text-slate-200 transition-colors hover:border-emerald-400/50 hover:text-emerald-300"
              >
                <SocialBrandIcon id={ch.id} className="h-4 w-4" />
                <span>{ch.englishName}</span>
              </a>
            ))}
          </div>
        </div>

        {/* Admin-Only Full Website Archive Download at Very Bottom */}
        {canExportSiteZip && (
          <div className="space-y-2.5 rounded-2xl border border-emerald-400/40 bg-emerald-500/10 px-4 py-3.5">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2.5 text-xs">
                <FolderArchive className="h-4 w-4 shrink-0 text-emerald-300" />
                <div>
                  <span className="font-bold text-emerald-100">
                    خاص بالمسؤولين: تحميل ملف الموقع المضغوط (بداخله مجلد يحتوي
                    جميع ملفات الموقع لإنشاء نسخة مطابقة)
                  </span>
                  {siteArchiveMeta && (
                    <span className="block text-[11px] text-emerald-300/90 tabular-nums mt-0.5">
                      جاهز للتنزيل الفوري · {siteArchiveMeta.fileCount} ملف حقيقي ·{" "}
                      {sizeLabel}
                    </span>
                  )}
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                {siteArchiveMeta?.downloadUrl ? (
                  <a
                    href={siteArchiveMeta.downloadUrl}
                    download="iraqi-coders-website-complete.zip"
                    onClick={() =>
                      onNotifyDownloadStarted?.(
                        "بدأ التنزيل الحقيقي لملف الموقع المضغوط في المتصفح!"
                      )
                    }
                    className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-4 py-2 text-xs font-extrabold text-white shadow-lg transition-colors hover:bg-emerald-500 cursor-pointer shrink-0"
                  >
                    <Download className="h-4 w-4" />
                    <span>نزل ملف الموقع</span>
                  </a>
                ) : (
                  <button
                    type="button"
                    disabled={downloadingZip}
                    onClick={() => void handleDownloadClick()}
                    className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-4 py-2 text-xs font-extrabold text-white shadow-lg transition-colors hover:bg-emerald-500 disabled:opacity-60 cursor-pointer shrink-0"
                  >
                    <FolderArchive className="h-4 w-4" />
                    <span>
                      {downloadingZip ? "جاري التجهيز..." : "نزل ملف الموقع"}
                    </span>
                  </button>
                )}

                <button
                  type="button"
                  disabled={downloadingZip || Boolean(siteArchiveProgress?.active)}
                  onClick={() => void handleDownloadClick()}
                  className="inline-flex items-center gap-1.5 rounded-xl border border-emerald-400/40 bg-emerald-950/60 px-3 py-2 text-[11px] font-bold text-emerald-200 transition-colors hover:bg-emerald-900/70 disabled:opacity-60 cursor-pointer"
                >
                  <FolderArchive className="h-3.5 w-3.5" />
                  <span>
                    {siteArchiveProgress?.active
                      ? `جاري التحميل ${siteArchiveProgress.percent}% (${siteArchiveProgress.loadedMb}/${siteArchiveProgress.totalMb} MB)`
                      : "تنزيل مع مؤشر %"}
                  </span>
                </button>

                {siteArchiveMeta?.downloadUrl && (
                  <button
                    type="button"
                    onClick={() => void handleCopyDirectUrl()}
                    className="inline-flex items-center gap-1.5 rounded-xl border border-white/15 bg-white/5 px-3 py-2 text-[11px] font-bold text-slate-200 transition-colors hover:bg-white/10 cursor-pointer"
                  >
                    {copiedUrl ? (
                      <Check className="h-3.5 w-3.5 text-emerald-400" />
                    ) : (
                      <Copy className="h-3.5 w-3.5" />
                    )}
                    <span>{copiedUrl ? "تم النسخ" : "نسخ الرابط"}</span>
                  </button>
                )}
              </div>
            </div>

            {siteArchiveProgress && (
              <div className="space-y-1 pt-1">
                <div className="flex items-center justify-between text-[11px] font-bold text-emerald-200 tabular-nums">
                  <span>
                    {siteArchiveProgress.active
                      ? "جاري سحب الأرشيف من السيرفر..."
                      : "اكتمل التحميل بنجاح 100%!"}
                  </span>
                  <span>
                    {siteArchiveProgress.loadedMb} / {siteArchiveProgress.totalMb} MB (
                    {siteArchiveProgress.percent}%)
                  </span>
                </div>
                <div className="h-1.5 w-full overflow-hidden rounded-full bg-black/40">
                  <div
                    className="h-full bg-emerald-400 transition-all duration-150"
                    style={{ width: `${siteArchiveProgress.percent}%` }}
                  />
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </footer>
  );
};
