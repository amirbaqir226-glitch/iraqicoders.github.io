import React, { useState } from "react";
import { Laugh, Send, Sparkles, X } from "lucide-react";
import { SITE_INFO } from "../data/siteConfig";

interface BrownDuolingoModalProps {
  isOpen: boolean;
  onClose: () => void;
  onEnterComedyBackstage: () => void;
}

interface OwlMessage {
  id: string;
  sender: "owl" | "user";
  text: string;
}

export const BrownDuolingoIcon: React.FC<{ className?: string }> = ({
  className = "h-7 w-7",
}) => (
  <svg viewBox="0 0 64 64" className={className} aria-hidden="true">
    <path
      d="M14 14 C18 8, 25 11, 28 15 L36 15 C39 11, 46 8, 50 14 C54 22, 55 38, 49 48 C44 55, 20 55, 15 48 C9 38, 10 22, 14 14 Z"
      fill="#8B5A2B"
    />
    <ellipse cx="32" cy="43" rx="13" ry="9" fill="#B8834E" />
    <circle cx="24" cy="27" r="8.5" fill="#5C3A18" />
    <circle cx="40" cy="27" r="8.5" fill="#5C3A18" />
    <circle cx="24" cy="27" r="6.5" fill="#FFFFFF" />
    <circle cx="40" cy="27" r="6.5" fill="#FFFFFF" />
    <circle cx="25" cy="27" r="3.4" fill="#1E1B18" />
    <circle cx="41" cy="27" r="3.4" fill="#1E1B18" />
    <circle cx="26.2" cy="25.5" r="1.2" fill="#FFFFFF" />
    <circle cx="42.2" cy="25.5" r="1.2" fill="#FFFFFF" />
    <path d="M28 32 L36 32 L32 39 Z" fill="#F59E0B" />
    <path d="M10 30 C7 35, 9 43, 14 45" fill="#6F4518" />
    <path d="M54 30 C57 35, 55 43, 50 45" fill="#6F4518" />
  </svg>
);

function getOwlReply(question: string): string {
  const q = question.toLowerCase();

  if (
    q.includes("احتفال") ||
    q.includes("علم") ||
    q.includes("احكي") ||
    q.includes("الموقع") ||
    q.includes("عراقي كودرز") ||
    q.includes("شنو")
  ) {
    return (
      "يا هلا بيك! اليوم رفعت علم العراق بفخر بمناسبة إطلاق الإصدار 26.5 من منصة عراقي كودرز! " +
      "عندك مهندس الأكواد الذكي، وزر المحادثة «Talk to Iraqi Bots» في أعلى الشاشة، ومحرر الكود المباشر، وقسم التحديات، ومكتبة مشاريع Roblox Luau و Minecraft Add-ons. " +
      "وإذا حسّيت بالملل، بس گول لي «أني مليت» وأودّيك لكواليس العمال الكوميدية فوراً!"
    );
  }

  if (q.includes("iraqi bot") || q.includes("بوت") || q.includes("ذكاء")) {
    return "اضغط على زر «Talk to Iraqi Bots» بالأسفل أو بأعلى الشاشة لفتح مساعد المحادثة المباشر!";
  }

  return (
    "هلا بيك! جرب تسألني: «أني مليت» حتى أنقلك إلى كواليس النكت مع العمال، أو اسألني «شنو سبب الاحتفال؟»"
  );
}

export const BrownDuolingoModal: React.FC<BrownDuolingoModalProps> = ({
  isOpen,
  onClose,
  onEnterComedyBackstage,
}) => {
  const [messages, setMessages] = useState<OwlMessage[]>([
    {
      id: "owl-init",
      sender: "owl",
      text: "هلا والله! أنا طائر دولينجو البني في عراقي كودرز 26.3. إذا ضايج ومليت بس اكتب «أني مليت» حتى نضحك ويه العمال!",
    },
  ]);
  const [input, setInput] = useState("");

  if (!isOpen) return null;

  const sendQuestion = (text: string) => {
    const trimmed = text.trim();
    if (!trimmed) return;

    const normalized = trimmed.toLowerCase();
    if (
      normalized.includes("أني مليت") ||
      normalized.includes("اني مليت") ||
      normalized.includes("مليت") ||
      normalized.includes("ملل") ||
      normalized.includes("bored")
    ) {
      onClose();
      onEnterComedyBackstage();
      return;
    }

    const userMsg: OwlMessage = {
      id: `u-${Date.now()}`,
      sender: "user",
      text: trimmed,
    };
    const owlMsg: OwlMessage = {
      id: `o-${Date.now() + 1}`,
      sender: "owl",
      text: getOwlReply(trimmed),
    };
    setMessages((prev) => [...prev, userMsg, owlMsg]);
    setInput("");
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="brown-owl-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-lg overflow-hidden rounded-2xl border border-amber-700/45 bg-[#0E1424] shadow-2xl"
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/10 bg-[#17110C] px-5 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl border border-amber-700/40 bg-[#8B5A2B]/20">
              <BrownDuolingoIcon className="h-9 w-9" />
            </div>
            <div>
              <h3 id="brown-owl-title" className="text-base font-extrabold text-white">
                طائر دولينجو البني
              </h3>
              <p className="text-xs text-amber-300/90">
                دليلك التفاعلي وكواليس الإصدار 26.3
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="إغلاق نافذة الطائر البني"
            className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 bg-white/5 text-slate-300 hover:bg-white/10 hover:text-white cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Quick Questions including "أني مليت" */}
        <div className="flex flex-wrap gap-2 border-b border-white/10 bg-[#0B0F19] px-5 py-3">
          <button
            type="button"
            onClick={() => sendQuestion("أني مليت")}
            className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-500/40 bg-emerald-600/20 px-3 py-1.5 text-xs font-extrabold text-emerald-300 transition-colors hover:bg-emerald-600/35 cursor-pointer"
          >
            <Laugh className="h-3.5 w-3.5" />
            <span>أني مليت</span>
          </button>

          {["شنو سبب الاحتفال؟", "احكي لي على الموقع"].map((preset) => (
            <button
              key={preset}
              type="button"
              onClick={() => sendQuestion(preset)}
              className="rounded-lg border border-amber-700/40 bg-amber-900/20 px-3 py-1.5 text-xs font-bold text-amber-200 transition-colors hover:bg-amber-800/35 cursor-pointer"
            >
              {preset}
            </button>
          ))}
        </div>

        {/* Chat Stream */}
        <div className="h-64 overflow-y-auto p-5 space-y-3 bg-[#0B0F19]/60">
          {messages.map((m) => (
            <div
              key={m.id}
              className={`flex ${
                m.sender === "user" ? "justify-start" : "justify-end"
              }`}
            >
              <div
                className={`max-w-[85%] rounded-2xl px-4 py-3 text-xs leading-relaxed sm:text-sm ${
                  m.sender === "user"
                    ? "bg-violet-600/25 border border-violet-500/35 text-white"
                    : "bg-[#221810] border border-amber-700/40 text-amber-50"
                }`}
              >
                {m.text}
              </div>
            </div>
          ))}
        </div>

        {/* Input & Iraqi Bots Shortcut */}
        <div className="border-t border-white/10 bg-[#0E1424] p-4 space-y-3">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              sendQuestion(input);
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="اكتب «أني مليت» أو اسأل طائر دولينجو البني..."
              className="h-10 flex-1 rounded-xl border border-white/10 bg-[#0B0F19] px-3.5 text-xs text-white placeholder:text-slate-500 focus:border-amber-500 focus:outline-none"
            />
            <button
              type="submit"
              className="inline-flex h-10 items-center gap-1.5 rounded-xl bg-[#8B5A2B] px-4 text-xs font-bold text-white hover:bg-[#9C6632] cursor-pointer"
            >
              <span>إرسال</span>
              <Send className="h-3.5 w-3.5" />
            </button>
          </form>

          <a
            href={SITE_INFO.botExternalUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex w-full items-center justify-center gap-2 rounded-xl border border-emerald-500/40 bg-emerald-600/15 py-2.5 text-xs font-bold text-emerald-300 transition-colors hover:bg-emerald-600/25 cursor-pointer"
          >
            <Sparkles className="h-4 w-4" />
            <span>{SITE_INFO.botButtonLabel}</span>
          </a>
        </div>
      </div>
    </div>
  );
};
