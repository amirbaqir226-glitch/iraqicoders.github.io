import React, { useEffect, useMemo, useState } from "react";
import {
  Check,
  CloudUpload,
  Code2,
  Copy,
  Download,
  FileCode2,
  FolderOpen,
  Play,
  Plus,
  Puzzle,
  Terminal,
  Trash2,
  X,
} from "lucide-react";
import { EMBEDDED_EXTENSION_FILES } from "../data/embeddedExtensionFiles";
import { CloudFileItem, UserProfile } from "../types";

interface SecretCodeEditorModalProps {
  isOpen: boolean;
  user: UserProfile | null;
  initialFileToLoad?: { name: string; content: string } | null;
  onClose: () => void;
  onSaveToDataCenter: (item: CloudFileItem) => void;
  onShowToast: (msg: string) => void;
}

interface WorkspaceFile {
  id: string;
  name: string;
  language: "javascript" | "html" | "luau" | "json" | "css";
  content: string;
}

interface TerminalLine {
  id: string;
  kind: "info" | "log" | "warn" | "error" | "success";
  text: string;
}

const DEFAULT_WORKSPACE_FILES: WorkspaceFile[] = [
  {
    id: "ws-bot-engine",
    name: "iraqi_bot_runner.js",
    language: "javascript",
    content: `// محرر الأكواد السري (بيئة تشغيل بدون روت) - بناء واختبار البوتات
const botConfig = {
  name: "Iraqi Coders Bot Pro",
  version: "4.0.0",
  mode: "no-root-sandbox",
  commands: ["/build", "/deploy", "/scan", "/status"]
};

function handleCommand(cmd, author) {
  console.log("[BOT] تم استلام الأمر:", cmd, "من:", author);
  if (cmd === "/build") {
    return { ok: true, message: "تم تجميع المشروع وتجهيزه لمركز البيانات!" };
  }
  if (cmd === "/scan") {
    return { ok: true, message: "فحص السكربتات سليم 100% بدون أخطاء." };
  }
  return { ok: true, message: "أمر مفعّل: " + cmd };
}

console.log("تهيئة:", botConfig.name, "v" + botConfig.version);
console.log("نتيجة اختبار /build =>", JSON.stringify(handleCommand("/build", "المطور العراقي")));
console.log("نتيجة اختبار /scan =>", JSON.stringify(handleCommand("/scan", "المشرف")));`,
  },
  {
    id: "ws-cyber-widget",
    name: "cyber_hud_widget.html",
    language: "html",
    content: `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <style>
    body { margin: 0; padding: 18px; background: #070b14; color: #f8fafc; font-family: Tahoma, sans-serif; }
    .panel { border: 1px solid #38bdf8; border-radius: 12px; padding: 16px; background: #0f172a; }
    h3 { margin: 0 0 8px; color: #38bdf8; font-size: 16px; }
    button { background: #0284c7; color: #fff; border: 0; border-radius: 8px; padding: 8px 14px; font-weight: bold; cursor: pointer; }
  </style>
</head>
<body>
  <div class="panel">
    <h3>واجهة اختبار بدون روت — عراقي كودرز</h3>
    <p id="msg">جاهز لاختبار أدوات الويب والسكربتات مباشرة.</p>
    <button onclick="document.getElementById('msg').innerText='تم تشغيل المهمة بنجاح! ✅'; console.log('تم الضغط على زر الاختبار في المعاينة');">تشغيل المهمة</button>
  </div>
</body>
</html>`,
  },
  {
    id: "ws-luau-script",
    name: "arena_guard.luau",
    language: "luau",
    content: `-- سكربت Roblox Luau جاهز للاختبار والتصدير
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local function onPlayerJoined(player)
  local leaderstats = Instance.new("Folder")
  leaderstats.Name = "leaderstats"
  leaderstats.Parent = player

  local coins = Instance.new("IntValue")
  coins.Name = "IraqiCoins"
  coins.Value = 250
  coins.Parent = leaderstats
  print("تم تفعيل حلبة عراقي كودرز للاعب:", player.Name)
end

Players.PlayerAdded:Connect(onPlayerJoined)`,
  },
  {
    id: "ws-factory-json",
    name: "mc_factory_manifest.json",
    language: "json",
    content: `{
  "format_version": 2,
  "header": {
    "name": "Iraqi Coders Mega Factory",
    "description": "No-Root Mobile Export for Minecraft Bedrock",
    "version": [4, 0, 0]
  },
  "features": {
    "auto_smelter": true,
    "cyber_vault": true
  }
}`,
  },
];

function inferLanguage(fileName: string): WorkspaceFile["language"] {
  const lower = fileName.toLowerCase();
  if (lower.endsWith(".html") || lower.endsWith(".htm")) return "html";
  if (lower.endsWith(".css")) return "css";
  if (lower.endsWith(".json")) return "json";
  if (lower.endsWith(".lua") || lower.endsWith(".luau")) return "luau";
  return "javascript";
}

export const SecretCodeEditorModal: React.FC<SecretCodeEditorModalProps> = ({
  isOpen,
  user,
  initialFileToLoad,
  onClose,
  onSaveToDataCenter,
  onShowToast,
}) => {
  const [files, setFiles] = useState<WorkspaceFile[]>(DEFAULT_WORKSPACE_FILES);
  const [activeFileId, setActiveFileId] = useState<string>(
    DEFAULT_WORKSPACE_FILES[0].id
  );
  const [newFileName, setNewFileName] = useState("");
  const [showNewFileInput, setShowNewFileInput] = useState(false);
  const [copied, setCopied] = useState(false);
  const [previewHtmlDoc, setPreviewHtmlDoc] = useState<string | null>(null);
  const [terminalCmd, setTerminalCmd] = useState("");
  const [terminalLines, setTerminalLines] = useState<TerminalLine[]>([
    {
      id: "boot-1",
      kind: "info",
      text: "تم تهيئة محرر الأكواد السري (بيئة بدون روت) — اختر ملفاً واضغط «تشغيل الاختبار».",
    },
  ]);

  const activeFile = useMemo(
    () => files.find((f) => f.id === activeFileId) || files[0],
    [files, activeFileId]
  );

  // Load external/extension file cleanly when invoked from Floating Dashboard
  useEffect(() => {
    if (!initialFileToLoad || !isOpen) return;
    setFiles((prev) => {
      const existing = prev.find((f) => f.name === initialFileToLoad.name);
      if (existing) {
        setActiveFileId(existing.id);
        return prev.map((f) =>
          f.id === existing.id ? { ...f, content: initialFileToLoad.content } : f
        );
      }
      const added: WorkspaceFile = {
        id: `ws-ext-${Date.now()}`,
        name: initialFileToLoad.name,
        language: inferLanguage(initialFileToLoad.name),
        content: initialFileToLoad.content,
      };
      setActiveFileId(added.id);
      return [added, ...prev];
    });
  }, [initialFileToLoad, isOpen]);

  // Listen for sandbox iframe console messages
  useEffect(() => {
    const onMessage = (event: MessageEvent) => {
      if (event.data?.source !== "iraqi-secret-ide") return;
      const level = (event.data.level || "log") as TerminalLine["kind"];
      setTerminalLines((prev) => [
        ...prev.slice(-60),
        {
          id: `${Date.now()}-${Math.random()}`,
          kind: level,
          text: String(event.data.text || ""),
        },
      ]);
    };
    window.addEventListener("message", onMessage);
    return () => window.removeEventListener("message", onMessage);
  }, []);

  if (!isOpen) return null;

  const appendTerminal = (kind: TerminalLine["kind"], text: string) => {
    setTerminalLines((prev) => [
      ...prev.slice(-60),
      { id: `${Date.now()}-${Math.random()}`, kind, text },
    ]);
  };

  const handleUpdateContent = (nextContent: string) => {
    if (!activeFile) return;
    setFiles((prev) =>
      prev.map((f) =>
        f.id === activeFile.id ? { ...f, content: nextContent } : f
      )
    );
  };

  const handleRunActiveFile = () => {
    if (!activeFile) return;
    const t0 = performance.now();
    appendTerminal("info", `> تشغيل ${activeFile.name} (${activeFile.language})...`);

    if (activeFile.language === "json") {
      try {
        const parsed = JSON.parse(activeFile.content) as Record<string, unknown>;
        const keys = Object.keys(parsed);
        appendTerminal(
          "success",
          `ملف JSON صحيح (المفاتيح الرئيسية: ${keys.join(", ")}) — ${(
            performance.now() - t0
          ).toFixed(2)}ms`
        );
      } catch (err) {
        appendTerminal(
          "error",
          `خطأ صياغة JSON: ${err instanceof Error ? err.message : String(err)}`
        );
      }
      setPreviewHtmlDoc(null);
      return;
    }

    if (activeFile.language === "luau") {
      const fnMatches = activeFile.content.match(/\bfunction\s+[a-zA-Z0-9_.:]+/g) || [];
      const services = activeFile.content.match(/GetService\(["']([^"']+)["']\)/g) || [];
      const prints = Array.from(
        activeFile.content.matchAll(/print\(([^)]+)\)/g)
      ).map((m) => m[1]);
      appendTerminal(
        "success",
        `تحليل Luau ناجح: ${fnMatches.length} دالة · ${services.length} خدمة Roblox.`
      );
      prints.forEach((p) => appendTerminal("log", `[Luau Output] ${p}`));
      setPreviewHtmlDoc(null);
      return;
    }

    if (activeFile.language === "css") {
      const ruleCount = (activeFile.content.match(/\{[^}]*\}/g) || []).length;
      appendTerminal("success", `تم فحص ملف CSS بنجاح (${ruleCount} قاعدة تنسيق).`);
      setPreviewHtmlDoc(null);
      return;
    }

    if (activeFile.language === "html") {
      const consoleBridge = `<script>(function(){const s=(l,a)=>{try{window.parent.postMessage({source:'iraqi-secret-ide',level:l,text:a.map(x=>typeof x==='object'?JSON.stringify(x):String(x)).join(' ')},'*')}catch(e){}};const o=console.log;console.log=(...a)=>{s('log',a);o.apply(console,a)};window.onerror=(m)=>s('error',[m])})();</script>`;
      const doc = activeFile.content.includes("</head>")
        ? activeFile.content.replace("</head>", `${consoleBridge}</head>`)
        : `${consoleBridge}${activeFile.content}`;
      setPreviewHtmlDoc(doc);
      appendTerminal("success", "تم فتح المعاينة التفاعلية للواجهة بنجاح.");
      return;
    }

    // JavaScript Sandbox Execution inside ephemeral iframe
    setPreviewHtmlDoc(`<!doctype html><html><head><meta charset="UTF-8"><style>body{margin:0;padding:12px;background:#070b14;color:#94a3b8;font-family:monospace;font-size:12px}</style></head><body><div id="stage">Sandbox Active (${activeFile.name})</div><script>
      (function(){
        const post=(level,args)=>{try{window.parent.postMessage({source:'iraqi-secret-ide',level,text:args.map(a=>typeof a==='object'?JSON.stringify(a):String(a)).join(' ')},'*')}catch(e){}};
        console.log=(...a)=>post('log',a);
        console.warn=(...a)=>post('warn',a);
        console.error=(...a)=>post('error',a);
        try{
          ${activeFile.content}
          post('success',['تم التنفيذ بنجاح داخل البيئة الآمنة.']);
        }catch(err){
          post('error',[err&&err.message?err.message:String(err)]);
        }
      })();
    </script></body></html>`);
  };

  const handleLoadEmbeddedFile = (name: string, content: string) => {
    setFiles((prev) => {
      const existing = prev.find((f) => f.name === name);
      if (existing) {
        setActiveFileId(existing.id);
        return prev;
      }
      const nextFile: WorkspaceFile = {
        id: `ws-emb-${name}`,
        name,
        language: inferLanguage(name),
        content,
      };
      setActiveFileId(nextFile.id);
      return [...prev, nextFile];
    });
    appendTerminal("info", `تم تحميل ملف النواة المدمج: ${name}`);
  };

  const handleCreateNewFile = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = newFileName.trim() || `script_${files.length + 1}.js`;
    const created: WorkspaceFile = {
      id: `ws-${Date.now()}`,
      name: cleanName,
      language: inferLanguage(cleanName),
      content:
        cleanName.endsWith(".json")
          ? '{\n  "name": "iraqi-script",\n  "version": "1.0.0"\n}'
          : cleanName.endsWith(".html")
          ? "<!doctype html>\n<html lang=\"ar\" dir=\"rtl\">\n<body>\n  <h2>مشروع جديد</h2>\n</body>\n</html>"
          : `// ${cleanName}\nconsole.log("مرحباً من محرر الأكواد السري!");`,
    };
    setFiles((prev) => [...prev, created]);
    setActiveFileId(created.id);
    setNewFileName("");
    setShowNewFileInput(false);
  };

  const handleDeleteWorkspaceFile = (id: string) => {
    if (files.length <= 1) return;
    setFiles((prev) => {
      const next = prev.filter((f) => f.id !== id);
      if (activeFileId === id && next[0]) {
        setActiveFileId(next[0].id);
      }
      return next;
    });
  };

  const handleTerminalCommand = (e: React.FormEvent) => {
    e.preventDefault();
    const raw = terminalCmd.trim();
    if (!raw) return;
    setTerminalCmd("");
    appendTerminal("info", `$ ${raw}`);

    if (raw === "clear") {
      setTerminalLines([]);
      return;
    }
    if (raw === "run") {
      handleRunActiveFile();
      return;
    }
    if (raw === "help") {
      appendTerminal(
        "log",
        "الأوامر المتاحة: run (تشغيل الملف الحالي) · clear (مسح الطرفية) · files (قائمة الملفات) · status (حالة البيئة بدون روت)"
      );
      return;
    }
    if (raw === "files") {
      appendTerminal("log", files.map((f) => f.name).join(" | "));
      return;
    }
    if (raw === "status") {
      appendTerminal(
        "success",
        "بيئة البرمجة بدون روت فعّالة · نواة الـ 6 ملفات متصلة · Sandbox Ready"
      );
      return;
    }
    appendTerminal("warn", `أمر غير معروف: ${raw} — اكتب help لعرض الأوامر.`);
  };

  const handleDownloadActiveFile = () => {
    if (!activeFile) return;
    const blob = new Blob([activeFile.content], {
      type: "text/plain;charset=utf-8",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = activeFile.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    onShowToast(`تم تنزيل الملف: ${activeFile.name}`);
  };

  const handleSaveToDataCenter = () => {
    if (!activeFile) return;
    const item: CloudFileItem = {
      id: `cloud-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      ownerId: user?.id || "local-guest-dev",
      ownerName: user?.name || "مطور عراقي كودرز",
      ownerHandle: user?.handle || "@iraqi_dev",
      title: `مشروع محرر السري: ${activeFile.name}`,
      description: "تم بناؤه واختباره عبر محرر الأكواد السري (بيئة بدون روت).",
      fileName: activeFile.name,
      fileType: activeFile.language === "html" ? "web" : "code",
      fileSizeBytes: new Blob([activeFile.content]).size,
      content: activeFile.content,
      visibility: "private",
      downloads: 0,
      createdAt: "الآن",
    };
    onSaveToDataCenter(item);
    appendTerminal("success", `تم حفظ «${activeFile.name}» في مركز البيانات بنجاح!`);
  };

  const handleCopyCode = async () => {
    if (!activeFile) return;
    try {
      await navigator.clipboard.writeText(activeFile.content);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      // Safe no-op
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="secret-ide-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-2 sm:p-4 backdrop-blur-md"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="flex h-[92vh] w-full max-w-6xl flex-col overflow-hidden rounded-2xl border border-sky-400/40 bg-[#080D18] shadow-2xl"
      >
        {/* Top IDE Header */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 bg-[#0D1426] px-4 py-3">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl border border-sky-400/40 bg-sky-500/15 text-sky-300">
              <Code2 className="h-5 w-5" />
            </div>
            <div>
              <h2
                id="secret-ide-title"
                className="text-sm sm:text-base font-extrabold text-white"
              >
                محرر الأكواد السري (بيئة البرمجة بدون روت)
              </h2>
              <p className="text-[11px] text-slate-400">
                بناء واختبار السكربتات، البوتات، ومشاريع الويب وملفات الإضافة الـ 6 مباشرة
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={handleRunActiveFile}
              className="inline-flex items-center gap-1.5 rounded-xl bg-emerald-600 px-3.5 py-2 text-xs font-extrabold text-white hover:bg-emerald-500 cursor-pointer"
            >
              <Play className="h-3.5 w-3.5" />
              <span>تشغيل الاختبار</span>
            </button>
            <button
              type="button"
              onClick={handleSaveToDataCenter}
              className="inline-flex items-center gap-1.5 rounded-xl border border-sky-400/40 bg-sky-500/15 px-3 py-2 text-xs font-extrabold text-sky-200 hover:bg-sky-500/25 cursor-pointer"
            >
              <CloudUpload className="h-3.5 w-3.5" />
              <span>حفظ في مركز البيانات</span>
            </button>
            <button
              type="button"
              onClick={handleDownloadActiveFile}
              className="inline-flex items-center gap-1.5 rounded-xl border border-white/15 bg-white/5 px-3 py-2 text-xs font-bold text-slate-200 hover:bg-white/10 cursor-pointer"
            >
              <Download className="h-3.5 w-3.5" />
              <span>تصدير</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              aria-label="إغلاق محرر الأكواد السري"
              className="inline-flex h-9 w-9 items-center justify-center rounded-xl border border-rose-500/35 bg-rose-500/10 text-rose-300 hover:bg-rose-500/20 cursor-pointer"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Main IDE Split Grid */}
        <div className="grid flex-1 grid-cols-1 overflow-hidden lg:grid-cols-12">
          {/* File Explorer Sidebar */}
          <aside className="flex flex-col border-b border-white/10 bg-[#0B1120] p-3 lg:col-span-3 lg:border-b-0 lg:border-l overflow-y-auto space-y-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="inline-flex items-center gap-1.5 text-xs font-extrabold text-slate-200">
                  <FolderOpen className="h-3.5 w-3.5 text-sky-400" />
                  <span>ملفات مساحة العمل</span>
                </span>
                <button
                  type="button"
                  onClick={() => setShowNewFileInput((p) => !p)}
                  className="inline-flex items-center gap-1 rounded-lg border border-sky-400/35 bg-sky-500/10 px-2 py-1 text-[11px] font-bold text-sky-300 hover:bg-sky-500/20 cursor-pointer"
                >
                  <Plus className="h-3 w-3" />
                  <span>جديد</span>
                </button>
              </div>

              {showNewFileInput && (
                <form
                  onSubmit={handleCreateNewFile}
                  className="flex items-center gap-1.5"
                >
                  <input
                    type="text"
                    dir="ltr"
                    value={newFileName}
                    onChange={(e) => setNewFileName(e.target.value)}
                    placeholder="my_bot.js"
                    className="h-8 flex-1 rounded-lg border border-white/15 bg-[#070B14] px-2 font-mono text-xs text-white focus:border-sky-400 focus:outline-none"
                  />
                  <button
                    type="submit"
                    className="h-8 rounded-lg bg-sky-600 px-2.5 text-[11px] font-bold text-white cursor-pointer"
                  >
                    إنشاء
                  </button>
                </form>
              )}

              <div className="space-y-1">
                {files.map((f) => (
                  <div
                    key={f.id}
                    className={`flex items-center justify-between gap-2 rounded-lg px-2.5 py-2 text-xs transition-colors ${
                      f.id === activeFile?.id
                        ? "border border-sky-400/45 bg-sky-500/15 text-white"
                        : "text-slate-300 hover:bg-white/5"
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => setActiveFileId(f.id)}
                      className="flex flex-1 items-center gap-2 text-left font-mono truncate cursor-pointer"
                      dir="ltr"
                    >
                      <FileCode2 className="h-3.5 w-3.5 shrink-0 text-sky-400" />
                      <span className="truncate">{f.name}</span>
                    </button>
                    {files.length > 1 && (
                      <button
                        type="button"
                        onClick={() => handleDeleteWorkspaceFile(f.id)}
                        aria-label={`حذف ${f.name}`}
                        className="text-slate-500 hover:text-rose-400 cursor-pointer"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Embedded 6-File Core Shortcuts */}
            <div className="border-t border-white/10 pt-3 space-y-2">
              <p className="inline-flex items-center gap-1.5 text-[11px] font-extrabold text-emerald-300">
                <Puzzle className="h-3.5 w-3.5" />
                <span>ملفات نواة الإضافة الـ 6</span>
              </p>
              <div className="grid grid-cols-2 gap-1.5">
                {EMBEDDED_EXTENSION_FILES.map((extFile) => (
                  <button
                    key={extFile.path}
                    type="button"
                    dir="ltr"
                    onClick={() =>
                      handleLoadEmbeddedFile(extFile.path, extFile.content)
                    }
                    className="truncate rounded-lg border border-white/10 bg-[#070B14] px-2 py-1.5 text-left font-mono text-[11px] text-slate-300 hover:border-emerald-400/45 hover:text-emerald-200 cursor-pointer"
                  >
                    {extFile.path}
                  </button>
                ))}
              </div>
            </div>
          </aside>

          {/* Code Editor + Live Terminal/Preview */}
          <div className="flex flex-col overflow-hidden lg:col-span-9">
            {/* Active File Bar */}
            <div className="flex items-center justify-between border-b border-white/10 bg-[#0A101D] px-4 py-2 text-xs">
              <div className="flex items-center gap-2">
                <span dir="ltr" className="font-mono font-bold text-sky-300">
                  {activeFile?.name}
                </span>
                <span className="text-slate-500">·</span>
                <span className="font-mono text-[11px] text-slate-400">
                  {activeFile?.content.split("\n").length} أسطر
                </span>
              </div>

              <button
                type="button"
                onClick={() => void handleCopyCode()}
                className="inline-flex items-center gap-1 rounded-lg border border-white/10 bg-white/5 px-2.5 py-1 text-[11px] font-bold text-slate-300 hover:text-white cursor-pointer"
              >
                {copied ? (
                  <>
                    <Check className="h-3 w-3 text-emerald-400" />
                    <span>تم النسخ</span>
                  </>
                ) : (
                  <>
                    <Copy className="h-3 w-3" />
                    <span>نسخ الكود</span>
                  </>
                )}
              </button>
            </div>

            {/* Editor & Sandbox Split */}
            <div className="flex-1 grid grid-cols-1 md:grid-cols-12 overflow-hidden">
              <textarea
                dir="ltr"
                spellCheck={false}
                value={activeFile?.content || ""}
                onChange={(e) => handleUpdateContent(e.target.value)}
                aria-label="محرر الأكواد السري"
                className={`h-full w-full resize-none bg-[#060A12] p-4 font-mono text-[13px] leading-6 text-slate-100 focus:outline-none ${
                  previewHtmlDoc ? "md:col-span-7" : "md:col-span-12"
                }`}
              />

              {previewHtmlDoc && (
                <div className="md:col-span-5 border-t md:border-t-0 md:border-r border-white/10 bg-[#070B14] flex flex-col">
                  <div className="flex items-center justify-between border-b border-white/10 px-3 py-1.5 text-[11px] font-bold text-slate-300">
                    <span>معاينة التشغيل الحي</span>
                    <button
                      type="button"
                      onClick={() => setPreviewHtmlDoc(null)}
                      className="text-slate-400 hover:text-white cursor-pointer"
                    >
                      إخفاء
                    </button>
                  </div>
                  <iframe
                    title="معاينة محرر الأكواد السري"
                    sandbox="allow-scripts"
                    srcDoc={previewHtmlDoc}
                    className="flex-1 w-full border-0 bg-[#070B14]"
                  />
                </div>
              )}
            </div>

            {/* Interactive No-Root Terminal Console */}
            <div className="border-t border-white/10 bg-[#050810] p-3 space-y-2">
              <div className="flex items-center justify-between text-[11px] text-slate-400">
                <span className="inline-flex items-center gap-1.5 font-extrabold text-emerald-300">
                  <Terminal className="h-3.5 w-3.5" />
                  <span>طرفية التنفيذ بدون روت (Console)</span>
                </span>
                <button
                  type="button"
                  onClick={() => setTerminalLines([])}
                  className="hover:text-white cursor-pointer"
                >
                  مسح المخرجات
                </button>
              </div>

              <div
                dir="ltr"
                className="h-28 overflow-y-auto rounded-lg border border-white/5 bg-[#03050A] p-2.5 font-mono text-xs space-y-1"
              >
                {terminalLines.map((line) => (
                  <div
                    key={line.id}
                    className={
                      line.kind === "error"
                        ? "text-rose-400"
                        : line.kind === "warn"
                        ? "text-amber-300"
                        : line.kind === "success"
                        ? "text-emerald-300"
                        : line.kind === "info"
                        ? "text-sky-300"
                        : "text-slate-200"
                    }
                  >
                    {line.text}
                  </div>
                ))}
              </div>

              <form
                onSubmit={handleTerminalCommand}
                className="flex items-center gap-2"
                dir="ltr"
              >
                <span className="font-mono text-xs font-bold text-emerald-400">
                  $
                </span>
                <input
                  type="text"
                  value={terminalCmd}
                  onChange={(e) => setTerminalCmd(e.target.value)}
                  placeholder="run | files | status | clear | help"
                  className="h-8 flex-1 rounded-lg border border-white/10 bg-[#0B101D] px-3 font-mono text-xs text-white placeholder:text-slate-500 focus:border-emerald-400 focus:outline-none"
                />
                <button
                  type="submit"
                  className="h-8 rounded-lg border border-emerald-400/40 bg-emerald-600/20 px-3 text-xs font-bold text-emerald-200 hover:bg-emerald-600/35 cursor-pointer"
                >
                  تنفيذ
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
