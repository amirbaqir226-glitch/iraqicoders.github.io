import React, { useEffect, useRef, useState } from "react";
import { BookOpen, Compass, Moon, Sparkles, Volume2, VolumeX, X } from "lucide-react";
import {
  speakArabicText,
  startSnoringSound,
  stopArabicSpeech,
  stopSnoringSound,
} from "../services/speechEngine";

interface SleepingRobotTopWidgetProps {
  onJumpToSection: (sectionId: string) => void;
}

type WakeOutcome = "none" | "sleep" | "story" | "full-tour";

const IRAQI_STORIES_AND_JOKES = [
  "كان يا ما كان في مختبر بغداد مبرمج نسي فاصلة منقوطة الساعة 2 بالليل، فقرر الخادم أن يكتب له بيت شعر عراقي بدل الخطأ، ومن يومها صار يراجع الكود قبل أن ينام!",
  "نكتة مبرمجين: سألوا المبرمج العراقي شلون تنام؟ كال أعد الأخطاء البرمجية من 1 إلى 1024 وإذا خلصت أسوي Restart للأحلام!",
  "قصة قصيرة: طالب عراقي بنى أول لعبة مصغرة على موقع عراقي كودرز خلال استراحة المدرسة، واليوم أصحابه يتنافسون على تحطيم رقمه القياسي!",
];

export const SleepingRobotTopWidget: React.FC<SleepingRobotTopWidgetProps> = ({
  onJumpToSection,
}) => {
  const [isSnoring, setIsSnoring] = useState(false);
  const [isAwake, setIsAwake] = useState(false);
  const [repliedByUser, setRepliedByUser] = useState(false);
  const [outcome, setOutcome] = useState<WakeOutcome>("none");
  const [storyText, setStoryText] = useState("");
  const [tourStep, setTourStep] = useState(0);

  const pressTimerRef = useRef<number | null>(null);
  const longPressTriggeredRef = useRef(false);

  useEffect(() => {
    return () => {
      stopSnoringSound();
      if (pressTimerRef.current) window.clearTimeout(pressTimerRef.current);
    };
  }, []);

  const wakeRobotNow = () => {
    stopSnoringSound();
    setIsSnoring(false);
    setIsAwake(true);
    setRepliedByUser(false);
    setOutcome("none");
    speakArabicText("الجاي يصير؟ أني وين؟ هل أنا بحلم؟", {
      voiceProfile: "robot-male",
      pitch: 1.04,
      rate: 0.96,
    });
  };

  const handlePointerDown = () => {
    longPressTriggeredRef.current = false;
    if (pressTimerRef.current) window.clearTimeout(pressTimerRef.current);
    pressTimerRef.current = window.setTimeout(() => {
      longPressTriggeredRef.current = true;
      wakeRobotNow();
    }, 620);
  };

  const handlePointerUpOrLeave = () => {
    if (pressTimerRef.current) {
      window.clearTimeout(pressTimerRef.current);
      pressTimerRef.current = null;
    }
  };

  const handleNormalClick = () => {
    if (longPressTriggeredRef.current) return;
    if (isSnoring) {
      stopSnoringSound();
      setIsSnoring(false);
    } else if (!isAwake) {
      startSnoringSound();
      setIsSnoring(true);
    }
  };

  const triggerOutcome = (mode: "weighted-random" | "sleep" | "story" | "full-tour") => {
    let chosen: WakeOutcome = "sleep";
    if (mode === "weighted-random") {
      // Exact probability weights: 1% full site explanation, ~49% story, ~50% go back to sleep
      const roll = Math.random() * 100;
      if (roll < 1) {
        chosen = "full-tour";
      } else if (roll < 50) {
        chosen = "story";
      } else {
        chosen = "sleep";
      }
    } else {
      chosen = mode;
    }

    setOutcome(chosen);
    setRepliedByUser(true);

    if (chosen === "sleep") {
      speakArabicText("آسف بس أريد أكمل نوم... تصبح على خير.", {
        voiceProfile: "robot-male",
        rate: 0.88,
      });
      window.setTimeout(() => {
        setIsAwake(false);
        setOutcome("none");
        setRepliedByUser(false);
      }, 2800);
    } else if (chosen === "story") {
      const picked =
        IRAQI_STORIES_AND_JOKES[
          Math.floor(Math.random() * IRAQI_STORIES_AND_JOKES.length)
        ];
      setStoryText(picked);
      speakArabicText(`أوكي راح أقرأ لك قصة: ${picked}`, {
        voiceProfile: "robot-male",
      });
    } else if (chosen === "full-tour") {
      setTourStep(0);
      speakArabicText(
        "مفاجأة الـ 1 بالمية! راح أشرح لك على الموقع كاملاً من الطول للطول: نبدأ من قسم التحديات واستوديو انشئ كل شيء والمتجر والسحابة والنسخة التجريبية!",
        { voiceProfile: "robot-male" }
      );
    }
  };

  const FULL_TOUR_STEPS = [
    {
      title: "1. الهيدر والوصول السريع",
      desc: "يحتوي على زر Talk to Iraqi Bots، التحقق من الرسائل وصوت الشبكة، تبديل الموبايل وسطح المكتب، الإضافة وزر «تجريبية»، السلة، والمتجر السحابي.",
      target: "hero",
    },
    {
      title: "2. قسم التحديات التفاعلي",
      desc: "ينشئ فيه المطورون والمدراء والمسؤولون أسئلة برمجية بأزرار خضراء وحمراء مع تعليقات الحلول.",
      target: "challenges",
    },
    {
      title: "3. استوديو انشئ كل شيء والمتجر",
      desc: "تصميم مواقع، تطبيقات APK، ألعاب 2D و API بالذكاء الاصطناعي مع سلة بيع وشراء ونظام إخفاء الإعلانات.",
      target: "omni-studio",
    },
    {
      title: "4. بيئة تجريبية والمبرمج وعالم الخيال",
      desc: "محرر لغات Python و Java و Luau مع ختم Iraqi Coders  1329 وتصدير .krok وتحديث مدرسة ميسون للبنين.",
      target: "beta-hub",
    },
  ];

  return (
    <div className="border-b border-white/10 bg-[#090E1A]/90 px-3 py-2.5 sm:px-6">
      <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3">
        {/* Sleeping Robot on Mini Bed Trigger */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={handleNormalClick}
            onPointerDown={handlePointerDown}
            onPointerUp={handlePointerUpOrLeave}
            onPointerLeave={handlePointerUpOrLeave}
            onPointerCancel={handlePointerUpOrLeave}
            data-guide-hint="هذا الروبوت النائم على سريره الصغير! انقر نقرة عادية لتشغيل أو إيقاف الشخير، واضغط مطولاً لإيقاظه."
            className="group relative flex items-center gap-3 rounded-2xl border border-indigo-400/35 bg-[#10182E] px-3.5 py-2 text-right transition-all hover:border-indigo-400/70 select-none cursor-pointer"
          >
            {/* Mini Bed + Robot SVG */}
            <svg viewBox="0 0 88 52" className="h-11 w-16 shrink-0" aria-hidden="true">
              {/* Bed Frame & Legs */}
              <rect x="6" y="34" width="76" height="9" rx="3" fill="#475569" />
              <rect x="9" y="42" width="6" height="8" rx="2" fill="#334155" />
              <rect x="73" y="42" width="6" height="8" rx="2" fill="#334155" />
              {/* Pillow */}
              <rect x="10" y="25" width="18" height="9" rx="4" fill="#E2E8F0" />
              {/* Sleeping Robot Head & Antenna */}
              <line x1="20" y1="12" x2="20" y2="17" stroke="#38BDF8" strokeWidth="2" />
              <circle cx="20" cy="10" r="2.5" fill={isAwake ? "#34D399" : "#F59E0B"} />
              <rect x="12" y="16" width="16" height="12" rx="4" fill="#64748B" stroke="#94A3B8" strokeWidth="1.2" />
              {/* Eyes: closed sleeping arcs vs awake bright circles */}
              {isAwake ? (
                <>
                  <circle cx="17" cy="22" r="2" fill="#34D399" />
                  <circle cx="23" cy="22" r="2" fill="#34D399" />
                </>
              ) : (
                <>
                  <path d="M15 22 Q17 24 19 22" stroke="#0F172A" strokeWidth="1.5" fill="none" />
                  <path d="M21 22 Q23 24 25 22" stroke="#0F172A" strokeWidth="1.5" fill="none" />
                </>
              )}
              {/* Blanket */}
              <path
                d="M28 24 C42 22, 68 23, 78 27 L78 35 L28 35 Z"
                fill="#7C3AED"
              />
              <path d="M28 24 L42 24 L42 35 L28 35 Z" fill="#A78BFA" />
            </svg>

            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-extrabold text-white">
                  {isAwake ? "الروبوت استيقظ!" : "الروبوت نائم على سريره الصغير"}
                </span>
                {!isAwake && (
                  <span className="inline-flex items-center gap-1 rounded-md border border-indigo-400/35 bg-indigo-500/15 px-1.5 py-0.5 font-mono text-[10px] font-bold text-indigo-200">
                    <Moon className="h-3 w-3" />
                    <span>{isSnoring ? "Zzz شخير" : "هدوء"}</span>
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-400">
                انقر {isSnoring ? "لإيقاف الشخير" : "لسماع الشخير"} ·{" "}
                <span className="text-amber-300 font-bold">
                  اضغط مطولاً لإيقاظه
                </span>
              </p>
            </div>
          </button>

          {!isAwake && (
            <button
              type="button"
              onClick={handleNormalClick}
              className={`hidden sm:inline-flex items-center gap-1.5 rounded-xl border px-3 py-2 text-[11px] font-bold cursor-pointer ${
                isSnoring
                  ? "border-amber-400/45 bg-amber-500/15 text-amber-200"
                  : "border-white/10 bg-white/5 text-slate-300 hover:text-white"
              }`}
            >
              {isSnoring ? (
                <>
                  <VolumeX className="h-3.5 w-3.5" />
                  <span>إيقاف صوت الشخير</span>
                </>
              ) : (
                <>
                  <Volume2 className="h-3.5 w-3.5" />
                  <span>صوت الشخير</span>
                </>
              )}
            </button>
          )}
        </div>

        {/* Direct Quick Wake Button for Keyboard Accessibility */}
        {!isAwake && (
          <button
            type="button"
            onClick={wakeRobotNow}
            className="rounded-xl border border-violet-400/35 bg-violet-600/15 px-3 py-1.5 text-[11px] font-bold text-violet-200 hover:bg-violet-600/25 cursor-pointer"
          >
            إيقاظ الروبوت الآن
          </button>
        )}
      </div>

      {/* Wake-up Interactive Dialogue Drawer */}
      {isAwake && (
        <div className="mx-auto mt-3 max-w-7xl rounded-2xl border border-amber-400/40 bg-[#0E1528] p-4 shadow-xl space-y-3">
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="text-xs font-bold text-amber-300">
                الروبوت الصغير (مندهش للتو من النوم):
              </p>
              <h3 className="text-base font-extrabold text-white mt-0.5">
                «الجاي يصير؟ أني وين؟ هل أنا بحلم؟»
              </h3>
            </div>
            <button
              type="button"
              onClick={() => {
                stopArabicSpeech();
                setIsAwake(false);
                setOutcome("none");
              }}
              aria-label="إغلاق حوار الروبوت"
              className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-white/10 bg-white/5 text-slate-300 hover:text-white cursor-pointer"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          {!repliedByUser ? (
            <div className="space-y-2.5">
              <button
                type="button"
                onClick={() => triggerOutcome("weighted-random")}
                className="w-full rounded-xl border border-emerald-400/45 bg-emerald-500/15 px-4 py-3 text-right text-xs font-extrabold text-emerald-200 transition-colors hover:bg-emerald-500/25 cursor-pointer"
              >
                ردك: «لا حبيبي انت مو حلم بس انا قعدتك بالغلط وتقدر ترجع تنام أو تسولف لي شلون يعني الموقع أو تعطيني نكتة أو حاجة» (فرصة عشوائية)
              </button>

              <div className="grid grid-cols-1 gap-2 sm:grid-cols-3 text-[11px]">
                <button
                  type="button"
                  onClick={() => triggerOutcome("sleep")}
                  className="rounded-xl border border-slate-500/35 bg-white/5 px-3 py-2 font-bold text-slate-200 hover:bg-white/10 cursor-pointer"
                >
                  😴 آسف بس أريد أكمل نوم (100%)
                </button>
                <button
                  type="button"
                  onClick={() => triggerOutcome("story")}
                  className="rounded-xl border border-sky-400/35 bg-sky-500/15 px-3 py-2 font-bold text-sky-200 hover:bg-sky-500/25 cursor-pointer"
                >
                  📖 أوكي راح أقرأ لك قصة أو نكتة (100%)
                </button>
                <button
                  type="button"
                  onClick={() => triggerOutcome("full-tour")}
                  className="rounded-xl border border-amber-400/45 bg-amber-500/15 px-3 py-2 font-bold text-amber-200 hover:bg-amber-500/25 cursor-pointer"
                >
                  🌟 شرح الموقع من الطول للطول (حظ 1%)
                </button>
              </div>
            </div>
          ) : outcome === "sleep" ? (
            <div className="rounded-xl border border-indigo-400/35 bg-indigo-950/40 p-3 text-xs font-bold text-indigo-200">
              😴 «آسف بس أريد أكمل نوم...» — سيعود الروبوت للنوم على سريره خلال ثوانٍ.
            </div>
          ) : outcome === "story" ? (
            <div className="rounded-xl border border-sky-400/35 bg-sky-950/35 p-3.5 space-y-2">
              <div className="flex items-center gap-2 text-xs font-extrabold text-sky-300">
                <BookOpen className="h-4 w-4" />
                <span>«أوكي راح أقرأ لك قصة / نكتة:»</span>
              </div>
              <p className="text-xs leading-relaxed text-slate-100">{storyText}</p>
              <button
                type="button"
                onClick={() => triggerOutcome("story")}
                className="rounded-lg bg-sky-600 px-3 py-1.5 text-[11px] font-bold text-white hover:bg-sky-500 cursor-pointer"
              >
                قصة أو نكتة ثانية
              </button>
            </div>
          ) : (
            <div className="rounded-xl border border-emerald-400/45 bg-emerald-950/35 p-4 space-y-3">
              <div className="flex items-center justify-between gap-2">
                <span className="inline-flex items-center gap-1.5 text-xs font-extrabold text-emerald-300">
                  <Sparkles className="h-4 w-4" />
                  <span>حصلت على شرح الـ 1%! «راح أشرح لك على الموقع كاملاً من الطول للطول»</span>
                </span>
                <span className="font-mono text-[11px] text-emerald-200 tabular-nums">
                  {tourStep + 1} / {FULL_TOUR_STEPS.length}
                </span>
              </div>

              <div className="rounded-xl border border-white/10 bg-[#080C15] p-3">
                <p className="text-xs font-extrabold text-white">
                  {FULL_TOUR_STEPS[tourStep].title}
                </p>
                <p className="text-xs text-slate-300 mt-1">
                  {FULL_TOUR_STEPS[tourStep].desc}
                </p>
              </div>

              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() => onJumpToSection(FULL_TOUR_STEPS[tourStep].target)}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-emerald-500 cursor-pointer"
                >
                  <Compass className="h-3.5 w-3.5" />
                  <span>انتقل لهذا القسم</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const next = (tourStep + 1) % FULL_TOUR_STEPS.length;
                    setTourStep(next);
                    speakArabicText(
                      `${FULL_TOUR_STEPS[next].title}. ${FULL_TOUR_STEPS[next].desc}`,
                      { voiceProfile: "robot-male" }
                    );
                  }}
                  className="rounded-lg border border-white/15 bg-white/5 px-3 py-1.5 text-xs font-bold text-white hover:bg-white/10 cursor-pointer"
                >
                  المحطة التالية
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
