import React from "react";
import { ArrowUpLeft, Crown, Shield, SlidersHorizontal } from "lucide-react";
import { AD_SYSTEM_CONFIG, AdSlotConfig } from "../data/siteConfig";
import { AdVisibilityResult } from "../services/adManager";

interface AdBannerSlotProps {
  placement: AdSlotConfig["placement"];
  adVisibility: AdVisibilityResult;
  onOpenDnsSettings: () => void;
  onOpenVipUpgrade: () => void;
}

export const AdBannerSlot: React.FC<AdBannerSlotProps> = ({
  placement,
  adVisibility,
  onOpenDnsSettings,
  onOpenVipUpgrade,
}) => {
  // إذا كان المستخدم مستثنى (VIP أو مشرف أو تفعيل DNS من الإعدادات)، تختفي جميع المساحات الإعلانية بالكامل
  if (!adVisibility.shouldShowAds || !AD_SYSTEM_CONFIG.enabled) {
    return null;
  }

  const slot = AD_SYSTEM_CONFIG.slots.find((s) => s.placement === placement);
  if (!slot) return null;

  const isAccentViolet = slot.accent === "violet";

  return (
    <aside
      aria-label={`مساحة إعلانية - ${slot.networkLabel}`}
      data-ad-placement={slot.placement}
      data-ad-client={AD_SYSTEM_CONFIG.googleAdClient}
      data-ad-slot={slot.googleAdSlotId}
      className="border-b border-white/10 bg-[#090D16] py-5"
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div
          className={`rounded-2xl border p-4 sm:p-5 transition-colors ${
            isAccentViolet
              ? "border-violet-500/25 bg-[#0F1526]"
              : "border-white/10 bg-[#0E1424]"
          }`}
        >
          {/* Top Ad Metadata & Quick Hide Controls */}
          <div className="mb-3 flex flex-wrap items-center justify-between gap-2 border-b border-white/10 pb-2.5 text-[11px]">
            <div className="flex items-center gap-2 text-slate-400">
              <span className="font-bold text-slate-300">إعلان ممول</span>
              <span aria-hidden="true">·</span>
              <span>{slot.networkLabel}</span>
              <span aria-hidden="true">·</span>
              <span dir="ltr" className="font-mono text-slate-500">
                {slot.googleAdSlotId}
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={onOpenDnsSettings}
                className="inline-flex items-center gap-1 rounded-lg border border-sky-400/30 bg-sky-500/10 px-2.5 py-1 text-[11px] font-bold text-sky-300 transition-colors hover:bg-sky-500/20 cursor-pointer"
              >
                <SlidersHorizontal className="h-3 w-3" />
                <span>إخفاء عبر DNS الإعدادات</span>
              </button>

              <button
                type="button"
                onClick={onOpenVipUpgrade}
                className="inline-flex items-center gap-1 rounded-lg border border-amber-400/35 bg-amber-500/10 px-2.5 py-1 text-[11px] font-bold text-amber-300 transition-colors hover:bg-amber-500/20 cursor-pointer"
              >
                <Crown className="h-3 w-3" />
                <span>إزالة الإعلانات (VIP)</span>
              </button>
            </div>
          </div>

          {/* Responsive Ad Banner Content */}
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="space-y-1 min-w-0">
              <div className="flex items-center gap-2 text-xs font-bold text-emerald-400">
                <Shield className="h-3.5 w-3.5 shrink-0" />
                <span>{slot.sponsorName}</span>
              </div>
              <h3 className="text-sm sm:text-base font-extrabold text-white">
                {slot.headline}
              </h3>
              <p className="text-xs leading-relaxed text-slate-400 max-w-2xl">
                {slot.description}
              </p>
            </div>

            <a
              href={slot.ctaHref}
              target={slot.ctaExternal ? "_blank" : undefined}
              rel={slot.ctaExternal ? "noopener noreferrer" : undefined}
              className="inline-flex items-center justify-center gap-2 rounded-xl border border-emerald-400/40 bg-emerald-500/15 px-4 py-2.5 text-xs font-extrabold text-emerald-200 transition-colors hover:bg-emerald-500/25 whitespace-nowrap shrink-0"
            >
              <span>{slot.ctaLabel}</span>
              <ArrowUpLeft className="h-3.5 w-3.5" />
            </a>
          </div>
        </div>
      </div>
    </aside>
  );
};
