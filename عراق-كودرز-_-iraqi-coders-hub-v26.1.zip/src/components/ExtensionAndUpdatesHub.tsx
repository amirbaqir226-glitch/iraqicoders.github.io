import React, { useEffect, useRef, useState } from "react";
import {
  Archive,
  Check,
  CheckCircle2,
  Copy,
  Crown,
  Database,
  Download,
  ExternalLink,
  Eye,
  FileUp,
  Globe,
  Link2,
  Loader2,
  Lock,
  Play,
  Puzzle,
  RefreshCw,
  Rocket,
  ScanSearch,
  ShieldAlert,
  SlidersHorizontal,
  Sparkles,
  Trash2,
  Unlink,
  Upload,
  UserCheck,
  XCircle,
} from "lucide-react";
import { MEDIAFIRE_EXTENSION_URL } from "../config/firebase";
import { EMBEDDED_EXTENSION_FILES } from "../data/embeddedExtensionFiles";
import { unpackExtensionZip } from "../services/zipUnpacker";
import {
  ExtensionPairingSession,
  PlatformAiUpdate,
  PlatformUpdateVisibility,
  UnpackedExtensionPackage,
  UserProfile,
  UserRole,
} from "../types";

interface ExtensionAndUpdatesHubProps {
  user: UserProfile | null;
  userRole: UserRole;
  extensionMode: boolean;
  previewVersion: number;
  updates: PlatformAiUpdate[];
  isAdminPrivileged: boolean;
  pairingSession: ExtensionPairingSession | null;
  pairingLoading: boolean;
  activeFloatingExtension: UnpackedExtensionPackage | null;
  lazyBridgeOpenNonce: number;
  onGeneratePairing: () => Promise<void>;
  onScanAndPairFromScreen: (
    code: string,
    extensionName?: string
  ) => Promise<boolean>;
  onTriggerPairingRequest: (code: string, extensionName?: string) => Promise<void>;
  onConfirmPairingDecision: (allow: boolean) => Promise<void>;
  onUnlinkPairing: () => Promise<void>;
  onActivateFloatingExtension: (pkg: UnpackedExtensionPackage) => void;
  onTriggerAutoInjectCyberBridge: () => void;
  onOpenSecretCodeEditor: (initialFile?: {
    name: string;
    content: string;
  }) => void;
  onChangePreviewVersion: (nextVersion: number) => void;
  onToggleExtensionMode: (enabled: boolean) => void;
  onCreateUpdate: (update: PlatformAiUpdate) => void;
  onToggleVisibility: (
    updateId: string,
    visibility: PlatformUpdateVisibility
  ) => void;
  onDeleteUpdate: (updateId: string) => void;
  onExecuteUpdateAction: (update: PlatformAiUpdate) => void;
  onOpenDeveloperCategory: () => void;
  onOpenAdminRequest: () => void;
  onShowToast: (msg: string) => void;
}

const PROMPT_PRESETS = [
  "أضف أداة فحص سرعة استجابة الأكواد والمشاريع",
  "أضف لوحة اختصارات سريعة لمطوري ماينكرافت و Luau",
  "أضف شريط احتفال تفاعلي بمناسبة ترقية v999.9 المستقبلية",
];

export const ExtensionAndUpdatesHub: React.FC<
  ExtensionAndUpdatesHubProps
> = ({
  user,
  userRole,
  extensionMode,
  previewVersion,
  updates,
  isAdminPrivileged,
  pairingSession,
  pairingLoading,
  activeFloatingExtension,
  lazyBridgeOpenNonce,
  onGeneratePairing,
  onScanAndPairFromScreen,
  onTriggerPairingRequest,
  onConfirmPairingDecision,
  onUnlinkPairing,
  onActivateFloatingExtension,
  onTriggerAutoInjectCyberBridge,
  onOpenSecretCodeEditor,
  onChangePreviewVersion,
  onToggleExtensionMode,
  onCreateUpdate,
  onToggleVisibility,
  onDeleteUpdate,
  onExecuteUpdateAction,
  onOpenDeveloperCategory,
  onOpenAdminRequest,
  onShowToast,
}) => {
  const [manualPairCode, setManualPairCode] = useState("");
  const [domScanError, setDomScanError] = useState("");
  const [copiedCode, setCopiedCode] = useState(false);

  // "ما بيا حيل" Floating Bridge & ZIP Uploader state
  const [lazyBridgeOpen, setLazyBridgeOpen] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const [unpackingZip, setUnpackingZip] = useState(false);
  const [unpackError, setUnpackError] = useState("");
  const zipDropInputRef = useRef<HTMLInputElement>(null);

  const [aiPrompt, setAiPrompt] = useState("");
  const [aiGenerating, setAiGenerating] = useState(false);
  const [aiModelLabel, setAiModelLabel] = useState("gemini-4-hydrogen");

  const isSiteAdmin = userRole === "admin" || isAdminPrivileged;
  const isDevOrAdmin = userRole === "developer" || isSiteAdmin;

  useEffect(() => {
    if (lazyBridgeOpenNonce > 0) {
      setLazyBridgeOpen(true);
    }
  }, [lazyBridgeOpenNonce]);

  const handleCopyCode = async () => {
    if (!pairingSession?.code) return;
    try {
      await navigator.clipboard.writeText(pairingSession.code);
      setCopiedCode(true);
      window.setTimeout(() => setCopiedCode(false), 1800);
      onShowToast("تم نسخ رمز الاقتران!");
    } catch {
      // Safe no-op
    }
  };

  const handleDomScanPairSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const targetCode = manualPairCode.trim().toUpperCase();
    if (targetCode.length < 4) {
      setDomScanError("أدخل الرمز المعروض على الشاشة أولاً (مثال: IRAQI-CODE-777).");
      return;
    }
    setDomScanError("");
    const matched = await onScanAndPairFromScreen(
      targetCode,
      "إدارة عراقي كودرز"
    );
    if (!matched) {
      setDomScanError(
        `فشل فحص الشاشة أونلاين: الرمز «${targetCode}» غير مطابق لأي رمز معروض حياً على شاشة المنصة.`
      );
    }
  };

  const handleTriggerModalRequest = async () => {
    const targetCode = (manualPairCode || pairingSession?.code || "")
      .trim()
      .toUpperCase();
    if (targetCode.length < 4) {
      onShowToast("أدخل رمز الاقتران أولاً.");
      return;
    }
    setDomScanError("");
    await onTriggerPairingRequest(targetCode, "إدارة عراقي كودرز");
  };

  const processExtensionZipFile = async (file: File) => {
    if (!file.name.toLowerCase().endsWith(".zip")) {
      setUnpackError("يرجى اختيار ملف بامتداد .zip فقط.");
      return;
    }
    setUnpackError("");
    setUnpackingZip(true);
    try {
      const unpacked = await unpackExtensionZip(file);
      onActivateFloatingExtension(unpacked);
      onToggleExtensionMode(true);
      onShowToast(
        `تم فك ضغط «${unpacked.extensionName}» (${unpacked.files.length} ملف) وتثبيت الجسر العائم في أعلى الشاشة!`
      );
    } catch (err) {
      setUnpackError(
        err instanceof Error ? err.message : "تعذر فك ضغط ملف الـ ZIP."
      );
    } finally {
      setUnpackingZip(false);
    }
  };

  const handleZipFileInputChange = async (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    await processExtensionZipFile(file);
    e.target.value = "";
  };

  const handleDropZip = async (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setDragActive(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      await processExtensionZipFile(file);
    }
  };

  const handleGenerateAiUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isSiteAdmin) {
      onShowToast("مولّد التحديثات المباشرة مخصص لمدير الموقع فقط.");
      return;
    }
    const prompt = aiPrompt.trim();
    if (!prompt) {
      onShowToast("اكتب وصف الميزة التي تريد توليدها أولاً.");
      return;
    }

    setAiGenerating(true);
    const versionStr = previewVersion.toFixed(1);

    try {
      const res = await fetch("/api/gemini/generate-update", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt, targetVersion: versionStr }),
      });
      const data = (await res.json()) as {
        feature?: {
          title: string;
          description: string;
          badgeText: string;
          accentColor: "blue" | "emerald" | "violet" | "amber";
          featureType: "banner" | "widget" | "theme" | "tool";
          actionLabel: string;
          actionPayload: string;
        };
        model?: string;
        error?: string;
      };

      if (!res.ok || !data.feature) {
        onShowToast(data.error || "تعذر توليد التحديث.");
        return;
      }

      if (data.model) setAiModelLabel(data.model);

      const newUpdate: PlatformAiUpdate = {
        id: `upd-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        authorId: user?.id || "local-admin-dev",
        authorName: user?.name || "الإدارة",
        title: data.feature.title,
        description: data.feature.description,
        badgeText: data.feature.badgeText,
        accentColor: data.feature.accentColor,
        featureType: data.feature.featureType,
        actionLabel: data.feature.actionLabel,
        actionPayload: data.feature.actionPayload,
        targetVersion: versionStr,
        visibility: "private",
        createdAt: "الآن",
        isAiGenerated: true,
      };

      onCreateUpdate(newUpdate);
      setAiPrompt("");
      onShowToast(
        "تم توليد الميزة الجديدة! اختر «عام» لنشرها للجميع أو «خاص» لإبقائها لك."
      );
    } catch {
      onShowToast("حدث خطأ أثناء الاتصال بمولّد التحديثات.");
    } finally {
      setAiGenerating(false);
    }
  };

  const versionStr = previewVersion.toFixed(1);
  const isPaired = pairingSession?.status === "paired";
  const isRejected = pairingSession?.status === "rejected";
  const isPendingConfirm = pairingSession?.status === "pending_confirm";
  const isWaiting = pairingSession?.status === "waiting";

  return (
    <section
      id="extension-pairing"
      className="scroll-mt-24 border-b border-white/10 bg-[#0B0F19] py-14"
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 space-y-8">
        {/* Section Heading + Active Role Indicator */}
        <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
          <div>
            <p className="text-xs font-extrabold text-sky-400 mb-1.5">
              إضافة إدارة عراقي كودرز · الجسر العائم · نظام الرتب والصلاحيات
            </p>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
              مركز <span className="text-blue-400">اقتران</span> الإضافة والتحديثات الذكية
            </h2>
          </div>

          <div className="flex flex-wrap items-center gap-2 text-xs font-bold">
            <span
              className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 ${
                userRole === "admin"
                  ? "border-amber-400/50 bg-amber-500/15 text-amber-300"
                  : userRole === "developer"
                  ? "border-emerald-400/50 bg-emerald-500/15 text-emerald-300"
                  : "border-sky-400/40 bg-sky-500/10 text-sky-300"
              }`}
            >
              {userRole === "admin" ? (
                <Crown className="h-3.5 w-3.5" />
              ) : (
                <Puzzle className="h-3.5 w-3.5" />
              )}
              <span>
                {userRole === "admin"
                  ? isAdminPrivileged && user?.handle?.toLowerCase() === "@amirbaqir226"
                    ? "Master Admin: amirbaqir226 (Super-Admin + Dev)"
                    : "الرتبة: مدير / مشرف الموقع"
                  : userRole === "developer"
                  ? "الرتبة: مطور معتمد"
                  : "الرتبة: عضو (صلاحية قياسية + الجسر)"}
              </span>
            </span>

            <span className="inline-flex items-center gap-1.5 rounded-lg border border-white/10 bg-[#111827] px-3 py-1.5 text-slate-200">
              <span>الإضافة:</span>
              <span
                className={
                  extensionMode ? "text-emerald-300" : "text-slate-400"
                }
              >
                {extensionMode ? "متزامنة" : "متوقفة"}
              </span>
            </span>

            <span className="inline-flex items-center gap-1.5 rounded-lg border border-white/10 bg-[#111827] px-3 py-1.5 font-mono text-emerald-300 tabular-nums">
              v{versionStr}
            </span>
          </div>
        </div>

        {/* Ranks & Roles Info Strip for Standard Users (Full Bridge Access Active) */}
        {!isSiteAdmin && (
          <div className="flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-emerald-400/30 bg-[#101729] p-5">
            <div className="flex items-start gap-3">
              <UserCheck className="h-5 w-5 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <h3 className="text-sm font-extrabold text-white">
                  جسر الإضافة والمزايا الأساسية مفتوحة للجميع
                </h3>
                <p className="mt-1 text-xs text-slate-300 leading-relaxed">
                  يمكنك استخدام الاقتران وتنزيل الحزمة وجسر «ما بيا حيل» مباشرة. وللحصول على شارة{" "}
                  <strong className="text-emerald-300">مطور</strong> ادخل عبر صورتك الشخصية إلى{" "}
                  <strong className="text-sky-300">«فئة المطور»</strong> وأكمل المهام، أو تواصل مع الإدارة لطلب رتبة{" "}
                  <strong className="text-amber-300">مشرف / مدير</strong>.
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2 shrink-0">
              {userRole !== "developer" && (
                <button
                  type="button"
                  onClick={onOpenDeveloperCategory}
                  className="inline-flex items-center gap-1.5 rounded-xl bg-gradient-to-l from-emerald-600 to-blue-600 px-4 py-2.5 text-xs font-extrabold text-white shadow-lg hover:opacity-95 cursor-pointer"
                >
                  <Sparkles className="h-4 w-4" />
                  <span>فئة المطور (اكسب الشارة)</span>
                </button>
              )}
              <button
                type="button"
                onClick={onOpenAdminRequest}
                className="inline-flex items-center gap-1.5 rounded-xl border border-amber-400/45 bg-amber-500/15 px-4 py-2.5 text-xs font-extrabold text-amber-200 hover:bg-amber-500/25 cursor-pointer"
              >
                <Crown className="h-4 w-4 text-amber-300" />
                <span>طلب رتبة مدير / مشرف</span>
              </button>
            </div>
          </div>
        )}

        {/* Row 1: Blue Pairing ("اقتران") + MediaFire ZIP Download + "ما بيا حيل" Floating Bridge & Version Slider */}
        <div className="desktop-grid-12 grid grid-cols-1 gap-6 lg:grid-cols-12">
          {/* Blue "اقتران" (Pairing) Card + MediaFire ZIP Package + "ما بيا حيل" */}
          <div className="desktop-col-span-6 lg:col-span-6 rounded-2xl border border-blue-500/35 bg-[#101729] p-6 space-y-5 relative">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <div className="flex flex-wrap items-center gap-4">
                  <button
                    type="button"
                    onClick={() => void onGeneratePairing()}
                    className="group inline-flex items-center gap-2 text-right cursor-pointer"
                  >
                    <Link2 className="h-6 w-6 text-blue-400 transition-transform group-hover:rotate-12" />
                    <span className="text-2xl font-extrabold text-blue-400 underline decoration-blue-400/50 underline-offset-4 group-hover:text-sky-300">
                      اقتران
                    </span>
                  </button>

                  {/* Clickable Blue Text/Button "ما بيا حيل" — Auto-Inject Cyber-Admin Bridge */}
                  <button
                    id="ext-lazy-bridge"
                    type="button"
                    onClick={() => {
                      if (isDevOrAdmin) {
                        onTriggerAutoInjectCyberBridge();
                      } else {
                        setLazyBridgeOpen((prev) => !prev);
                      }
                    }}
                    aria-expanded={isDevOrAdmin ? Boolean(activeFloatingExtension) : lazyBridgeOpen}
                    className="scroll-mt-24 inline-flex items-center gap-1.5 rounded-xl border border-sky-400/50 bg-sky-500/15 px-3.5 py-1.5 text-sm font-extrabold text-sky-400 underline decoration-sky-400/60 underline-offset-4 transition-colors hover:bg-sky-500/25 hover:text-sky-200 cursor-pointer"
                  >
                    <Upload className="h-4 w-4 text-blue-400" />
                    <span>ما بيا حيل</span>
                  </button>
                </div>

                <p className="mt-1.5 text-xs sm:text-sm text-slate-300">
                  {isDevOrAdmin ? (
                    <>
                      مرحباً بالقائد والمشرف <strong className="text-amber-300">amirbaqir226</strong> — اضغط{" "}
                      <strong className="text-sky-400">ما بيا حيل</strong>{" "}
                      لتشغيل لوحة <strong className="text-emerald-300">Cyber-Admin</strong>{" "}
                      العائمة بأكثر من <strong className="text-sky-300">1,050+ أداة</strong> فوراً بدون رمز اقتران أو تنزيل يدوي!
                    </>
                  ) : (
                    <>
                      انقر على <strong className="text-blue-400">اقتران</strong>{" "}
                      أو <strong className="text-sky-400">ما بيا حيل</strong>، أو أكمل{" "}
                      <strong className="text-emerald-300">فئة المطور</strong>{" "}
                      لفتح الحقن الفوري المباشر عبر الـ 6 ملفات المدمجة.
                    </>
                  )}
                </p>
              </div>

              <span
                className={`inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1 text-xs font-extrabold ${
                  isPaired
                    ? "border-emerald-400/50 bg-emerald-500/15 text-emerald-300"
                    : isRejected
                    ? "border-rose-400/50 bg-rose-500/15 text-rose-300"
                    : isPendingConfirm
                    ? "border-amber-400/50 bg-amber-500/15 text-amber-300"
                    : isWaiting
                    ? "border-blue-400/50 bg-blue-500/15 text-blue-300"
                    : "border-white/15 bg-white/5 text-slate-300"
                }`}
              >
                <Database className="h-3.5 w-3.5" />
                <span>
                  {isPaired
                    ? "مقترن بتحكم كامل"
                    : isRejected
                    ? "مرفوض من الموقع"
                    : isPendingConfirm
                    ? "بانتظار تأكيدك (نعم / لا)"
                    : isWaiting
                    ? "بانتظار إدخال الرمز بالإضافة"
                    : "جاهز للاقتران"}
                </span>
              </span>
            </div>

            {/* Smart "ما بيا حيل" Dropzone & Floating Bridge Injector */}
            {lazyBridgeOpen && (
              <div className="rounded-2xl border border-sky-400/50 bg-[#070C18] p-4 space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 text-xs font-extrabold text-sky-300">
                    <Puzzle className="h-4 w-4 text-blue-400" />
                    <span>جسر «ما بيا حيل» الذكي — رفع وفك ضغط حزمة ZIP</span>
                  </div>
                  {activeFloatingExtension && (
                    <span className="text-[11px] font-bold text-emerald-300">
                      مُفعّل أعلى الشاشة: {activeFloatingExtension.extensionName}
                    </span>
                  )}
                </div>

                <div
                  onDragOver={(e) => {
                    e.preventDefault();
                    setDragActive(true);
                  }}
                  onDragLeave={() => setDragActive(false)}
                  onDrop={(e) => void handleDropZip(e)}
                  onClick={() => zipDropInputRef.current?.click()}
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" || e.key === " ") {
                      zipDropInputRef.current?.click();
                    }
                  }}
                  className={`flex flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed p-5 text-center transition-colors cursor-pointer ${
                    dragActive
                      ? "border-sky-400 bg-sky-500/15"
                      : "border-white/20 bg-[#0B0F19] hover:border-sky-400/60"
                  }`}
                >
                  {unpackingZip ? (
                    <Loader2 className="h-7 w-7 animate-spin text-sky-400" />
                  ) : (
                    <FileUp className="h-7 w-7 text-blue-400" />
                  )}
                  <p className="text-xs font-extrabold text-white">
                    {unpackingZip
                      ? "جاري فك ضغط الأرشيف وحقن الواجهة العائمة..."
                      : "اسحب وأفلت أي ملف إضافة ZIP هنا أو انقر لاختيار الملف"}
                  </p>
                  <p className="text-[11px] text-slate-400">
                    سيقوم النظام بفك الضغط تلقائياً وإظهار واجهة الإضافة العائمة في أعلى الشاشة للتفاعل المباشر.
                  </p>
                  <input
                    ref={zipDropInputRef}
                    type="file"
                    accept=".zip,application/zip"
                    onChange={(e) => void handleZipFileInputChange(e)}
                    className="hidden"
                  />
                </div>

                {unpackError && (
                  <p className="text-xs font-bold text-rose-300">{unpackError}</p>
                )}
              </div>
            )}

            {/* Generate Pairing Code Action */}
            <button
              type="button"
              disabled={pairingLoading}
              onClick={() => void onGeneratePairing()}
              className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-blue-600 px-5 py-3 text-sm font-extrabold text-white shadow-lg transition-colors hover:bg-blue-500 disabled:opacity-50 cursor-pointer"
            >
              {pairingLoading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <RefreshCw className="h-4 w-4" />
              )}
              <span>توليد رمز شاشة حي جديد للاقتران</span>
            </button>

            {/* Active Live On-Screen Pairing Code & Zero-Delay DOM Scan Form */}
            {pairingSession && (
              <div className="rounded-xl border border-blue-400/35 bg-[#0B0F19] p-4 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2 text-[11px] font-bold text-blue-300">
                      <span className="inline-block h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
                      <span>رمز الاقتران المعروض حياً على الشاشة (فحص الشاشة أونلاين)</span>
                    </div>
                    <p
                      id="live-screen-pairing-code"
                      data-live-pairing-code={pairingSession.code}
                      dir="ltr"
                      className="mt-0.5 inline-block rounded-lg border border-sky-400/35 bg-[#111A2E] px-3 py-1 font-mono text-2xl font-extrabold tracking-widest text-white tabular-nums"
                    >
                      {pairingSession.code}
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => void handleCopyCode()}
                      className="inline-flex items-center gap-1.5 rounded-lg border border-white/15 bg-white/5 px-3 py-1.5 text-xs font-bold text-slate-200 hover:bg-white/10 cursor-pointer"
                    >
                      {copiedCode ? (
                        <Check className="h-3.5 w-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="h-3.5 w-3.5" />
                      )}
                      <span>{copiedCode ? "تم النسخ" : "نسخ الرمز"}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => void onUnlinkPairing()}
                      className="inline-flex items-center gap-1 rounded-lg border border-rose-500/35 bg-rose-500/10 px-2.5 py-1.5 text-xs font-bold text-rose-300 hover:bg-rose-500/20 cursor-pointer"
                    >
                      <Unlink className="h-3.5 w-3.5" />
                      <span>فصل</span>
                    </button>
                  </div>
                </div>

                {/* Live Floating UI & DOM Scan Feedback */}
                {pairingSession.feedbackMessage && (
                  <div
                    data-dom-scan-ignore="true"
                    className={`rounded-lg border px-3 py-2 text-xs font-bold space-y-1 ${
                      isPaired
                        ? "border-emerald-500/45 bg-emerald-500/15 text-emerald-200"
                        : isRejected
                        ? "border-rose-500/40 bg-rose-500/10 text-rose-300"
                        : "border-blue-500/35 bg-blue-500/10 text-sky-200"
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      {isPaired ? (
                        <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-300" />
                      ) : isRejected ? (
                        <XCircle className="h-4 w-4 shrink-0" />
                      ) : (
                        <ScanSearch className="h-4 w-4 shrink-0 text-sky-300" />
                      )}
                      <span>{pairingSession.feedbackMessage}</span>
                    </div>
                    {pairingSession.domScan && (
                      <p
                        dir="ltr"
                        className="font-mono text-[11px] text-emerald-300"
                      >
                        DOM Scan Verified: {pairingSession.domScan.scannedNodesCount}{" "}
                        DOM nodes scanned in {pairingSession.domScan.durationMs}ms ·{" "}
                        {pairingSession.domScan.sourceHint}
                      </p>
                    )}
                  </div>
                )}

                {domScanError && (
                  <div
                    data-dom-scan-ignore="true"
                    className="flex items-center gap-2 rounded-lg border border-rose-500/40 bg-rose-500/10 px-3 py-2 text-xs font-bold text-rose-200"
                  >
                    <XCircle className="h-4 w-4 shrink-0" />
                    <span>{domScanError}</span>
                  </div>
                )}

                {!isPaired && (
                  <form
                    data-dom-scan-ignore="true"
                    onSubmit={(e) => void handleDomScanPairSubmit(e)}
                    className="space-y-2 pt-1"
                  >
                    <div className="flex flex-wrap items-center gap-2">
                      <input
                        type="text"
                        dir="ltr"
                        value={manualPairCode}
                        onChange={(e) => {
                          setManualPairCode(e.target.value.toUpperCase());
                          if (domScanError) setDomScanError("");
                        }}
                        placeholder="أدخل رمز الشاشة مثل IRAQI-CODE-777"
                        className="h-10 flex-1 min-w-[180px] rounded-lg border border-white/15 bg-[#111827] px-3 font-mono text-sm text-white focus:border-emerald-400 focus:outline-none"
                      />
                      <button
                        type="submit"
                        disabled={pairingLoading}
                        className="inline-flex h-10 items-center gap-1.5 rounded-lg bg-gradient-to-l from-emerald-600 to-sky-600 px-4 text-xs font-extrabold text-white hover:opacity-95 disabled:opacity-50 cursor-pointer"
                      >
                        <ScanSearch className="h-3.5 w-3.5" />
                        <span>فحص الشاشة واقتران فوري</span>
                      </button>
                    </div>

                    <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-400">
                      <span>
                        عند تطابق الرمز مع المعروض حياً في صفحة الموقع يتم الفتح الفوري بصلاحيات الإدارة والمطور بدون تأخير.
                      </span>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            setManualPairCode(pairingSession.code);
                            setDomScanError("");
                          }}
                          className="font-bold text-sky-300 hover:text-sky-200 underline cursor-pointer"
                        >
                          نسخ من الشاشة
                        </button>
                        <span>·</span>
                        <button
                          type="button"
                          onClick={() => void handleTriggerModalRequest()}
                          className="font-bold text-slate-300 hover:text-white underline cursor-pointer"
                        >
                          طلب تأكيد (نعم / لا)
                        </button>
                      </div>
                    </div>
                  </form>
                )}
              </div>
            )}

            {/* Embedded 6-File Extension Core (Zero Manual Download Needed for Admins/Devs) */}
            <div
              id="ext-mediafire-download"
              className="scroll-mt-24 rounded-xl border border-sky-400/35 bg-[#0B0F19] p-4 space-y-3"
            >
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="text-xs font-extrabold text-white">
                    نواة الإضافة المدمجة داخل المنصة (6 ملفات رسمية — v4.0.0)
                  </p>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    جميع الأكواد والملفات الـ 6 مدمجة مباشرة في صميم الموقع — لا يحتاج الإداريون والمشرفون والمطورون إلى تنزيل أو تثبيت أي ملف ZIP يدوياً.
                  </p>
                </div>
                <span className="inline-flex items-center gap-1 text-[11px] font-mono font-bold text-emerald-300">
                  <Archive className="h-3.5 w-3.5" />
                  <span>6 Core Files</span>
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {EMBEDDED_EXTENSION_FILES.map((extFile) => (
                  <button
                    key={extFile.path}
                    type="button"
                    dir="ltr"
                    onClick={() =>
                      onOpenSecretCodeEditor({
                        name: extFile.path,
                        content: extFile.content,
                      })
                    }
                    className="flex items-center justify-between gap-1.5 rounded-lg border border-white/10 bg-[#101729] px-2.5 py-2 text-left font-mono text-[11px] font-bold text-sky-200 hover:border-sky-400/55 hover:text-white cursor-pointer"
                  >
                    <span className="truncate">{extFile.path}</span>
                    <span className="text-[10px] text-emerald-400 shrink-0">
                      مُدمج
                    </span>
                  </button>
                ))}
              </div>

              <div className="flex flex-wrap items-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => {
                    if (isDevOrAdmin) {
                      onTriggerAutoInjectCyberBridge();
                    } else {
                      onOpenDeveloperCategory();
                    }
                  }}
                  className="inline-flex flex-1 min-w-[200px] items-center justify-center gap-2 rounded-xl bg-gradient-to-l from-sky-600 to-blue-600 px-4 py-2.5 text-xs font-extrabold text-white shadow-lg hover:opacity-95 cursor-pointer"
                >
                  <Rocket className="h-4 w-4" />
                  <span>
                    {isDevOrAdmin
                      ? "ما بيا حيل — فتح لوحة Cyber-Admin (1,050+ أداة)"
                      : "فعّل فئة المطور للحقن التلقائي المباشر"}
                  </span>
                </button>

                <a
                  href={MEDIAFIRE_EXTENSION_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() =>
                    onShowToast(
                      "فتح رابط حزمة IraqiCodersAdmin.zip الاحتياطية على MediaFire..."
                    )
                  }
                  className="inline-flex items-center justify-center gap-1.5 rounded-xl border border-white/15 bg-white/5 px-3.5 py-2.5 text-[11px] font-bold text-slate-300 hover:border-sky-400/40 hover:text-white"
                >
                  <Download className="h-3.5 w-3.5" />
                  <span>نسخة MediaFire</span>
                  <ExternalLink className="h-3 w-3 opacity-80" />
                </a>
              </div>
            </div>
          </div>

          {/* Futuristic Version Slider (26.5 -> 999.9) — Admin Full Control */}
          <div
            id="version-future-slider"
            className="scroll-mt-24 desktop-col-span-6 lg:col-span-6 rounded-2xl border border-violet-500/35 bg-[#101729] p-6 flex flex-col justify-between space-y-5 relative"
          >
            <div>
              <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                <div className="inline-flex items-center gap-2 text-violet-300 font-extrabold text-sm">
                  <SlidersHorizontal className="h-4 w-4" />
                  <span>شريط التحكم المستقبلي بالإصدار (حتى v999.9)</span>
                </div>
                <span className="font-mono text-xl font-extrabold text-emerald-300 tabular-nums">
                  v{versionStr}
                </span>
              </div>

              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                اسحب المؤشر لمعاينة المنصة في الإصدار المستقبلي حتى{" "}
                <strong className="font-mono text-sky-300">v999.9</strong>.
                تتحدّث شارات النظام والواجهة بالكامل فوراً أثناء التحريك!
              </p>
            </div>

            {!isSiteAdmin && (
              <div className="flex items-center gap-2 rounded-xl border border-amber-400/35 bg-amber-500/10 px-3.5 py-2.5 text-xs font-bold text-amber-200">
                <Lock className="h-4 w-4 shrink-0 text-amber-400" />
                <span>تحكم الإصدار الكامل v999.9 مخصص لمدير الموقع فقط.</span>
              </div>
            )}

            <div
              className={`rounded-xl border border-white/10 bg-[#0B0F19] p-4 space-y-4 ${
                !isSiteAdmin ? "opacity-60 pointer-events-none select-none" : ""
              }`}
            >
              <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 tabular-nums">
                <span>v26.5 (الإصدار الحالي)</span>
                <span>v500.0</span>
                <span className="text-sky-300 font-bold">v999.9 (المستقبل)</span>
              </div>

              <input
                type="range"
                aria-label="شريط التحكم في إصدار المعاينة من 26.5 إلى 999.9"
                min={26.5}
                max={999.9}
                step={0.1}
                disabled={!isSiteAdmin}
                value={previewVersion}
                onChange={(e) =>
                  onChangePreviewVersion(Number(e.target.value))
                }
                dir="ltr"
                className="w-full accent-sky-400 cursor-pointer h-2 rounded-lg bg-slate-800"
              />

              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex flex-wrap gap-2">
                  {[26.5, 50.0, 100.0, 999.9].map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      disabled={!isSiteAdmin}
                      onClick={() => onChangePreviewVersion(preset)}
                      className={`rounded-lg border px-2.5 py-1 font-mono text-xs font-bold transition-colors cursor-pointer tabular-nums ${
                        Math.abs(previewVersion - preset) < 0.05
                          ? "border-sky-400 bg-sky-500/20 text-sky-200"
                          : "border-white/10 bg-white/5 text-slate-300 hover:text-white"
                      }`}
                    >
                      v{preset.toFixed(1)}
                    </button>
                  ))}
                </div>

                <button
                  type="button"
                  disabled={!isSiteAdmin}
                  onClick={() => {
                    const target = previewVersion >= 999.8 ? 26.5 : 999.9;
                    onChangePreviewVersion(target);
                    onShowToast(
                      target === 999.9
                        ? "تم تفعيل معاينة المستقبل الأسطورية v999.9!"
                        : "تمت العودة إلى الإصدار الرسمي v26.5."
                    );
                  }}
                  className="inline-flex items-center gap-1.5 rounded-xl bg-gradient-to-l from-violet-600 to-sky-600 px-3.5 py-2 text-xs font-extrabold text-white hover:opacity-95 cursor-pointer"
                >
                  <Rocket className="h-3.5 w-3.5" />
                  <span>
                    {previewVersion >= 999.8
                      ? "الرجوع إلى v26.5"
                      : "قفزة إلى v999.9"}
                  </span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Row 2: AI-Powered Live Update Generator Box + Public / Private Toggles */}
        <div
          id="ai-live-updates"
          className="scroll-mt-24 rounded-2xl border border-emerald-500/30 bg-[#101729] p-6 space-y-5"
        >
          <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <div className="inline-flex items-center gap-2 text-emerald-300 text-xs font-extrabold mb-1">
                <Sparkles className="h-4 w-4" />
                <span>مولّد التحديثات الحية بالذكاء الاصطناعي ({aiModelLabel})</span>
              </div>
              <h3 className="text-lg sm:text-xl font-extrabold text-white">
                أضف ميزة أو تحديثاً جديداً للموقع بأمر نصي فوري
              </h3>
            </div>
            <span className="text-xs text-slate-400">
              {isSiteAdmin ? (
                <>
                  تُعرض أزرار <strong className="text-emerald-300">عام</strong> و{" "}
                  <strong className="text-amber-300">خاص</strong> أسفل كل تحديث مولّد
                </>
              ) : (
                <span className="inline-flex items-center gap-1 text-amber-300 font-bold">
                  <Lock className="h-3.5 w-3.5" />
                  <span>توليد التحديثات الحية مخصص لمدير الموقع</span>
                </span>
              )}
            </span>
          </div>

          <form
            onSubmit={(e) => void handleGenerateAiUpdate(e)}
            className="flex flex-col gap-3 sm:flex-row"
          >
            <input
              type="text"
              disabled={!isSiteAdmin}
              value={aiPrompt}
              onChange={(e) => setAiPrompt(e.target.value)}
              placeholder={
                isSiteAdmin
                  ? "اكتب وصف الميزة المطلوبة (مثال: أضف أداة فحص سرعة الأكواد، أو بانر تهنئة v999.9)..."
                  : "يتطلب صلاحية مدير الموقع لإضافة تحديثات حية..."
              }
              className="h-12 flex-1 rounded-xl border border-white/15 bg-[#0B0F19] px-4 text-sm text-white placeholder:text-slate-500 focus:border-emerald-400 focus:outline-none disabled:opacity-60"
            />
            <button
              type="submit"
              disabled={aiGenerating || !isSiteAdmin}
              className="inline-flex h-12 items-center justify-center gap-2 rounded-xl bg-emerald-600 px-6 text-sm font-extrabold text-white transition-colors hover:bg-emerald-500 disabled:opacity-50 shrink-0 cursor-pointer"
            >
              {aiGenerating ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Sparkles className="h-4 w-4" />
              )}
              <span>
                {aiGenerating ? "جاري التوليد..." : "توليد وإضافة الميزة"}
              </span>
            </button>
          </form>

          {/* Quick Prompt Suggestions */}
          {isSiteAdmin && (
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs text-slate-400">أفكار سريعة:</span>
              {PROMPT_PRESETS.map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => setAiPrompt(preset)}
                  className="rounded-lg border border-white/10 bg-[#0B0F19] px-3 py-1.5 text-xs font-semibold text-slate-300 hover:border-emerald-400/50 hover:text-emerald-300 cursor-pointer"
                >
                  {preset}
                </button>
              ))}
            </div>
          )}

          {/* Generated Updates List */}
          {updates.length > 0 && (
            <div className="grid grid-cols-1 gap-4 pt-2 md:grid-cols-2">
              {updates.map((upd) => {
                const isPublic = upd.visibility === "public";
                const canControl =
                  isSiteAdmin ||
                  (isDevOrAdmin &&
                    upd.authorId === (user?.id || "local-admin-dev"));

                return (
                  <div
                    key={upd.id}
                    className="rounded-2xl border border-white/10 bg-[#0B0F19] p-4 space-y-3"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <div className="flex flex-wrap items-center gap-2 text-[11px] font-bold mb-1">
                          <span className="text-sky-300">{upd.badgeText}</span>
                          <span className="text-slate-600">·</span>
                          <span className="font-mono text-slate-400">
                            v{upd.targetVersion}
                          </span>
                          <span className="text-slate-600">·</span>
                          <span
                            className={
                              isPublic ? "text-emerald-300" : "text-amber-300"
                            }
                          >
                            {isPublic ? "منشور للعامة (عام)" : "للمنشئ فقط (خاص)"}
                          </span>
                        </div>
                        <h4 className="text-sm font-extrabold text-white">
                          {upd.title}
                        </h4>
                        <p className="mt-1 text-xs text-slate-400 leading-relaxed">
                          {upd.description}
                        </p>
                      </div>

                      {canControl && (
                        <button
                          type="button"
                          onClick={() => onDeleteUpdate(upd.id)}
                          aria-label="حذف التحديث"
                          className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-rose-500/30 bg-rose-500/10 text-rose-300 hover:bg-rose-500/20 cursor-pointer"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      )}
                    </div>

                    <button
                      type="button"
                      onClick={() => onExecuteUpdateAction(upd)}
                      className="inline-flex w-full items-center justify-center gap-1.5 rounded-xl border border-sky-400/35 bg-sky-500/15 py-2 text-xs font-extrabold text-sky-200 hover:bg-sky-500/25 cursor-pointer"
                    >
                      <Play className="h-3.5 w-3.5" />
                      <span>{upd.actionLabel}</span>
                    </button>

                    {canControl && (
                      <div className="grid grid-cols-2 gap-2 pt-1">
                        <button
                          type="button"
                          onClick={() => onToggleVisibility(upd.id, "public")}
                          aria-pressed={isPublic}
                          className={`inline-flex items-center justify-center gap-1.5 rounded-xl border py-2 text-xs font-extrabold transition-colors cursor-pointer ${
                            isPublic
                              ? "border-emerald-400 bg-emerald-600 text-white"
                              : "border-white/15 bg-white/5 text-slate-300 hover:border-emerald-400/40 hover:text-emerald-300"
                          }`}
                        >
                          <Globe className="h-3.5 w-3.5" />
                          <span>عام (للجميع)</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => onToggleVisibility(upd.id, "private")}
                          aria-pressed={!isPublic}
                          className={`inline-flex items-center justify-center gap-1.5 rounded-xl border py-2 text-xs font-extrabold transition-colors cursor-pointer ${
                            !isPublic
                              ? "border-amber-400 bg-amber-600 text-white"
                              : "border-white/15 bg-white/5 text-slate-300 hover:border-amber-400/40 hover:text-amber-300"
                          }`}
                        >
                          <Lock className="h-3.5 w-3.5" />
                          <span>خاص (للمنشئ فقط)</span>
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {updates.length === 0 && (
            <div className="rounded-xl border border-dashed border-white/15 bg-[#0B0F19]/60 p-4 text-center text-xs text-slate-400">
              <Eye className="h-5 w-5 text-slate-500 mx-auto mb-1.5" />
              لا توجد ميزات مولّدة بعد — يظهر هذا القسم التحديثات الحية فور إنشائها مع خياري{" "}
              <strong className="text-emerald-300">عام</strong> و{" "}
              <strong className="text-amber-300">خاص</strong>.
            </div>
          )}
        </div>
      </div>

      {/* Interactive Confirmation Modal when Extension ("إدارة عراقي كودرز") enters a pairing code */}
      {isPendingConfirm && pairingSession && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="pairing-confirm-title"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm"
        >
          <div className="w-full max-w-md overflow-hidden rounded-2xl border border-blue-400/50 bg-[#0E1424] shadow-2xl">
            <div className="flex items-center gap-3 border-b border-white/10 bg-[#101A33] px-6 py-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl border border-blue-400/40 bg-blue-500/15 text-blue-300">
                <ShieldAlert className="h-5 w-5" />
              </div>
              <div>
                <h3
                  id="pairing-confirm-title"
                  className="text-base font-extrabold text-white"
                >
                  طلب اقتران — {pairingSession.extensionName}
                </h3>
                <p dir="ltr" className="font-mono text-xs text-sky-300">
                  CODE: {pairingSession.code}
                </p>
              </div>
            </div>

            <div className="p-6 space-y-5">
              <p className="text-base font-extrabold text-white leading-relaxed">
                هل تسمح بالاقتران والتحكم الكامل بالموقع؟
              </p>
              <p className="text-xs text-slate-300 leading-relaxed">
                قامت إضافة <strong className="text-sky-300">«إدارة عراقي كودرز»</strong> بإدخال رمز الاقتران. اختيار <strong className="text-emerald-300">نعم</strong> سيمنح الإضافة صلاحية التحكم وإرسال رسالة نجاح إلى واجهتها العائمة، واختيار <strong className="text-rose-300">لا</strong> سيرفض الطلب فوراً.
              </p>

              <div className="grid grid-cols-2 gap-3 pt-1">
                <button
                  type="button"
                  disabled={pairingLoading}
                  onClick={() => void onConfirmPairingDecision(true)}
                  className="inline-flex items-center justify-center gap-2 rounded-xl bg-emerald-600 py-3 text-sm font-extrabold text-white shadow-lg hover:bg-emerald-500 disabled:opacity-60 cursor-pointer"
                >
                  <CheckCircle2 className="h-4 w-4" />
                  <span>نعم</span>
                </button>

                <button
                  type="button"
                  disabled={pairingLoading}
                  onClick={() => void onConfirmPairingDecision(false)}
                  className="inline-flex items-center justify-center gap-2 rounded-xl border border-rose-500/45 bg-rose-600/20 py-3 text-sm font-extrabold text-rose-200 hover:bg-rose-600/35 disabled:opacity-60 cursor-pointer"
                >
                  <XCircle className="h-4 w-4" />
                  <span>لا</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
