import React, { useEffect, useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import {
  Clock,
  KeyRound,
  Monitor,
  Scissors,
  Smartphone,
  Sparkles,
  Tv,
  X,
} from "lucide-react";

interface MaintenanceScreenProps {
  isOpen: boolean;
  desktopMode: boolean;
  onToggleDesktopMode: (enabled: boolean) => void;
  onBypassMaintenance: () => void;
  onUnlockAdminAndEnter: () => void;
}

type WorkerActivity = "versions" | "flags" | "prayer" | "tv";

const ACTIVITIES: Array<{
  id: WorkerActivity;
  title: string;
  caption: string;
}> = [
  {
    id: "versions",
    title: "تبديل الشارات (2.x ➔ 3.x)",
    caption: "العمال يرفعون شارات الإصدار 2.x ويستبدلونها بشعارات 3.x و 26.5",
  },
  {
    id: "flags",
    title: "رفع الأعلام",
    caption: "العمال يلوّحون بعلم العراق وراية «يا علي» بحماس كبير",
  },
  {
    id: "prayer",
    title: "الصلاة في وقتها",
    caption: "العمال يؤدون الصلاة في وقتها قبل استئناف العمل",
  },
  {
    id: "tv",
    title: "مشاهدة التلفاز من الملل",
    caption: "استراحة قصيرة أمام التلفاز بانتظار دقات الساعة 10:00 بالليل",
  },
];

function getTimeLeftToTenPM(): {
  hours: string;
  minutes: string;
  seconds: string;
  isPastTenPM: boolean;
  isNinePMOrLater: boolean;
} {
  const now = new Date();
  const hour = now.getHours();
  const isNinePMOrLater = hour >= 21;
  const target = new Date(now);
  target.setHours(22, 0, 0, 0);

  const diffMs = target.getTime() - now.getTime();
  if (diffMs <= 0) {
    return {
      hours: "00",
      minutes: "00",
      seconds: "00",
      isPastTenPM: true,
      isNinePMOrLater: true,
    };
  }

  const totalSec = Math.floor(diffMs / 1000);
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;

  return {
    hours: String(h).padStart(2, "0"),
    minutes: String(m).padStart(2, "0"),
    seconds: String(s).padStart(2, "0"),
    isPastTenPM: false,
    isNinePMOrLater,
  };
}

const MiniWorker: React.FC<{
  helmet: string;
  suit: string;
  kneeling?: boolean;
}> = ({ helmet, suit, kneeling = false }) => (
  <svg
    viewBox="0 0 70 90"
    className={`h-20 w-16 sm:h-24 sm:w-20 ${kneeling ? "translate-y-2" : ""}`}
    aria-hidden="true"
  >
    <path d="M19 24 C19 12, 51 12, 51 24 Z" fill={helmet} />
    <rect x="15" y="22" width="40" height="4.5" rx="2" fill={helmet} />
    <circle cx="35" cy="34" r="10" fill="#F3C69F" />
    <circle cx="31.5" cy="33" r="1.5" fill="#1E293B" />
    <circle cx="38.5" cy="33" r="1.5" fill="#1E293B" />
    <path
      d="M31.5 38 Q35 41 38.5 38"
      fill="none"
      stroke="#1E293B"
      strokeWidth="1.6"
      strokeLinecap="round"
    />
    <rect x="23" y="45" width="24" height="24" rx="5" fill={suit} />
    <rect x="13" y="46" width="10" height="5" rx="2.5" fill="#F3C69F" />
    <rect x="47" y="46" width="10" height="5" rx="2.5" fill="#F3C69F" />
    {!kneeling ? (
      <>
        <rect x="26" y="69" width="6.5" height="14" rx="2.5" fill="#334155" />
        <rect x="37.5" y="69" width="6.5" height="14" rx="2.5" fill="#334155" />
      </>
    ) : (
      <rect x="24" y="68" width="22" height="8" rx="3" fill="#334155" />
    )}
  </svg>
);

export const MaintenanceScreen: React.FC<MaintenanceScreenProps> = ({
  isOpen,
  desktopMode,
  onToggleDesktopMode,
  onBypassMaintenance,
  onUnlockAdminAndEnter,
}) => {
  const [countdown, setCountdown] = useState(getTimeLeftToTenPM);
  const [activityIdx, setActivityIdx] = useState(0);
  const [openingCeremony, setOpeningCeremony] = useState(false);
  const [ribbonCut, setRibbonCut] = useState(false);

  // PIN Modal state
  const [pinModalOpen, setPinModalOpen] = useState(false);
  const [pinInput, setPinInput] = useState("");
  const [pinError, setPinError] = useState("");

  useEffect(() => {
    if (!isOpen) return;
    const interval = window.setInterval(() => {
      const next = getTimeLeftToTenPM();
      setCountdown(next);
      if (next.isPastTenPM && !openingCeremony) {
        setOpeningCeremony(true);
        window.setTimeout(() => setRibbonCut(true), 1000);
      }
    }, 1000);
    return () => window.clearInterval(interval);
  }, [isOpen, openingCeremony]);

  // Auto-rotate cartoon worker activities while in maintenance
  useEffect(() => {
    if (!isOpen || openingCeremony) return;
    const rot = window.setInterval(() => {
      setActivityIdx((prev) => (prev + 1) % ACTIVITIES.length);
    }, 5200);
    return () => window.clearInterval(rot);
  }, [isOpen, openingCeremony]);

  if (!isOpen) return null;

  const activeActivity = ACTIVITIES[activityIdx];

  const handlePinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const code = pinInput.trim();
    if (code === "2019") {
      setPinError("");
      setPinInput("");
      setPinModalOpen(false);
      onUnlockAdminAndEnter();
    } else if (code === "404") {
      setPinError("");
      setPinInput("");
      setPinModalOpen(false);
      onBypassMaintenance();
    } else {
      setPinError("الرمز السري غير صحيح. أدخل رمز الصيانة أو رمز المسؤول.");
    }
  };

  const triggerTenPMOpening = () => {
    setOpeningCeremony(true);
    setRibbonCut(false);
    window.setTimeout(() => setRibbonCut(true), 1100);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="شاشة الصيانة والافتتاح"
      className="fixed inset-0 z-50 overflow-y-auto overflow-x-auto bg-[#070B14]"
    >
      <div
        className={`flex min-h-full flex-col justify-between p-3 sm:p-8 ${
          desktopMode ? "min-w-[1240px]" : "w-full"
        }`}
      >
        {/* Ambient Background Glow */}
        <div
          aria-hidden="true"
          className="pointer-events-none fixed inset-0 bg-[radial-gradient(circle_at_top_right,rgba(124,58,237,0.18),transparent_50%),radial-gradient(circle_at_bottom_left,rgba(16,185,129,0.12),transparent_45%)]"
        />

        {/* Top Header with Clickable Blue "صيانة" Trigger & Mobile/Desktop Switch */}
        <div className="relative z-10 mx-auto flex w-full max-w-5xl flex-wrap items-center justify-between gap-3 border-b border-white/10 pb-3 sm:pb-4">
          <div className="flex items-center gap-2 sm:gap-3">
            <span className="text-base font-extrabold text-white sm:text-xl">
              عراقي كودرز
            </span>
            <span className="version-glow rounded-md border border-violet-400/45 bg-violet-600/25 px-2 py-0.5 text-[11px] font-extrabold text-emerald-300 sm:px-2.5 sm:text-xs">
              الإصدار 26.5
            </span>
          </div>

          <div className="flex items-center gap-2.5 sm:gap-4">
            <div
              role="group"
              aria-label="تبديل واجهة الموبايل وسطح المكتب"
              className="inline-flex items-center rounded-lg border border-white/15 bg-[#0E1424] p-0.5"
            >
              <button
                type="button"
                onClick={() => onToggleDesktopMode(false)}
                className={`inline-flex items-center gap-1 rounded-md px-2 py-1 text-[11px] font-bold cursor-pointer ${
                  !desktopMode
                    ? "bg-violet-600 text-white"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                <Smartphone className="h-3.5 w-3.5" />
                <span>موبايل</span>
              </button>
              <button
                type="button"
                onClick={() => onToggleDesktopMode(true)}
                className={`inline-flex items-center gap-1 rounded-md px-2 py-1 text-[11px] font-bold cursor-pointer ${
                  desktopMode
                    ? "bg-emerald-600 text-white"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                <Monitor className="h-3.5 w-3.5" />
                <span>سطح المكتب</span>
              </button>
            </div>

            {/* SECRET BYPASS: Clickable Blue "صيانة" Text */}
            <button
              type="button"
              onClick={() => {
                setPinError("");
                setPinInput("");
                setPinModalOpen(true);
              }}
              title="إدخال رمز الصيانة أو المسؤول"
              className="text-sm sm:text-base font-extrabold text-sky-400 underline decoration-sky-400/60 underline-offset-4 transition-colors hover:text-sky-300 cursor-pointer"
            >
              صيانة
            </button>
          </div>
        </div>

        {/* Main Content Stage */}
        <div className="relative z-10 mx-auto my-auto w-full max-w-4xl py-4 sm:py-6">
          {!openingCeremony ? (
            <div className="space-y-4 sm:space-y-6">
              {/* Countdown Card */}
              <div className="glass-surface rounded-2xl sm:rounded-3xl border border-violet-500/30 p-4 text-center sm:p-8">
                <div className="mb-2.5 inline-flex items-center gap-1.5 text-[11px] sm:text-xs font-bold text-emerald-300">
                  <Clock className="h-4 w-4 shrink-0" />
                  <span>
                    الوقت المثالي 10:00 بالليل · وحتى الساعة 9:00 يُسمح بالمرور بسلاسة
                  </span>
                </div>

                <h1 className="text-xl font-extrabold text-white sm:text-3xl mb-2 leading-snug">
                  الموقع قيد التجهيز والاحتفال —{" "}
                  <button
                    type="button"
                    onClick={() => setPinModalOpen(true)}
                    className="text-sky-400 underline decoration-sky-400/60 underline-offset-4 hover:text-sky-300 cursor-pointer"
                  >
                    صيانة
                  </button>
                </h1>
                <p className="text-xs text-slate-400 sm:text-sm mb-4 sm:mb-6">
                  يقوم فريق العمال الصغار الآن بإتمام اللمسات الأخيرة لإطلاق الإصدار 26.5، وبانتظار المدير لقص الشريط الأحمر.
                </p>

                {/* Live Digital Countdown */}
                <div
                  dir="ltr"
                  className="mx-auto inline-flex items-center gap-2 sm:gap-3 rounded-2xl border border-white/10 bg-[#0B0F19] px-4 py-3 font-mono text-2xl font-extrabold text-emerald-300 tabular-nums sm:px-6 sm:py-4 sm:text-5xl"
                >
                  <span>{countdown.hours}</span>
                  <span className="text-slate-600">:</span>
                  <span>{countdown.minutes}</span>
                  <span className="text-slate-600">:</span>
                  <span>{countdown.seconds}</span>
                </div>

                <div className="mt-4 sm:mt-5 flex flex-wrap items-center justify-center gap-3">
                  {countdown.isNinePMOrLater && (
                    <button
                      type="button"
                      onClick={triggerTenPMOpening}
                      className="version-glow inline-flex items-center gap-2 rounded-xl bg-gradient-to-l from-rose-600 to-amber-500 px-4 py-2.5 text-xs font-extrabold text-white shadow-lg transition-transform hover:scale-[1.02] cursor-pointer"
                    >
                      <Scissors className="h-4 w-4 shrink-0" />
                      <span>الساعة 9:00+ م — دخول سلس وقص الشريط الأحمر</span>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={triggerTenPMOpening}
                    className="inline-flex items-center gap-2 rounded-xl border border-emerald-500/40 bg-emerald-500/15 px-3.5 py-2 text-xs font-bold text-emerald-300 transition-colors hover:bg-emerald-500/25 cursor-pointer"
                  >
                    <Scissors className="h-3.5 w-3.5 shrink-0" />
                    <span>افتتاح ساعة 9:00 / 10:00 (المدير يقص الشريط الأحمر)</span>
                  </button>
                </div>
              </div>

              {/* Cartoon Workers Real-Time Activity Stage */}
              <div className="glass-surface rounded-2xl sm:rounded-3xl border border-white/10 p-4 sm:p-6">
              <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="text-xs font-bold text-violet-300">
                    كواليس العمال المباشرة
                  </p>
                  <h2 className="text-base font-extrabold text-white">
                    {activeActivity.caption}
                  </h2>
                </div>

                {/* Activity Selector Tabs */}
                <div className="flex flex-wrap gap-1.5">
                  {ACTIVITIES.map((act, idx) => (
                    <button
                      key={act.id}
                      type="button"
                      onClick={() => setActivityIdx(idx)}
                      className={`rounded-lg px-3 py-1.5 text-[11px] font-bold transition-colors cursor-pointer ${
                        activityIdx === idx
                          ? "bg-violet-600 text-white"
                          : "bg-white/5 text-slate-400 hover:text-white"
                      }`}
                    >
                      {act.title}
                    </button>
                  ))}
                </div>
              </div>

              {/* Animated Scene Canvas */}
              <div className="relative flex min-h-[190px] items-center justify-center overflow-hidden rounded-2xl border border-white/10 bg-[#080C15] p-6">
                <AnimatePresence mode="wait">
                  {activeActivity.id === "versions" && (
                    <motion.div
                      key="versions"
                      initial={{ opacity: 0, y: 12 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -12 }}
                      className="flex flex-wrap items-center justify-center gap-6"
                    >
                      <motion.div
                        animate={{ x: [0, 8, 0] }}
                        transition={{ duration: 1.4, repeat: Infinity }}
                      >
                        <MiniWorker helmet="#F59E0B" suit="#7C3AED" />
                      </motion.div>

                      <div className="flex items-center gap-3 rounded-xl border border-violet-500/40 bg-[#111827] px-5 py-3">
                        <span className="font-mono text-lg font-bold text-slate-500 line-through">
                          v2.x
                        </span>
                        <span className="text-emerald-400 font-bold">➔</span>
                        <motion.span
                          animate={{ scale: [1, 1.08, 1] }}
                          transition={{ duration: 1.2, repeat: Infinity }}
                          className="font-mono text-2xl font-extrabold text-emerald-300"
                        >
                          v3.x · 26.5
                        </motion.span>
                      </div>

                      <motion.div
                        animate={{ x: [0, -8, 0] }}
                        transition={{ duration: 1.4, repeat: Infinity }}
                      >
                        <MiniWorker helmet="#10B981" suit="#2563EB" />
                      </motion.div>
                    </motion.div>
                  )}

                  {activeActivity.id === "flags" && (
                    <motion.div
                      key="flags"
                      initial={{ opacity: 0, y: 12 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -12 }}
                      className="flex flex-wrap items-center justify-center gap-8"
                    >
                      <div className="flex flex-col items-center gap-2">
                        <motion.div
                          animate={{ rotate: [-4, 4, -4] }}
                          transition={{ duration: 1.5, repeat: Infinity }}
                          className="rounded-lg border border-emerald-500/40 bg-emerald-950/80 px-4 py-1.5 text-sm font-extrabold text-emerald-300 shadow-lg"
                        >
                          راية: يا علي
                        </motion.div>
                        <MiniWorker helmet="#10B981" suit="#7C3AED" />
                      </div>

                      <div className="flex flex-col items-center gap-2">
                        <motion.div
                          animate={{ rotate: [4, -4, 4] }}
                          transition={{ duration: 1.5, repeat: Infinity }}
                          className="overflow-hidden rounded border border-white/20 shadow-lg"
                        >
                          <svg viewBox="0 0 60 36" className="h-9 w-16" aria-label="العلم العراقي">
                            <rect width="60" height="12" y="0" fill="#CE1126" />
                            <rect width="60" height="12" y="12" fill="#FFFFFF" />
                            <rect width="60" height="12" y="24" fill="#000000" />
                            <text
                              x="30"
                              y="21"
                              textAnchor="middle"
                              fontSize="8"
                              fontWeight="bold"
                              fill="#007A3D"
                            >
                              الله أكبر
                            </text>
                          </svg>
                        </motion.div>
                        <MiniWorker helmet="#F59E0B" suit="#0284C7" />
                      </div>
                    </motion.div>
                  )}

                  {activeActivity.id === "prayer" && (
                    <motion.div
                      key="prayer"
                      initial={{ opacity: 0, y: 12 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -12 }}
                      className="flex flex-col items-center gap-3 text-center"
                    >
                      <div className="flex items-end gap-6">
                        <div className="flex flex-col items-center">
                          <MiniWorker helmet="#10B981" suit="#4F46E5" kneeling />
                          <div className="h-3 w-20 rounded bg-emerald-700/80 border border-emerald-400/50" />
                        </div>
                        <div className="flex flex-col items-center">
                          <MiniWorker helmet="#F59E0B" suit="#6D28D9" kneeling />
                          <div className="h-3 w-20 rounded bg-emerald-700/80 border border-emerald-400/50" />
                        </div>
                      </div>
                      <p className="text-xs font-bold text-emerald-300">
                        تقبل الله طاعاتكم — استراحة الصلاة في وقتها
                      </p>
                    </motion.div>
                  )}

                  {activeActivity.id === "tv" && (
                    <motion.div
                      key="tv"
                      initial={{ opacity: 0, y: 12 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -12 }}
                      className="flex flex-wrap items-center justify-center gap-6"
                    >
                      <MiniWorker helmet="#F59E0B" suit="#475569" />
                      <div className="flex flex-col items-center rounded-2xl border-2 border-violet-500/50 bg-[#111827] px-6 py-4 shadow-lg">
                        <Tv className="h-8 w-8 text-sky-400 mb-1" />
                        <span className="text-xs font-bold text-slate-300">
                          العمال يتابعون التلفاز من الملل بانتظار 10:00 م
                        </span>
                      </div>
                      <MiniWorker helmet="#10B981" suit="#475569" />
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>
          </div>
        ) : (
          /* 9:00 / 10:00 PM Grand Opening Ceremony ("المدير يقص الشريط الأحمر") */
          <motion.div
            initial={{ scale: 0.94, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="glass-surface relative overflow-hidden rounded-3xl border border-emerald-500/45 p-8 text-center shadow-2xl"
          >
            <div className="mb-3 inline-flex items-center gap-2 text-xs font-bold text-emerald-300">
              <Sparkles className="h-4 w-4" />
              <span>مراسم الافتتاح والترحيب · الساعة 9:00 / 10:00 بالليل</span>
            </div>

            <h2 className="text-2xl font-extrabold text-white sm:text-3xl mb-3">
              {ribbonCut
                ? "تم قص الشريط الأحمر! أهلاً وسهلاً بك في عراقي كودرز 🎉"
                : "المدير يحمل المقص الآن ويستعد لقص الشريط الأحمر..."}
            </h2>
            <p className="text-xs sm:text-sm text-emerald-200/90 mb-6">
              {ribbonCut
                ? "انفتح الموقع بنجاح وحيّاك الله يا زائرنا الكريم — استمتع بجميع الأدوات والمغامرات!"
                : "العمال يفرشون السجاد الأحمر وتُجهّز المنصة للانطلاق الرسمي."}
            </p>

            {/* Carpet Rollout + Manager with Scissors cutting Red Ribbon */}
            <div className="relative mx-auto max-w-xl rounded-2xl border border-white/10 bg-[#080C15] p-6 mb-6 overflow-hidden">
              <motion.div
                initial={{ scaleX: 0 }}
                animate={{ scaleX: 1 }}
                transition={{ duration: 0.85, ease: [0.16, 1, 0.3, 1] }}
                className="mx-auto mb-5 h-5 w-full origin-right rounded-md bg-gradient-to-l from-red-700 via-rose-600 to-amber-500/80 border border-amber-300/40"
              />

              <div className="flex items-center justify-center gap-6">
                <MiniWorker helmet="#F59E0B" suit="#7C3AED" />

                {/* Manager with Suit & Scissors */}
                <div className="flex flex-col items-center gap-2">
                  <div className="relative flex flex-col items-center">
                    <div className="h-9 w-9 rounded-full bg-[#F3C69F] border-2 border-amber-400 flex items-center justify-center text-xs font-extrabold text-slate-900">
                      م
                    </div>
                    <div className="mt-1 rounded-lg bg-slate-900 border border-amber-400/60 px-2.5 py-1 text-[10px] font-extrabold text-amber-300">
                      المدير العام
                    </div>
                  </div>
                  <motion.div
                    animate={
                      ribbonCut
                        ? { rotate: [-15, -45, -20], scale: 1.2, y: 6 }
                        : { rotate: [0, 12, 0] }
                    }
                    transition={{ duration: 0.5 }}
                    className="flex h-12 w-12 items-center justify-center rounded-full border-2 border-red-400 bg-red-500/20 text-amber-300 shadow-[0_0_20px_rgba(239,68,68,0.4)]"
                  >
                    <Scissors className="h-6 w-6" />
                  </motion.div>
                </div>

                <MiniWorker helmet="#10B981" suit="#2563EB" />
              </div>

              {/* Bright Red Ribbon Line */}
              <div className="mt-5 flex items-center justify-center gap-1">
                <motion.div
                  animate={
                    ribbonCut
                      ? { x: 32, y: 8, rotate: 14, opacity: 0.45 }
                      : { x: 0 }
                  }
                  transition={{ duration: 0.6 }}
                  className="h-3 w-32 rounded-l-full bg-red-600 border border-red-300/50 shadow-[0_0_16px_rgba(220,38,38,0.65)]"
                />
                <motion.div
                  animate={
                    ribbonCut
                      ? { x: -32, y: 8, rotate: -14, opacity: 0.45 }
                      : { x: 0 }
                  }
                  transition={{ duration: 0.6 }}
                  className="h-3 w-32 rounded-r-full bg-red-600 border border-red-300/50 shadow-[0_0_16px_rgba(220,38,38,0.65)]"
                />
              </div>
            </div>

            {ribbonCut && (
              <motion.button
                initial={{ y: 12, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                type="button"
                onClick={onBypassMaintenance}
                className="version-glow rounded-xl bg-gradient-to-l from-violet-600 to-emerald-600 px-8 py-3.5 text-sm font-extrabold text-white shadow-xl transition-transform hover:scale-[1.02] cursor-pointer"
              >
                دخول وترحيب في عراقي كودرز 26.5
              </motion.button>
            )}
          </motion.div>
        )}
      </div>

      {/* Footer Hint */}
      <div className="relative z-10 mx-auto w-full max-w-5xl text-center text-xs text-slate-500">
        عراقي كودرز · الإصدار 26.5 · اضغط على كلمة «صيانة» بالأعلى لإدخال الرمز السري
      </div>
      </div>

      {/* Secret PIN Modal */}
      {pinModalOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="نافذة رمز الصيانة السري"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm"
          onClick={() => setPinModalOpen(false)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-sm rounded-2xl border border-sky-500/40 bg-[#0E1424] p-6 shadow-2xl"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <KeyRound className="h-5 w-5 text-sky-400" />
                <h3 className="text-base font-extrabold text-white">
                  رمز الدخول السري
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setPinModalOpen(false)}
                aria-label="إغلاق"
                className="rounded-lg p-1.5 text-slate-400 hover:bg-white/10 hover:text-white cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <form onSubmit={handlePinSubmit} className="space-y-4">
              <div>
                <label
                  htmlFor="maintenance-pin"
                  className="block text-xs font-bold text-slate-300 mb-1.5"
                >
                  أدخل رمز الصيانة أو رمز المدير
                </label>
                <input
                  id="maintenance-pin"
                  type="password"
                  dir="ltr"
                  autoFocus
                  value={pinInput}
                  onChange={(e) => {
                    setPinInput(e.target.value);
                    setPinError("");
                  }}
                  placeholder="PIN..."
                  className="h-11 w-full rounded-xl border border-white/15 bg-[#0B0F19] px-4 text-center font-mono text-lg tracking-widest text-white focus:border-sky-400 focus:outline-none"
                />
              </div>

              {pinError && (
                <p className="rounded-lg border border-rose-500/35 bg-rose-500/10 px-3 py-2 text-xs font-semibold text-rose-300">
                  {pinError}
                </p>
              )}

              <button
                type="submit"
                className="w-full rounded-xl bg-sky-600 py-2.5 text-sm font-bold text-white hover:bg-sky-500 cursor-pointer"
              >
                تأكيد الرمز
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
