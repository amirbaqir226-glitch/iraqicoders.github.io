import React, { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import {
  CheckCircle2,
  Cloud,
  Coins,
  Download,
  FileArchive,
  FilePlus2,
  FolderGit2,
  Gamepad2,
  Globe,
  Lock,
  Menu,
  Smartphone,
  Sparkles,
  Terminal,
  Upload,
  X,
} from "lucide-react";
import { saveCloudBinaryBlob } from "../services/blobStore";
import {
  buildMinecraftFactoriesExpansionBlob,
  FACTORY_MAIN_SCRIPT,
} from "../services/minecraftFactoryPack";
import {
  buildAndroidApkBlob,
  buildMinecraftAddonBlob,
  buildWebSourceZipBlob,
} from "../services/packageBuilder";
import {
  CloudFileItem,
  CloudVisibility,
  UserEconomy,
  UserProfile,
} from "../types";

interface SecretCreatorConsoleProps {
  isOpen: boolean;
  user: UserProfile | null;
  economy: UserEconomy;
  isAdminPrivileged: boolean;
  privateFiles: CloudFileItem[];
  onClose: () => void;
  onSaveToCloud: (item: CloudFileItem) => void;
  onOpenStore: () => void;
  onDownloadCloudItem: (item: CloudFileItem) => void;
}

type StudioTab = "create" | "my-files";
type BuilderMode = "apk" | "web" | "minecraft" | "upload";

function triggerDownloadBlob(blob: Blob, fileName: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

const DEFAULT_APK_HTML = `<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>تطبيق عراقي كودرز</title>
  <style>
    body{margin:0;min-height:100vh;display:grid;place-items:center;background:#0B0F19;color:#F8FAFC;font-family:Cairo,sans-serif;text-align:center;padding:24px}
    .box{border:1px solid #8b5cf6;border-radius:16px;padding:24px;background:#111827;max-width:340px}
    button{background:#10b981;color:#fff;border:0;padding:10px 18px;border-radius:10px;font-weight:700;margin-top:12px;cursor:pointer}
  </style>
</head>
<body>
  <div class="box">
    <h2>تطبيق أندرويد من عراقي كودرز</h2>
    <p>تم بناء هذه الحزمة داخل وحدة المطور السرية (/)</p>
    <button onclick="document.getElementById('res').innerText='تم التفاعل بنجاح!'">اختبار التشغيل</button>
    <p id="res"></p>
  </div>
</body>
</html>`;

const PRO_APK_GAME_HTML = `<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>مغامرة دجلة APK Pro</title>
</head>
<body style="margin:0;background:#070B14;color:#fff;font-family:Cairo,sans-serif;text-align:center;padding:20px">
  <h3>لعبة نجم دجلة — نسخة APK الاحترافية</h3>
  <canvas id="c" width="320" height="260" style="border:2px solid #10b981;border-radius:12px;background:#0F172A"></canvas>
  <script>
    const c=document.getElementById('c'),x=c.getContext('2d');let px=150,score=0,stars=[{x:80,y:20},{x:220,y:100}];
    c.addEventListener('pointermove',e=>{const r=c.getBoundingClientRect();px=e.clientX-r.left-15;});
    setInterval(()=>{x.clearRect(0,0,320,260);x.fillStyle='#8b5cf6';x.fillRect(px,225,36,16);
      stars.forEach(s=>{s.y+=3;if(s.y>260){s.y=0;s.x=Math.random()*290;}
      if(s.y>215&&s.x>px-10&&s.x<px+36){score++;s.y=0;s.x=Math.random()*290;}
      x.fillStyle='#fbbf24';x.beginPath();x.arc(s.x,s.y,7,0,Math.PI*2);x.fill();});
      x.fillStyle='#34d399';x.fillText('النقاط: '+score,16,24);},24);
  </script>
</body>
</html>`;

export const SecretCreatorConsole: React.FC<SecretCreatorConsoleProps> = ({
  isOpen,
  user,
  economy,
  isAdminPrivileged,
  privateFiles,
  onClose,
  onSaveToCloud,
  onOpenStore,
  onDownloadCloudItem,
}) => {
  const [booting, setBooting] = useState(true);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [studioTab, setStudioTab] = useState<StudioTab>("create");
  const [builderMode, setBuilderMode] = useState<BuilderMode>("apk");
  const [visibility, setVisibility] = useState<CloudVisibility>("private");
  const [statusNotice, setStatusNotice] = useState("");

  // Shared metadata
  const [projectTitle, setProjectTitle] = useState("مشروعي الأول من الاستوديو");
  const [projectDesc, setProjectDesc] = useState(
    "حزمة حقيقية مُنشأة من وحدة المطور السرية (/) في عراقي كودرز 26.5"
  );

  // APK fields
  const [apkPackageId, setApkPackageId] = useState("iq.coders.baghdadapp");
  const [apkHtml, setApkHtml] = useState(DEFAULT_APK_HTML);

  // Web ZIP fields
  const [webHtml, setWebHtml] = useState(
    '<main class="hero-card">\n  <h1>موقعي العراقي الجديد</h1>\n  <p>مشروع ويب متكامل جاهز للاستضافة.</p>\n</main>'
  );
  const [webCss, setWebCss] = useState(
    "body{margin:0;min-height:100vh;display:grid;place-items:center;background:#0B0F19;color:#F1F5F9;font-family:Cairo,sans-serif;}\n.hero-card{padding:32px;border-radius:16px;border:1px solid #8b5cf6;background:#111827;text-align:center;}"
  );
  const [webJs, setWebJs] = useState(
    'console.log("Iraqi Coders Web Project Initialized!");'
  );

  // Minecraft fields
  const [mcFormat, setMcFormat] = useState<"mcpack" | "mcaddon" | "mcworld">(
    "mcaddon"
  );
  const [mcModKind, setMcModKind] = useState<"behavior" | "skin">("behavior");
  const [mcScript, setMcScript] = useState(
    'import { world } from "@minecraft/server";\n\nworld.afterEvents.playerSpawn.subscribe((ev) => {\n  ev.player.sendMessage("§aأهلاً بك في إضافة عراقي كودرز 26.5!");\n});'
  );

  // Uploaded file fields
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const uploadInputRef = useRef<HTMLInputElement>(null);

  const hasProApkTemplate =
    isAdminPrivileged ||
    economy.unlockedItems.includes("item-apk-pro-template");

  useEffect(() => {
    if (!isOpen) return;
    setBooting(true);
    setStatusNotice("");
    const timer = window.setTimeout(() => {
      setBooting(false);
    }, 1450);
    return () => window.clearTimeout(timer);
  }, [isOpen]);

  if (!isOpen) return null;

  const ownerId = user?.id || "local-guest-dev";
  const ownerName = user?.name || "مطور عراقي";
  const ownerHandle = user?.handle || "@iraqi_dev";

  const compileCurrentPackage = async (): Promise<{
    item: CloudFileItem;
    blob: Blob;
  } | null> => {
    const cleanTitle = projectTitle.trim() || "مشروع عراقي كودرز";
    const id = `studio-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;

    if (builderMode === "apk") {
      const safeFileBase =
        cleanTitle
          .replace(/[^\w\u0600-\u06FF-]+/g, "_")
          .replace(/^_+|_+$/g, "") || "iraqi_app";
      const fileName = `${safeFileBase}.apk`;
      const built = buildAndroidApkBlob({
        title: cleanTitle,
        packageId: apkPackageId,
        author: ownerName,
        htmlContent: apkHtml,
      });

      await saveCloudBinaryBlob(id, built.blob);
      const item: CloudFileItem = {
        id,
        ownerId,
        ownerName,
        ownerHandle,
        title: cleanTitle,
        description: projectDesc.trim(),
        fileName,
        fileType: "apk",
        fileSizeBytes: built.blob.size,
        content: built.previewManifest,
        visibility,
        downloads: 0,
        createdAt: "الآن",
      };
      return { item, blob: built.blob };
    }

    if (builderMode === "web") {
      const safeFileBase =
        cleanTitle
          .replace(/[^\w\u0600-\u06FF-]+/g, "_")
          .replace(/^_+|_+$/g, "") || "iraqi_web";
      const fileName = `${safeFileBase}.zip`;
      const built = buildWebSourceZipBlob({
        title: cleanTitle,
        author: ownerName,
        html: webHtml,
        css: webCss,
        js: webJs,
      });

      await saveCloudBinaryBlob(id, built.blob);
      const item: CloudFileItem = {
        id,
        ownerId,
        ownerName,
        ownerHandle,
        title: cleanTitle,
        description: projectDesc.trim(),
        fileName,
        fileType: "web",
        fileSizeBytes: built.blob.size,
        content: built.previewText,
        visibility,
        downloads: 0,
        createdAt: "الآن",
      };
      return { item, blob: built.blob };
    }

    if (builderMode === "minecraft") {
      const safeFileBase =
        cleanTitle
          .replace(/[^\w\u0600-\u06FF-]+/g, "_")
          .replace(/^_+|_+$/g, "") || "iraqi_addon";
      const fileName = `${safeFileBase}.${mcFormat}`;
      const isFactoriesScript = mcScript.includes("buildIraqiCodersMegaFactory");
      const built =
        mcFormat === "mcworld"
          ? (() => {
              const res = buildMinecraftFactoriesExpansionBlob("mcworld");
              return { blob: res.blob, previewManifest: res.previewText };
            })()
          : isFactoriesScript && mcFormat === "mcaddon"
          ? (() => {
              const res = buildMinecraftFactoriesExpansionBlob("mcaddon");
              return { blob: res.blob, previewManifest: res.previewText };
            })()
          : buildMinecraftAddonBlob({
              title: cleanTitle,
              description: projectDesc.trim(),
              author: ownerName,
              format: mcFormat === "mcpack" ? "mcpack" : "mcaddon",
              modKind: mcModKind,
              scriptCode: mcScript,
            });

      await saveCloudBinaryBlob(id, built.blob);
      const item: CloudFileItem = {
        id,
        ownerId,
        ownerName,
        ownerHandle,
        title: cleanTitle,
        description: projectDesc.trim(),
        fileName,
        fileType: "minecraft",
        fileSizeBytes: built.blob.size,
        content: built.previewManifest,
        visibility,
        downloads: 0,
        createdAt: "الآن",
      };
      return { item, blob: built.blob };
    }

    // Upload from local disk
    if (!uploadedFile) {
      setStatusNotice("الرجاء اختيار ملف من جهازك أولاً.");
      return null;
    }

    const lower = uploadedFile.name.toLowerCase();
    const inferredType = lower.endsWith(".apk")
      ? "apk"
      : lower.endsWith(".mcpack") ||
        lower.endsWith(".mcaddon") ||
        lower.endsWith(".mcworld")
      ? "minecraft"
      : lower.endsWith(".zip") || lower.endsWith(".html")
      ? "web"
      : "code";

    await saveCloudBinaryBlob(id, uploadedFile);
    const previewSnippet =
      uploadedFile.type.startsWith("text/") ||
      lower.endsWith(".lua") ||
      lower.endsWith(".html") ||
      lower.endsWith(".js")
        ? (await uploadedFile.text()).slice(0, 180000)
        : `[حزمة أصلية مرفوعة من الجهاز]\nFile: ${uploadedFile.name}\nBytes: ${uploadedFile.size}\nFormat: ${inferredType.toUpperCase()}`;

    const item: CloudFileItem = {
      id,
      ownerId,
      ownerName,
      ownerHandle,
      title: cleanTitle,
      description: projectDesc.trim(),
      fileName: uploadedFile.name,
      fileType: inferredType,
      fileSizeBytes: uploadedFile.size,
      content: previewSnippet,
      visibility,
      downloads: 0,
      createdAt: "الآن",
    };
    return { item, blob: uploadedFile };
  };

  const handleBuildAndSaveToCloud = async (e: React.FormEvent) => {
    e.preventDefault();
    const compiled = await compileCurrentPackage();
    if (!compiled) return;

    onSaveToCloud(compiled.item);
    setStatusNotice(
      `تم تجميع الحزمة «${compiled.item.fileName}» (${compiled.blob.size} بايت) وحفظها في ${
        visibility === "public" ? "سحابات الناس" : "سحابتك الخاصة"
      }!`
    );
  };

  const handleBuildAndInstantDownload = async () => {
    const compiled = await compileCurrentPackage();
    if (!compiled) return;

    triggerDownloadBlob(compiled.blob, compiled.item.fileName);
    setStatusNotice(
      `بدأ تنزيل الحزمة الحقيقية «${compiled.item.fileName}» (${compiled.blob.size} بايت) خالية من الأخطاء.`
    );
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="وحدة أوامر المطور السرية واستوديو إنشاء الملفات"
      className="fixed inset-0 z-[70] flex flex-col bg-[#05070D] text-slate-100"
    >
      {/* Stage 1: Cinematic Black Screen Transition with Central / */}
      <AnimatePresence>
        {booting && (
          <motion.div
            key="slash-boot-screen"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-black px-6 text-center"
          >
            <motion.div
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{ scale: [0.9, 1.12, 1], opacity: 1 }}
              transition={{ duration: 0.65 }}
              className="flex h-24 w-24 items-center justify-center rounded-3xl border border-emerald-400/50 bg-emerald-500/10 shadow-[0_0_50px_rgba(16,185,129,0.35)]"
            >
              <span
                dir="ltr"
                className="font-mono text-6xl font-extrabold text-emerald-400"
              >
                /
              </span>
            </motion.div>

            <p
              dir="ltr"
              className="mt-6 font-mono text-xs sm:text-sm text-emerald-300 tracking-wide"
            >
              /init iraqi-coders --creator-studio --v26.5
            </p>
            <p className="mt-2 text-xs text-slate-400">
              جارٍ تهيئة استوديو بناء التطبيقات وحزم ماينكرافت وأرشيفات الويب...
            </p>

            <div className="mt-5 h-1.5 w-60 overflow-hidden rounded-full bg-white/10">
              <motion.div
                initial={{ width: "0%" }}
                animate={{ width: "100%" }}
                transition={{ duration: 1.35, ease: "easeInOut" }}
                className="h-full bg-gradient-to-r from-violet-500 to-emerald-400"
              />
            </div>

            <button
              type="button"
              onClick={() => setBooting(false)}
              className="mt-6 rounded-lg border border-white/15 px-3 py-1.5 text-[11px] font-bold text-slate-400 hover:text-white cursor-pointer"
            >
              تخطي الدخول الفوري
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Studio Top Bar */}
      <header className="flex items-center justify-between gap-3 border-b border-white/10 bg-[#0B0F19] px-4 py-3">
        <div className="flex items-center gap-3">
          {/* Required 3-line sidebar menu toggle button */}
          <button
            type="button"
            onClick={() => setSidebarOpen((prev) => !prev)}
            aria-label="قائمة إضافة وإنشاء الملفات"
            title="قائمة إنشاء الملفات والاستوديو"
            className="inline-flex h-10 w-10 items-center justify-center rounded-xl border border-emerald-400/40 bg-emerald-500/15 text-emerald-300 hover:bg-emerald-500/25 cursor-pointer"
          >
            <Menu className="h-5 w-5" />
          </button>

          <div className="flex items-center gap-2">
            <span
              dir="ltr"
              className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-violet-400/50 bg-violet-600/20 font-mono text-base font-extrabold text-emerald-300"
            >
              /
            </span>
            <div>
              <h2 className="text-sm sm:text-base font-extrabold text-white">
                استوديو المطور السري — إنشاء وبناء الحزم
              </h2>
              <p className="text-[11px] text-slate-400 hidden sm:block">
                دليل متكامل لصناعة حزم APK ومشاريع ZIP وإضافات Minecraft بدون
                أخطاء
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onOpenStore}
            className="inline-flex items-center gap-1.5 rounded-xl border border-amber-400/40 bg-amber-500/15 px-3 py-1.5 text-xs font-extrabold text-amber-300 hover:bg-amber-500/25 cursor-pointer"
          >
            <Coins className="h-3.5 w-3.5" />
            <span>
              {isAdminPrivileged ? "∞ عملة (أمير)" : `${economy.coins} عملة`}
            </span>
          </button>

          <button
            type="button"
            onClick={onClose}
            aria-label="إغلاق الاستوديو"
            className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-rose-500/35 bg-rose-500/15 px-3 text-xs font-bold text-rose-200 hover:bg-rose-500/25 cursor-pointer"
          >
            <X className="h-4 w-4" />
            <span className="hidden sm:inline">خروج للمنصة</span>
          </button>
        </div>
      </header>

      {/* Main Studio Split Area */}
      <div className="relative flex flex-1 overflow-hidden">
        {/* 3-Line Sidebar Drawer */}
        {sidebarOpen && (
          <aside className="w-64 shrink-0 border-l border-white/10 bg-[#0A0E18] p-4 flex flex-col justify-between overflow-y-auto">
            <div className="space-y-2">
              <p className="px-2 text-[11px] font-bold text-slate-400">
                قائمة الاستوديو (≡)
              </p>

              <button
                type="button"
                onClick={() => setStudioTab("create")}
                className={`flex w-full items-center gap-2.5 rounded-xl px-3.5 py-2.5 text-xs font-extrabold transition-colors cursor-pointer ${
                  studioTab === "create"
                    ? "bg-emerald-600 text-white"
                    : "text-slate-300 hover:bg-white/5 hover:text-white"
                }`}
              >
                <FilePlus2 className="h-4 w-4 shrink-0" />
                <span>إضافة ملف / إنشاء ملف</span>
              </button>

              <button
                type="button"
                onClick={() => setStudioTab("my-files")}
                className={`flex w-full items-center gap-2.5 rounded-xl px-3.5 py-2.5 text-xs font-extrabold transition-colors cursor-pointer ${
                  studioTab === "my-files"
                    ? "bg-violet-600 text-white"
                    : "text-slate-300 hover:bg-white/5 hover:text-white"
                }`}
              >
                <FolderGit2 className="h-4 w-4 shrink-0" />
                <span>ملفاتي السحابية ({privateFiles.length})</span>
              </button>

              <button
                type="button"
                onClick={onOpenStore}
                className="flex w-full items-center gap-2.5 rounded-xl px-3.5 py-2.5 text-xs font-extrabold text-amber-300 hover:bg-amber-500/10 cursor-pointer"
              >
                <Coins className="h-4 w-4 shrink-0" />
                <span>متجر العملات والسكنات</span>
              </button>
            </div>

            <div className="rounded-xl border border-white/10 bg-[#0E1424] p-3 space-y-1.5 text-[11px] text-slate-400">
              <p className="font-bold text-emerald-300 flex items-center gap-1.5">
                <Terminal className="h-3.5 w-3.5" />
                <span>محرك الحزم الحقيقية</span>
              </p>
              <p className="leading-relaxed">
                يتم تجميع ملفاتك بصيغة PKZIP القياسية مع CRC32 وملفات Manifest
                صحيحة لتجنب خطأ «حزمة غير مطابقة».
              </p>
            </div>
          </aside>
        )}

        {/* Workspace Content */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          <div className="mx-auto max-w-4xl space-y-6">
            {statusNotice && (
              <div className="flex items-center gap-2 rounded-xl border border-emerald-400/45 bg-emerald-500/15 px-4 py-3 text-xs font-bold text-emerald-200">
                <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-400" />
                <span>{statusNotice}</span>
              </div>
            )}

            {studioTab === "create" ? (
              <form
                onSubmit={(e) => void handleBuildAndSaveToCloud(e)}
                className="space-y-6"
              >
                {/* Step 1: Select Creation Type */}
                <section className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-extrabold text-white">
                      1. اختر نوع الملف الذي تريد إنشاءه أو رفعه
                    </h3>
                    <span className="text-[11px] text-slate-400">
                      مناسب للمبتدئين والمحترفين
                    </span>
                  </div>

                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
                    {(
                      [
                        {
                          id: "apk",
                          title: "تطبيق / لعبة أندرويد",
                          ext: ".apk",
                          icon: Smartphone,
                          color: "emerald",
                        },
                        {
                          id: "web",
                          title: "موقع ويب متكامل",
                          ext: ".zip",
                          icon: Globe,
                          color: "sky",
                        },
                        {
                          id: "minecraft",
                          title: "مود / عالم ماينكرافت",
                          ext: ".mcaddon / .mcworld",
                          icon: Gamepad2,
                          color: "violet",
                        },
                        {
                          id: "upload",
                          title: "رفع ملف جاهز من جهازك",
                          ext: "APK / ZIP / MCADDON",
                          icon: Upload,
                          color: "amber",
                        },
                      ] as const
                    ).map((card) => {
                      const Icon = card.icon;
                      const active = builderMode === card.id;
                      return (
                        <button
                          key={card.id}
                          type="button"
                          onClick={() => setBuilderMode(card.id)}
                          className={`rounded-2xl border p-4 text-right transition-all cursor-pointer ${
                            active
                              ? "border-emerald-400 bg-emerald-500/15 shadow-lg"
                              : "border-white/10 bg-[#0E1424] hover:border-white/25"
                          }`}
                        >
                          <Icon
                            className={`h-5 w-5 mb-2 ${
                              active ? "text-emerald-300" : "text-slate-400"
                            }`}
                          />
                          <p className="text-xs font-extrabold text-white">
                            {card.title}
                          </p>
                          <p
                            dir="ltr"
                            className="mt-1 font-mono text-[11px] text-emerald-300 text-right"
                          >
                            {card.ext}
                          </p>
                        </button>
                      );
                    })}
                  </div>
                </section>

                {/* Step 2: Project Details */}
                <section className="rounded-2xl border border-white/10 bg-[#0E1424] p-5 space-y-4">
                  <h3 className="text-sm font-extrabold text-white">
                    2. بيانات المشروع الأساسية
                  </h3>

                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1.5">
                        اسم التطبيق أو المشروع
                      </label>
                      <input
                        type="text"
                        required
                        value={projectTitle}
                        onChange={(e) => setProjectTitle(e.target.value)}
                        className="h-10 w-full rounded-xl border border-white/10 bg-[#080C15] px-3 text-xs text-white focus:border-emerald-400 focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1.5">
                        الخصوصية عند الحفظ في السحابة
                      </label>
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          type="button"
                          onClick={() => setVisibility("private")}
                          className={`inline-flex h-10 items-center justify-center gap-1.5 rounded-xl border text-xs font-bold cursor-pointer ${
                            visibility === "private"
                              ? "border-violet-400 bg-violet-600 text-white"
                              : "border-white/10 bg-[#080C15] text-slate-300"
                          }`}
                        >
                          <Lock className="h-3.5 w-3.5" />
                          <span>سحابتي الخاصة</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setVisibility("public")}
                          className={`inline-flex h-10 items-center justify-center gap-1.5 rounded-xl border text-xs font-bold cursor-pointer ${
                            visibility === "public"
                              ? "border-emerald-400 bg-emerald-600 text-white"
                              : "border-white/10 bg-[#080C15] text-slate-300"
                          }`}
                        >
                          <Globe className="h-3.5 w-3.5" />
                          <span>سحابات الناس</span>
                        </button>
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1.5">
                      وصف المشروع
                    </label>
                    <input
                      type="text"
                      value={projectDesc}
                      onChange={(e) => setProjectDesc(e.target.value)}
                      className="h-10 w-full rounded-xl border border-white/10 bg-[#080C15] px-3 text-xs text-white focus:border-emerald-400 focus:outline-none"
                    />
                  </div>
                </section>

                {/* Step 3: Format-Specific Guided Builder */}
                <section className="rounded-2xl border border-white/10 bg-[#0E1424] p-5 space-y-4">
                  <h3 className="text-sm font-extrabold text-white">
                    3. إعدادات الحزمة البرمجية والتجميع
                  </h3>

                  {builderMode === "apk" && (
                    <div className="space-y-4">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="flex-1 min-w-[220px]">
                          <label className="block text-xs font-bold text-slate-300 mb-1">
                            معرّف الحزمة (Android Package ID)
                          </label>
                          <input
                            type="text"
                            dir="ltr"
                            value={apkPackageId}
                            onChange={(e) => setApkPackageId(e.target.value)}
                            className="h-10 w-full rounded-xl border border-white/10 bg-[#080C15] px-3 font-mono text-xs text-emerald-300 focus:border-emerald-400 focus:outline-none"
                          />
                        </div>

                        <div className="flex items-center gap-2 pt-5">
                          <button
                            type="button"
                            onClick={() => setApkHtml(DEFAULT_APK_HTML)}
                            className="rounded-xl border border-white/15 bg-white/5 px-3 py-2 text-xs font-bold text-slate-200 hover:bg-white/10 cursor-pointer"
                          >
                            قالب تطبيق أساسي
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              if (!hasProApkTemplate) {
                                onOpenStore();
                                return;
                              }
                              setApkHtml(PRO_APK_GAME_HTML);
                            }}
                            className={`inline-flex items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-extrabold cursor-pointer ${
                              hasProApkTemplate
                                ? "border border-amber-400/45 bg-amber-500/15 text-amber-300 hover:bg-amber-500/25"
                                : "border border-white/10 bg-white/5 text-slate-400"
                            }`}
                          >
                            <Sparkles className="h-3.5 w-3.5" />
                            <span>
                              {hasProApkTemplate
                                ? "قالب لعبة APK Pro (مفتوح)"
                                : "قالب لعبة Pro (من المتجر)"}
                            </span>
                          </button>
                        </div>
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-slate-300 mb-1">
                          واجهة التطبيق الداخلية (assets/www/index.html)
                        </label>
                        <textarea
                          dir="ltr"
                          rows={8}
                          value={apkHtml}
                          onChange={(e) => setApkHtml(e.target.value)}
                          className="w-full rounded-xl border border-white/10 bg-[#080C15] p-3 font-mono text-xs text-emerald-200 focus:border-emerald-400 focus:outline-none"
                        />
                      </div>
                    </div>
                  )}

                  {builderMode === "web" && (
                    <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
                      <div>
                        <label className="block text-xs font-bold text-slate-300 mb-1">
                          index.html
                        </label>
                        <textarea
                          dir="ltr"
                          rows={7}
                          value={webHtml}
                          onChange={(e) => setWebHtml(e.target.value)}
                          className="w-full rounded-xl border border-white/10 bg-[#080C15] p-3 font-mono text-xs text-sky-200 focus:border-sky-400 focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-300 mb-1">
                          styles.css
                        </label>
                        <textarea
                          dir="ltr"
                          rows={7}
                          value={webCss}
                          onChange={(e) => setWebCss(e.target.value)}
                          className="w-full rounded-xl border border-white/10 bg-[#080C15] p-3 font-mono text-xs text-violet-200 focus:border-violet-400 focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-300 mb-1">
                          script.js
                        </label>
                        <textarea
                          dir="ltr"
                          rows={7}
                          value={webJs}
                          onChange={(e) => setWebJs(e.target.value)}
                          className="w-full rounded-xl border border-white/10 bg-[#080C15] p-3 font-mono text-xs text-emerald-200 focus:border-emerald-400 focus:outline-none"
                        />
                      </div>
                    </div>
                  )}

                  {builderMode === "minecraft" && (
                    <div className="space-y-4">
                      <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-cyan-500/30 bg-[#070B15] p-3">
                        <span className="text-xs font-bold text-cyan-200">
                          قالب جاهز: توسعة مصنع آيرون كودرز الكبير + Factory A
                        </span>
                        <button
                          type="button"
                          onClick={() => {
                            setProjectTitle("Iraqi Coders Mega Factories");
                            setProjectDesc(
                              "توسعة ماينكرافت Bedrock 1.21+ (أندرويد 14) لبناء مصنع آيرون كودرز RGB ومصنع A الكبير عند نقطة السباون."
                            );
                            setMcFormat("mcworld");
                            setMcModKind("behavior");
                            setMcScript(FACTORY_MAIN_SCRIPT);
                            setStatusNotice(
                              "تم تحميل كود المصانع العملاقة بنجاح! يمكنك التعديل أو التصدير كـ .mcworld أو .mcaddon."
                            );
                          }}
                          className="rounded-lg bg-cyan-600 px-3 py-1.5 text-[11px] font-extrabold text-white hover:bg-cyan-500 cursor-pointer"
                        >
                          تحميل قالب المصانع العملاقة
                        </button>
                      </div>

                      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                        <div>
                          <label className="block text-xs font-bold text-slate-300 mb-1">
                            صيغة ملف ماينكرافت
                          </label>
                          <select
                            value={mcFormat}
                            onChange={(e) =>
                              setMcFormat(
                                e.target.value as "mcpack" | "mcaddon" | "mcworld"
                              )
                            }
                            className="h-10 w-full rounded-xl border border-white/10 bg-[#080C15] px-3 text-xs text-white"
                          >
                            <option value="mcaddon">
                              حزمة كاملة (.mcaddon - Behavior + Resource)
                            </option>
                            <option value="mcworld">
                              عالم جاهز بالمصانع (.mcworld - World + Packs)
                            </option>
                            <option value="mcpack">
                              حزمة مفردة (.mcpack - Pack أو Skin)
                            </option>
                          </select>
                        </div>

                        <div>
                          <label className="block text-xs font-bold text-slate-300 mb-1">
                            نوع المحتوى داخل الحزمة
                          </label>
                          <select
                            value={mcModKind}
                            onChange={(e) =>
                              setMcModKind(
                                e.target.value as "behavior" | "skin"
                              )
                            }
                            className="h-10 w-full rounded-xl border border-white/10 bg-[#080C15] px-3 text-xs text-white"
                          >
                            <option value="behavior">
                              مود برمجي (Script API + Manifest v2)
                            </option>
                            <option value="skin">
                              حزمة سكنات (Skin Pack + skins.json)
                            </option>
                          </select>
                        </div>
                      </div>

                      {mcModKind === "behavior" && (
                        <div>
                          <label className="block text-xs font-bold text-slate-300 mb-1">
                            كود السكربت (scripts/main.js — @minecraft/server)
                          </label>
                          <textarea
                            dir="ltr"
                            rows={6}
                            value={mcScript}
                            onChange={(e) => setMcScript(e.target.value)}
                            className="w-full rounded-xl border border-white/10 bg-[#080C15] p-3 font-mono text-xs text-violet-200 focus:border-violet-400 focus:outline-none"
                          />
                        </div>
                      )}
                    </div>
                  )}

                  {builderMode === "upload" && (
                    <div className="rounded-2xl border border-dashed border-amber-400/45 bg-[#080C15] p-6 text-center space-y-3">
                      <FileArchive className="mx-auto h-10 w-10 text-amber-300" />
                      <div>
                        <p className="text-sm font-extrabold text-white">
                          اختر ملفاً حقيقياً من جهازك (.apk, .zip, .mcpack,
                          .mcaddon, .lua)
                        </p>
                        <p className="mt-1 text-xs text-slate-400">
                          يتم حفظ الملف بحالته الأصلية داخل قاعدة البيانات
                          السريعة بدون تعديل أو إتلاف البنية.
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => uploadInputRef.current?.click()}
                        className="inline-flex items-center gap-2 rounded-xl bg-amber-500 px-5 py-2.5 text-xs font-extrabold text-slate-950 hover:bg-amber-400 cursor-pointer"
                      >
                        <Upload className="h-4 w-4" />
                        <span>استعراض الملفات</span>
                      </button>
                      <input
                        ref={uploadInputRef}
                        type="file"
                        accept=".apk,.aab,.zip,.mcpack,.mcaddon,.mcworld,.lua,.html,.js,.json"
                        onChange={(e) => {
                          const picked = e.target.files?.[0] || null;
                          setUploadedFile(picked);
                          if (picked) {
                            setProjectTitle(picked.name.replace(/\.[^.]+$/, ""));
                          }
                        }}
                        className="hidden"
                      />
                      {uploadedFile && (
                        <p className="text-xs font-bold text-emerald-300">
                          تم اختيار: {uploadedFile.name} (
                          {Math.max(1, Math.round(uploadedFile.size / 1024))}{" "}
                          KB)
                        </p>
                      )}
                    </div>
                  )}
                </section>

                {/* Action Buttons */}
                <div className="flex flex-wrap items-center justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => void handleBuildAndInstantDownload()}
                    className="inline-flex items-center gap-2 rounded-xl border border-emerald-400/50 bg-emerald-500/15 px-5 py-3 text-xs font-extrabold text-emerald-200 hover:bg-emerald-500/25 cursor-pointer"
                  >
                    <Download className="h-4 w-4" />
                    <span>بناء وتنزيل مباشر على جهازي</span>
                  </button>

                  <button
                    type="submit"
                    className="inline-flex items-center gap-2 rounded-xl bg-violet-600 px-6 py-3 text-xs font-extrabold text-white shadow-lg hover:bg-violet-500 cursor-pointer"
                  >
                    <Cloud className="h-4 w-4" />
                    <span>تجميع وحفظ في السحابة</span>
                  </button>
                </div>
              </form>
            ) : (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-extrabold text-white">
                    ملفاتي المحفوظة في السحابة ({privateFiles.length})
                  </h3>
                  <button
                    type="button"
                    onClick={() => setStudioTab("create")}
                    className="inline-flex items-center gap-1.5 rounded-xl bg-emerald-600 px-4 py-2 text-xs font-extrabold text-white hover:bg-emerald-500 cursor-pointer"
                  >
                    <FilePlus2 className="h-4 w-4" />
                    <span>إنشاء ملف جديد</span>
                  </button>
                </div>

                {privateFiles.length === 0 ? (
                  <div className="rounded-2xl border border-dashed border-white/15 bg-[#0E1424] p-10 text-center text-sm text-slate-400">
                    لا توجد ملفات في سحابتك الخاصة بعد. أنشئ أول حزمة من تبويب
                    «إضافة ملف / إنشاء ملف».
                  </div>
                ) : (
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    {privateFiles.map((file) => (
                      <div
                        key={file.id}
                        className="rounded-2xl border border-white/10 bg-[#0E1424] p-4 flex flex-col justify-between gap-3"
                      >
                        <div>
                          <div className="flex items-center justify-between gap-2 mb-1">
                            <span className="text-xs font-extrabold text-white">
                              {file.title}
                            </span>
                            <span
                              dir="ltr"
                              className="font-mono text-[11px] text-emerald-300"
                            >
                              {file.fileName}
                            </span>
                          </div>
                          <p className="text-xs text-slate-400 line-clamp-2">
                            {file.description}
                          </p>
                        </div>

                        <button
                          type="button"
                          onClick={() => onDownloadCloudItem(file)}
                          className="inline-flex w-full items-center justify-center gap-1.5 rounded-xl bg-emerald-600 py-2 text-xs font-extrabold text-white hover:bg-emerald-500 cursor-pointer"
                        >
                          <Download className="h-3.5 w-3.5" />
                          <span>تنزيل الحزمة</span>
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
};
