import React, { useState } from "react";
import { ArrowLeft, Code2, Sparkles } from "lucide-react";
import { HERO_BANNER_IMAGE } from "../data/initialData";
import { BETA_PROGRAMMING_LANGUAGES, SITE_INFO } from "../data/siteConfig";
import { ProgrammingLanguageId } from "../types";

interface HeroSectionProps {
  displayVersion: string;
  projectCount: number;
  postCount: number;
  codeRunsCount: number;
  totalDownloads: number;
  fantasyMode?: boolean;
  betaEnabled?: boolean;
  activeProgLang?: ProgrammingLanguageId;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  displayVersion,
  projectCount,
  postCount,
  codeRunsCount,
  totalDownloads,
  fantasyMode = false,
  betaEnabled = false,
  activeProgLang = "javascript",
}) => {
  const [imgFailed, setImgFailed] = useState(false);

  const langInfo = BETA_PROGRAMMING_LANGUAGES.find(
    (l) => l.id === activeProgLang
  );

  const stats = [
    { label: "مشاريع Roblox و Minecraft", value: projectCount.toLocaleString("en-US") },
    { label: "مناقشات المجتمع النشطة", value: postCount.toLocaleString("en-US") },
    { label: "مرات تشغيل الكود المباشر", value: codeRunsCount.toLocaleString("en-US") },
    { label: "إجمالي التحميلات البرمجية", value: totalDownloads.toLocaleString("en-US") },
  ];

  return (
    <section
      id="hero"
      className="relative overflow-hidden border-b border-white/10 pt-10 pb-14 lg:pt-16 lg:pb-20"
    >
      {/* Subtle Background Ambient Glow */}
      <div
        aria-hidden="true"
        className={`pointer-events-none absolute -top-24 left-1/2 h-96 w-[760px] -translate-x-1/2 rounded-full blur-3xl ${
          fantasyMode ? "bg-pink-500/20" : "bg-violet-700/15"
        }`}
      />

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="desktop-grid-12 grid grid-cols-1 gap-8 lg:grid-cols-12 lg:gap-10 lg:items-stretch">
          {/* Primary Text Column */}
          <div className="desktop-col-span-6 flex flex-col justify-center lg:col-span-6 min-w-0">
            <div className="mb-5 flex flex-wrap items-center gap-2 text-xs font-semibold text-slate-400">
              <span className="text-emerald-400">
                {fantasyMode ? "عالم خيال عراقي كودرز ✨" : "منصة المطورين العراقيين"}
              </span>
              <span aria-hidden="true">·</span>
              <span className="font-mono tabular-nums">الإصدار {displayVersion}</span>
              <span aria-hidden="true">·</span>
              <span>Talk to Iraqi Bots ومختبر الكود والتحديات</span>
              {betaEnabled && langInfo && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="rounded bg-fuchsia-500/20 border border-fuchsia-400/40 px-2 py-0.5 text-[11px] font-mono font-bold text-fuchsia-200">
                    لغة المحرك: {langInfo.name}
                  </span>
                </>
              )}
            </div>

            <h1
              className={`font-extrabold tracking-tight leading-[1.22] mb-5 ${
                fantasyMode
                  ? "bg-gradient-to-l from-pink-200 via-white to-sky-200 bg-clip-text text-transparent"
                  : "text-white"
              }`}
              style={{
                fontSize: "clamp(2.1rem, 4vw, 3.5rem)",
                textWrap: "balance",
              }}
            >
              {fantasyMode
                ? "عالم الخيال والحلويات: انشئ مواقع، تطبيقات، ألعاباً، وتحديات لا تنتهي"
                : "انشئ مواقع، تطبيقات، ألعاباً، وخدمات متكاملة من مكان واحد"}
            </h1>

            <p className="max-w-2xl text-base leading-relaxed text-slate-300 mb-8">
              الإصدار <span className="font-mono tabular-nums">{displayVersion}</span> من عراقي كودرز يجمع استوديو الخلق الشامل{" "}
              <strong className="text-emerald-300">«انشئ كل شيء»</strong> لتوليد مواقع ويب كاملة، تطبيقات أندرويد APK، خوادم API، إضافات متصفح، قسم التحديات، ومهندس الأكواد مع محرر الكود السري ومركز البيانات.
            </p>

            {/* Primary CTA: Omni-Creator Studio + External Chat + Live Playground */}
            <div className="flex flex-wrap items-center gap-3">
              <a
                href="#omni-studio"
                className="version-glow inline-flex items-center gap-2 rounded-xl bg-gradient-to-l from-violet-600 to-emerald-600 px-6 py-3.5 text-sm font-extrabold text-white shadow-lg transition-transform duration-150 hover:-translate-y-0.5 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Sparkles className="h-4 w-4" />
                <span>انشئ موقع أو تطبيق الآن</span>
              </a>

              <a
                href={SITE_INFO.botExternalUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 rounded-xl border border-emerald-400/35 bg-emerald-500/15 px-5 py-3.5 text-sm font-bold text-emerald-200 transition-colors hover:bg-emerald-500/25 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <span>{SITE_INFO.botButtonLabel}</span>
              </a>

              <a
                href="#playground"
                className="inline-flex items-center gap-2 rounded-xl border border-white/15 bg-white/5 px-5 py-3.5 text-sm font-bold text-slate-200 transition-colors hover:border-violet-500/40 hover:text-white whitespace-nowrap shrink-0"
              >
                <Code2 className="h-4 w-4 text-violet-400" />
                <span>محرر الكود</span>
                <ArrowLeft className="h-4 w-4" />
              </a>
            </div>
          </div>

          {/* Visual Showcase Column */}
          <div className="desktop-col-span-6 lg:col-span-6 min-w-0">
            <div className="relative h-full min-h-[280px] overflow-hidden rounded-2xl border border-white/10 bg-[#111827]">
              {!imgFailed ? (
                <img
                  src={HERO_BANNER_IMAGE}
                  alt="استوديو تطوير برمجيات حديث يطل على نهر دجلة في بغداد"
                  referrerPolicy="no-referrer"
                  onError={() => setImgFailed(true)}
                  className="h-full w-full object-cover lg:h-full"
                />
              ) : (
                <div className="flex h-full min-h-[300px] flex-col items-center justify-center bg-gradient-to-br from-violet-950 via-[#0B0F19] to-emerald-950 p-8 text-center">
                  <Code2 className="h-12 w-12 text-violet-400 mb-3" />
                  <p className="text-lg font-bold text-white">استوديو عراق كودرز</p>
                  <p className="text-sm text-slate-400">الإصدار {displayVersion}</p>
                </div>
              )}
              <div
                aria-hidden="true"
                className="absolute inset-0 bg-gradient-to-t from-[#0B0F19]/90 via-[#0B0F19]/20 to-transparent"
              />
              <div className="absolute bottom-5 right-5 left-5 flex items-end justify-between gap-4">
                <div>
                  <p className="text-xs font-semibold text-emerald-300 mb-1">
                    بغداد · البصرة · أربيل · النجف
                  </p>
                  <p className="text-base font-bold text-white">
                    اليوم رفعت علم · تطوير فوري بالذكاء الاصطناعي و Luau
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Full-Width 4-Column Live Statistics Strip */}
        <div className="desktop-grid-4 mt-10 grid grid-cols-2 gap-4 lg:grid-cols-4">
          {stats.map((stat) => (
            <div
              key={stat.label}
              className="glass-surface rounded-xl px-5 py-4 transition-colors hover:border-violet-500/30"
            >
              <div className="text-2xl font-extrabold text-white tabular-nums sm:text-3xl">
                {stat.value}
              </div>
              <div className="mt-1 text-xs font-medium text-slate-400 sm:text-sm">
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
