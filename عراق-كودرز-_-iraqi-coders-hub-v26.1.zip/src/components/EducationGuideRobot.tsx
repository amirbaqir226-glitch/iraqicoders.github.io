import React, { useEffect, useState } from "react";
import { Bot, CheckCircle2, Sparkles, Volume2, VolumeX, X } from "lucide-react";
import { speakArabicText, stopArabicSpeech } from "../services/speechEngine";

interface EducationGuideRobotProps {
  isVisible: boolean;
  onSkipForever: () => void;
}

const WELCOME_SPEECH =
  "هلو، أني المساعد الشخصي لك، راح أساعدك وأعلمك كل شيء بالموقع";

function describeClickedElement(target: HTMLElement): string | null {
  const actionable = target.closest(
    "button, a, summary, [role='button'], [data-guide-hint], section[id]"
  ) as HTMLElement | null;
  if (!actionable) return null;

  const customHint = actionable.getAttribute("data-guide-hint");
  if (customHint) return customHint;

  const href = actionable.getAttribute("href") || "";
  if (href.includes("gemini.google.com")) {
    return "هذا زر «Talk to Iraqi Bots» الذي يفتح لك مساعد البرمجة الخارجي مباشرة في تبويب جديد.";
  }
  if (href === "#challenges") {
    return "هذا قسم التحديات حيث يطرح المطورون والمسؤولون تحديات برمجية تفاعلية مع أزرار نعم ولا والتعليقات.";
  }
  if (href === "#omni-studio") {
    return "هذا استوديو «انشئ كل شيء» لبناء المواقع والتطبيقات والألعاب وتصدير الحزم بالذكاء الاصطناعي.";
  }
  if (href === "#shop") {
    return "هذا متجر عراقي كودرز لاقتناء الخدمات والأنظمة وحزم الألعاب وإتمام الطلبات.";
  }
  if (href === "#playground") {
    return "هذا محرر الكود المباشر لكتابة وتجربة HTML و CSS و JavaScript فوراً داخل الموقع.";
  }

  const label =
    actionable.getAttribute("aria-label") ||
    actionable.getAttribute("title") ||
    actionable.textContent?.replace(/\s+/g, " ").trim() ||
    "";

  if (!label || label.length > 90) {
    const section = target.closest("section[id]");
    const secId = section?.getAttribute("id");
    if (secId === "challenges") {
      return "أنت الآن داخل قسم التحديات البرمجية، يمكنك الإجابة على الأسئلة بالأخضر والأحمر وكتابة تعليقك.";
    }
    if (secId === "beta-hub") {
      return "أنت داخل مركز النسخة التجريبية الذي يضم تحديث مدرسة ميسون للبنين ولعبة البقاء وإعدادات بلس.";
    }
    return null;
  }

  return `الزر أو العنصر «${label}» مخصص للتفاعل المباشر وتنفيذ هذه المهمة داخل عراقي كودرز.`;
}

export const EducationGuideRobot: React.FC<EducationGuideRobotProps> = ({
  isVisible,
  onSkipForever,
}) => {
  const [speechText, setSpeechText] = useState(WELCOME_SPEECH);
  const [voiceMuted, setVoiceMuted] = useState(false);

  // Welcome greeting spoken once when robot mounts & becomes visible
  useEffect(() => {
    if (!isVisible) return;
    setSpeechText(WELCOME_SPEECH);
    if (!voiceMuted) {
      speakArabicText(WELCOME_SPEECH, { voiceProfile: "robot-male", pitch: 0.94 });
    }
    return () => {
      stopArabicSpeech();
    };
  }, [isVisible]);

  // Global listener that explains any clicked button/element inside the site
  useEffect(() => {
    if (!isVisible) return;

    const handleDocumentClick = (event: MouseEvent) => {
      const target = event.target as HTMLElement | null;
      if (!target) return;
      if (target.closest("[data-edu-robot='true']")) return;

      const explanation = describeClickedElement(target);
      if (!explanation) return;
      setSpeechText(explanation);
      if (!voiceMuted) {
        speakArabicText(explanation, { voiceProfile: "robot-male", pitch: 0.95 });
      }
    };

    document.addEventListener("click", handleDocumentClick, true);
    return () => {
      document.removeEventListener("click", handleDocumentClick, true);
    };
  }, [isVisible, voiceMuted]);

  if (!isVisible) return null;

  return (
    <aside
      data-edu-robot="true"
      aria-label="الروبوت المعلم الشخصي"
      className="fixed bottom-4 right-4 z-45 w-[calc(100vw-2rem)] max-w-md rounded-2xl border border-emerald-400/50 bg-[#0D1526]/95 p-4 shadow-[0_18px_50px_rgba(16,185,129,0.28)] backdrop-blur-md"
    >
      <div className="flex items-start gap-3">
        {/* Cute Mini AI Robot Avatar */}
        <div className="relative flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl border border-emerald-400/45 bg-gradient-to-br from-violet-600/35 to-emerald-500/35 text-emerald-300 shadow-inner">
          <Bot className="h-7 w-7" />
          <span className="absolute -top-1 -right-1 h-3 w-3 rounded-full border-2 border-[#0D1526] bg-emerald-400 animate-pulse" />
        </div>

        <div className="min-w-0 flex-1 space-y-2">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-1.5">
              <Sparkles className="h-3.5 w-3.5 text-emerald-400 shrink-0" />
              <span className="text-xs font-extrabold text-emerald-300">
                المساعد التعليمي · قانون التعليم الذكي
              </span>
            </div>

            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => {
                  const next = !voiceMuted;
                  setVoiceMuted(next);
                  if (next) stopArabicSpeech();
                  else speakArabicText(speechText, { voiceProfile: "robot-male" });
                }}
                title={voiceMuted ? "تشغيل صوت الروبوت" : "كتم صوت الروبوت"}
                aria-label={voiceMuted ? "تشغيل صوت الروبوت" : "كتم صوت الروبوت"}
                className="inline-flex h-7 w-7 items-center justify-center rounded-lg border border-white/10 bg-white/5 text-slate-300 hover:text-white cursor-pointer"
              >
                {voiceMuted ? (
                  <VolumeX className="h-3.5 w-3.5 text-rose-300" />
                ) : (
                  <Volume2 className="h-3.5 w-3.5 text-emerald-300" />
                )}
              </button>
              <button
                type="button"
                onClick={() => {
                  stopArabicSpeech();
                  onSkipForever();
                }}
                title="تخطي للأبد"
                aria-label="تخطي المساعد للأبد"
                className="inline-flex h-7 w-7 items-center justify-center rounded-lg border border-white/10 bg-white/5 text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>

          <p className="rounded-xl border border-white/10 bg-[#080C15] px-3 py-2 text-xs font-bold leading-relaxed text-slate-100">
            «{speechText}»
          </p>

          <div className="flex flex-wrap items-center justify-between gap-2 pt-0.5">
            <span className="text-[11px] text-slate-400">
              اضغط على أي زر أو قسم لأشرح لك وظيفته فوراً
            </span>

            <button
              type="button"
              onClick={() => {
                stopArabicSpeech();
                onSkipForever();
              }}
              className="inline-flex items-center gap-1.5 rounded-xl bg-amber-500/20 border border-amber-400/50 px-3 py-1.5 text-xs font-extrabold text-amber-200 transition-colors hover:bg-amber-500/30 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <CheckCircle2 className="h-3.5 w-3.5" />
              <span>تخطي (أنا أعلم لا أحتاج)</span>
            </button>
          </div>
        </div>
      </div>
    </aside>
  );
};
