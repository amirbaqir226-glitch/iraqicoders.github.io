import React, { useEffect, useState } from "react";
import { AnimatePresence, motion } from "motion/react";

interface LaunchCelebrationProps {
  isOpen: boolean;
  onDismiss: () => void;
}

const CONFETTI_PIECES = [
  { id: 1, x: "10%", delay: 0.4, color: "#CE1126" },
  { id: 2, x: "20%", delay: 0.55, color: "#FFFFFF" },
  { id: 3, x: "32%", delay: 0.48, color: "#10B981" },
  { id: 4, x: "45%", delay: 0.62, color: "#8B5CF6" },
  { id: 5, x: "56%", delay: 0.42, color: "#CE1126" },
  { id: 6, x: "68%", delay: 0.58, color: "#10B981" },
  { id: 7, x: "78%", delay: 0.5, color: "#FFFFFF" },
  { id: 8, x: "88%", delay: 0.65, color: "#8B5CF6" },
  { id: 9, x: "25%", delay: 0.75, color: "#F59E0B" },
  { id: 10, x: "62%", delay: 0.72, color: "#F59E0B" },
  { id: 11, x: "39%", delay: 0.8, color: "#34D399" },
  { id: 12, x: "82%", delay: 0.78, color: "#A78BFA" },
];

const CartoonWorker: React.FC<{
  helmetColor: string;
  shirtColor: string;
  flip?: boolean;
}> = ({ helmetColor, shirtColor, flip = false }) => (
  <svg
    viewBox="0 0 80 100"
    className={`h-24 w-20 sm:h-28 sm:w-24 ${flip ? "-scale-x-100" : ""}`}
    aria-hidden="true"
  >
    {/* Hardhat */}
    <path d="M22 26 C22 12, 58 12, 58 26 Z" fill={helmetColor} />
    <rect x="18" y="24" width="44" height="5" rx="2.5" fill={helmetColor} />
    {/* Head */}
    <circle cx="40" cy="37" r="11" fill="#F3C69F" />
    {/* Eyes & Smile */}
    <circle cx="36" cy="36" r="1.7" fill="#1E293B" />
    <circle cx="44" cy="36" r="1.7" fill="#1E293B" />
    <path
      d="M36 41 Q40 45 44 41"
      fill="none"
      stroke="#1E293B"
      strokeWidth="1.8"
      strokeLinecap="round"
    />
    {/* Torso / Overalls */}
    <rect x="27" y="49" width="26" height="26" rx="6" fill={shirtColor} />
    <rect x="31" y="57" width="18" height="18" rx="3" fill="#1E293B" opacity="0.4" />
    {/* Arms */}
    <rect x="16" y="50" width="11" height="6" rx="3" fill="#F3C69F" />
    <rect x="53" y="50" width="11" height="6" rx="3" fill="#F3C69F" />
    {/* Legs */}
    <rect x="30" y="75" width="7" height="16" rx="3" fill="#334155" />
    <rect x="43" y="75" width="7" height="16" rx="3" fill="#334155" />
    {/* Boots */}
    <rect x="28" y="88" width="10" height="5" rx="2" fill="#0F172A" />
    <rect x="42" y="88" width="10" height="5" rx="2" fill="#0F172A" />
  </svg>
);

export const LaunchCelebration: React.FC<LaunchCelebrationProps> = ({
  isOpen,
  onDismiss,
}) => {
  const [upgraded, setUpgraded] = useState(false);

  useEffect(() => {
    if (!isOpen) return;
    setUpgraded(false);
    const timer = window.setTimeout(() => {
      setUpgraded(true);
    }, 1050);
    return () => window.clearTimeout(timer);
  }, [isOpen]);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.25 }}
          role="dialog"
          aria-modal="true"
          aria-label="احتفالية إطلاق الإصدار 26.2"
          className="fixed inset-0 z-50 flex flex-col items-center justify-between bg-[#070A12]/92 p-4 backdrop-blur-md overflow-hidden"
        >
          {/* Top Notification Banner: "اليوم رفعت علم" + "تم" button */}
          <motion.div
            initial={{ y: -32, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
            className="relative z-20 mt-2 flex w-full max-w-2xl items-center justify-between gap-4 rounded-2xl border border-emerald-500/40 bg-[#0E1424]/95 px-5 py-3.5 shadow-2xl"
          >
            <div className="flex items-center gap-3">
              {/* Iraqi Flag Ribbon SVG */}
              <svg
                viewBox="0 0 36 24"
                className="h-6 w-9 rounded border border-white/15 shrink-0"
                aria-hidden="true"
              >
                <rect width="36" height="8" y="0" fill="#CE1126" />
                <rect width="36" height="8" y="8" fill="#FFFFFF" />
                <rect width="36" height="8" y="16" fill="#000000" />
                <text
                  x="18"
                  y="14.5"
                  textAnchor="middle"
                  fontSize="5"
                  fontWeight="bold"
                  fill="#007A3D"
                >
                  الله أكبر
                </text>
              </svg>
              <div>
                <p className="text-sm font-extrabold text-white sm:text-base">
                  اليوم رفعت علم
                </p>
                <p className="text-xs text-emerald-300">
                  تم تحديث منصة عراق كودرز بنجاح إلى الإصدار 26.2
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={onDismiss}
              className="rounded-xl bg-emerald-600 px-5 py-2 text-xs font-extrabold text-white shadow-lg transition-colors hover:bg-emerald-500 whitespace-nowrap shrink-0 cursor-pointer"
            >
              تم
            </button>
          </motion.div>

          {/* Confetti Layer */}
          {upgraded &&
            CONFETTI_PIECES.map((piece) => (
              <motion.span
                key={piece.id}
                aria-hidden="true"
                initial={{ y: -40, opacity: 1, rotate: 0 }}
                animate={{ y: "88vh", opacity: 0, rotate: 360 }}
                transition={{
                  duration: 2.8,
                  delay: piece.delay - 0.35,
                  repeat: Infinity,
                  repeatDelay: 1.2,
                  ease: "easeOut",
                }}
                style={{ left: piece.x, backgroundColor: piece.color }}
                className="pointer-events-none fixed top-0 z-10 h-3 w-2 rounded-sm"
              />
            ))}

          {/* Center Cartoon Stage: Workers carrying & swapping 26.1 -> 26.2 */}
          <div className="relative z-20 flex w-full max-w-2xl flex-col items-center justify-center rounded-3xl border border-violet-500/30 bg-[#0E1424]/90 p-6 text-center shadow-2xl sm:p-10">
            <p className="text-xs font-bold text-emerald-400 mb-3">
              تحديث المنصة · عراق كودرز
            </p>

            {/* Animated Version Swap Stage */}
            <div className="relative flex w-full items-center justify-center gap-2 sm:gap-6 my-4 min-h-[140px]">
              {/* Left Cartoon Worker walking in */}
              <motion.div
                initial={{ x: -120, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ duration: 0.75, ease: [0.16, 1, 0.3, 1] }}
                className="shrink-0"
              >
                <motion.div
                  animate={upgraded ? { y: [0, -10, 0] } : { y: [0, -3, 0] }}
                  transition={{
                    duration: upgraded ? 0.55 : 0.35,
                    repeat: upgraded ? 3 : 2,
                  }}
                >
                  <CartoonWorker helmetColor="#F59E0B" shirtColor="#7C3AED" />
                </motion.div>
              </motion.div>

              {/* Center Version Plate Transition (26.1 -> 26.2) */}
              <div className="relative flex flex-col items-center justify-center px-3">
                <AnimatePresence mode="wait">
                  {!upgraded ? (
                    <motion.div
                      key="v261"
                      initial={{ scale: 0.9, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      exit={{ y: -28, scale: 0.75, opacity: 0 }}
                      transition={{ duration: 0.35 }}
                      className="rounded-2xl border border-white/15 bg-[#161F33] px-6 py-4"
                    >
                      <span className="block text-[11px] font-bold text-slate-400">
                        النسخة السابقة
                      </span>
                      <span className="font-mono text-2xl font-extrabold text-slate-300 sm:text-3xl">
                        الإصدار 26.1
                      </span>
                    </motion.div>
                  ) : (
                    <motion.div
                      key="v262"
                      initial={{ y: 28, scale: 0.8, opacity: 0 }}
                      animate={{ y: 0, scale: 1, opacity: 1 }}
                      transition={{
                        type: "spring",
                        stiffness: 260,
                        damping: 18,
                      }}
                      className="version-glow rounded-2xl border border-emerald-400/50 bg-gradient-to-br from-violet-700/40 to-emerald-700/30 px-6 py-4"
                    >
                      <span className="block text-[11px] font-bold text-emerald-300">
                        تم التحديث بنجاح
                      </span>
                      <span className="font-mono text-2xl font-extrabold text-white sm:text-3xl">
                        الإصدار 26.2
                      </span>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Right Cartoon Worker walking in */}
              <motion.div
                initial={{ x: 120, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ duration: 0.75, ease: [0.16, 1, 0.3, 1] }}
                className="shrink-0"
              >
                <motion.div
                  animate={upgraded ? { y: [0, -10, 0] } : { y: [0, -3, 0] }}
                  transition={{
                    duration: upgraded ? 0.55 : 0.35,
                    delay: 0.1,
                    repeat: upgraded ? 3 : 2,
                  }}
                >
                  <CartoonWorker
                    helmetColor="#10B981"
                    shirtColor="#2563EB"
                    flip
                  />
                </motion.div>
              </motion.div>
            </div>

            <h2 className="text-xl font-extrabold text-white sm:text-2xl mt-2">
              أهلاً بكم في عراق كودرز — الإصدار 26.2
            </h2>
            <p className="mt-2 max-w-lg text-xs leading-relaxed text-slate-300 sm:text-sm">
              رفعت راية التحديث الجديد مع تكامل مباشر لمساعد Iraqi Bots، ودخول
              حصري بحساب Google، وطائر دولينجو البني في الشريط العلوي.
            </p>

            <button
              type="button"
              onClick={onDismiss}
              className="mt-6 rounded-xl bg-gradient-to-l from-violet-600 to-emerald-600 px-8 py-3 text-sm font-extrabold text-white shadow-lg transition-transform hover:scale-[1.02] cursor-pointer"
            >
              تم — دخول إلى المنصة
            </button>
          </div>

          <div className="h-4" aria-hidden="true" />
        </motion.div>
      )}
    </AnimatePresence>
  );
};
