import React, { useState } from "react";
import {
  BookOpen,
  Compass,
  Palette,
  Play,
  Rocket,
  Sparkles,
  Star,
  Volume2,
  X,
} from "lucide-react";
import { speakArabicText, stopArabicSpeech } from "../services/speechEngine";

interface KidsLesson {
  id: string;
  title: string;
  category: "numbers" | "letters" | "colors" | "science" | "puzzles";
  categoryLabel: string;
  duration: string;
  colorClass: string;
  emoji: string;
  narration: string;
  funFact: string;
  quizQuestion: string;
  quizOptions: string[];
  correctIndex: number;
}

const KIDS_LESSONS: KidsLesson[] = [
  {
    id: "kids-letters",
    title: "أبجدية الحروف الجميلة (أ ب ت — A B C)",
    category: "letters",
    categoryLabel: "حروف وكلمات",
    duration: "3 دقائق",
    colorClass: "from-rose-500 to-amber-500",
    emoji: "🔤",
    narration:
      "أهلاً يا بطل في عراقي كيدز! اليوم نتعلم الحروف: ألف أسد، باء بطة، تاء تفاحة! الحروف تفتح لنا أبواب القراءة والقصص الممتعة.",
    funFact: "اللغة العربية تحتوي على 28 حرفاً جميلاً وكل حرف له صوت مميز!",
    quizQuestion: "أي كلمة تبدأ بحرف الألف (أ)؟",
    quizOptions: ["أسد", "بطة", "قمر"],
    correctIndex: 0,
  },
  {
    id: "kids-numbers",
    title: "عالم الأرقام الممتع والعد الذكي 1 - 10",
    category: "numbers",
    categoryLabel: "الأرقام والحساب",
    duration: "4 دقائق",
    colorClass: "from-sky-500 to-indigo-600",
    emoji: "🔢",
    narration:
      "هيا نعد معاً بصوت عالٍ! واحد، اثنان، ثلاثة، أربعة، خمسة! الأرقام تساعدنا على عد النجوم والفواكه والألعاب.",
    funFact: "إذا جمعت 3 نجوم + 2 نجمتين تحصل على 5 نجوم لامعة!",
    quizQuestion: "كم ناتج جمع 4 + 3 يا بطل؟",
    quizOptions: ["6", "7", "9"],
    correctIndex: 1,
  },
  {
    id: "kids-colors",
    title: "قوس قزح الألوان والأشكال الهندسية",
    category: "colors",
    categoryLabel: "الألوان والأشكال",
    duration: "3 دقائق",
    colorClass: "from-emerald-500 to-teal-500",
    emoji: "🎨",
    narration:
      "الألوان تملأ عالمنا بهجة! الأحمر لون التفاحة، والأخضر لون الشجر، والأزرق لون السماء الصافية، والدائرة تشبه الشمس المشرقة.",
    funFact: "عند مزج اللون الأصفر مع الأزرق نحصل على اللون الأخضر!",
    quizQuestion: "ما اللون الذي نحصل عليه إذا مزجنا الأصفر والأزرق؟",
    quizOptions: ["أخضر", "أسود", "أبيض"],
    correctIndex: 0,
  },
  {
    id: "kids-space",
    title: "رحلة صاروخ الفضاء والكواكب السبعة",
    category: "science",
    categoryLabel: "علوم واكتشاف",
    duration: "5 دقائق",
    colorClass: "from-violet-600 to-fuchsia-600",
    emoji: "🚀",
    narration:
      "انطلق معنا في صاروخ عراقي كيدز نحو الفضاء! نحن نعيش على كوكب الأرض الجميل، ويدور حولنا القمر المضيء والشمس الدافئة.",
    funFact: "كوكب المريخ يُسمى الكوكب الأحمر لأن رماله حمراء اللون!",
    quizQuestion: "ما اسم الكوكب الذي نعيش عليه؟",
    quizOptions: ["زحل", "الأرض", "المشتري"],
    correctIndex: 1,
  },
  {
    id: "kids-puzzle",
    title: "ألغاز الحيوانات الذكية وتفكير الأبطال",
    category: "puzzles",
    categoryLabel: "ألغاز ذكية",
    duration: "3 دقائق",
    colorClass: "from-amber-500 to-orange-600",
    emoji: "🦁",
    narration:
      "مرحباً يا صديقي الذكي! هذه فقرة الألغاز الخفيفة لتنشيط العقل باللعب والضحك دون تعقيد.",
    funFact: "الدلفين ينام وعين واحدة مفتوحة ليحمي نفسه في البحر!",
    quizQuestion: "حيوان يعيش في الماء وله زعانف ويسبح بذكاء:",
    quizOptions: ["الدلفين", "الزرافة", "النعامة"],
    correctIndex: 0,
  },
];

interface IraqiKidsViewProps {
  onOpenSettingsExitHint: () => void;
}

export const IraqiKidsView: React.FC<IraqiKidsViewProps> = ({
  onOpenSettingsExitHint,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [activeLesson, setActiveLesson] = useState<KidsLesson | null>(null);
  const [starsEarned, setStarsEarned] = useState(5);
  const [quizFeedback, setQuizFeedback] = useState("");

  const visibleLessons =
    selectedCategory === "all"
      ? KIDS_LESSONS
      : KIDS_LESSONS.filter((l) => l.category === selectedCategory);

  const openLessonPlayer = (lesson: KidsLesson) => {
    setActiveLesson(lesson);
    setQuizFeedback("");
    speakArabicText(lesson.narration, { voiceProfile: "fusha-clear", rate: 0.94 });
  };

  const handleAnswerQuiz = (idx: number) => {
    if (!activeLesson) return;
    if (idx === activeLesson.correctIndex) {
      setStarsEarned((s) => s + 3);
      setQuizFeedback("أحسنت يا بطل! إجابة صحيحة +3 نجوم ذهبية ⭐");
      speakArabicText("أحسنت يا بطل! إجابة صحيحة وممتازة!", {
        voiceProfile: "fusha-clear",
      });
    } else {
      setQuizFeedback("قريب جداً! حاول اختيار الإجابة الصحيحة يا صديقي.");
    }
  };

  return (
    <div className="min-h-[75vh] bg-gradient-to-b from-[#170F2E] via-[#0F1B33] to-[#0B1220] px-4 py-8 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-6xl space-y-7">
        {/* Cheerful YouTube-Kids Style Hero */}
        <div className="relative overflow-hidden rounded-3xl border-2 border-amber-400/50 bg-gradient-to-l from-pink-600/25 via-violet-600/25 to-sky-500/25 p-6 sm:p-8 shadow-2xl">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="space-y-2 max-w-2xl">
              <div className="inline-flex items-center gap-2 rounded-full border border-amber-300/60 bg-amber-400/20 px-3.5 py-1 text-xs font-extrabold text-amber-200">
                <Sparkles className="h-4 w-4" />
                <span>عراقي كيدز · Iraqi Kids الآمن والممتع</span>
              </div>
              <h1 className="text-2xl sm:text-4xl font-extrabold text-white">
                أهلاً بالأبطال الصغار في عالم المعرفة والألعاب الخفيفة! 🎈
              </h1>
              <p className="text-xs sm:text-sm leading-relaxed text-slate-200">
                فيديوهات ودروس صوتية بسيطة وممتعة عن الحروف، الأرقام، الألوان، والفضاء بدون أدوات برمجة معقدة.
              </p>
            </div>

            <div className="flex flex-col items-end gap-2">
              <div className="inline-flex items-center gap-2 rounded-2xl border-2 border-amber-400/60 bg-[#1B1406] px-4 py-2.5 text-sm font-extrabold text-amber-300 shadow-lg">
                <Star className="h-5 w-5 fill-amber-400 text-amber-400" />
                <span className="tabular-nums">نجومك الذهبية: {starsEarned}</span>
              </div>
              <button
                type="button"
                onClick={onOpenSettingsExitHint}
                className="text-[11px] font-bold text-sky-200 underline hover:text-white cursor-pointer"
              >
                إعدادات الحساب الشخصي
              </button>
            </div>
          </div>
        </div>

        {/* Simple Fun Category Filter Chips */}
        <div className="flex flex-wrap gap-2">
          {[
            { id: "all", label: "الكل 🌟", icon: Sparkles },
            { id: "letters", label: "الحروف 🔤", icon: BookOpen },
            { id: "numbers", label: "الأرقام 🔢", icon: Compass },
            { id: "colors", label: "الألوان 🎨", icon: Palette },
            { id: "science", label: "الفضاء 🚀", icon: Rocket },
          ].map((cat) => {
            const active = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => setSelectedCategory(cat.id)}
                className={`rounded-2xl border px-4 py-2.5 text-xs font-extrabold transition-all cursor-pointer ${
                  active
                    ? "border-amber-300 bg-amber-500 text-slate-950 shadow-lg scale-[1.02]"
                    : "border-white/15 bg-white/10 text-white hover:bg-white/15"
                }`}
              >
                {cat.label}
              </button>
            );
          })}
        </div>

        {/* Kid-Safe Lesson Cards Grid */}
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {visibleLessons.map((lesson) => (
            <button
              key={lesson.id}
              type="button"
              onClick={() => openLessonPlayer(lesson)}
              className="group flex flex-col justify-between overflow-hidden rounded-3xl border-2 border-white/15 bg-[#121A2F] text-right transition-transform hover:-translate-y-1 hover:border-amber-300/70 shadow-xl cursor-pointer"
            >
              <div
                className={`flex h-36 items-center justify-center bg-gradient-to-br ${lesson.colorClass} relative`}
              >
                <span className="text-6xl drop-shadow-lg transition-transform group-hover:scale-110">
                  {lesson.emoji}
                </span>
                <span className="absolute bottom-3 left-3 inline-flex items-center gap-1 rounded-full bg-black/50 px-3 py-1 text-[11px] font-extrabold text-white backdrop-blur-xs">
                  <Play className="h-3 w-3 fill-white" />
                  <span>شغّل الدرس</span>
                </span>
              </div>

              <div className="p-5 space-y-2">
                <div className="flex items-center justify-between text-[11px] font-bold">
                  <span className="text-amber-300">{lesson.categoryLabel}</span>
                  <span className="text-slate-400">{lesson.duration}</span>
                </div>
                <h3 className="text-base font-extrabold text-white leading-snug">
                  {lesson.title}
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {lesson.funFact}
                </p>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Interactive Video & Voice Lesson Modal */}
      {activeLesson && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={activeLesson.title}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm"
          onClick={() => {
            stopArabicSpeech();
            setActiveLesson(null);
          }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-xl overflow-hidden rounded-3xl border-2 border-amber-400/60 bg-[#121B32] shadow-2xl"
          >
            <div
              className={`flex items-center justify-between bg-gradient-to-l ${activeLesson.colorClass} px-6 py-4`}
            >
              <div className="flex items-center gap-3">
                <span className="text-3xl">{activeLesson.emoji}</span>
                <h3 className="text-base sm:text-lg font-extrabold text-white">
                  {activeLesson.title}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => {
                  stopArabicSpeech();
                  setActiveLesson(null);
                }}
                className="inline-flex h-9 w-9 items-center justify-center rounded-full bg-black/30 text-white hover:bg-black/50 cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              <div className="rounded-2xl border border-white/15 bg-[#090E1C] p-4 space-y-3">
                <p className="text-sm font-bold leading-relaxed text-white">
                  {activeLesson.narration}
                </p>
                <button
                  type="button"
                  onClick={() =>
                    speakArabicText(activeLesson.narration, {
                      voiceProfile: "fusha-clear",
                      rate: 0.94,
                    })
                  }
                  className="inline-flex items-center gap-1.5 rounded-xl bg-sky-600 px-3.5 py-2 text-xs font-extrabold text-white hover:bg-sky-500 cursor-pointer"
                >
                  <Volume2 className="h-4 w-4" />
                  <span>استمع للدرس بصوت واضح</span>
                </button>
              </div>

              <div className="rounded-2xl border border-amber-400/40 bg-amber-500/10 p-4 space-y-3">
                <p className="text-xs font-extrabold text-amber-200">
                  سؤال البطل السريع: {activeLesson.quizQuestion}
                </p>
                <div className="grid grid-cols-3 gap-2">
                  {activeLesson.quizOptions.map((opt, idx) => (
                    <button
                      key={opt}
                      type="button"
                      onClick={() => handleAnswerQuiz(idx)}
                      className="rounded-xl border border-white/15 bg-[#0D1424] py-2.5 px-2 text-xs font-extrabold text-white hover:border-amber-300 cursor-pointer"
                    >
                      {opt}
                    </button>
                  ))}
                </div>
                {quizFeedback && (
                  <p className="text-xs font-extrabold text-emerald-300">
                    {quizFeedback}
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
