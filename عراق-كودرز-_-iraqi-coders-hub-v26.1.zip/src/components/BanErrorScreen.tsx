import React from "react";
import { ShieldAlert } from "lucide-react";

interface BanErrorScreenProps {
  isOpen: boolean;
  bannedEmail: string;
  onApologize: () => void;
}

export const BanErrorScreen: React.FC<BanErrorScreenProps> = ({
  isOpen,
  bannedEmail,
  onApologize,
}) => {
  if (!isOpen) return null;

  return (
    <div
      role="alertdialog"
      aria-modal="true"
      aria-labelledby="ban-screen-title"
      className="fixed inset-0 z-[70] flex flex-col items-center justify-center bg-[#030305] p-6 text-center"
    >
      <div
        aria-hidden="true"
        className="pointer-events-none fixed inset-0 bg-[radial-gradient(circle_at_center,rgba(220,38,38,0.16),transparent_65%)]"
      />

      <div className="relative z-10 max-w-lg rounded-3xl border border-rose-600/50 bg-[#0B0406] p-8 shadow-2xl">
        <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-2xl border border-rose-500/50 bg-rose-600/20 text-rose-400">
          <ShieldAlert className="h-9 w-9" />
        </div>

        <p dir="ltr" className="font-mono text-sm font-extrabold text-rose-500 mb-2">
          SYSTEM LOCKDOWN · HTTP 404
        </p>

        <h1
          id="ban-screen-title"
          className="text-2xl font-extrabold text-white sm:text-3xl mb-3"
        >
          Error 404: تمت حظر هذا الحساب بسبب عدم الضحك!
        </h1>

        <p className="text-sm leading-relaxed text-rose-200/80 mb-5">
          لقد جرحت مشاعر العمال الصغار عندما قلت «أبداً ما تضحك»، فقاموا
          بإغلاق الموقع فوراً وحظر البريد الإلكتروني:
        </p>

        <div
          dir="ltr"
          className="mx-auto mb-7 rounded-xl border border-rose-500/35 bg-black/70 px-4 py-2.5 font-mono text-xs font-bold text-rose-300"
        >
          {bannedEmail || "visitor@iraqicoders.iq"}
        </div>

        <button
          type="button"
          onClick={onApologize}
          className="w-full rounded-xl bg-gradient-to-l from-rose-600 to-amber-600 px-6 py-3.5 text-sm font-extrabold text-white shadow-lg transition-transform hover:scale-[1.02] cursor-pointer"
        >
          آسف، ضحكت والله آسف
        </button>
      </div>
    </div>
  );
};
