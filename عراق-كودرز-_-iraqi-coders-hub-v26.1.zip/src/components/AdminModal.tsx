import React, { useEffect, useState } from "react";
import {
  Check,
  Copy,
  KeyRound,
  Lock,
  LogOut,
  RotateCcw,
  Save,
  ShieldCheck,
  Trash2,
  X,
} from "lucide-react";
import {
  FIREBASE_HOSTING_SITE,
  firebaseConfig,
} from "../config/firebase";
import { ForumPost } from "../types";

interface AdminModalProps {
  isOpen: boolean;
  isUnlocked: boolean;
  assistantUrl: string;
  assistantTitle: string;
  posts: ForumPost[];
  onClose: () => void;
  onUnlock: () => void;
  onLock: () => void;
  onSaveAssistantConfig: (url: string, title: string) => void;
  onDeletePost: (postId: string) => void;
  onResetCommunity: () => void;
}

export const AdminModal: React.FC<AdminModalProps> = ({
  isOpen,
  isUnlocked,
  assistantUrl,
  assistantTitle,
  posts,
  onClose,
  onUnlock,
  onLock,
  onSaveAssistantConfig,
  onDeletePost,
  onResetCommunity,
}) => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loginError, setLoginError] = useState("");

  const [urlDraft, setUrlDraft] = useState(assistantUrl || "#assistant");
  const [titleDraft, setTitleDraft] = useState(assistantTitle);
  const [saveMessage, setSaveMessage] = useState("");
  const [activeAdminTab, setActiveAdminTab] = useState<
    "assistant" | "moderation" | "firebase"
  >("assistant");
  const [copiedConfig, setCopiedConfig] = useState(false);

  useEffect(() => {
    setUrlDraft(assistantUrl || "#assistant");
    setTitleDraft(assistantTitle);
  }, [assistantUrl, assistantTitle, isOpen]);

  if (!isOpen) return null;

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (username.trim() === "A" && password === "A20019") {
      setLoginError("");
      setUsername("");
      setPassword("");
      onUnlock();
    } else {
      setLoginError("بيانات دخول المسؤول غير صحيحة. تأكد من اسم المستخدم وكلمة المرور.");
    }
  };

  const handleSaveAssistant = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanUrl = urlDraft.trim() || "#assistant";
    onSaveAssistantConfig(cleanUrl, titleDraft.trim() || "Talk to Iraqi Bots");
    setSaveMessage("تم حفظ إعدادات رابط المحادثة ومهندس الأكواد بنجاح.");
    window.setTimeout(() => setSaveMessage(""), 3200);
  };

  const handleRestoreDefaultBot = () => {
    setUrlDraft("#assistant");
    onSaveAssistantConfig(
      "#assistant",
      titleDraft.trim() || "Talk to Iraqi Bots"
    );
    setSaveMessage("تمت استعادة الإعداد الافتراضي لمهندس الأكواد الذكي.");
    window.setTimeout(() => setSaveMessage(""), 3200);
  };

  const handleCopyFirebaseConfig = async () => {
    try {
      await navigator.clipboard.writeText(JSON.stringify(firebaseConfig, null, 2));
      setCopiedConfig(true);
      window.setTimeout(() => setCopiedConfig(false), 1800);
    } catch {
      // Safe no-op
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="admin-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-2xl border border-violet-500/30 bg-[#0E1424] shadow-2xl"
      >
        {/* Header */}
        <div className="flex items-center justify-between gap-4 border-b border-white/10 px-6 py-4">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="h-5 w-5 text-emerald-400" />
            <h3 id="admin-modal-title" className="text-lg font-extrabold text-white">
              لوحة تحكم المسؤول
            </h3>
          </div>

          <div className="flex items-center gap-2">
            {isUnlocked && (
              <button
                type="button"
                onClick={onLock}
                className="inline-flex items-center gap-1.5 rounded-lg border border-rose-500/30 bg-rose-500/10 px-3 py-1.5 text-xs font-bold text-rose-300 hover:bg-rose-500/20 cursor-pointer"
              >
                <LogOut className="h-3.5 w-3.5" />
                <span>قفل اللوحة</span>
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              aria-label="إغلاق لوحة المسؤول"
              className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 bg-white/5 text-slate-300 hover:bg-white/10 hover:text-white cursor-pointer"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Body */}
        {!isUnlocked ? (
          <form onSubmit={handleAdminLogin} className="p-6 space-y-5">
            <div className="flex items-center gap-3 rounded-xl border border-white/10 bg-[#0B0F19] p-4">
              <Lock className="h-5 w-5 text-violet-400 shrink-0" />
              <p className="text-xs leading-relaxed text-slate-300">
                منطقة إدارة محمية لتعديل مسار مهندس الأكواد الذكي وإدارة
                المجتمع وإعدادات Firebase.
              </p>
            </div>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <label
                  htmlFor="admin-username"
                  className="block text-xs font-bold text-slate-300 mb-1.5"
                >
                  اسم المستخدم
                </label>
                <input
                  id="admin-username"
                  type="text"
                  dir="ltr"
                  required
                  value={username}
                  onChange={(e) => {
                    setUsername(e.target.value);
                    setLoginError("");
                  }}
                  placeholder="Username"
                  className="h-11 w-full rounded-xl border border-white/10 bg-[#0B0F19] px-4 font-mono text-sm text-white focus:border-violet-500 focus:outline-none"
                />
              </div>

              <div>
                <label
                  htmlFor="admin-password"
                  className="block text-xs font-bold text-slate-300 mb-1.5"
                >
                  كلمة المرور
                </label>
                <input
                  id="admin-password"
                  type="password"
                  dir="ltr"
                  required
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    setLoginError("");
                  }}
                  placeholder="••••••••"
                  className="h-11 w-full rounded-xl border border-white/10 bg-[#0B0F19] px-4 font-mono text-sm text-white focus:border-violet-500 focus:outline-none"
                />
              </div>
            </div>

            {loginError && (
              <p className="rounded-xl border border-rose-500/30 bg-rose-500/10 px-4 py-2.5 text-xs font-semibold text-rose-300">
                {loginError}
              </p>
            )}

            <button
              type="submit"
              className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-violet-600 py-3 text-sm font-bold text-white transition-colors hover:bg-violet-500 cursor-pointer"
            >
              <KeyRound className="h-4 w-4" />
              <span>دخول إلى لوحة تحكم المسؤول</span>
            </button>
          </form>
        ) : (
          <div className="p-6">
            {/* Admin Tabs */}
            <div className="mb-6 flex flex-wrap items-center gap-1 rounded-xl border border-white/10 bg-[#0B0F19] p-1">
              {(
                [
                  { id: "assistant", label: "مهندس الأكواد" },
                  { id: "moderation", label: "إدارة المنتدى" },
                  { id: "firebase", label: "إعدادات Firebase" },
                ] as const
              ).map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveAdminTab(tab.id)}
                  className={`flex-1 rounded-lg px-3 py-2 text-xs font-bold transition-colors whitespace-nowrap cursor-pointer ${
                    activeAdminTab === tab.id
                      ? "bg-violet-600 text-white"
                      : "text-slate-400 hover:text-white"
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Tab 1: Built-in AI Assistant Config */}
            {activeAdminTab === "assistant" && (
              <form onSubmit={handleSaveAssistant} className="space-y-5">
                <div>
                  <label
                    htmlFor="custom-assistant-url"
                    className="block text-sm font-extrabold text-emerald-300 mb-2"
                  >
                    مسار مهندس الأكواد الذكي المدمج
                  </label>
                  <p className="text-xs text-slate-400 mb-3 leading-relaxed">
                    يعمل مهندس الأكواد مباشرة داخل المنصة، بينما يفتح زر «Talk to Iraqi Bots» في أعلى الشاشة رابط Gem الخارجي مباشرة.
                  </p>
                  <input
                    id="custom-assistant-url"
                    type="text"
                    dir="ltr"
                    required
                    value={urlDraft}
                    onChange={(e) => setUrlDraft(e.target.value)}
                    placeholder="#assistant"
                    className="h-12 w-full rounded-xl border border-violet-500/40 bg-[#0B0F19] px-4 font-mono text-sm text-white placeholder:text-slate-500 focus:border-emerald-400 focus:outline-none"
                  />
                </div>

                <div>
                  <label
                    htmlFor="custom-assistant-title"
                    className="block text-xs font-bold text-slate-300 mb-1.5"
                  >
                    عنوان قسم مهندس الأكواد
                  </label>
                  <input
                    id="custom-assistant-title"
                    type="text"
                    value={titleDraft}
                    onChange={(e) => setTitleDraft(e.target.value)}
                    placeholder="مهندس الأكواد الذكي"
                    className="h-11 w-full rounded-xl border border-white/10 bg-[#0B0F19] px-4 text-sm text-white focus:border-violet-500 focus:outline-none"
                  />
                </div>

                {saveMessage && (
                  <div className="rounded-xl border border-emerald-500/40 bg-emerald-500/15 px-4 py-3 text-xs font-bold text-emerald-300">
                    {saveMessage}
                  </div>
                )}

                <div className="flex flex-wrap items-center gap-3 pt-2">
                  <button
                    type="submit"
                    className="inline-flex flex-1 items-center justify-center gap-2 rounded-xl bg-emerald-600 px-5 py-3 text-xs font-bold text-white transition-colors hover:bg-emerald-500 cursor-pointer"
                  >
                    <Save className="h-4 w-4" />
                    <span>حفظ وتحديث الإعدادات</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleRestoreDefaultBot}
                    className="inline-flex items-center justify-center gap-2 rounded-xl border border-white/15 bg-white/5 px-4 py-3 text-xs font-bold text-slate-300 hover:bg-white/10 cursor-pointer"
                  >
                    <RotateCcw className="h-4 w-4" />
                    <span>استعادة المسار الداخلي</span>
                  </button>
                </div>
              </form>
            )}

            {/* Tab 2: Forum Moderation */}
            {activeAdminTab === "moderation" && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <p className="text-xs font-semibold text-slate-300">
                    إجمالي المواضيع المنشورة: {posts.length}
                  </p>
                  <button
                    type="button"
                    onClick={onResetCommunity}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-bold text-slate-200 hover:bg-white/10 cursor-pointer"
                  >
                    <RotateCcw className="h-3.5 w-3.5" />
                    <span>استعادة المواضيع الافتراضية</span>
                  </button>
                </div>

                <div className="space-y-2.5 max-h-72 overflow-y-auto">
                  {posts.map((post) => (
                    <div
                      key={post.id}
                      className="flex items-center justify-between gap-3 rounded-xl border border-white/10 bg-[#0B0F19] px-4 py-3"
                    >
                      <div className="min-w-0">
                        <p className="truncate text-xs font-bold text-white">
                          {post.title}
                        </p>
                        <p className="text-[11px] text-slate-400">
                          {post.authorName} · {post.topicLabel}
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => onDeletePost(post.id)}
                        title="حذف الموضوع"
                        className="inline-flex items-center gap-1 rounded-lg border border-rose-500/30 bg-rose-500/10 px-2.5 py-1.5 text-xs font-bold text-rose-300 hover:bg-rose-500/20 shrink-0 cursor-pointer"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                        <span>حذف</span>
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Tab 3: Firebase Hosting Config */}
            {activeAdminTab === "firebase" && (
              <div className="space-y-4">
                <div className="rounded-xl border border-white/10 bg-[#0B0F19] p-4 text-xs text-slate-300 space-y-1.5">
                  <div>
                    <span className="text-slate-400">معرف المشروع: </span>
                    <span className="font-mono font-bold text-emerald-300">
                      {firebaseConfig.projectId}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400">موقع الاستضافة: </span>
                    <span className="font-mono font-bold text-violet-300">
                      {FIREBASE_HOSTING_SITE}
                    </span>
                  </div>
                </div>

                <div className="overflow-hidden rounded-xl border border-white/10 bg-[#080C15]">
                  <div className="flex items-center justify-between border-b border-white/10 px-4 py-2.5">
                    <span className="font-mono text-xs text-slate-300">
                      firebaseConfig
                    </span>
                    <button
                      type="button"
                      onClick={handleCopyFirebaseConfig}
                      className="inline-flex items-center gap-1.5 rounded-md border border-white/10 bg-white/5 px-2.5 py-1 text-xs font-semibold text-slate-200 hover:bg-white/10 cursor-pointer"
                    >
                      {copiedConfig ? (
                        <>
                          <Check className="h-3.5 w-3.5 text-emerald-400" />
                          <span>تم النسخ</span>
                        </>
                      ) : (
                        <>
                          <Copy className="h-3.5 w-3.5" />
                          <span>نسخ الإعدادات</span>
                        </>
                      )}
                    </button>
                  </div>
                  <pre dir="ltr" className="overflow-x-auto p-4 font-mono text-xs text-slate-300">
                    {JSON.stringify(firebaseConfig, null, 2)}
                  </pre>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
