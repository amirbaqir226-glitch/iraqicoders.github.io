import React, { useEffect, useMemo, useState } from "react";
import {
  Download,
  Eye,
  Heart,
  MessageSquare,
  Plus,
  Search,
  Send,
} from "lucide-react";
import { DEFAULT_DEVELOPER_AVATAR } from "../data/initialData";
import { ForumPost, PostTopic, ProjectItem, UserProfile } from "../types";

interface CommunityHubProps {
  projects: ProjectItem[];
  posts: ForumPost[];
  user: UserProfile | null;
  requestedFilter?: { filter: "all" | "roblox" | "minecraft" | "forum"; nonce: number };
  onSelectProject: (project: ProjectItem) => void;
  onDownloadProject: (project: ProjectItem) => void;
  onCreatePost: (title: string, content: string, topic: PostTopic) => void;
  onToggleLike: (postId: string) => void;
  onAddReply: (postId: string, content: string) => void;
  onRequestAuth: () => void;
}

type HubFilter = "all" | "roblox" | "minecraft" | "forum";

export const CommunityHub: React.FC<CommunityHubProps> = ({
  projects,
  posts,
  user,
  requestedFilter,
  onSelectProject,
  onDownloadProject,
  onCreatePost,
  onToggleLike,
  onAddReply,
  onRequestAuth,
}) => {
  const [filter, setFilter] = useState<HubFilter>("all");

  useEffect(() => {
    if (requestedFilter && requestedFilter.nonce > 0) {
      setFilter(requestedFilter.filter);
    }
  }, [requestedFilter]);
  const [searchQuery, setSearchQuery] = useState("");
  const [showComposer, setShowComposer] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [newTopic, setNewTopic] = useState<PostTopic>("roblox");
  const [newContent, setNewContent] = useState("");
  const [expandedPostId, setExpandedPostId] = useState<string | null>(null);
  const [replyDrafts, setReplyDrafts] = useState<Record<string, string>>({});
  const [brokenImages, setBrokenImages] = useState<Record<string, boolean>>({});

  const filteredProjects = useMemo(() => {
    if (filter === "forum") return [];
    return projects.filter((p) => {
      const matchesCategory = filter === "all" || p.category === filter;
      const q = searchQuery.trim().toLowerCase();
      const matchesQuery =
        !q ||
        p.title.toLowerCase().includes(q) ||
        p.summary.toLowerCase().includes(q) ||
        p.author.toLowerCase().includes(q);
      return matchesCategory && matchesQuery;
    });
  }, [projects, filter, searchQuery]);

  const filteredPosts = useMemo(() => {
    if (filter === "roblox" || filter === "minecraft") {
      return posts.filter(
        (post) =>
          post.topic === filter &&
          (!searchQuery.trim() ||
            post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
            post.content.toLowerCase().includes(searchQuery.toLowerCase()))
      );
    }
    const q = searchQuery.trim().toLowerCase();
    return posts.filter(
      (post) =>
        !q ||
        post.title.toLowerCase().includes(q) ||
        post.content.toLowerCase().includes(q) ||
        post.authorName.toLowerCase().includes(q)
    );
  }, [posts, filter, searchQuery]);

  const handleSubmitPost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newContent.trim()) return;
    onCreatePost(newTitle.trim(), newContent.trim(), newTopic);
    setNewTitle("");
    setNewContent("");
    setShowComposer(false);
  };

  const handleSubmitReply = (postId: string, e: React.FormEvent) => {
    e.preventDefault();
    const text = (replyDrafts[postId] || "").trim();
    if (!text) return;
    onAddReply(postId, text);
    setReplyDrafts((prev) => ({ ...prev, [postId]: "" }));
  };

  return (
    <section id="community" className="py-14 lg:py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section Header + Filter Bar */}
        <div className="mb-8 flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <p className="text-xs font-bold text-emerald-400 mb-2">
              المشاريع والمنتدى التفاعلي
            </p>
            <h2 className="text-2xl font-extrabold text-white sm:text-3xl">
              مكتبة Roblox Luau و Minecraft Add-ons ومنتدى المطورين
            </h2>
          </div>

          {/* Search & Segmented Filter */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative flex-1 sm:w-64 sm:flex-none">
              <Search className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <input
                type="search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="ابحث في المشاريع والنقاشات..."
                className="h-10 w-full rounded-lg border border-white/10 bg-[#111827] pr-9 pl-3 text-xs text-white placeholder:text-slate-500 focus:border-violet-500 focus:outline-none"
              />
            </div>

            <div className="flex flex-wrap items-center gap-1 rounded-lg border border-white/10 bg-[#111827] p-1">
              {(
                [
                  { id: "all", label: "الكل" },
                  { id: "roblox", label: "Roblox (Luau)" },
                  { id: "minecraft", label: "Minecraft" },
                  { id: "forum", label: "النقاشات" },
                ] as const
              ).map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setFilter(tab.id)}
                  className={`rounded-md px-3 py-1.5 text-xs font-bold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    filter === tab.id
                      ? "bg-violet-600 text-white"
                      : "text-slate-400 hover:text-white"
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Projects Grid */}
        {filteredProjects.length > 0 && (
          <div id="community-projects" className="mb-14 scroll-mt-24">
            <div className="mb-5 flex items-center justify-between">
              <h3 className="text-lg font-bold text-white">
                أحدث المشاريع الجاهزة للتحميل
              </h3>
              <span className="text-xs text-slate-400 tabular-nums">
                {filteredProjects.length} مشاريع متاحة
              </span>
            </div>

            <div className="desktop-grid-2 grid grid-cols-1 gap-6 md:grid-cols-2">
              {filteredProjects.map((project) => (
                <article
                  key={project.id}
                  id={`project-card-${project.id}`}
                  className="scroll-mt-24 glass-surface group flex flex-col overflow-hidden rounded-2xl transition-colors hover:border-violet-500/40"
                >
                  <div className="relative h-52 overflow-hidden bg-[#0E1424]">
                    {!brokenImages[project.id] ? (
                      <img
                        src={project.imageUrl}
                        alt={project.title}
                        referrerPolicy="no-referrer"
                        onError={() =>
                          setBrokenImages((prev) => ({ ...prev, [project.id]: true }))
                        }
                        className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
                      />
                    ) : (
                      <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-violet-950 to-slate-900 text-sm font-bold text-slate-300">
                        {project.categoryLabel}
                      </div>
                    )}
                    <div
                      aria-hidden="true"
                      className="absolute inset-0 bg-gradient-to-t from-[#111827] via-transparent to-transparent"
                    />
                  </div>

                  <div className="flex flex-1 flex-col p-6">
                    {/* Unboxed Clean Metadata */}
                    <div className="mb-2 flex flex-wrap items-center gap-2 text-xs text-slate-400">
                      <span className="font-bold text-emerald-400">
                        {project.categoryLabel}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{project.version}</span>
                      <span aria-hidden="true">·</span>
                      <span>
                        {project.author} ({project.city})
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="tabular-nums">
                        {project.downloads.toLocaleString("en-US")} تحميل
                      </span>
                    </div>

                    <h4 className="text-lg font-extrabold text-white mb-2">
                      {project.title}
                    </h4>

                    <p className="flex-1 text-sm leading-relaxed text-slate-300 mb-6">
                      {project.summary}
                    </p>

                    <div className="flex flex-wrap items-center gap-3 pt-4 border-t border-white/10">
                      <button
                        type="button"
                        onClick={() => onSelectProject(project)}
                        className="inline-flex flex-1 items-center justify-center gap-2 rounded-xl bg-violet-600 px-4 py-2.5 text-xs font-bold text-white transition-colors hover:bg-violet-500 whitespace-nowrap shrink-0 cursor-pointer"
                      >
                        <Eye className="h-4 w-4" />
                        <span>معاينة الكود والتفاصيل</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => onDownloadProject(project)}
                        className="inline-flex items-center justify-center gap-2 rounded-xl border border-emerald-500/40 bg-emerald-500/10 px-4 py-2.5 text-xs font-bold text-emerald-300 transition-colors hover:bg-emerald-500/20 whitespace-nowrap shrink-0 cursor-pointer"
                      >
                        <Download className="h-4 w-4" />
                        <span>تحميل مباشر</span>
                      </button>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </div>
        )}

        {/* Community Forum Section */}
        <div id="community-forum" className="scroll-mt-24">
          <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
            <div>
              <h3 className="text-xl font-extrabold text-white">
                منتدى نقاشات المطورين
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                اطرح أسئلتك البرمجية وشارك حلولك مع مجتمع المبرمجين في العراق.
              </p>
            </div>

            <button
              type="button"
              onClick={() => {
                if (!user) {
                  onRequestAuth();
                } else {
                  setShowComposer((prev) => !prev);
                }
              }}
              className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-4 py-2.5 text-xs font-bold text-white transition-colors hover:bg-emerald-500 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Plus className="h-4 w-4" />
              <span>{user ? "نشر موضوع جديد" : "سجّل الدخول للمشاركة"}</span>
            </button>
          </div>

          {/* New Post Composer */}
          {showComposer && user && (
            <form
              onSubmit={handleSubmitPost}
              className="glass-surface mb-8 rounded-2xl p-6 space-y-4"
            >
              <div className="flex items-center justify-between">
                <h4 className="text-base font-bold text-white">
                  كتابة منشور جديد باسم {user.name}
                </h4>
                <button
                  type="button"
                  onClick={() => setShowComposer(false)}
                  className="text-xs text-slate-400 hover:text-white cursor-pointer"
                >
                  إلغاء
                </button>
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="عنوان الموضوع أو الاستفسار..."
                  className="sm:col-span-2 h-11 rounded-xl border border-white/10 bg-[#0B0F19] px-4 text-sm text-white placeholder:text-slate-500 focus:border-violet-500 focus:outline-none"
                />
                <select
                  value={newTopic}
                  onChange={(e) => setNewTopic(e.target.value as PostTopic)}
                  className="h-11 rounded-xl border border-white/10 bg-[#0B0F19] px-4 text-sm text-white focus:border-violet-500 focus:outline-none cursor-pointer"
                >
                  <option value="roblox">Roblox (Luau)</option>
                  <option value="minecraft">Minecraft Add-on</option>
                  <option value="web">تطوير الويب</option>
                  <option value="general">نقاش عام</option>
                </select>
              </div>

              <textarea
                required
                rows={3}
                value={newContent}
                onChange={(e) => setNewContent(e.target.value)}
                placeholder="اشرح تفاصيل مشروعك أو المشكلة البرمجية..."
                className="w-full rounded-xl border border-white/10 bg-[#0B0F19] p-4 text-sm text-white placeholder:text-slate-500 focus:border-violet-500 focus:outline-none"
              />

              <div className="flex justify-end">
                <button
                  type="submit"
                  className="inline-flex items-center gap-2 rounded-xl bg-violet-600 px-6 py-2.5 text-xs font-bold text-white hover:bg-violet-500 cursor-pointer"
                >
                  <Send className="h-4 w-4" />
                  <span>نشر في المنتدى</span>
                </button>
              </div>
            </form>
          )}

          {/* Forum Posts List */}
          {filteredPosts.length === 0 ? (
            <div className="glass-surface rounded-2xl p-10 text-center">
              <p className="text-sm font-semibold text-slate-300">
                لا توجد مناقشات مطابقة لبحثك الحالي.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredPosts.map((post) => {
                const isExpanded = expandedPostId === post.id;
                return (
                  <article
                    key={post.id}
                    className="glass-surface rounded-2xl p-6 transition-colors hover:border-white/15"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
                      <div className="flex items-center gap-3">
                        <img
                          src={post.authorAvatar || DEFAULT_DEVELOPER_AVATAR}
                          alt={post.authorName}
                          referrerPolicy="no-referrer"
                          className="h-10 w-10 rounded-full object-cover border border-white/15"
                        />
                        <div>
                          <div className="text-sm font-bold text-white">
                            {post.authorName}
                          </div>
                          <div className="flex items-center gap-2 text-xs text-slate-400">
                            <span>{post.authorCity}</span>
                            <span aria-hidden="true">·</span>
                            <span>{post.createdAt}</span>
                            <span aria-hidden="true">·</span>
                            <span className="text-emerald-400 font-semibold">
                              {post.topicLabel}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <h4 className="text-base font-extrabold text-white mb-2 sm:text-lg">
                      {post.title}
                    </h4>
                    <p className="text-sm leading-relaxed text-slate-300 mb-4">
                      {post.content}
                    </p>

                    {/* Post Actions */}
                    <div className="flex flex-wrap items-center gap-4 pt-3 border-t border-white/10">
                      <button
                        type="button"
                        onClick={() => onToggleLike(post.id)}
                        className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-bold transition-colors cursor-pointer ${
                          post.likedByUser
                            ? "bg-rose-500/20 text-rose-300 border border-rose-500/30"
                            : "bg-white/5 text-slate-300 border border-white/10 hover:bg-white/10"
                        }`}
                      >
                        <Heart className="h-3.5 w-3.5" />
                        <span className="tabular-nums">{post.likes}</span>
                        <span>إعجاب</span>
                      </button>

                      <button
                        type="button"
                        onClick={() =>
                          setExpandedPostId(isExpanded ? null : post.id)
                        }
                        className="inline-flex items-center gap-1.5 rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-bold text-slate-300 hover:bg-white/10 cursor-pointer"
                      >
                        <MessageSquare className="h-3.5 w-3.5 text-violet-400" />
                        <span className="tabular-nums">{post.replies.length}</span>
                        <span>ردود</span>
                      </button>
                    </div>

                    {/* Replies Drawer */}
                    {isExpanded && (
                      <div className="mt-4 space-y-3 border-t border-white/10 pt-4">
                        {post.replies.map((reply) => (
                          <div
                            key={reply.id}
                            className="rounded-xl bg-[#0B0F19]/80 border border-white/5 p-3.5"
                          >
                            <div className="flex items-center gap-2 text-xs mb-1">
                              <span className="font-bold text-white">
                                {reply.authorName}
                              </span>
                              <span aria-hidden="true" className="text-slate-500">
                                ·
                              </span>
                              <span className="text-slate-500">{reply.createdAt}</span>
                            </div>
                            <p className="text-xs leading-relaxed text-slate-300">
                              {reply.content}
                            </p>
                          </div>
                        ))}

                        <form
                          onSubmit={(e) => handleSubmitReply(post.id, e)}
                          className="flex items-center gap-2 pt-1"
                        >
                          <input
                            type="text"
                            value={replyDrafts[post.id] || ""}
                            onChange={(e) =>
                              setReplyDrafts((prev) => ({
                                ...prev,
                                [post.id]: e.target.value,
                              }))
                            }
                            placeholder={
                              user
                                ? "أضف ردك التقني هنا..."
                                : "اكتب رداً سريعاً (أو سجّل الدخول باسمك)..."
                            }
                            className="h-10 flex-1 rounded-lg border border-white/10 bg-[#0B0F19] px-3 text-xs text-white placeholder:text-slate-500 focus:border-violet-500 focus:outline-none"
                          />
                          <button
                            type="submit"
                            className="inline-flex h-10 items-center gap-1.5 rounded-lg bg-violet-600 px-4 text-xs font-bold text-white hover:bg-violet-500 cursor-pointer"
                          >
                            <span>رد</span>
                          </button>
                        </form>
                      </div>
                    )}
                  </article>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </section>
  );
};
