import React, { useRef, useState } from "react";
import {
  Baby,
  Camera,
  CheckCircle2,
  CreditCard,
  IdCard,
  ShieldCheck,
  Sparkles,
  Upload,
} from "lucide-react";

interface AgeVerificationModalProps {
  isOpen: boolean;
  onVerifiedAdult: (methodLabel: string) => void;
  onChooseKidMode: () => void;
}

type VerifyMethodTab = "id-card" | "face" | "credit-card";

function luhnCheck(cardDigits: string): boolean {
  const digits = cardDigits.replace(/\D/g, "");
  if (digits.length < 13 || digits.length > 19) return false;
  let sum = 0;
  let shouldDouble = false;
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) digit -= 9;
    }
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  return sum % 10 === 0;
}

export const AgeVerificationModal: React.FC<AgeVerificationModalProps> = ({
  isOpen,
  onVerifiedAdult,
  onChooseKidMode,
}) => {
  const [activeTab, setActiveTab] = useState<VerifyMethodTab>("id-card");
  const [errorMsg, setErrorMsg] = useState("");

  // Tab 1: Iraqi National ID
  const [iraqiIdNumber, setIraqiIdNumber] = useState("");
  const [iraqiBirthYear, setIraqiBirthYear] = useState("2008");
  const [idPhotoPreview, setIdPhotoPreview] = useState("");
  const idPhotoRef = useRef<HTMLInputElement>(null);

  // Tab 2: Face Check
  const [facePreview, setFacePreview] = useState("");
  const [faceConfirmedAge, setFaceConfirmedAge] = useState(false);
  const [cameraActive, setCameraActive] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const faceUploadRef = useRef<HTMLInputElement>(null);

  // Tab 3: Credit Card (strictly client-side Luhn check; NEVER stored or sent)
  const [cardNumberInput, setCardNumberInput] = useState("");
  const [cardExpiryInput, setCardExpiryInput] = useState("12/28");
  const [cardHolderInput, setCardHolderInput] = useState("");

  if (!isOpen) return null;

  const stopCameraStream = () => {
    const videoEl = videoRef.current;
    if (videoEl && videoEl.srcObject) {
      const stream = videoEl.srcObject as MediaStream;
      stream.getTracks().forEach((t) => t.stop());
      videoEl.srcObject = null;
    }
    setCameraActive(false);
  };

  const handleImagePick = (
    e: React.ChangeEvent<HTMLInputElement>,
    setter: (val: string) => void
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      setter(String(reader.result || ""));
      setErrorMsg("");
    };
    reader.readAsDataURL(file);
  };

  const handleVerifyIraqiId = (e: React.FormEvent) => {
    e.preventDefault();
    const digits = iraqiIdNumber.replace(/\D/g, "");
    const yearNum = Number(iraqiBirthYear);
    const currentYear = new Date().getFullYear();

    if (digits.length < 10) {
      setErrorMsg("أدخل رقم البطاقة الوطنية العراقية (10 إلى 12 رقماً).");
      return;
    }
    if (!idPhotoPreview) {
      setErrorMsg("يرجى رفع صورة الهوية العراقية للتحقق.");
      return;
    }
    if (Number.isNaN(yearNum) || currentYear - yearNum < 12) {
      setErrorMsg("سنة الميلاد المدخلة أقل من 12 سنة — يمكنك اختيار «الصراحة أنا طفل».");
      return;
    }

    stopCameraStream();
    onVerifiedAdult("الهوية العراقية");
  };

  const handleStartCamera = async () => {
    setErrorMsg("");
    try {
      if (!navigator.mediaDevices?.getUserMedia) {
        setErrorMsg("الكاميرا غير مدعومة في هذا المتصفح، يمكنك رفع صورة سيلفي بدلاً من ذلك.");
        return;
      }
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      setCameraActive(true);
      window.setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      }, 60);
    } catch {
      setErrorMsg("تعذر الوصول للكاميرا — يمكنك رفع صورة وجه واضحة للتحقق فوراً.");
    }
  };

  const handleVerifyFace = () => {
    if (!cameraActive && !facePreview) {
      setErrorMsg("افتح الكاميرا أو ارفع صورة وجه للتحقق أولاً.");
      return;
    }
    if (!faceConfirmedAge) {
      setErrorMsg("أكّد أن عمرك الظاهر 12 سنة أو أكثر للمتابعة.");
      return;
    }
    stopCameraStream();
    onVerifiedAdult("التحقق بالوجه");
  };

  const handleVerifyCreditCard = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanDigits = cardNumberInput.replace(/\D/g, "");
    if (!luhnCheck(cleanDigits)) {
      setErrorMsg("رقم البطاقة غير صالح وفق فحص Luhn القياسي.");
      return;
    }
    if (!/^(0[1-9]|1[0-2])\/\d{2}$/.test(cardExpiryInput.trim())) {
      setErrorMsg("صيغة تاريخ الانتهاء غير صالحة (مثال: 12/28).");
      return;
    }
    if (cardHolderInput.trim().length < 3) {
      setErrorMsg("أدخل اسم حامل البطاقة.");
      return;
    }

    // Security guarantee: immediately wipe raw PAN from memory; never persist full number
    const last4 = cleanDigits.slice(-4);
    setCardNumberInput("");
    stopCameraStream();
    onVerifiedAdult(`بطاقة ائتمانية (•••• ${last4})`);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="age-gate-title"
      className="fixed inset-0 z-[65] flex items-center justify-center bg-black/88 p-4 backdrop-blur-md"
    >
      <div className="w-full max-w-xl max-h-[92vh] overflow-y-auto rounded-3xl border border-violet-400/45 bg-[#0D1424] p-6 shadow-2xl space-y-5">
        <div className="text-center space-y-2">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl border border-emerald-400/45 bg-emerald-500/15 text-emerald-300">
            <ShieldCheck className="h-6 w-6" />
          </div>
          <h2 id="age-gate-title" className="text-xl font-extrabold text-white">
            التحقق السريع من العمر: هل عمرك 12 سنة أو أكثر؟
          </h2>
          <p className="text-xs leading-relaxed text-slate-300">
            لضمان تجربة مناسبة وآمنة للجميع في «عراقي كودرز»، اختر إحدى وسائل التحقق التالية أو انتقل لنسخة الأطفال المبسطة.
          </p>
        </div>

        {/* 3 Adult Verification Method Tabs */}
        <div className="grid grid-cols-3 gap-2 rounded-2xl border border-white/10 bg-[#080C15] p-1.5">
          <button
            type="button"
            onClick={() => {
              setActiveTab("id-card");
              setErrorMsg("");
            }}
            className={`inline-flex flex-col items-center gap-1 rounded-xl py-2.5 px-2 text-[11px] font-extrabold cursor-pointer ${
              activeTab === "id-card"
                ? "bg-emerald-600 text-white"
                : "text-slate-300 hover:text-white"
            }`}
          >
            <IdCard className="h-4 w-4" />
            <span>الهوية العراقية</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveTab("face");
              setErrorMsg("");
            }}
            className={`inline-flex flex-col items-center gap-1 rounded-xl py-2.5 px-2 text-[11px] font-extrabold cursor-pointer ${
              activeTab === "face"
                ? "bg-violet-600 text-white"
                : "text-slate-300 hover:text-white"
            }`}
          >
            <Camera className="h-4 w-4" />
            <span>التحقق بالوجه</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveTab("credit-card");
              setErrorMsg("");
            }}
            className={`inline-flex flex-col items-center gap-1 rounded-xl py-2.5 px-2 text-[11px] font-extrabold cursor-pointer ${
              activeTab === "credit-card"
                ? "bg-sky-600 text-white"
                : "text-slate-300 hover:text-white"
            }`}
          >
            <CreditCard className="h-4 w-4" />
            <span>بطاقة ائتمانية</span>
          </button>
        </div>

        {errorMsg && (
          <div className="rounded-xl border border-rose-500/45 bg-rose-500/15 px-4 py-2.5 text-xs font-bold text-rose-200">
            {errorMsg}
          </div>
        )}

        {/* Method 1: Iraqi National ID */}
        {activeTab === "id-card" && (
          <form onSubmit={handleVerifyIraqiId} className="space-y-3.5">
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  رقم البطاقة الوطنية العراقية
                </label>
                <input
                  type="text"
                  dir="ltr"
                  maxLength={14}
                  value={iraqiIdNumber}
                  onChange={(e) => setIraqiIdNumber(e.target.value)}
                  placeholder="199912345678"
                  className="h-10 w-full rounded-xl border border-white/15 bg-[#080C15] px-3 font-mono text-xs text-white"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  سنة الميلاد
                </label>
                <input
                  type="number"
                  dir="ltr"
                  min={1930}
                  max={new Date().getFullYear()}
                  value={iraqiBirthYear}
                  onChange={(e) => setIraqiBirthYear(e.target.value)}
                  className="h-10 w-full rounded-xl border border-white/15 bg-[#080C15] px-3 font-mono text-xs text-white"
                />
              </div>
            </div>

            <div className="rounded-2xl border border-white/10 bg-[#080C15] p-3.5 flex items-center justify-between gap-3">
              <div className="flex items-center gap-3 min-w-0">
                {idPhotoPreview ? (
                  <img
                    src={idPhotoPreview}
                    alt="صورة الهوية"
                    className="h-12 w-16 rounded-lg object-cover border border-emerald-400/50 shrink-0"
                  />
                ) : (
                  <div className="flex h-12 w-16 items-center justify-center rounded-lg border border-dashed border-white/20 text-slate-400 shrink-0">
                    <IdCard className="h-5 w-5" />
                  </div>
                )}
                <p className="text-xs text-slate-300 truncate">
                  {idPhotoPreview ? "تم إرفاق صورة الهوية ✓" : "ارفق صورة الهوية الوطنية"}
                </p>
              </div>
              <button
                type="button"
                onClick={() => idPhotoRef.current?.click()}
                className="inline-flex items-center gap-1.5 rounded-xl bg-white/10 px-3 py-2 text-xs font-bold text-white hover:bg-white/15 shrink-0 cursor-pointer"
              >
                <Upload className="h-3.5 w-3.5" />
                <span>رفع صورة</span>
              </button>
              <input
                ref={idPhotoRef}
                type="file"
                accept="image/*"
                onChange={(e) => handleImagePick(e, setIdPhotoPreview)}
                className="hidden"
              />
            </div>

            <button
              type="submit"
              className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-600 py-3 text-xs font-extrabold text-white hover:bg-emerald-500 cursor-pointer"
            >
              <CheckCircle2 className="h-4 w-4" />
              <span>تأكيد الهوية العراقية والدخول للموقع</span>
            </button>
          </form>
        )}

        {/* Method 2: Face Check */}
        {activeTab === "face" && (
          <div className="space-y-3.5">
            <div className="rounded-2xl border border-white/10 bg-[#080C15] p-4 text-center space-y-3">
              {cameraActive ? (
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className="mx-auto h-44 w-full max-w-xs rounded-2xl border border-violet-400/60 object-cover"
                />
              ) : facePreview ? (
                <img
                  src={facePreview}
                  alt="صورة التحقق بالوجه"
                  className="mx-auto h-40 w-40 rounded-full border-2 border-emerald-400 object-cover"
                />
              ) : (
                <div className="mx-auto flex h-24 w-24 items-center justify-center rounded-full border border-dashed border-violet-400/50 bg-violet-500/10 text-violet-300">
                  <Camera className="h-9 w-9" />
                </div>
              )}

              <div className="flex flex-wrap justify-center gap-2">
                <button
                  type="button"
                  onClick={() => void handleStartCamera()}
                  className="inline-flex items-center gap-1.5 rounded-xl bg-violet-600 px-4 py-2 text-xs font-bold text-white hover:bg-violet-500 cursor-pointer"
                >
                  <Camera className="h-3.5 w-3.5" />
                  <span>فتح الكاميرا</span>
                </button>
                <button
                  type="button"
                  onClick={() => faceUploadRef.current?.click()}
                  className="inline-flex items-center gap-1.5 rounded-xl border border-white/15 bg-white/5 px-4 py-2 text-xs font-bold text-slate-200 hover:bg-white/10 cursor-pointer"
                >
                  <Upload className="h-3.5 w-3.5" />
                  <span>أو رفع صورة وجه</span>
                </button>
                <input
                  ref={faceUploadRef}
                  type="file"
                  accept="image/*"
                  onChange={(e) => handleImagePick(e, setFacePreview)}
                  className="hidden"
                />
              </div>
            </div>

            <label className="flex items-center gap-2 rounded-xl border border-white/10 bg-[#080C15] px-3.5 py-2.5 text-xs font-bold text-slate-200 cursor-pointer">
              <input
                type="checkbox"
                checked={faceConfirmedAge}
                onChange={(e) => setFaceConfirmedAge(e.target.checked)}
                className="h-4 w-4 accent-violet-500"
              />
              <span>أؤكد أن عمري 12 سنة فأكثر بعد فحص الوجه</span>
            </label>

            <button
              type="button"
              onClick={handleVerifyFace}
              className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-violet-600 py-3 text-xs font-extrabold text-white hover:bg-violet-500 cursor-pointer"
            >
              <CheckCircle2 className="h-4 w-4" />
              <span>إتمام التحقق بالوجه والدخول</span>
            </button>
          </div>
        )}

        {/* Method 3: Credit Card (Client-side Luhn check ONLY — no storage/transmission) */}
        {activeTab === "credit-card" && (
          <form onSubmit={handleVerifyCreditCard} className="space-y-3.5">
            <p className="rounded-xl border border-sky-400/30 bg-sky-500/10 px-3 py-2 text-[11px] text-sky-200">
              يتم فحص صلاحية البطاقة محلياً داخل متصفحك فقط ولا يتم حفظ أو إرسال أي أرقام بطاقات إطلاقاً.
            </p>
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                رقم البطاقة الائتمانية
              </label>
              <input
                type="text"
                dir="ltr"
                inputMode="numeric"
                autoComplete="off"
                maxLength={23}
                value={cardNumberInput}
                onChange={(e) => setCardNumberInput(e.target.value)}
                placeholder="4532 0151 1283 0366"
                className="h-10 w-full rounded-xl border border-white/15 bg-[#080C15] px-3 font-mono text-xs text-white"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  اسم حامل البطاقة
                </label>
                <input
                  type="text"
                  autoComplete="off"
                  value={cardHolderInput}
                  onChange={(e) => setCardHolderInput(e.target.value)}
                  placeholder="الاسم كما في البطاقة"
                  className="h-10 w-full rounded-xl border border-white/15 bg-[#080C15] px-3 text-xs text-white"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  تاريخ الانتهاء (MM/YY)
                </label>
                <input
                  type="text"
                  dir="ltr"
                  autoComplete="off"
                  maxLength={5}
                  value={cardExpiryInput}
                  onChange={(e) => setCardExpiryInput(e.target.value)}
                  placeholder="12/28"
                  className="h-10 w-full rounded-xl border border-white/15 bg-[#080C15] px-3 font-mono text-xs text-white"
                />
              </div>
            </div>

            <button
              type="submit"
              className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-sky-600 py-3 text-xs font-extrabold text-white hover:bg-sky-500 cursor-pointer"
            >
              <Sparkles className="h-4 w-4" />
              <span>التحقق بالبطاقة (فحص آمن) والدخول</span>
            </button>
          </form>
        )}

        {/* Option 4: Honest Kids Button -> Transitions smoothly to "عراقي كيدز" */}
        <div className="border-t border-white/10 pt-4">
          <button
            type="button"
            onClick={() => {
              stopCameraStream();
              onChooseKidMode();
            }}
            className="inline-flex w-full items-center justify-center gap-2.5 rounded-2xl border-2 border-amber-400/55 bg-gradient-to-l from-amber-500/20 via-pink-500/20 to-sky-500/20 py-3.5 text-sm font-extrabold text-amber-200 transition-transform hover:scale-[1.01] cursor-pointer"
          >
            <Baby className="h-5 w-5 text-amber-300" />
            <span>الصراحة أنا طفل (الدخول إلى عراقي كيدز)</span>
          </button>
        </div>
      </div>
    </div>
  );
};
