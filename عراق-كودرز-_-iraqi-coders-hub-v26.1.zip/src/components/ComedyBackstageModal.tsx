import React, { useState } from "react";
import { Laugh, PartyPopper, Send, ThumbsDown, X } from "lucide-react";

interface ComedyBackstageModalProps {
  isOpen: boolean;
  mode: "comedy" | "prank";
  onClose: () => void;
  onTriggerBan: () => void;
}

interface BackstageMessage {
  id: string;
  sender: "worker" | "manager" | "user";
  speakerLabel: string;
  text: string;
}

const IRAQI_JOKES_AND_POEMS = [
  {
    type: "نكتة عراقية",
    text: "واحد مبرمج عراقي فتح مطعم، سمّى القائمة «Array» وكتب على الباب: إذا خلص الأكل يعني صار Overflow!",
  },
  {
    type: "قصيدة فكاهية",
    text: "كتبنا الكود نص الليل سهرانين · طلع بالـ Console خطأ بالسطر ميتين · سألنا الشايب كال: أعيدوا التشغيل · بلكي يشتغل وحق رب العالمين!",
  },
  {
    type: "نكتة بغدادية",
    text: "عامل صيانة كال لصاحبه: إذا انطفت الكهرباء واحنا نرفع التحديث، شنو نسوي؟ كال: نصلّي ركعتين ونگول يا علي وننتظر الساعة 10!",
  },
  {
    type: "دارمي مبرمجين",
    text: "يا كود شكد عنيد وياي بالليل · أموتن من الـ Bug ومالي كل حيل!",
  },
];

export const ComedyBackstageModal: React.FC<ComedyBackstageModalProps> = ({
  isOpen,
  mode,
  onClose,
  onTriggerBan,
}) => {
  const [jokeIndex, setJokeIndex] = useState(0);
  const [prankStage, setPrankStage] = useState<"ask" | "revealed">("ask");
  const [chatPartner, setChatPartner] = useState<"workers" | "manager">("workers");
  const [chatInput, setChatInput] = useState("");
  const [messages, setMessages] = useState<BackstageMessage[]>([
    {
      id: "init-1",
      sender: "worker",
      speakerLabel: "العامل حسون",
      text: "هلا والله بالضيف الغالي! بما إنك مليت، جبتلك أقوى نكتة من كواليس الصيانة... اسمع واضحك!",
    },
  ]);

  if (!isOpen) return null;

  const currentJoke = IRAQI_JOKES_AND_POEMS[jokeIndex];

  const handleNextJoke = () => {
    const nextIdx = (jokeIndex + 1) % IRAQI_JOKES_AND_POEMS.length;
    setJokeIndex(nextIdx);
    const nextItem = IRAQI_JOKES_AND_POEMS[nextIdx];
    setMessages((prev) => [
      ...prev,
      {
        id: `j-${Date.now()}`,
        sender: "worker",
        speakerLabel: "العامل علاوي",
        text: `${nextItem.type}: ${nextItem.text}`,
      },
    ]);
  };

  const handleReaction = (text: string) => {
    const trimmed = text.trim();
    if (!trimmed) return;

    const normalized = trimmed.toLowerCase();
    const isNotFunny =
      normalized.includes("أبداً ما تضحك") ||
      normalized.includes("ابدا ما تضحك") ||
      normalized.includes("ما تضحك") ||
      normalized.includes("بايخة");

    if (mode === "comedy" && isNotFunny) {
      onTriggerBan();
      return;
    }

    const userMsg: BackstageMessage = {
      id: `u-${Date.now()}`,
      sender: "user",
      speakerLabel: "أنت",
      text: trimmed,
    };

    let reply: BackstageMessage;
    if (mode === "prank" && prankStage === "revealed") {
      if (chatPartner === "manager") {
        reply = {
          id: `m-${Date.now() + 1}`,
          sender: "manager",
          speakerLabel: "المدير",
          text: "والله نورتنا بكواليس عراقي كودرز 26.3! هذا كله كان مقلب خفيف حتى نغير جو قبل ما تكمل برمجة مشاريعك!",
        };
      } else {
        reply = {
          id: `w-${Date.now() + 1}`,
          sender: "worker",
          speakerLabel: "العمال",
          text: "ههههه عاش ذوقك! تره كلنا إخوة هنا نشتغل ليل ونهار على الإصدار 26.3 لعيون المبرمجين العراقيين!",
        };
      }
    } else {
      reply = {
        id: `w-${Date.now() + 1}`,
        sender: "worker",
        speakerLabel: "العمال (يحتفلون)",
        text: "هههههه دوم الضحكة يا بطل! شوف الشغل العراقي الأصيل — كلهم يصفقون لك!",
      };
    }

    setMessages((prev) => [...prev, userMsg, reply]);
    setChatInput("");
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="كواليس العمال الكوميدية"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-2xl overflow-hidden rounded-3xl border border-violet-500/35 bg-[#0E1424] shadow-2xl"
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/10 bg-[#131A2D] px-6 py-4">
          <div className="flex items-center gap-3">
            <PartyPopper className="h-6 w-6 text-amber-400" />
            <div>
              <h3 className="text-lg font-extrabold text-white">
                {mode === "prank"
                  ? "المسامح كريم — كواليس العمال والمدير"
                  : "كواليس العمال الكوميدية"}
              </h3>
              <p className="text-xs text-emerald-300">
                {mode === "prank"
                  ? "نرحب بك من جديد بعد الاعتذار!"
                  : "نكت عراقية وأشعار فكاهية لطرد الملل"}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="إغلاق الكواليس"
            className="rounded-lg border border-white/10 bg-white/5 p-2 text-slate-300 hover:bg-white/10 hover:text-white cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Stage Content */}
        {mode === "prank" && prankStage === "ask" ? (
          <div className="p-8 text-center space-y-5">
            <div className="mx-auto inline-flex rounded-xl border border-emerald-500/40 bg-emerald-500/15 px-4 py-1.5 text-sm font-extrabold text-emerald-300">
              المسامح كريم!
            </div>
            <h4 className="text-2xl font-extrabold text-white">
              بصراحة... هل ضحكت فعلاً أم كنت تجاملنا؟
            </h4>
            <p className="text-sm text-slate-300">
              العمال والمدير ينتظرون جوابك الصريح الآن!
            </p>
            <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
              <button
                type="button"
                onClick={() => {
                  setPrankStage("revealed");
                  setMessages([
                    {
                      id: "prank-rev",
                      sender: "manager",
                      speakerLabel: "المدير والعمال",
                      text: "مقلب!! هههههه كلنا نضحك ونصفق لك! أهلاً بك في الدردشة المفتوحة مع العمال والمدير.",
                    },
                  ]);
                }}
                className="rounded-xl bg-emerald-600 px-6 py-3 text-sm font-extrabold text-white hover:bg-emerald-500 cursor-pointer"
              >
                والله ضحكت من كل قلبي!
              </button>
              <button
                type="button"
                onClick={() => {
                  setPrankStage("revealed");
                  setMessages([
                    {
                      id: "prank-rev-2",
                      sender: "worker",
                      speakerLabel: "العمال والمدير",
                      text: "مقلب!! ههههه حتى لو جاملتنا، صارت ضحكة حلوة! تفضل دردش ويه العمال أو المدير.",
                    },
                  ]);
                }}
                className="rounded-xl border border-white/15 bg-white/5 px-6 py-3 text-sm font-bold text-slate-200 hover:bg-white/10 cursor-pointer"
              >
                الصراحة شوية بس لا تزعلون
              </button>
            </div>
          </div>
        ) : (
          <div className="p-6 space-y-4">
            {mode === "prank" && prankStage === "revealed" ? (
              <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-amber-400/40 bg-amber-500/10 p-4">
                <div>
                  <span className="text-sm font-extrabold text-amber-300">
                    مقلب! الجميع يضحك ويصفق 👏
                  </span>
                  <p className="text-xs text-slate-200 mt-0.5">
                    اختر مع من تريد الدردشة الآن:
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setChatPartner("workers")}
                    className={`rounded-lg px-3.5 py-1.5 text-xs font-bold cursor-pointer ${
                      chatPartner === "workers"
                        ? "bg-violet-600 text-white"
                        : "bg-white/10 text-slate-300"
                    }`}
                  >
                    العمال
                  </button>
                  <button
                    type="button"
                    onClick={() => setChatPartner("manager")}
                    className={`rounded-lg px-3.5 py-1.5 text-xs font-bold cursor-pointer ${
                      chatPartner === "manager"
                        ? "bg-emerald-600 text-white"
                        : "bg-white/10 text-slate-300"
                    }`}
                  >
                    المدير
                  </button>
                </div>
              </div>
            ) : (
              /* Joke Showcase Card */
              <div className="rounded-2xl border border-violet-500/30 bg-[#0B0F19] p-5">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-extrabold text-emerald-400">
                    {currentJoke.type}
                  </span>
                  <button
                    type="button"
                    onClick={handleNextJoke}
                    className="rounded-lg border border-white/10 bg-white/5 px-3 py-1 text-xs font-bold text-slate-200 hover:bg-white/10 cursor-pointer"
                  >
                    نكتة / قصيدة أخرى
                  </button>
                </div>
                <p className="text-base font-bold leading-relaxed text-white">
                  «{currentJoke.text}»
                </p>
                <div className="mt-4 flex flex-wrap items-center gap-3">
                  <button
                    type="button"
                    onClick={() => handleReaction("هههههه والله تضحك!")}
                    className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-4 py-2 text-xs font-extrabold text-white hover:bg-emerald-500 cursor-pointer"
                  >
                    <Laugh className="h-4 w-4" />
                    <span>ههههه تضحك!</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleReaction("أبداً ما تضحك")}
                    className="inline-flex items-center gap-2 rounded-xl border border-rose-500/40 bg-rose-500/15 px-4 py-2 text-xs font-extrabold text-rose-300 hover:bg-rose-500/25 cursor-pointer"
                  >
                    <ThumbsDown className="h-4 w-4" />
                    <span>أبداً ما تضحك</span>
                  </button>
                </div>
              </div>
            )}

            {/* Chat Log */}
            <div className="h-52 overflow-y-auto rounded-2xl border border-white/10 bg-[#080C15] p-4 space-y-3">
              {messages.map((m) => (
                <div
                  key={m.id}
                  className={`flex flex-col ${
                    m.sender === "user" ? "items-start" : "items-end"
                  }`}
                >
                  <span className="text-[11px] font-bold text-slate-400 mb-1">
                    {m.speakerLabel}
                  </span>
                  <div
                    className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-xs leading-relaxed sm:text-sm ${
                      m.sender === "user"
                        ? "bg-violet-600/25 border border-violet-500/35 text-white"
                        : m.sender === "manager"
                        ? "bg-amber-500/15 border border-amber-500/35 text-amber-100"
                        : "bg-[#161F33] border border-white/10 text-slate-100"
                    }`}
                  >
                    {m.text}
                  </div>
                </div>
              ))}
            </div>

            {/* Interactive Reply Form */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleReaction(chatInput);
              }}
              className="flex items-center gap-2"
            >
              <input
                type="text"
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                placeholder={
                  mode === "prank"
                    ? `تحدث مع ${chatPartner === "manager" ? "المدير" : "العمال"}...`
                    : "اكتب تعليقك للعمال أو جرّب كتابة: أبداً ما تضحك..."
                }
                className="h-11 flex-1 rounded-xl border border-white/10 bg-[#0B0F19] px-4 text-xs text-white placeholder:text-slate-500 focus:border-violet-500 focus:outline-none"
              />
              <button
                type="submit"
                className="inline-flex h-11 items-center gap-2 rounded-xl bg-violet-600 px-5 text-xs font-bold text-white hover:bg-violet-500 cursor-pointer"
              >
                <span>إرسال</span>
                <Send className="h-4 w-4" />
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
