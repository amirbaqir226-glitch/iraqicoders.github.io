import React, { useEffect, useMemo, useState } from "react";
import {
  Check,
  CloudUpload,
  Copy,
  Download,
  FileArchive,
  Monitor,
  Play,
  RotateCcw,
  Smartphone,
  Terminal,
} from "lucide-react";
import { PLAYGROUND_TEMPLATES } from "../data/initialData";
import { saveCloudBinaryBlob } from "../services/blobStore";
import { buildWebSourceZipBlob } from "../services/packageBuilder";
import { CloudFileItem, UserProfile } from "../types";
import { GeneratedCodeBundle } from "./AssistantSection";

interface CodePlaygroundProps {
  user?: UserProfile | null;
  onCodeRun: () => void;
  onSaveToCloud?: (item: CloudFileItem) => void;
  onShowToast?: (msg: string) => void;
  injectedBundle?: GeneratedCodeBundle | null;
}

type CodeTab = "html" | "css" | "js";

interface ConsoleEntry {
  id: string;
  level: "log" | "warn" | "error";
  text: string;
}

export const CodePlayground: React.FC<CodePlaygroundProps> = ({
  user,
  onCodeRun,
  onSaveToCloud,
  onShowToast,
  injectedBundle,
}) => {
  const defaultTemplate = PLAYGROUND_TEMPLATES[0];

  const [selectedTemplateId, setSelectedTemplateId] = useState(defaultTemplate.id);
  const [activeTab, setActiveTab] = useState<CodeTab>("html");
  const [htmlCode, setHtmlCode] = useState(defaultTemplate.html);
  const [cssCode, setCssCode] = useState(defaultTemplate.css);
  const [jsCode, setJsCode] = useState(defaultTemplate.js);
  const [autoRun, setAutoRun] = useState(true);
  const [previewMobile, setPreviewMobile] = useState(false);
  const [manualRunTrigger, setManualRunTrigger] = useState(0);
  const [copied, setCopied] = useState(false);
  const [consoleEntries, setConsoleEntries] = useState<ConsoleEntry[]>([]);

  const buildSrcDoc = (html: string, css: string, js: string) => `<!doctype html>
<html lang="ar">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap" rel="stylesheet" />
  <style>${css}</style>
</head>
<body>
${html}
<script>
  (function() {
    const send = (level, args) => {
      try {
        window.parent.postMessage({
          source: 'iraqi-coders-playground',
          level,
          text: args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' ')
        }, '*');
      } catch (e) {}
    };
    const origLog = console.log;
    const origWarn = console.warn;
    const origError = console.error;
    console.log = (...args) => { send('log', args); origLog.apply(console, args); };
    console.warn = (...args) => { send('warn', args); origWarn.apply(console, args); };
    console.error = (...args) => { send('error', args); origError.apply(console, args); };
    window.onerror = (msg) => { send('error', [msg]); };
    try {
      ${js}
    } catch (err) {
      send('error', [err && err.message ? err.message : String(err)]);
    }
  })();
</script>
</body>
</html>`;

  const [committedDoc, setCommittedDoc] = useState(() =>
    buildSrcDoc(defaultTemplate.html, defaultTemplate.css, defaultTemplate.js)
  );

  // Inject AI-generated code directly when requested
  useEffect(() => {
    if (!injectedBundle) return;
    setHtmlCode(injectedBundle.html);
    setCssCode(injectedBundle.css);
    setJsCode(injectedBundle.js);
    setConsoleEntries([]);
    setCommittedDoc(
      buildSrcDoc(injectedBundle.html, injectedBundle.css, injectedBundle.js)
    );
    setManualRunTrigger((c) => c + 1);
  }, [injectedBundle]);

  useEffect(() => {
    if (!autoRun) return;
    const timer = window.setTimeout(() => {
      setCommittedDoc(buildSrcDoc(htmlCode, cssCode, jsCode));
    }, 280);
    return () => window.clearTimeout(timer);
  }, [htmlCode, cssCode, jsCode, autoRun]);

  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (event.data?.source !== "iraqi-coders-playground") return;
      setConsoleEntries((prev) => [
        ...prev.slice(-19),
        {
          id: `${Date.now()}-${Math.random()}`,
          level: event.data.level || "log",
          text: event.data.text || "",
        },
      ]);
    };
    window.addEventListener("message", handleMessage);
    return () => window.removeEventListener("message", handleMessage);
  }, []);

  const handleManualRun = () => {
    setConsoleEntries([]);
    setCommittedDoc(buildSrcDoc(htmlCode, cssCode, jsCode));
    setManualRunTrigger((c) => c + 1);
    onCodeRun();
  };

  const handleTemplateSelect = (templateId: string) => {
    const tpl = PLAYGROUND_TEMPLATES.find((t) => t.id === templateId);
    if (!tpl) return;
    setSelectedTemplateId(tpl.id);
    setHtmlCode(tpl.html);
    setCssCode(tpl.css);
    setJsCode(tpl.js);
    setConsoleEntries([]);
    setCommittedDoc(buildSrcDoc(tpl.html, tpl.css, tpl.js));
    onCodeRun();
  };

  const handleReset = () => {
    handleTemplateSelect(selectedTemplateId);
  };

  const handleCopyBundle = async () => {
    const fullHtml = buildSrcDoc(htmlCode, cssCode, jsCode);
    try {
      await navigator.clipboard.writeText(fullHtml);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      // Safe no-op
    }
  };

  const handleDownloadHtml = () => {
    const fullHtml = buildSrcDoc(htmlCode, cssCode, jsCode);
    const blob = new Blob([fullHtml], { type: "text/html;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `iraqi-coders-${selectedTemplateId}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleDownloadZip = () => {
    const tplName =
      PLAYGROUND_TEMPLATES.find((t) => t.id === selectedTemplateId)?.name ||
      "مشروع عراقي كودرز";
    const built = buildWebSourceZipBlob({
      title: tplName,
      author: user?.name || "مطور عراقي كودرز",
      html: htmlCode,
      css: cssCode,
      js: jsCode,
    });
    const url = URL.createObjectURL(built.blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `iraqi-coders-${selectedTemplateId}.zip`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    onShowToast?.("تم تصدير مشروع الويب الكامل بصيغة ZIP!");
  };

  const handleSaveToCloud = async () => {
    if (!onSaveToCloud) return;
    const tplName =
      injectedBundle?.label ||
      PLAYGROUND_TEMPLATES.find((t) => t.id === selectedTemplateId)?.name ||
      "مشروع ويب من المحرر";
    const id = `play-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const built = buildWebSourceZipBlob({
      title: tplName,
      author: user?.name || "مطور عراقي كودرز",
      html: htmlCode,
      css: cssCode,
      js: jsCode,
    });
    await saveCloudBinaryBlob(id, built.blob);
    onSaveToCloud({
      id,
      ownerId: user?.id || "local-guest-dev",
      ownerName: user?.name || "مطور عراقي كودرز",
      ownerHandle: user?.handle || "@iraqi_dev",
      title: tplName,
      description: "مشروع ويب من محرر الكود المباشر (HTML/CSS/JS).",
      fileName: `${selectedTemplateId}.zip`,
      fileType: "web",
      fileSizeBytes: built.blob.size,
      content: buildSrcDoc(htmlCode, cssCode, jsCode),
      visibility: "private",
      downloads: 0,
      createdAt: "الآن",
    });
    onShowToast?.(`تم حفظ «${tplName}» في سحابتك الخاصة!`);
  };

  const activeValue = useMemo(() => {
    if (activeTab === "html") return htmlCode;
    if (activeTab === "css") return cssCode;
    return jsCode;
  }, [activeTab, htmlCode, cssCode, jsCode]);

  const handleEditorChange = (val: string) => {
    if (activeTab === "html") setHtmlCode(val);
    else if (activeTab === "css") setCssCode(val);
    else setJsCode(val);
  };

  const lineCount = activeValue.split("\n").length;

  return (
    <section id="playground" className="scroll-mt-24 border-b border-white/10 py-14 lg:py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mb-8 flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <p className="text-xs font-bold text-emerald-400 mb-2">
              بيئة التجربة الحية · HTML / CSS / JS
            </p>
            <h2 className="text-2xl font-extrabold text-white sm:text-3xl">
              محرر الكود المباشر
            </h2>
            <p className="mt-2 max-w-2xl text-sm leading-relaxed text-slate-400">
              اكتب شيفرتك البرمجية أو جرّب قوالب المواقع ولوحات التحكم والحاسبات،
              واختبر العرض على الموبايل والكمبيوتر وصدّرها فوراً.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <label htmlFor="tpl-select" className="text-xs font-semibold text-slate-400">
              القالب الجاهز:
            </label>
            <select
              id="tpl-select"
              value={selectedTemplateId}
              onChange={(e) => handleTemplateSelect(e.target.value)}
              className="rounded-lg border border-white/15 bg-[#111827] px-3 py-2 text-xs font-bold text-white focus:border-violet-500 focus:outline-none cursor-pointer"
            >
              {PLAYGROUND_TEMPLATES.map((tpl) => (
                <option key={tpl.id} value={tpl.id}>
                  {tpl.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="glass-surface overflow-hidden rounded-2xl">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 bg-[#0E1424] px-4 py-3">
            <div className="flex items-center gap-1 rounded-lg bg-[#0B0F19] p-1 border border-white/10">
              {(
                [
                  { id: "html", label: "HTML" },
                  { id: "css", label: "CSS" },
                  { id: "js", label: "JavaScript" },
                ] as const
              ).map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveTab(tab.id)}
                  className={`rounded-md px-3.5 py-1.5 font-mono text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    activeTab === tab.id
                      ? "bg-violet-600 text-white"
                      : "text-slate-400 hover:text-white"
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <label className="inline-flex items-center gap-2 rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-semibold text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={autoRun}
                  onChange={(e) => setAutoRun(e.target.checked)}
                  className="accent-emerald-500"
                />
                <span>تشغيل تلقائي</span>
              </label>

              <button
                type="button"
                onClick={handleManualRun}
                className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3.5 py-1.5 text-xs font-bold text-white transition-colors hover:bg-emerald-500 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Play className="h-3.5 w-3.5" />
                <span>تشغيل الكود</span>
              </button>

              <button
                type="button"
                onClick={handleCopyBundle}
                className="inline-flex items-center gap-1.5 rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-semibold text-slate-200 hover:bg-white/10 whitespace-nowrap shrink-0 cursor-pointer"
              >
                {copied ? (
                  <>
                    <Check className="h-3.5 w-3.5 text-emerald-400" />
                    <span>تم النسخ</span>
                  </>
                ) : (
                  <>
                    <Copy className="h-3.5 w-3.5" />
                    <span>نسخ</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={handleDownloadHtml}
                className="inline-flex items-center gap-1.5 rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-semibold text-slate-200 hover:bg-white/10 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Download className="h-3.5 w-3.5" />
                <span>HTML</span>
              </button>

              <button
                type="button"
                onClick={handleDownloadZip}
                className="inline-flex items-center gap-1.5 rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-semibold text-amber-200 hover:bg-white/10 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <FileArchive className="h-3.5 w-3.5" />
                <span>تصدير ZIP</span>
              </button>

              {onSaveToCloud && (
                <button
                  type="button"
                  onClick={() => void handleSaveToCloud()}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-sky-400/35 bg-sky-500/15 px-3 py-1.5 text-xs font-bold text-sky-200 hover:bg-sky-500/25 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <CloudUpload className="h-3.5 w-3.5" />
                  <span>حفظ بالسحابة</span>
                </button>
              )}

              <button
                type="button"
                onClick={handleReset}
                title="إعادة القالب الافتراضي"
                className="inline-flex items-center gap-1.5 rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-semibold text-slate-300 hover:bg-white/10 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <RotateCcw className="h-3.5 w-3.5" />
                <span>إعادة ضبط</span>
              </button>
            </div>
          </div>

          <div className="desktop-grid-2 grid grid-cols-1 lg:grid-cols-2">
            <div className="flex flex-col border-b border-white/10 bg-[#080C15] lg:border-b-0 lg:border-l">
              <div className="flex items-center justify-between border-b border-white/5 px-4 py-2 text-[11px] font-mono text-slate-400">
                <span>
                  {activeTab.toUpperCase()} · {lineCount} أسطر
                </span>
                <span>UTF-8</span>
              </div>
              <textarea
                dir="ltr"
                spellCheck={false}
                value={activeValue}
                onChange={(e) => handleEditorChange(e.target.value)}
                aria-label={`محرر كود ${activeTab}`}
                className="code-editor h-[380px] w-full resize-none bg-transparent p-4 font-mono text-[13px] leading-6 text-slate-100 focus:outline-none"
              />
            </div>

            <div className="flex flex-col bg-[#0B0F19]">
              <div className="flex items-center justify-between border-b border-white/10 bg-[#0E1424]/60 px-4 py-2 text-xs text-slate-400">
                <span className="font-semibold text-slate-200">المعاينة الحية</span>
                <div className="inline-flex items-center gap-1 rounded-lg border border-white/10 bg-[#080C15] p-0.5">
                  <button
                    type="button"
                    onClick={() => setPreviewMobile(false)}
                    className={`inline-flex items-center gap-1 rounded-md px-2 py-1 text-[11px] font-bold cursor-pointer ${
                      !previewMobile ? "bg-emerald-600 text-white" : "text-slate-400 hover:text-white"
                    }`}
                  >
                    <Monitor className="h-3 w-3" />
                    <span>حاسوب</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setPreviewMobile(true)}
                    className={`inline-flex items-center gap-1 rounded-md px-2 py-1 text-[11px] font-bold cursor-pointer ${
                      previewMobile ? "bg-violet-600 text-white" : "text-slate-400 hover:text-white"
                    }`}
                  >
                    <Smartphone className="h-3 w-3" />
                    <span>موبايل</span>
                  </button>
                </div>
              </div>

              <div className="flex justify-center bg-[#060912]">
                <iframe
                  key={manualRunTrigger}
                  srcDoc={committedDoc}
                  title="معاينة الكود المباشر"
                  sandbox="allow-scripts"
                  className={`h-[290px] w-full border-0 bg-[#0B0F19] transition-all duration-200 ${
                    previewMobile ? "max-w-[380px] border-x border-white/10" : ""
                  }`}
                />
              </div>

              <div className="border-t border-white/10 bg-[#080C15] px-4 py-2.5">
                <div className="mb-1.5 flex items-center justify-between text-[11px] text-slate-400">
                  <span className="inline-flex items-center gap-1.5 font-bold text-slate-300">
                    <Terminal className="h-3.5 w-3.5 text-violet-400" />
                    <span>سجل Console</span>
                  </span>
                  {consoleEntries.length > 0 && (
                    <button
                      type="button"
                      onClick={() => setConsoleEntries([])}
                      className="text-slate-400 hover:text-white cursor-pointer"
                    >
                      مسح السجل
                    </button>
                  )}
                </div>
                <div
                  dir="ltr"
                  className="h-[62px] overflow-y-auto font-mono text-xs space-y-1"
                >
                  {consoleEntries.length === 0 ? (
                    <div className="text-slate-600">
                      لا توجد رسائل مسجلة بعد — استخدم console.log() لعرض المخرجات هنا.
                    </div>
                  ) : (
                    consoleEntries.map((entry) => (
                      <div
                        key={entry.id}
                        className={
                          entry.level === "error"
                            ? "text-rose-400"
                            : entry.level === "warn"
                            ? "text-amber-300"
                            : "text-emerald-300"
                        }
                      >
                        &gt; {entry.text}
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
