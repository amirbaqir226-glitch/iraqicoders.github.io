import React, { useRef, useState } from "react";
import {
  Camera,
  CheckCircle2,
  CreditCard,
  Radio,
  RotateCw,
  ShieldCheck,
  Sparkles,
  Volume2,
  X,
} from "lucide-react";
import { speakArabicText, stopArabicSpeech } from "../services/speechEngine";
import { CustomNationalityCard, UserProfile, UserRole } from "../types";

interface NetworkVoiceNationalityModalProps {
  isOpen: boolean;
  user: UserProfile | null;
  userRole: UserRole;
  myNationality: CustomNationalityCard | null;
  onClose: () => void;
  onCreateNationality: (card: CustomNationalityCard) => Promise<void>;
  onShowToast: (msg: string) => void;
}

function compressImageToDataUrl(file: File, maxDim = 260): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const scale = Math.min(1, maxDim / Math.max(img.width, img.height));
        const w = Math.max(48, Math.round(img.width * scale));
        const h = Math.max(48, Math.round(img.height * scale));
        const canvas = document.createElement("canvas");
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          reject(new Error("Canvas not available"));
          return;
        }
        ctx.drawImage(img, 0, 0, w, h);
        resolve(canvas.toDataURL("image/jpeg", 0.78));
      };
      img.onerror = () => reject(new Error("تعذر قراءة الصورة."));
      img.src = String(reader.result || "");
    };
    reader.onerror = () => reject(new Error("تعذر فتح ملف الصورة."));
    reader.readAsDataURL(file);
  });
}

function getRankArabicTitle(role: UserRole): string {
  if (role === "admin") return "مسؤول المنصة";
  if (role === "director") return "مدير المنصة";
  if (role === "moderator") return "مشرف معتمد";
  if (role === "developer") return "مطور معتمد";
  return "مواطن عراقي كودرز";
}

export const NationalityDualFacesView: React.FC<{
  card: CustomNationalityCard;
}> = ({ card }) => {
  return (
    <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
      {/* الواجهة الأولى (الأمامية): الصورة الشخصية والبيانات الأساسية */}
      <div className="relative overflow-hidden rounded-2xl border-2 border-emerald-400/55 bg-gradient-to-br from-[#0F241E] via-[#0B1424] to-[#1A1330] p-5 shadow-xl">
        <div className="flex items-center justify-between border-b border-white/15 pb-3 mb-4">
          <div>
            <p className="text-[10px] font-bold tracking-wider text-emerald-300">
              الواجهة الأولى · البطاقة الوطنية الرقمية
            </p>
            <h4 className="text-sm font-extrabold text-white">
              جمهورية عراقي كودرز · IRAQI CODERS ID
            </h4>
          </div>
          <span className="rounded-lg border border-amber-400/50 bg-amber-500/15 px-2 py-0.5 font-mono text-[11px] font-extrabold text-amber-200">
            {card.nationalityCode}
          </span>
        </div>

        <div className="flex items-start gap-4">
          <div className="h-24 w-24 shrink-0 overflow-hidden rounded-2xl border-2 border-emerald-400/70 bg-[#080C15] flex items-center justify-center">
            {card.frontPhotoUrl || card.frontPhotoDataUrl ? (
              <img
                src={card.frontPhotoUrl || card.frontPhotoDataUrl}
                alt={card.fullName}
                className="h-full w-full object-cover"
              />
            ) : (
              <ShieldCheck className="h-10 w-10 text-emerald-400" />
            )}
          </div>

          <div className="min-w-0 flex-1 space-y-1.5 text-xs">
            <div>
              <span className="text-slate-400">الاسم الكامل: </span>
              <strong className="text-white">{card.fullName}</strong>
            </div>
            <div>
              <span className="text-slate-400">المعرّف: </span>
              <span dir="ltr" className="font-mono font-bold text-emerald-300">
                {card.ownerHandle}
              </span>
            </div>
            <div>
              <span className="text-slate-400">المحافظة: </span>
              <strong className="text-sky-200">{card.governorate}</strong>
            </div>
            <div>
              <span className="text-slate-400">الصفة / الرتبة: </span>
              <span className="rounded bg-violet-500/25 border border-violet-400/40 px-2 py-0.5 text-[11px] font-extrabold text-violet-200">
                {card.titleRank || card.rankTitle || "مواطن عراقي كودرز"}
              </span>
            </div>
          </div>
        </div>

        <div className="mt-4 flex items-center justify-between border-t border-white/10 pt-2.5 text-[11px] text-emerald-300 font-bold">
          <span>رقم السجل: #{card.numericId || card.nationalityCode}</span>
          <span className="inline-flex items-center gap-1">
            <CheckCircle2 className="h-3.5 w-3.5" />
            <span>جنسية موثقة</span>
          </span>
        </div>
      </div>

      {/* الواجهة الثانية (الخلفية): الجهة الخلفية المليئة بالمعلومات والصورة الثانية */}
      <div className="relative overflow-hidden rounded-2xl border-2 border-violet-400/55 bg-gradient-to-br from-[#16102B] via-[#0B1220] to-[#0E1E24] p-5 shadow-xl flex flex-col justify-between gap-3">
        <div>
          <div className="flex items-center justify-between border-b border-white/15 pb-3 mb-3">
            <div>
              <p className="text-[10px] font-bold text-violet-300">
                الواجهة الثانية · السجل الخلفي والتفاصيل الكاملة
              </p>
              <h4 className="text-sm font-extrabold text-white">
                البيانات البرمجية والتحقق الأمني
              </h4>
            </div>
            <div className="h-12 w-12 overflow-hidden rounded-xl border border-violet-400/50 bg-[#080C15] flex items-center justify-center shrink-0">
              {card.backEmblemUrl || card.backPhotoDataUrl ? (
                <img
                  src={card.backEmblemUrl || card.backPhotoDataUrl}
                  alt="شعار الجنسية الخلفي"
                  className="h-full w-full object-cover"
                />
              ) : card.frontPhotoUrl || card.frontPhotoDataUrl ? (
                <img
                  src={card.frontPhotoUrl || card.frontPhotoDataUrl}
                  alt={card.fullName}
                  className="h-full w-full object-cover opacity-80"
                />
              ) : (
                <CreditCard className="h-5 w-5 text-violet-300" />
              )}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 text-[11px]">
            <div className="rounded-xl border border-white/10 bg-[#080C15]/80 p-2">
              <span className="text-slate-400 block">التخصص البرمجي:</span>
              <strong className="text-emerald-300">{card.specialty}</strong>
            </div>
            <div className="rounded-xl border border-white/10 bg-[#080C15]/80 p-2">
              <span className="text-slate-400 block">تاريخ الإصدار:</span>
              <strong dir="ltr" className="font-mono text-sky-200">
                {new Date(card.issuedAt).toLocaleDateString("en-GB")}
              </strong>
            </div>
            <div className="rounded-xl border border-white/10 bg-[#080C15]/80 p-2 col-span-2">
              <span className="text-slate-400 block">البريد المرتبط والمعرّف الفريد:</span>
              <strong dir="ltr" className="font-mono text-amber-200 break-all">
                {card.ownerEmail || card.ownerUid} · UID:{card.numericId || card.nationalityCode}
              </strong>
            </div>
            <div className="rounded-xl border border-white/10 bg-[#080C15]/80 p-2 col-span-2">
              <span className="text-slate-400 block">النبذة والسجل الوطني:</span>
              <p className="text-slate-200 mt-0.5 leading-relaxed">{card.bio}</p>
            </div>
          </div>
        </div>

        {/* SVG Barcode Strip */}
        <div className="rounded-xl border border-white/10 bg-white px-3 py-2 flex items-center justify-between gap-3">
          <svg viewBox="0 0 180 28" className="h-6 flex-1" aria-hidden="true">
            {Array.from({ length: 34 }, (_, idx) => (
              <rect
                key={idx}
                x={idx * 5 + 2}
                y={2}
                width={(idx % 3) + 1.5}
                height={24}
                fill="#0F172A"
              />
            ))}
          </svg>
          <span dir="ltr" className="font-mono text-[10px] font-extrabold text-slate-900">
            {card.nationalityCode}-{card.numericId || card.ownerHandle.replace(/^@/, "")}
          </span>
        </div>
      </div>
    </div>
  );
};

export const NetworkVoiceNationalityModal: React.FC<
  NetworkVoiceNationalityModalProps
> = ({
  isOpen,
  user,
  userRole,
  myNationality,
  onClose,
  onCreateNationality,
  onShowToast,
}) => {
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [fullName, setFullName] = useState(user?.name || "");
  const [governorate, setGovernorate] = useState(user?.city || "بغداد");
  const [specialty, setSpecialty] = useState("تطوير مواقع وتطبيقات");
  const [nationalityCode, setNationalityCode] = useState(
    () => `IQ-${Math.floor(100000 + Math.random() * 899999)}`
  );
  const [bio, setBio] = useState("مطور ومبتكر داخل منصة عراقي كودرز");
  const [frontPhoto, setFrontPhoto] = useState(user?.avatarUrl || "");
  const [backPhoto, setBackPhoto] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [voicePlaying, setVoicePlaying] = useState(false);

  const frontInputRef = useRef<HTMLInputElement>(null);
  const backInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handlePlayNetworkVoice = () => {
    if (voicePlaying) {
      stopArabicSpeech();
      setVoicePlaying(false);
      return;
    }
    setVoicePlaying(true);
    speakArabicText(
      myNationality
        ? `أهلاً بك في صوت الشبكة! المواطن الرقمي ${myNationality.fullName} من محافظة ${myNationality.governorate}، جنسيتك الموثقة برمز ${myNationality.nationalityCode} جاهزة.`
        : "مرحباً بك في صوت الشبكة من عراقي كودرز! يمكنك هنا اختبار الصوت الشبكي أو الضغط على أنشئ جنسيتك الخاصة لإصدار بطاقتك الوطنية بواجهتين.",
      { voiceProfile: "fusha-clear" }
    );
    window.setTimeout(() => setVoicePlaying(false), 5500);
  };

  const handleUploadPhoto = async (
    e: React.ChangeEvent<HTMLInputElement>,
    target: "front" | "back"
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await compressImageToDataUrl(file);
      if (target === "front") setFrontPhoto(dataUrl);
      else setBackPhoto(dataUrl);
      onShowToast("تم رفع الصورة وضغطها للبطاقة بنجاح.");
    } catch {
      onShowToast("تعذر معالجة الصورة المختارة.");
    }
  };

  const handleSubmitNationality = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName.trim()) {
      onShowToast("يرجى كتابة الاسم الكامل أولاً.");
      return;
    }
    setSubmitting(true);
    try {
      const uid = user?.id || `local-${Date.now()}`;
      const frontResolved = frontPhoto || user?.avatarUrl || "";
      const backResolved = backPhoto || frontPhoto || user?.avatarUrl || "";
      const rankArabic = getRankArabicTitle(userRole);
      const card: CustomNationalityCard = {
        id: `nat-${uid}`,
        ownerUid: uid,
        ownerHandle: user?.handle || `@${fullName.trim().replace(/\s+/g, "_").toLowerCase()}`,
        ownerEmail: user?.email || "",
        numericId: String(Math.floor(100000 + Math.random() * 899999)),
        fullName: fullName.trim(),
        governorate: governorate.trim() || "بغداد",
        nationalityCode: nationalityCode.trim() || `IQ-${Date.now().toString().slice(-6)}`,
        specialty: specialty.trim() || "برمجة",
        titleRank: rankArabic,
        rankTitle: rankArabic,
        bio: bio.trim() || "مواطن رقمي في عراقي كودرز",
        frontPhotoUrl: frontResolved,
        backEmblemUrl: backResolved,
        frontPhotoDataUrl: frontResolved,
        backPhotoDataUrl: backResolved,
        issuedAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        verified: true,
      };
      await onCreateNationality(card);
      setShowCreateForm(false);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="network-voice-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="flex max-h-[92vh] w-full max-w-4xl flex-col overflow-hidden rounded-3xl border border-emerald-400/40 bg-[#0D1424] shadow-2xl"
      >
        {/* Header */}
        <div className="flex items-center justify-between gap-3 border-b border-white/10 bg-[#0A101E] px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl border border-emerald-400/45 bg-emerald-500/15 text-emerald-300">
              <Radio className="h-5 w-5" />
            </div>
            <div>
              <h2
                id="network-voice-title"
                className="text-lg font-extrabold text-white"
              >
                صوت الشبكة والهوية الرقمية
              </h2>
              <p className="text-xs text-slate-400">
                البث الصوتي المباشر للشبكة وإدارة جنسيتك الخاصة بواجهتين
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              stopArabicSpeech();
              onClose();
            }}
            aria-label="إغلاق صوت الشبكة"
            className="inline-flex h-9 w-9 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-slate-300 hover:text-white cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Network Voice Audio Control Strip */}
          <div className="rounded-2xl border border-sky-400/35 bg-[#080C15] p-4 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <Volume2 className="h-5 w-5 text-sky-400 shrink-0" />
              <div>
                <p className="text-xs font-extrabold text-white">
                  بث صوت الشبكة (Network Voice Engine)
                </p>
                <p className="text-[11px] text-slate-400">
                  استمع إلى حالة الشبكة أو نطق بيانات جنسيتك بالصوت العربي الفصيح
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={handlePlayNetworkVoice}
                className="inline-flex items-center gap-2 rounded-xl bg-sky-600 px-4 py-2 text-xs font-extrabold text-white hover:bg-sky-500 cursor-pointer"
              >
                <Volume2 className="h-4 w-4" />
                <span>{voicePlaying ? "إيقاف الصوت" : "تشغيل صوت الشبكة"}</span>
              </button>

              {/* Show "أنشئ جنسيتك الخاصة" ONLY if nationality has not been created yet! */}
              {!myNationality && !showCreateForm && (
                <button
                  type="button"
                  onClick={() => setShowCreateForm(true)}
                  className="version-glow inline-flex items-center gap-2 rounded-xl bg-gradient-to-l from-emerald-600 to-violet-600 px-4 py-2 text-xs font-extrabold text-white hover:opacity-95 cursor-pointer"
                >
                  <Sparkles className="h-4 w-4" />
                  <span>أنشئ جنسيتك الخاصة</span>
                </button>
              )}
            </div>
          </div>

          {/* After Creation: Button disappears and Two Nationality Faces appear! */}
          {myNationality ? (
            <div className="space-y-3">
              <div className="flex items-center justify-between gap-2">
                <h3 className="text-sm font-extrabold text-emerald-300 flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4" />
                  <span>جنسيتك الخاصة المصدّرة (الواجهتان الأمامية والخلفية):</span>
                </h3>
                <span className="text-[11px] font-mono text-slate-400">
                  تم الإخفاء التلقائي لزر الإنشاء ✓
                </span>
              </div>
              <NationalityDualFacesView card={myNationality} />
            </div>
          ) : showCreateForm ? (
            <form
              onSubmit={handleSubmitNationality}
              className="rounded-3xl border border-emerald-400/35 bg-[#0A101E] p-5 space-y-4"
            >
              <div className="flex items-center justify-between">
                <h3 className="text-base font-extrabold text-white">
                  استمارة إصدار «جنسيتك الخاصة»
                </h3>
                <button
                  type="button"
                  onClick={() => setNationalityCode(`IQ-${Math.floor(100000 + Math.random() * 899999)}`)}
                  className="inline-flex items-center gap-1 rounded-lg border border-white/15 bg-white/5 px-2.5 py-1 text-[11px] font-bold text-slate-300 hover:text-white cursor-pointer"
                >
                  <RotateCw className="h-3 w-3" />
                  <span>توليد رمز وطني</span>
                </button>
              </div>

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    الاسم الكامل
                  </label>
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="اكتب اسمك الكامل"
                    className="h-10 w-full rounded-xl border border-white/15 bg-[#080C15] px-3 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    المحافظة
                  </label>
                  <input
                    type="text"
                    required
                    value={governorate}
                    onChange={(e) => setGovernorate(e.target.value)}
                    placeholder="بغداد، البصرة، أربيل..."
                    className="h-10 w-full rounded-xl border border-white/15 bg-[#080C15] px-3 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    التخصص البرمجي / المهني
                  </label>
                  <input
                    type="text"
                    required
                    value={specialty}
                    onChange={(e) => setSpecialty(e.target.value)}
                    placeholder="مثال: Roblox Luau و React"
                    className="h-10 w-full rounded-xl border border-white/15 bg-[#080C15] px-3 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    رقم الجنسية المخصص
                  </label>
                  <input
                    type="text"
                    dir="ltr"
                    required
                    value={nationalityCode}
                    onChange={(e) => setNationalityCode(e.target.value)}
                    className="h-10 w-full rounded-xl border border-white/15 bg-[#080C15] px-3 font-mono text-xs text-emerald-300"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  معلومات إضافية (تظهر في الواجهة الخلفية)
                </label>
                <textarea
                  rows={2}
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  className="w-full rounded-xl border border-white/15 bg-[#080C15] p-3 text-xs text-white"
                />
              </div>

              {/* Dual Image Uploads */}
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div className="rounded-2xl border border-white/10 bg-[#080C15] p-3 flex items-center gap-3">
                  <div className="h-14 w-14 rounded-xl border border-emerald-400/40 bg-[#10182E] overflow-hidden flex items-center justify-center shrink-0">
                    {frontPhoto ? (
                      <img
                        src={frontPhoto}
                        alt="الصورة الأولى"
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <Camera className="h-5 w-5 text-emerald-300" />
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-extrabold text-white">
                      الصورة 1 (الواجهة الأمامية)
                    </p>
                    <button
                      type="button"
                      onClick={() => frontInputRef.current?.click()}
                      className="mt-1 rounded-lg bg-emerald-600/25 border border-emerald-400/40 px-2.5 py-1 text-[11px] font-bold text-emerald-200 cursor-pointer"
                    >
                      رفع صورة شخصية
                    </button>
                    <input
                      ref={frontInputRef}
                      type="file"
                      accept="image/*"
                      onChange={(e) => void handleUploadPhoto(e, "front")}
                      className="hidden"
                    />
                  </div>
                </div>

                <div className="rounded-2xl border border-white/10 bg-[#080C15] p-3 flex items-center gap-3">
                  <div className="h-14 w-14 rounded-xl border border-violet-400/40 bg-[#10182E] overflow-hidden flex items-center justify-center shrink-0">
                    {backPhoto ? (
                      <img
                        src={backPhoto}
                        alt="الصورة الثانية"
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <Camera className="h-5 w-5 text-violet-300" />
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-extrabold text-white">
                      الصورة 2 (الواجهة الخلفية)
                    </p>
                    <button
                      type="button"
                      onClick={() => backInputRef.current?.click()}
                      className="mt-1 rounded-lg bg-violet-600/25 border border-violet-400/40 px-2.5 py-1 text-[11px] font-bold text-violet-200 cursor-pointer"
                    >
                      رفع صورة/ختم خلفي
                    </button>
                    <input
                      ref={backInputRef}
                      type="file"
                      accept="image/*"
                      onChange={(e) => void handleUploadPhoto(e, "back")}
                      className="hidden"
                    />
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap gap-2 pt-1">
                <button
                  type="submit"
                  disabled={submitting}
                  className="inline-flex flex-1 items-center justify-center gap-2 rounded-xl bg-emerald-600 py-3 text-xs font-extrabold text-white hover:bg-emerald-500 disabled:opacity-60 cursor-pointer"
                >
                  <Sparkles className="h-4 w-4" />
                  <span>
                    {submitting
                      ? "جاري إصدار الجنسية..."
                      : "إنشاء وحفظ الجنسية بالواجهتين الآن"}
                  </span>
                </button>
                <button
                  type="button"
                  onClick={() => setShowCreateForm(false)}
                  className="rounded-xl border border-white/15 bg-white/5 px-4 py-3 text-xs font-bold text-slate-300 hover:bg-white/10 cursor-pointer"
                >
                  إلغاء
                </button>
              </div>
            </form>
          ) : (
            <div className="rounded-2xl border border-dashed border-emerald-400/35 bg-[#080C15] p-6 text-center space-y-3">
              <p className="text-sm font-extrabold text-white">
                لم تقم بإنشاء جنسيتك الخاصة بعد!
              </p>
              <p className="text-xs text-slate-400 max-w-md mx-auto">
                اضغط على «أنشئ جنسيتك الخاصة» لملء معلوماتك ورفع صورتيك، وبعد الإنشاء ستظهر واجهتان لبطاقتك الوطنية الرقمية.
              </p>
              <button
                type="button"
                onClick={() => setShowCreateForm(true)}
                className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-5 py-2.5 text-xs font-extrabold text-white hover:bg-emerald-500 cursor-pointer"
              >
                <Sparkles className="h-4 w-4" />
                <span>أنشئ جنسيتك الخاصة الآن</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
