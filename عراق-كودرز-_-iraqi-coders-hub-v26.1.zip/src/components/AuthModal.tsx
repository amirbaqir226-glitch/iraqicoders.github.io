import React, { useState } from "react";
import { GoogleAuthProvider, signInWithPopup } from "firebase/auth";
import { Crown, KeyRound, Loader2, ShieldCheck, UserCheck, X } from "lucide-react";
import {
  firebaseAuth,
  googleProvider,
  isOwnerEmail,
  matchesOwnerIdentity,
  OWNER_PERSON,
  setGmailAccessToken,
} from "../config/firebase";
import { DEFAULT_DEVELOPER_AVATAR } from "../data/initialData";
import { syncUserProfileToFirestore } from "../services/firestoreService";
import { ThemeDecoration, UserProfile } from "../types";

interface AuthModalProps {
  isOpen: boolean;
  defaultTheme: ThemeDecoration;
  defaultDesktopMode: boolean;
  onClose: () => void;
  onLogin: (profile: UserProfile) => void;
  onUnlockAdmin?: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  defaultTheme,
  defaultDesktopMode,
  onClose,
  onLogin,
  onUnlockAdmin,
}) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [canOfferPreviewFallback, setCanOfferPreviewFallback] = useState(false);
  const [fallbackName, setFallbackName] = useState<string>(OWNER_PERSON.displayName);
  const [fallbackIdentifier, setFallbackIdentifier] = useState<string>(OWNER_PERSON.username);
  const [fallbackPin, setFallbackPin] = useState("");
  const [pinError, setPinError] = useState("");

  if (!isOpen) return null;

  const handleGoogleSignIn = async () => {
    setLoading(true);
    setError("");
    setCanOfferPreviewFallback(false);

    try {
      const result = await signInWithPopup(firebaseAuth, googleProvider);
      const credential = GoogleAuthProvider.credentialFromResult(result);
      if (credential?.accessToken) {
        setGmailAccessToken(credential.accessToken);
      }
      const fbUser = result.user;

      const synced = await syncUserProfileToFirestore(fbUser, {
        city: "العراق",
        themeDecoration: defaultTheme,
        desktopMode: defaultDesktopMode,
      });

      const fallbackHandle = `@${(
        fbUser.email?.split("@")[0] || "iraqi_dev"
      )
        .replace(/[^a-zA-Z0-9_]/g, "")
        .toLowerCase()
        .slice(0, 28)}`;

      const ownerAuth = isOwnerEmail(fbUser.email);

      const profile: UserProfile = {
        id: fbUser.uid,
        name: synced?.displayName || fbUser.displayName || "مطور Google",
        handle: synced?.handle || fallbackHandle,
        email: fbUser.email || "",
        avatarUrl:
          synced?.avatarUrl || fbUser.photoURL || DEFAULT_DEVELOPER_AVATAR,
        provider: "google",
        city: synced?.city || "العراق",
        role: ownerAuth ? "admin" : synced?.role || "user",
        themeDecoration: synced?.themeDecoration || defaultTheme,
        desktopMode:
          synced?.desktopMode !== undefined
            ? synced.desktopMode
            : defaultDesktopMode,
        loggedInAt: new Date().toISOString(),
      };

      onLogin(profile);
      onClose();
    } catch (err: unknown) {
      const firebaseErr = err as { code?: string; message?: string };
      const code = firebaseErr?.code || "";
      if (code === "auth/popup-closed-by-user") {
        setError("تم إغلاق نافذة Google قبل إتمام تسجيل الدخول.");
        setCanOfferPreviewFallback(true);
      } else if (
        code === "auth/unauthorized-domain" ||
        code === "auth/operation-not-supported-in-this-environment" ||
        code === "auth/popup-blocked"
      ) {
        setError(
          `تعذر إتمام النافذة المنبثقة على هذا النطاق (${code}). يمكنك الدخول مباشرة بالمعرّف أو جلسة المعاينة أدناه.`
        );
        setCanOfferPreviewFallback(true);
      } else {
        setError(
          `تعذر إتمام تسجيل الدخول عبر Google: ${
            firebaseErr?.message || "يرجى المحاولة مرة أخرى."
          }`
        );
        setCanOfferPreviewFallback(true);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleLocalPreviewSession = (e: React.FormEvent) => {
    e.preventDefault();
    setPinError("");

    const rawId = fallbackIdentifier.trim() || OWNER_PERSON.username;
    const isOwnerMatch = matchesOwnerIdentity(rawId);
    const trimmedPin = fallbackPin.trim();
    const isPinValid = trimmedPin === "2019" || trimmedPin === "A20019";

    if (!isOwnerMatch && trimmedPin.length > 0 && !isPinValid) {
      setPinError(
        "رمز التحقق الإداري غير صحيح. أدخل الرمز الصحيح (2019) أو اتركه فارغاً."
      );
      return;
    }

    const cleanUsername = rawId
      .replace(/^@/, "")
      .split("@")[0]
      .replace(/[^a-zA-Z0-9_.-]/g, "")
      .toLowerCase()
      .slice(0, 28) || "iraqi_dev";

    const resolvedEmail = isOwnerMatch
      ? OWNER_PERSON.email
      : rawId.includes("@") && !rawId.startsWith("@")
      ? rawId.toLowerCase()
      : `${cleanUsername}@iraqicoders.iq`;

    const resolvedHandle = isOwnerMatch
      ? OWNER_PERSON.handle
      : `@${cleanUsername}`;

    const resolvedRole = isOwnerMatch || isPinValid ? "admin" : "user";

    if (isOwnerMatch || isPinValid) {
      onUnlockAdmin?.();
    }

    const profile: UserProfile = {
      id: isOwnerMatch ? OWNER_PERSON.username : `local-${cleanUsername}-${Date.now()}`,
      name:
        fallbackName.trim() ||
        (isOwnerMatch ? OWNER_PERSON.displayName : cleanUsername),
      handle: resolvedHandle,
      email: resolvedEmail,
      avatarUrl: DEFAULT_DEVELOPER_AVATAR,
      provider: "google",
      city: "بغداد",
      role: resolvedRole,
      themeDecoration: defaultTheme,
      desktopMode: defaultDesktopMode,
      loggedInAt: new Date().toISOString(),
    };

    void fetch("/api/directory/people", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        username: cleanUsername,
        displayName: profile.name,
        email: profile.email,
        role: profile.role,
        city: profile.city,
        enabled: true,
      }),
    }).catch(() => undefined);

    onLogin(profile);
    onClose();
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="auth-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md rounded-2xl border border-white/15 bg-[#0E1424] p-6 shadow-2xl max-h-[92vh] overflow-y-auto"
      >
        <div className="flex items-start justify-between gap-4 mb-5">
          <div>
            <h3 id="auth-modal-title" className="text-xl font-extrabold text-white">
              إنشاء حساب / تسجيل الدخول بواسطة Google
            </h3>
            <p className="mt-1 text-xs leading-relaxed text-slate-400">
              مربوط مباشرة مع Firebase Authentication و Cloud Firestore لحفظ
              ملفك الشخصي وسحابتك الخاصة.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="إغلاق نافذة تسجيل الدخول"
            className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 bg-white/5 text-slate-300 hover:bg-white/10 hover:text-white cursor-pointer shrink-0"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <button
          type="button"
          disabled={loading}
          onClick={handleGoogleSignIn}
          className="flex w-full items-center justify-center gap-3 rounded-xl border border-white/20 bg-white px-5 py-3.5 text-sm font-extrabold text-slate-900 shadow-lg transition-transform hover:scale-[1.01] disabled:opacity-60 cursor-pointer"
        >
          {loading ? (
            <>
              <Loader2 className="h-5 w-5 animate-spin text-violet-700" />
              <span>جارٍ التحقق عبر Google...</span>
            </>
          ) : (
            <>
              <svg className="h-5 w-5 shrink-0" viewBox="0 0 24 24" aria-hidden="true">
                <path
                  fill="#EA4335"
                  d="M12 10.2v3.9h5.5c-.2 1.3-1.5 3.9-5.5 3.9-3.3 0-6-2.7-6-6s2.7-6 6-6c1.9 0 3.1.8 3.9 1.5l2.7-2.6C16.9 3.3 14.7 2.4 12 2.4 6.7 2.4 2.4 6.7 2.4 12s4.3 9.6 9.6 9.6c5.5 0 9.2-3.9 9.2-9.4 0-.6-.1-1.1-.2-1.6H12z"
                />
              </svg>
              <span>إنشاء حساب / تسجيل الدخول بواسطة Google</span>
            </>
          )}
        </button>

        {!canOfferPreviewFallback && (
          <button
            type="button"
            onClick={() => setCanOfferPreviewFallback(true)}
            className="mt-3 flex w-full items-center justify-center gap-1.5 rounded-xl border border-white/10 bg-white/5 py-2.5 text-xs font-bold text-slate-300 transition-colors hover:border-emerald-400/40 hover:text-emerald-200 cursor-pointer"
          >
            <UserCheck className="h-3.5 w-3.5 text-emerald-400" />
            <span>دخول مباشر بالمعرّف (@amirbaqir226 أو معاينة محلية)</span>
          </button>
        )}

        {error && (
          <div className="mt-4 rounded-xl border border-rose-500/35 bg-rose-500/10 px-4 py-3 text-xs leading-relaxed font-semibold text-rose-200">
            {error}
          </div>
        )}

        {canOfferPreviewFallback && (
          <form
            onSubmit={handleLocalPreviewSession}
            className="mt-4 rounded-xl border border-emerald-500/30 bg-[#0B0F19] p-4 space-y-3"
          >
            <div className="flex items-center justify-between gap-2">
              <p className="text-xs font-extrabold text-emerald-300 flex items-center gap-1.5">
                <ShieldCheck className="h-4 w-4 shrink-0" />
                <span>جلسة المعاينة والتفعيل المباشر</span>
              </p>
              <button
                type="button"
                onClick={() => {
                  setFallbackName(OWNER_PERSON.displayName);
                  setFallbackIdentifier(OWNER_PERSON.username);
                  setPinError("");
                }}
                className="inline-flex items-center gap-1 rounded-lg border border-amber-400/40 bg-amber-500/15 px-2 py-1 text-[11px] font-bold text-amber-200 hover:bg-amber-500/25 cursor-pointer"
              >
                <Crown className="h-3 w-3" />
                <span dir="ltr">@amirbaqir226</span>
              </button>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-400 mb-1">
                الاسم المعروض
              </label>
              <input
                type="text"
                value={fallbackName}
                onChange={(e) => setFallbackName(e.target.value)}
                placeholder="أمير باقر"
                className="h-10 w-full rounded-lg border border-white/10 bg-[#111827] px-3 text-xs text-white focus:border-violet-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-400 mb-1">
                اسم المستخدم أو البريد (مثل amirbaqir226)
              </label>
              <input
                type="text"
                dir="ltr"
                value={fallbackIdentifier}
                onChange={(e) => setFallbackIdentifier(e.target.value)}
                placeholder="amirbaqir226 أو email@gmail.com"
                className="h-10 w-full rounded-lg border border-white/10 bg-[#111827] px-3 font-mono text-xs text-emerald-300 focus:border-violet-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-400 mb-1 flex items-center gap-1">
                <KeyRound className="h-3 w-3 text-amber-400" />
                <span>رمز الإدارة للتحقق الكامل (اختياري)</span>
              </label>
              <input
                type="password"
                dir="ltr"
                value={fallbackPin}
                onChange={(e) => {
                  setFallbackPin(e.target.value);
                  setPinError("");
                }}
                placeholder="اختياري — PIN لصلاحيات المدير الكاملة"
                className="h-10 w-full rounded-lg border border-white/10 bg-[#111827] px-3 font-mono text-xs text-white focus:border-amber-400 focus:outline-none"
              />
            </div>

            {pinError && (
              <p className="rounded-lg border border-rose-500/35 bg-rose-500/10 px-3 py-2 text-[11px] font-semibold text-rose-300">
                {pinError}
              </p>
            )}

            <button
              type="submit"
              className="w-full rounded-lg bg-violet-600 py-2.5 text-xs font-bold text-white hover:bg-violet-500 cursor-pointer"
            >
              تفعيل الدخول على المنصة
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
