import React from "react";
import {
  Check,
  Clock,
  Coins,
  Crown,
  Infinity as InfinityIcon,
  Paintbrush,
  Sparkles,
  Wrench,
  X,
  Zap,
} from "lucide-react";
import { STORE_ITEMS } from "../data/initialData";
import { StoreItem, ThemeDecoration, UserEconomy } from "../types";

interface CurrencyStoreModalProps {
  isOpen: boolean;
  economy: UserEconomy;
  isAdminPrivileged: boolean;
  onClose: () => void;
  onTradeTimeForCoins: (secondsCost: number, coinsReward: number) => void;
  onPurchaseOrActivateItem: (item: StoreItem) => void;
  onApplyThemeFromStore: (theme: ThemeDecoration) => void;
}

const TIME_EXCHANGE_OFFERS = [
  {
    id: "offer-1m",
    label: "دقيقة تفاعل واحدة",
    secondsCost: 60,
    coinsReward: 25,
    note: "تحويل سريع للمبتدئين",
  },
  {
    id: "offer-15m",
    label: "15 دقيقة برمجة",
    secondsCost: 900,
    coinsReward: 400,
    note: "مكافأة +25 عملة إضافية",
  },
  {
    id: "offer-1h",
    label: "ساعة كاملة (60 دقيقة)",
    secondsCost: 3600,
    coinsReward: 1800,
    note: "أفضل قيمة لتحويل الوقت",
  },
];

function formatActiveDuration(totalSeconds: number): string {
  const s = Math.max(0, Math.floor(totalSeconds));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const rem = s % 60;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(
    rem
  ).padStart(2, "0")}`;
}

export const CurrencyStoreModal: React.FC<CurrencyStoreModalProps> = ({
  isOpen,
  economy,
  isAdminPrivileged,
  onClose,
  onTradeTimeForCoins,
  onPurchaseOrActivateItem,
  onApplyThemeFromStore,
}) => {
  if (!isOpen) return null;

  const progressToNextMinute = Math.min(
    100,
    Math.round(((economy.activeSeconds % 60) / 60) * 100)
  );

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="متجر العملات ووقت التفاعل"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-3 sm:p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-4xl max-h-[90vh] overflow-y-auto rounded-2xl border border-amber-400/30 bg-[#0E1424] p-5 sm:p-6 shadow-2xl space-y-6"
      >
        {/* Modal Header */}
        <div className="flex items-start justify-between gap-4 border-b border-white/10 pb-4">
          <div>
            <div className="inline-flex items-center gap-1.5 rounded-lg border border-amber-400/35 bg-amber-500/10 px-2.5 py-1 text-[11px] font-extrabold text-amber-300 mb-2">
              <Coins className="h-3.5 w-3.5" />
              <span>نظام اقتصاد الوقت والعملات · الإصدار 26.5</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-white">
              متجر العملات ووقت التفاعل
            </h2>
            <p className="mt-1 text-xs sm:text-sm text-slate-400">
              كل ثانية تقضيها في التفاعل والبرمجة داخل عراقي كودرز تُحتسب لك
              كوقت قابل للتحويل إلى عملات رقمية وسكنات وأدوات حصرية.
            </p>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="إغلاق المتجر"
            className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-slate-300 hover:bg-white/10 hover:text-white cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Live Balances Banner */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div className="rounded-2xl border border-emerald-500/30 bg-[#0B0F19] p-4 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-300">
                <Clock className="h-4 w-4" />
                <span>وقت التفاعل المتراكم</span>
              </span>
              <span className="text-[11px] font-semibold text-slate-400">
                يحسب تلقائياً أثناء تواجدك
              </span>
            </div>
            <div
              dir="ltr"
              className="text-2xl sm:text-3xl font-extrabold font-mono text-white tracking-wider text-right"
            >
              {formatActiveDuration(economy.activeSeconds)}
            </div>
            <div className="space-y-1">
              <div className="flex justify-between text-[11px] text-slate-400">
                <span>التقدم للدقيقة التالية</span>
                <span>{progressToNextMinute}%</span>
              </div>
              <div className="h-2 w-full overflow-hidden rounded-full bg-white/10">
                <div
                  className="h-full rounded-full bg-gradient-to-l from-emerald-400 to-violet-500 transition-all duration-500"
                  style={{ width: `${progressToNextMinute}%` }}
                />
              </div>
            </div>
          </div>

          <div
            className={`rounded-2xl border p-4 flex flex-col justify-between ${
              isAdminPrivileged
                ? "border-amber-400/60 bg-gradient-to-br from-amber-500/15 via-[#0B0F19] to-violet-600/15"
                : "border-amber-400/30 bg-[#0B0F19]"
            }`}
          >
            <div className="flex items-center justify-between gap-2">
              <span className="inline-flex items-center gap-1.5 text-xs font-bold text-amber-300">
                {isAdminPrivileged ? (
                  <Crown className="h-4 w-4 text-amber-400" />
                ) : (
                  <Coins className="h-4 w-4" />
                )}
                <span>
                  {isAdminPrivileged
                    ? "رصيد المدير أمير (صلاحية مطلقة)"
                    : "رصيد العملات الرقمية"}
                </span>
              </span>
              {isAdminPrivileged && (
                <span className="rounded-md border border-amber-400/50 bg-amber-400/20 px-2 py-0.5 text-[10px] font-extrabold text-amber-200">
                  ADMIN VIP · فتح مجاني
                </span>
              )}
            </div>

            <div className="mt-2 flex items-center justify-between">
              {isAdminPrivileged ? (
                <div className="flex items-center gap-2 text-amber-300">
                  <InfinityIcon className="h-9 w-9" />
                  <span className="text-xl font-extrabold">
                    عملات لا نهائية
                  </span>
                </div>
              ) : (
                <div className="text-3xl font-extrabold text-amber-300 tabular-nums">
                  {economy.coins.toLocaleString("en-US")}{" "}
                  <span className="text-sm font-bold text-amber-200/80">
                    عملة
                  </span>
                </div>
              )}
            </div>

            <p className="mt-2 text-[11px] text-slate-400">
              {isAdminPrivileged
                ? "جميع السكنات والأدوات والزينة مفتوحة لك مجاناً بدون خصم رصيد."
                : `تم فتح ${economy.unlockedItems.length} من أصل ${STORE_ITEMS.length} عناصر في المتجر.`}
            </p>
          </div>
        </div>

        {/* Time-to-Coins Converter */}
        <section className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
              <Zap className="h-4 w-4 text-emerald-400" />
              <span>تحويل وقت التفاعل إلى عملات</span>
            </h3>
            <span className="text-[11px] text-slate-400">
              {isAdminPrivileged
                ? "المدير يستطيع التحويل بحرية كاملة"
                : "اختر الباقة المناسبة لوقتك المتراكم"}
            </span>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            {TIME_EXCHANGE_OFFERS.map((offer) => {
              const canAffordTime =
                isAdminPrivileged ||
                economy.activeSeconds >= offer.secondsCost;
              return (
                <div
                  key={offer.id}
                  className="flex flex-col justify-between rounded-xl border border-white/10 bg-[#0B0F19] p-4 space-y-3"
                >
                  <div>
                    <p className="text-xs font-extrabold text-white">
                      {offer.label}
                    </p>
                    <p className="mt-0.5 text-[11px] text-slate-400">
                      {offer.note}
                    </p>
                  </div>

                  <div className="flex items-center justify-between rounded-lg border border-amber-400/20 bg-amber-500/10 px-3 py-2">
                    <span className="text-[11px] font-bold text-slate-300">
                      المكافأة
                    </span>
                    <span className="text-sm font-extrabold text-amber-300">
                      +{offer.coinsReward} عملة
                    </span>
                  </div>

                  <button
                    type="button"
                    disabled={!canAffordTime}
                    onClick={() =>
                      onTradeTimeForCoins(offer.secondsCost, offer.coinsReward)
                    }
                    className={`w-full rounded-xl py-2 text-xs font-extrabold transition-colors ${
                      canAffordTime
                        ? "bg-emerald-600 text-white hover:bg-emerald-500 cursor-pointer"
                        : "bg-white/5 text-slate-500 cursor-not-allowed"
                    }`}
                  >
                    {canAffordTime
                      ? isAdminPrivileged
                        ? "إضافة فورية للمدير"
                        : "تحويل إلى عملات"
                      : `يتطلب ${Math.ceil(
                          (offer.secondsCost - economy.activeSeconds) / 60
                        )} د إضافية`}
                  </button>
                </div>
              );
            })}
          </div>
        </section>

        {/* Store Items Showcase */}
        <section className="space-y-3">
          <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-violet-400" />
            <span>سكنات الهوية، الأدوات الحصرية، وحزم الزينة</span>
          </h3>

          <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-2 lg:grid-cols-3">
            {STORE_ITEMS.map((item) => {
              const isUnlocked =
                isAdminPrivileged || economy.unlockedItems.includes(item.id);
              const isEquipped =
                item.category === "skin" && economy.equippedSkin === item.id;
              const canPurchase =
                isAdminPrivileged || economy.coins >= item.priceCoins;

              const CategoryIcon =
                item.category === "skin"
                  ? Crown
                  : item.category === "theme"
                  ? Paintbrush
                  : Wrench;

              return (
                <article
                  key={item.id}
                  className={`flex flex-col justify-between rounded-2xl border p-4 transition-colors ${
                    isEquipped
                      ? "border-emerald-400/60 bg-emerald-500/10"
                      : isUnlocked
                      ? "border-violet-400/35 bg-[#0B0F19]"
                      : "border-white/10 bg-[#0B0F19]"
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-2.5">
                      <span
                        className="inline-flex h-8 w-8 items-center justify-center rounded-xl border border-white/15"
                        style={{
                          backgroundColor: `${item.previewColor}22`,
                          color: item.previewColor,
                        }}
                      >
                        <CategoryIcon className="h-4 w-4" />
                      </span>

                      <span className="rounded-md border border-white/10 bg-white/5 px-2 py-0.5 text-[10px] font-bold text-slate-300">
                        {item.category === "skin"
                          ? "سكن شخصية"
                          : item.category === "theme"
                          ? "حزمة زينة"
                          : "أداة مطور"}
                      </span>
                    </div>

                    <h4 className="text-sm font-extrabold text-white">
                      {item.name}
                    </h4>
                    <p className="mt-1 text-xs leading-relaxed text-slate-400">
                      {item.description}
                    </p>
                  </div>

                  <div className="mt-4 pt-3 border-t border-white/10 space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-400">السعر</span>
                      {isAdminPrivileged ? (
                        <span className="font-extrabold text-amber-300">
                          مجاني للمدير
                        </span>
                      ) : (
                        <span className="font-extrabold text-amber-300">
                          {item.priceCoins} عملة
                        </span>
                      )}
                    </div>

                    {isUnlocked ? (
                      <div className="flex gap-2">
                        {item.category === "skin" ? (
                          <button
                            type="button"
                            onClick={() => onPurchaseOrActivateItem(item)}
                            className={`flex-1 inline-flex items-center justify-center gap-1.5 rounded-xl py-2 text-xs font-extrabold cursor-pointer ${
                              isEquipped
                                ? "border border-emerald-400/50 bg-emerald-600/25 text-emerald-200"
                                : "bg-violet-600 text-white hover:bg-violet-500"
                            }`}
                          >
                            <Check className="h-3.5 w-3.5" />
                            <span>
                              {isEquipped ? "مجهّز الآن (إلغاء)" : "تجهيز السكن"}
                            </span>
                          </button>
                        ) : item.category === "theme" ? (
                          <button
                            type="button"
                            onClick={() =>
                              onApplyThemeFromStore(
                                item.id === "theme-halloween-pack"
                                  ? "halloween"
                                  : "electric"
                              )
                            }
                            className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-xl bg-emerald-600 py-2 text-xs font-extrabold text-white hover:bg-emerald-500 cursor-pointer"
                          >
                            <Paintbrush className="h-3.5 w-3.5" />
                            <span>تفعيل الزينة فوراً</span>
                          </button>
                        ) : (
                          <div className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-xl border border-emerald-500/35 bg-emerald-500/15 py-2 text-xs font-extrabold text-emerald-300">
                            <Check className="h-3.5 w-3.5" />
                            <span>مفتوح وجاهز للاستخدام</span>
                          </div>
                        )}
                      </div>
                    ) : (
                      <button
                        type="button"
                        disabled={!canPurchase}
                        onClick={() => onPurchaseOrActivateItem(item)}
                        className={`w-full rounded-xl py-2 text-xs font-extrabold transition-colors ${
                          canPurchase
                            ? "bg-amber-500 text-slate-950 hover:bg-amber-400 cursor-pointer"
                            : "bg-white/5 text-slate-500 cursor-not-allowed"
                        }`}
                      >
                        {canPurchase
                          ? `شراء وتفعيل (${item.priceCoins} عملة)`
                          : `تحتاج ${item.priceCoins - economy.coins} عملة`}
                      </button>
                    )}
                  </div>
                </article>
              );
            })}
          </div>
        </section>
      </div>
    </div>
  );
};
