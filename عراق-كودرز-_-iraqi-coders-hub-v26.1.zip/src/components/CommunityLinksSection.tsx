import React from "react";
import { ArrowUpLeft, MessageCircle } from "lucide-react";
import { COMMUNITY_CHANNELS } from "../data/siteConfig";

export const SocialBrandIcon: React.FC<{
  id: "telegram" | "whatsapp" | "discord";
  className?: string;
}> = ({ id, className = "h-5 w-5" }) => {
  if (id === "telegram") {
    return (
      <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
        <path d="M21.9 4.6c.2-.9-.6-1.6-1.5-1.3L2.7 10.1c-1 .4-.9 1.8.1 2.1l4.5 1.4 1.7 5.3c.2.7 1.1.9 1.6.4l2.5-2.5 4.7 3.4c.7.5 1.7.1 1.9-.7L21.9 4.6zm-4.1 3.3-7.6 6.8-.3 3-1.2-3.8 9.1-6z" />
      </svg>
    );
  }
  if (id === "whatsapp") {
    return (
      <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
        <path d="M12 2a9.9 9.9 0 0 0-8.6 14.8L2 22l5.4-1.4A10 10 0 1 0 12 2zm5.8 14.2c-.2.6-1.3 1.2-1.8 1.3-.5.1-1.1.1-1.8-.1-.4-.1-1-.3-1.7-.7-3-1.3-5-4.3-5.1-4.5-.1-.2-1.2-1.6-1.2-3s.8-2.1 1.1-2.4c.3-.3.6-.4.8-.4h.6c.2 0 .5-.1.7.5.2.6.8 2 .9 2.2.1.2.1.4 0 .6-.1.2-.2.4-.4.6-.2.2-.3.4-.5.6-.2.2-.3.3-.1.6.2.3.9 1.5 2 2.4 1.4 1.2 2.5 1.6 2.9 1.8.3.1.5.1.7-.1.2-.2.8-1 1.1-1.3.2-.3.5-.3.8-.2.3.1 2 .9 2.3 1.1.3.2.6.3.7.4.1.2.1.8-.1 1.4z" />
      </svg>
    );
  }
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
      <path d="M19.3 5.3A16 16 0 0 0 15.2 4l-.2.4a14.4 14.4 0 0 1 3.5 1.7 12.1 12.1 0 0 0-13 0A14.6 14.6 0 0 1 9 4.4L8.8 4a16 16 0 0 0-4.1 1.3C2.1 9.2 1.4 13 1.7 16.7a16.2 16.2 0 0 0 5 2.5l1-1.6a10.4 10.4 0 0 1-1.6-.8l.4-.3a11.6 11.6 0 0 0 10.9 0l.4.3a10.4 10.4 0 0 1-1.6.8l1 1.6a16.2 16.2 0 0 0 5-2.5c.4-4.3-.7-8.1-2.9-11.4zM8.7 14.4c-1 0-1.8-.9-1.8-2s.8-2 1.8-2 1.8.9 1.8 2-.8 2-1.8 2zm6.6 0c-1 0-1.8-.9-1.8-2s.8-2 1.8-2 1.8.9 1.8 2-.8 2-1.8 2z" />
    </svg>
  );
};

export const CommunityLinksSection: React.FC = () => {
  return (
    <section
      id="contact-channels"
      className="scroll-mt-24 border-b border-white/10 py-14 lg:py-20"
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mb-8 flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
          <div>
            <div className="mb-2 flex items-center gap-2 text-xs font-bold text-emerald-400">
              <MessageCircle className="h-4 w-4" />
              <span>قنوات المجتمع والدعم الرسمية</span>
            </div>
            <h2
              className="text-2xl font-extrabold text-white sm:text-3xl"
              style={{ textWrap: "balance" }}
            >
              تواصل معنا وانضم لمجتمع عراقي كودرز
            </h2>
            <p className="mt-2 max-w-2xl text-sm text-slate-400">
              اختر القناة المناسبة لمتابعة التحديثات اليومية، تأكيد طلبات المتجر،
              أو التواصل المباشر مع المطورين على الهاتف والكمبيوتر.
            </p>
          </div>
        </div>

        <div className="desktop-grid-3 grid grid-cols-1 gap-5 md:grid-cols-3">
          {COMMUNITY_CHANNELS.map((channel) => {
            const accentStyles =
              channel.accentColor === "sky"
                ? {
                    border: "border-sky-400/25 hover:border-sky-400/55",
                    iconBox: "border-sky-400/35 bg-sky-500/15 text-sky-300",
                    btn: "bg-sky-500 hover:bg-sky-400 text-slate-950",
                    tag: "text-sky-300",
                  }
                : channel.accentColor === "emerald"
                ? {
                    border: "border-emerald-400/25 hover:border-emerald-400/55",
                    iconBox:
                      "border-emerald-400/35 bg-emerald-500/15 text-emerald-300",
                    btn: "bg-emerald-500 hover:bg-emerald-400 text-slate-950",
                    tag: "text-emerald-300",
                  }
                : {
                    border: "border-indigo-400/25 hover:border-indigo-400/55",
                    iconBox:
                      "border-indigo-400/35 bg-indigo-500/15 text-indigo-300",
                    btn: "bg-indigo-500 hover:bg-indigo-400 text-white",
                    tag: "text-indigo-300",
                  };

            return (
              <article
                key={channel.id}
                className={`glass-surface flex flex-col justify-between rounded-2xl border p-6 transition-transform duration-150 hover:-translate-y-0.5 ${accentStyles.border}`}
              >
                <div>
                  <div className="mb-4 flex items-center justify-between gap-3">
                    <div
                      className={`flex h-11 w-11 items-center justify-center rounded-xl border ${accentStyles.iconBox}`}
                    >
                      <SocialBrandIcon id={channel.id} className="h-5 w-5" />
                    </div>
                    <span className={`text-xs font-bold ${accentStyles.tag}`}>
                      {channel.englishName} · {channel.handleOrTag}
                    </span>
                  </div>

                  <h3 className="text-lg font-extrabold text-white">
                    {channel.name}
                  </h3>
                  <p className="mt-2 text-sm leading-relaxed text-slate-300">
                    {channel.description}
                  </p>
                </div>

                <div className="mt-6">
                  <a
                    href={channel.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`inline-flex w-full items-center justify-center gap-2 rounded-xl px-4 py-3 text-sm font-extrabold transition-colors whitespace-nowrap ${accentStyles.btn}`}
                  >
                    <SocialBrandIcon id={channel.id} className="h-4 w-4" />
                    <span>{channel.ctaLabel}</span>
                    <ArrowUpLeft className="h-4 w-4" />
                  </a>
                </div>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
};
