import React, { useMemo, useRef, useState } from "react";
import {
  Cloud,
  Code,
  Download,
  Eye,
  FileCode2,
  Gamepad2,
  Globe,
  Lock,
  Plus,
  Search,
  Smartphone,
  Trash2,
  Upload,
  X,
} from "lucide-react";
import { saveCloudBinaryBlob } from "../services/blobStore";
import { compileDownloadableBlobForCloudItem } from "../services/packageBuilder";
import {
  CloudFileItem,
  CloudFileType,
  CloudVisibility,
  UserProfile,
} from "../types";

interface CloudHubSectionProps {
  user: UserProfile | null;
  privateFiles: CloudFileItem[];
  publicFiles: CloudFileItem[];
  onUploadFile: (item: CloudFileItem) => void;
  onToggleVisibility: (fileId: string, nextVisibility: CloudVisibility) => void;
  onDeleteFile: (fileId: string) => void;
  onDownloadFile: (item: CloudFileItem) => void;
  onRequestAuth: () => void;
  onOpenCreatorStudio?: () => void;
}

const FILE_TYPE_META: Record<
  CloudFileType,
  { label: string; badgeClass: string; icon: React.ComponentType<{ className?: string }> }
> = {
  game: {
    label: "ملف لعبة",
    badgeClass: "border-violet-400/35 bg-violet-500/15 text-violet-300",
    icon: Gamepad2,
  },
  apk: {
    label: "تطبيق APK",
    badgeClass: "border-emerald-400/35 bg-emerald-500/15 text-emerald-300",
    icon: Smartphone,
  },
  web: {
    label: "موقع ZIP",
    badgeClass: "border-amber-400/35 bg-amber-500/15 text-amber-300",
    icon: Globe,
  },
  minecraft: {
    label: "مود ماينكرافت",
    badgeClass: "border-fuchsia-400/35 bg-fuchsia-500/15 text-fuchsia-300",
    icon: Gamepad2,
  },
  code: {
    label: "مشروع برمجي",
    badgeClass: "border-sky-400/35 bg-sky-500/15 text-sky-300",
    icon: FileCode2,
  },
};

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

function inferTypeFromFileName(name: string): CloudFileType {
  const lower = name.toLowerCase();
  if (lower.endsWith(".apk") || lower.endsWith(".aab")) return "apk";
  if (
    lower.endsWith(".mcaddon") ||
    lower.endsWith(".mcpack") ||
    lower.endsWith(".mcworld")
  ) {
    return "minecraft";
  }
  if (lower.endsWith(".zip") || lower.endsWith(".html")) return "web";
  if (
    lower.endsWith(".rbxl") ||
    lower.endsWith(".rbxm") ||
    lower.endsWith(".unitypackage")
  ) {
    return "game";
  }
  return "code";
}

export const CloudHubSection: React.FC<CloudHubSectionProps> = ({
  user,
  privateFiles,
  publicFiles,
  onUploadFile,
  onToggleVisibility,
  onDeleteFile,
  onDownloadFile,
  onRequestAuth,
  onOpenCreatorStudio,
}) => {
  const [activeTab, setActiveTab] = useState<"private" | "public">("private");
  const [searchQuery, setSearchQuery] = useState("");
  const [typeFilter, setTypeFilter] = useState<"all" | CloudFileType>("all");
  const [previewItem, setPreviewItem] = useState<CloudFileItem | null>(null);

  // Upload Form States
  const [showUploadForm, setShowUploadForm] = useState(false);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [fileName, setFileName] = useState("my_iraqi_project.lua");
  const [fileType, setFileType] = useState<CloudFileType>("code");
  const [visibility, setVisibility] = useState<CloudVisibility>("private");
  const [content, setContent] = useState(
    "-- اكتب كود مشروعك أو ارفع ملف لعبة / APK من جهازك\nprint('Iraqi Coders Cloud Hub')"
  );
  const [selectedBinaryBlob, setSelectedBinaryBlob] = useState<Blob | null>(
    null
  );
  const [selectedBinarySize, setSelectedBinarySize] = useState<number>(0);
  const filePickerRef = useRef<HTMLInputElement>(null);

  const filteredPublicFiles = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return publicFiles.filter((item) => {
      const matchesType = typeFilter === "all" || item.fileType === typeFilter;
      if (!matchesType) return false;
      if (!q) return true;
      return (
        item.title.toLowerCase().includes(q) ||
        item.description.toLowerCase().includes(q) ||
        item.fileName.toLowerCase().includes(q) ||
        item.ownerName.toLowerCase().includes(q) ||
        item.ownerHandle.toLowerCase().includes(q)
      );
    });
  }, [publicFiles, searchQuery, typeFilter]);

  const handleLocalFilePicked = async (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const inferred = inferTypeFromFileName(file.name);
    setFileName(file.name);
    setFileType(inferred);
    setSelectedBinarySize(file.size);
    if (!title.trim()) {
      setTitle(file.name.replace(/\.[^.]+$/, ""));
    }

    const lower = file.name.toLowerCase();
    const isTextLike =
      file.type.startsWith("text/") ||
      lower.endsWith(".lua") ||
      lower.endsWith(".luau") ||
      lower.endsWith(".js") ||
      lower.endsWith(".ts") ||
      lower.endsWith(".html") ||
      lower.endsWith(".css") ||
      lower.endsWith(".json") ||
      lower.endsWith(".txt") ||
      lower.endsWith(".md");

    if (isTextLike && file.size <= 350000) {
      const text = await file.text();
      setContent(text);
      setSelectedBinaryBlob(null);
    } else {
      setSelectedBinaryBlob(file);
      setContent(
        `[IRAQI_CODERS_BINARY_PACKAGE]\nFileName: ${file.name}\nFileSize: ${formatBytes(
          file.size
        )}\nType: ${file.type || "application/octet-stream"}\nUploadedAt: ${new Date().toISOString()}`
      );
    }
  };

  const handleSubmitUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !fileName.trim()) return;

    const id = `cloud-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    const draftItem: CloudFileItem = {
      id,
      ownerId: user?.id || "local-guest-dev",
      ownerName: user?.name || "مطور عراقي",
      ownerHandle: user?.handle || "@iraqi_dev",
      title: title.trim(),
      description:
        description.trim() ||
        "مشروع مرفوع عبر منصة سحابة عراقي كودرز الإصدار 26.5.",
      fileName: fileName.trim(),
      fileType,
      fileSizeBytes: selectedBinarySize > 0 ? selectedBinarySize : new Blob([content]).size,
      content: content.slice(0, 380000),
      visibility,
      downloads: 0,
      createdAt: "الآن",
    };

    if (selectedBinaryBlob) {
      await saveCloudBinaryBlob(id, selectedBinaryBlob);
    } else {
      const lower = draftItem.fileName.toLowerCase();
      if (
        lower.endsWith(".apk") ||
        lower.endsWith(".zip") ||
        lower.endsWith(".mcpack") ||
        lower.endsWith(".mcaddon") ||
        lower.endsWith(".mcworld")
      ) {
        const compiledBlob = compileDownloadableBlobForCloudItem(draftItem);
        draftItem.fileSizeBytes = compiledBlob.size;
        await saveCloudBinaryBlob(id, compiledBlob);
      }
    }

    onUploadFile(draftItem);
    setTitle("");
    setDescription("");
    setSelectedBinaryBlob(null);
    setSelectedBinarySize(0);
    setShowUploadForm(false);
    if (visibility === "public") {
      setActiveTab("public");
    }
  };

  const renderFileCard = (item: CloudFileItem, isOwnedView: boolean) => {
    const meta = FILE_TYPE_META[item.fileType];
    const TypeIcon = meta.icon;
    const canManage = isOwnedView || (user && item.ownerId === user.id);

    return (
      <article
        key={item.id}
        className="flex flex-col justify-between rounded-2xl border border-white/10 bg-[#0E1424]/90 p-5 transition-colors hover:border-violet-400/40"
      >
        <div>
          <div className="flex items-start justify-between gap-3 mb-3">
            <span
              className={`inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1 text-[11px] font-bold ${meta.badgeClass}`}
            >
              <TypeIcon className="h-3.5 w-3.5" />
              <span>{meta.label}</span>
            </span>

            <span
              className={`inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-[11px] font-bold ${
                item.visibility === "public"
                  ? "bg-emerald-500/15 text-emerald-300"
                  : "bg-slate-700/60 text-slate-300"
              }`}
            >
              {item.visibility === "public" ? (
                <>
                  <Globe className="h-3 w-3" />
                  <span>عام</span>
                </>
              ) : (
                <>
                  <Lock className="h-3 w-3" />
                  <span>خاص</span>
                </>
              )}
            </span>
          </div>

          <h3 className="text-base font-extrabold text-white leading-snug mb-1.5">
            {item.title}
          </h3>
          <p className="text-xs leading-relaxed text-slate-400 mb-3 line-clamp-2">
            {item.description}
          </p>

          <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-white/5 bg-[#0B0F19] px-3 py-2 text-[11px]">
            <span dir="ltr" className="font-mono text-slate-300 truncate max-w-[180px]">
              {item.fileName}
            </span>
            <span dir="ltr" className="font-mono text-emerald-300 shrink-0">
              {formatBytes(item.fileSizeBytes)}
            </span>
          </div>
        </div>

        <div className="mt-4 pt-3 border-t border-white/10 space-y-3">
          <div className="flex items-center justify-between text-[11px] text-slate-400">
            <span>
              {item.ownerName}{" "}
              <span dir="ltr" className="font-mono text-violet-300">
                {item.ownerHandle}
              </span>
            </span>
            <span className="tabular-nums">
              {item.downloads} تنزيل · {item.createdAt}
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => onDownloadFile(item)}
              className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-emerald-600 px-3 py-2 text-xs font-extrabold text-white hover:bg-emerald-500 cursor-pointer"
            >
              <Download className="h-3.5 w-3.5" />
              <span>تنزيل</span>
            </button>

            <button
              type="button"
              onClick={() => setPreviewItem(item)}
              title="معاينة المحتوى"
              className="inline-flex items-center gap-1 rounded-xl border border-white/15 bg-white/5 px-3 py-2 text-xs font-bold text-slate-200 hover:bg-white/10 cursor-pointer"
            >
              <Eye className="h-3.5 w-3.5" />
              <span>معاينة</span>
            </button>

            {canManage && (
              <>
                <button
                  type="button"
                  onClick={() =>
                    onToggleVisibility(
                      item.id,
                      item.visibility === "public" ? "private" : "public"
                    )
                  }
                  title={
                    item.visibility === "public"
                      ? "تحويل إلى سحابة خاصة"
                      : "نشر في سحابات الناس"
                  }
                  className="inline-flex items-center gap-1 rounded-xl border border-violet-500/35 bg-violet-500/15 px-3 py-2 text-xs font-bold text-violet-200 hover:bg-violet-500/25 cursor-pointer"
                >
                  {item.visibility === "public" ? (
                    <>
                      <Lock className="h-3.5 w-3.5" />
                      <span>جعله خاصاً</span>
                    </>
                  ) : (
                    <>
                      <Globe className="h-3.5 w-3.5" />
                      <span>نشر للناس</span>
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => onDeleteFile(item.id)}
                  aria-label="حذف الملف من السحابة"
                  className="inline-flex h-8 w-8 items-center justify-center rounded-xl border border-rose-500/30 bg-rose-500/10 text-rose-300 hover:bg-rose-500/20 cursor-pointer"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </>
            )}
          </div>
        </div>
      </article>
    );
  };

  return (
    <section id="cloud-hub" className="scroll-mt-24 border-t border-white/10 py-14">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-wrap items-end justify-between gap-4 mb-8">
          <div>
            <p className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-400 mb-1.5">
              <Cloud className="h-4 w-4" />
              <span>مركز البيانات والسحابة العامة والخاصة · Firebase Data Center</span>
            </p>
            <h2 className="text-2xl font-extrabold text-white sm:text-3xl">
              مركز البيانات وسحابة عراقي كودرز للمشاريع والـ APK
            </h2>
            <p className="mt-1.5 max-w-2xl text-sm text-slate-400">
              إدارة سيرفرات البيانات، أرشفة ملفات ألعابك وحزم الـ APK ومشاريع محرر الأكواد السري، ومشاركتها عبر «سحابات الناس».
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            {!user && (
              <button
                type="button"
                onClick={onRequestAuth}
                className="rounded-xl border border-violet-500/40 bg-violet-600/15 px-4 py-2.5 text-xs font-bold text-violet-200 hover:bg-violet-600/25 cursor-pointer"
              >
                اربط بحساب Google للمزامنة السحابية
              </button>
            )}
            {onOpenCreatorStudio && (
              <button
                type="button"
                onClick={onOpenCreatorStudio}
                className="inline-flex items-center gap-1.5 rounded-xl border border-emerald-400/40 bg-[#0E1424] px-3.5 py-2.5 text-xs font-extrabold text-emerald-300 hover:bg-emerald-500/15 cursor-pointer"
              >
                <span dir="ltr" className="font-mono text-sm">/</span>
                <span>استوديو بناء APK والمودات</span>
              </button>
            )}
            <button
              type="button"
              onClick={() => {
                setActiveTab("private");
                setShowUploadForm((prev) => !prev);
              }}
              className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-4 py-2.5 text-xs font-extrabold text-white shadow-lg transition-colors hover:bg-emerald-500 cursor-pointer"
            >
              <Plus className="h-4 w-4" />
              <span>رفع مشروع أو APK جديد</span>
            </button>
          </div>
        </div>

        {/* Main Cloud Tabs */}
        <div className="mb-6 flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-white/10 bg-[#0E1424] p-2">
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => setActiveTab("private")}
              className={`inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-xs font-extrabold transition-colors cursor-pointer ${
                activeTab === "private"
                  ? "bg-violet-600 text-white"
                  : "text-slate-300 hover:bg-white/5 hover:text-white"
              }`}
            >
              <Lock className="h-4 w-4" />
              <span>سحابتي الخاصة ({privateFiles.length})</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab("public")}
              className={`inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-xs font-extrabold transition-colors cursor-pointer ${
                activeTab === "public"
                  ? "bg-emerald-600 text-white"
                  : "text-slate-300 hover:bg-white/5 hover:text-white"
              }`}
            >
              <Globe className="h-4 w-4" />
              <span>سحابات الناس ({publicFiles.length})</span>
            </button>
          </div>

          {activeTab === "public" && (
            <div className="flex flex-wrap items-center gap-2 flex-1 justify-end">
              <div className="relative min-w-[200px] flex-1 max-w-xs">
                <Search className="pointer-events-none absolute right-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="ابحث عن لعبة أو APK أو مطور..."
                  className="h-9 w-full rounded-xl border border-white/10 bg-[#0B0F19] pr-9 pl-3 text-xs text-white placeholder:text-slate-500 focus:border-emerald-400 focus:outline-none"
                />
              </div>
              <div className="flex flex-wrap items-center gap-1">
                {(
                  [
                    { id: "all", label: "الكل" },
                    { id: "apk", label: "APK" },
                    { id: "web", label: "مواقع ZIP" },
                    { id: "minecraft", label: "ماينكرافت" },
                    { id: "game", label: "ألعاب" },
                    { id: "code", label: "أكواد" },
                  ] as const
                ).map((cat) => (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => setTypeFilter(cat.id)}
                    className={`rounded-lg px-2.5 py-1.5 text-xs font-bold cursor-pointer ${
                      typeFilter === cat.id
                        ? "bg-white/15 text-white"
                        : "text-slate-400 hover:text-white"
                    }`}
                  >
                    {cat.label}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Upload / Create File Drawer inside Private Cloud */}
        {showUploadForm && activeTab === "private" && (
          <form
            onSubmit={(e) => void handleSubmitUpload(e)}
            className="mb-8 rounded-2xl border border-emerald-500/35 bg-[#0E1424] p-6 space-y-4 shadow-xl"
          >
            <div className="flex items-center justify-between gap-4">
              <h3 className="text-base font-extrabold text-white">
                رفع ملف جديد إلى سحابتي الخاصة
              </h3>
              <button
                type="button"
                onClick={() => setShowUploadForm(false)}
                className="text-xs font-bold text-slate-400 hover:text-white cursor-pointer"
              >
                إغلاق
              </button>
            </div>

            <div className="flex flex-wrap items-center gap-3 rounded-xl border border-dashed border-violet-400/40 bg-[#0B0F19] p-4">
              <button
                type="button"
                onClick={() => filePickerRef.current?.click()}
                className="inline-flex items-center gap-2 rounded-xl bg-violet-600 px-4 py-2 text-xs font-extrabold text-white hover:bg-violet-500 cursor-pointer"
              >
                <Upload className="h-4 w-4" />
                <span>اختيار ملف من الجهاز (APK / لعبة / كود)</span>
              </button>
              <input
                ref={filePickerRef}
                type="file"
                onChange={(e) => void handleLocalFilePicked(e)}
                className="hidden"
              />
              <span className="text-xs text-slate-400">
                {selectedBinarySize > 0
                  ? `تم اختيار: ${fileName} (${formatBytes(selectedBinarySize)})`
                  : "أو اكتب الكود مباشرة في الحقول أدناه."}
              </span>
            </div>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  عنوان المشروع
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="مثال: لعبة سباق الرافدين APK"
                  className="h-10 w-full rounded-xl border border-white/10 bg-[#0B0F19] px-3 text-xs text-white focus:border-emerald-400 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  اسم الملف والامتداد
                </label>
                <input
                  type="text"
                  dir="ltr"
                  required
                  value={fileName}
                  onChange={(e) => setFileName(e.target.value)}
                  className="h-10 w-full rounded-xl border border-white/10 bg-[#0B0F19] px-3 font-mono text-xs text-emerald-300 focus:border-emerald-400 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    النوع
                  </label>
                  <select
                    value={fileType}
                    onChange={(e) =>
                      setFileType(e.target.value as CloudFileType)
                    }
                    className="h-10 w-full rounded-xl border border-white/10 bg-[#0B0F19] px-2 text-xs text-white"
                  >
                    <option value="apk">تطبيق APK</option>
                    <option value="web">موقع ويب (ZIP)</option>
                    <option value="minecraft">مود ماينكرافت</option>
                    <option value="game">لعبة (Game)</option>
                    <option value="code">كود برمجي</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    الخصوصية
                  </label>
                  <select
                    value={visibility}
                    onChange={(e) =>
                      setVisibility(e.target.value as CloudVisibility)
                    }
                    className="h-10 w-full rounded-xl border border-white/10 bg-[#0B0F19] px-2 text-xs text-white"
                  >
                    <option value="private">سحابتي الخاصة</option>
                    <option value="public">سحابات الناس</option>
                  </select>
                </div>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                وصف المشروع
              </label>
              <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="اشرح فكرة التطبيق أو متطلبات التشغيل..."
                className="h-10 w-full rounded-xl border border-white/10 bg-[#0B0F19] px-3 text-xs text-white focus:border-emerald-400 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                محتوى الكود أو بيانات الحزمة
              </label>
              <textarea
                dir="ltr"
                rows={5}
                value={content}
                onChange={(e) => setContent(e.target.value)}
                className="w-full rounded-xl border border-white/10 bg-[#080C15] p-3 font-mono text-xs text-slate-200 focus:border-emerald-400 focus:outline-none"
              />
            </div>

            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowUploadForm(false)}
                className="rounded-xl border border-white/15 bg-white/5 px-4 py-2.5 text-xs font-bold text-slate-300 hover:bg-white/10 cursor-pointer"
              >
                إلغاء
              </button>
              <button
                type="submit"
                className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-5 py-2.5 text-xs font-extrabold text-white hover:bg-emerald-500 cursor-pointer"
              >
                <Upload className="h-4 w-4" />
                <span>حفظ ورفع إلى السحابة</span>
              </button>
            </div>
          </form>
        )}

        {/* Active Tab Grid */}
        {activeTab === "private" ? (
          privateFiles.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-white/15 bg-[#0E1424]/70 p-10 text-center space-y-3">
              <Code className="mx-auto h-10 w-10 text-violet-400" />
              <h3 className="text-base font-extrabold text-white">
                سحابتك الخاصة فارغة حالياً
              </h3>
              <p className="mx-auto max-w-md text-xs leading-relaxed text-slate-400">
                يمكنك حفظ ملفات ألعابك، حزم الـ APK، أو أكواد Roblox و
                Minecraft هنا بشكل خاص أو نشرها في سحابات الناس لاحقاً.
              </p>
              <button
                type="button"
                onClick={() => setShowUploadForm(true)}
                className="inline-flex items-center gap-2 rounded-xl bg-violet-600 px-5 py-2.5 text-xs font-extrabold text-white hover:bg-violet-500 cursor-pointer"
              >
                <Plus className="h-4 w-4" />
                <span>إضافة أول ملف لسحابتي</span>
              </button>
            </div>
          ) : (
            <div className="desktop-grid-3 grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3">
              {privateFiles.map((file) => renderFileCard(file, true))}
            </div>
          )
        ) : filteredPublicFiles.length === 0 ? (
          <div className="rounded-2xl border border-white/10 bg-[#0E1424]/70 p-10 text-center text-sm text-slate-400">
            لا توجد ملفات مطابقة لبحثك في سحابات الناس حالياً.
          </div>
        ) : (
          <div className="desktop-grid-3 grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3">
            {filteredPublicFiles.map((file) => renderFileCard(file, false))}
          </div>
        )}
      </div>

      {/* Preview Modal */}
      {previewItem && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm"
          onClick={() => setPreviewItem(null)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-2xl rounded-2xl border border-white/15 bg-[#0E1424] p-6 shadow-2xl space-y-4"
          >
            <div className="flex items-start justify-between gap-4">
              <div>
                <h3 className="text-lg font-extrabold text-white">
                  {previewItem.title}
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  بواسطة {previewItem.ownerName} ({previewItem.ownerHandle}) ·{" "}
                  <span dir="ltr" className="font-mono text-emerald-300">
                    {previewItem.fileName}
                  </span>
                </p>
              </div>
              <button
                type="button"
                onClick={() => setPreviewItem(null)}
                className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-white/10 bg-white/5 text-slate-300 hover:text-white cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <p className="text-xs leading-relaxed text-slate-300">
              {previewItem.description}
            </p>

            <pre
              dir="ltr"
              className="max-h-72 overflow-auto rounded-xl border border-white/10 bg-[#080C15] p-4 font-mono text-xs text-emerald-200"
            >
              {previewItem.content}
            </pre>

            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => onDownloadFile(previewItem)}
                className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-5 py-2.5 text-xs font-extrabold text-white hover:bg-emerald-500 cursor-pointer"
              >
                <Download className="h-4 w-4" />
                <span>تنزيل الملف ({formatBytes(previewItem.fileSizeBytes)})</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
