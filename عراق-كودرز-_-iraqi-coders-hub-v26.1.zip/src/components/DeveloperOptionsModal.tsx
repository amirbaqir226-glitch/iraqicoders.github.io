import React, { useEffect, useState } from "react";
import {
  Activity,
  CheckCircle2,
  Copy,
  Crown,
  Download,
  KeyRound,
  Lock,
  RefreshCw,
  Search,
  Settings2,
  ShieldCheck,
  Terminal,
  Trash2,
  UserPlus,
  Users,
  X,
  XCircle,
} from "lucide-react";
import {
  FIREBASE_HOSTING_SITE,
  firebaseAuth,
  firebaseConfig,
  isMasterAdminIdentity,
  isOwnerEmail,
  OWNER_PERSON,
  STORAGE_KEYS,
} from "../config/firebase";
import { DEFAULT_DEVELOPER_AVATAR } from "../data/initialData";
import {
  fetchAllUsersForAdmin,
  fetchRoleRequestsForAdmin,
  updateRoleRequestStatusInFirestore,
  updateUserRoleByAdminInFirestore,
} from "../services/firestoreService";
import {
  AdminRoleRequest,
  SystemLogEntry,
  ThemeDecoration,
  UserProfile,
  UserRole,
} from "../types";
import { THEME_OPTIONS } from "./ThemeDecorationLayer";

interface DeveloperOptionsModalProps {
  isOpen: boolean;
  isAuthorized: boolean;
  userRole?: UserRole;
  currentUser: UserProfile | null;
  themeDecoration: ThemeDecoration;
  desktopMode: boolean;
  maintenanceActive: boolean;
  assistantUrl: string;
  assistantTitle: string;
  systemLogs: SystemLogEntry[];
  onClose: () => void;
  onAuthorize: () => void;
  onChangeTheme: (theme: ThemeDecoration) => void;
  onToggleDesktopMode: (enabled: boolean) => void;
  onToggleMaintenance: (active: boolean) => void;
  onSaveAssistantConfig: (url: string, title: string) => void;
  onClearLogs: () => void;
  onAddLog: (level: SystemLogEntry["level"], message: string) => void;
}

export const DeveloperOptionsModal: React.FC<DeveloperOptionsModalProps> = ({
  isOpen,
  isAuthorized,
  userRole = "user",
  currentUser,
  themeDecoration,
  desktopMode,
  maintenanceActive,
  assistantUrl,
  assistantTitle,
  systemLogs,
  onClose,
  onAuthorize,
  onChangeTheme,
  onToggleDesktopMode,
  onToggleMaintenance,
  onSaveAssistantConfig,
  onClearLogs,
  onAddLog,
}) => {
  const [activeTab, setActiveTab] = useState<"config" | "users" | "logs">(
    "config"
  );
  const [pinOrPassword, setPinOrPassword] = useState("");
  const [authError, setAuthError] = useState("");
  const [usersList, setUsersList] = useState<UserProfile[]>([]);
  const [roleRequests, setRoleRequests] = useState<AdminRoleRequest[]>([]);
  const [loadingUsers, setLoadingUsers] = useState(false);
  const [userSearchQuery, setUserSearchQuery] = useState("");
  const [newPersonInput, setNewPersonInput] = useState("");
  const [newPersonName, setNewPersonName] = useState("");
  const [newPersonRole, setNewPersonRole] = useState<UserRole>("developer");
  const [addingPerson, setAddingPerson] = useState(false);
  const [logFilter, setLogFilter] = useState<
    "ALL" | SystemLogEntry["level"]
  >("ALL");
  const [urlDraft, setUrlDraft] = useState(assistantUrl || "#assistant");
  const [titleDraft, setTitleDraft] = useState(assistantTitle);
  const [copiedId, setCopiedId] = useState("");

  useEffect(() => {
    setUrlDraft(assistantUrl || "#assistant");
    setTitleDraft(assistantTitle);
  }, [assistantUrl, assistantTitle, isOpen]);

  const loadUsersFromFirestore = async () => {
    setLoadingUsers(true);
    try {
      const [fetchedFirestoreUsers, directoryRes, firestoreRequests, apiRequestsRes] =
        await Promise.all([
          fetchAllUsersForAdmin().catch(() => [] as UserProfile[]),
          fetch("/api/directory/people")
            .then((r) => (r.ok ? r.json() : null))
            .catch(() => null) as Promise<{
            people?: Array<{
              id: string;
              username: string;
              displayName: string;
              handle: string;
              email: string;
              city: string;
              role: UserRole;
              updatedAt: string;
            }>;
          } | null>,
          fetchRoleRequestsForAdmin().catch(() => [] as AdminRoleRequest[]),
          fetch("/api/role-requests")
            .then((r) => (r.ok ? r.json() : null))
            .catch(() => null) as Promise<{ requests?: AdminRoleRequest[] } | null>,
        ]);

      const merged = [...fetchedFirestoreUsers];
      const serverPeople = directoryRes?.people || [];
      for (const person of serverPeople) {
        const alreadyExists = merged.some(
          (u) =>
            u.id === person.id ||
            u.handle.toLowerCase() === person.handle.toLowerCase()
        );
        if (!alreadyExists) {
          merged.push({
            id: person.id,
            name: person.displayName,
            handle: person.handle,
            email: person.email,
            avatarUrl: DEFAULT_DEVELOPER_AVATAR,
            provider: "google",
            city: person.city || "بغداد",
            role: person.role,
            themeDecoration: "default",
            desktopMode: true,
            loggedInAt: person.updatedAt || "مفعّل",
          });
        }
      }

      if (
        !merged.some(
          (u) => u.handle.toLowerCase() === OWNER_PERSON.handle.toLowerCase()
        )
      ) {
        merged.unshift({
          id: "owner-amirbaqir226",
          name: OWNER_PERSON.displayName,
          handle: OWNER_PERSON.handle,
          email: OWNER_PERSON.email,
          avatarUrl: DEFAULT_DEVELOPER_AVATAR,
          provider: "google",
          city: OWNER_PERSON.city,
          role: "admin",
          themeDecoration: "default",
          desktopMode: true,
          loggedInAt: "المالك الرسمي",
        });
      }

      if (currentUser && !merged.some((u) => u.id === currentUser.id)) {
        merged.unshift(currentUser);
      }

      setUsersList(merged);

      // Merge role requests from Firestore + API + localStorage
      let localRequests: AdminRoleRequest[] = [];
      try {
        const raw = localStorage.getItem(STORAGE_KEYS.ROLE_REQUESTS);
        if (raw) localRequests = JSON.parse(raw) as AdminRoleRequest[];
      } catch {
        // Safe fallback
      }
      const reqMap = new Map<string, AdminRoleRequest>();
      for (const r of [...firestoreRequests, ...(apiRequestsRes?.requests || []), ...localRequests]) {
        if (!reqMap.has(r.id)) reqMap.set(r.id, r);
      }
      setRoleRequests(Array.from(reqMap.values()));

      onAddLog("FIRESTORE", `تم تحديث قائمة المستخدمين (${merged.length})`);
    } catch {
      if (currentUser) {
        setUsersList([currentUser]);
      }
    } finally {
      setLoadingUsers(false);
    }
  };

  useEffect(() => {
    if (isOpen && activeTab === "users") {
      void loadUsersFromFirestore();
    }
  }, [isOpen, activeTab]);

  if (!isOpen) return null;

  const isFirebaseAdminEmail = isMasterAdminIdentity(
    currentUser,
    firebaseAuth.currentUser
  );
  const effectiveAuthorized =
    isAuthorized || isFirebaseAdminEmail || userRole === "developer" || userRole === "admin";

  const handleUnlockSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const val = pinOrPassword.trim();
    if (val === "2019" || val === "A20019") {
      setAuthError("");
      setPinOrPassword("");
      onAuthorize();
      onAddLog("AUTH", "تم تفعيل صلاحيات خيارات المطورين");
    } else {
      setAuthError("الرمز غير صحيح. أدخل رمز الإدارة المصرح به.");
    }
  };

  const handleExportLogs = () => {
    const payload = JSON.stringify(systemLogs, null, 2);
    const blob = new Blob([payload], {
      type: "application/json;charset=utf-8",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `iraqi-coders-system-logs-${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    onAddLog("INFO", "تم تصدير سجلات النظام بصيغة JSON");
  };

  const handleCopyUid = async (uid: string) => {
    try {
      await navigator.clipboard.writeText(uid);
      setCopiedId(uid);
      window.setTimeout(() => setCopiedId(""), 1500);
    } catch {
      // Safe no-op
    }
  };

  const filteredLogs =
    logFilter === "ALL"
      ? systemLogs
      : systemLogs.filter((l) => l.level === logFilter);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="dev-options-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="flex max-h-[90vh] w-full max-w-3xl flex-col overflow-hidden rounded-2xl border border-emerald-500/35 bg-[#0E1424] shadow-2xl"
      >
        {/* Header */}
        <div className="flex items-center justify-between gap-4 border-b border-white/10 px-6 py-4">
          <div className="flex items-center gap-2.5">
            <Terminal className="h-5 w-5 text-emerald-400" />
            <div>
              <h3
                id="dev-options-title"
                className="text-lg font-extrabold text-white"
              >
                خيارات المطورين وسطح المكتب
              </h3>
              <p className="text-[11px] text-slate-400">
                لوحة تحكم متقدمة لإعدادات الموقع، إدارة المستخدمين، وسجلات
                التشغيل
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="إغلاق خيارات المطورين"
            className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 bg-white/5 text-slate-300 hover:bg-white/10 hover:text-white cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {!effectiveAuthorized ? (
          <form onSubmit={handleUnlockSubmit} className="p-6 space-y-4">
            <div className="flex items-center gap-3 rounded-xl border border-amber-500/30 bg-amber-500/10 p-4">
              <Lock className="h-5 w-5 text-amber-400 shrink-0" />
              <p className="text-xs leading-relaxed text-amber-100">
                هذه الأدوات مخصصة للمسؤولين المصرح لهم. أدخل رمز التحقق الإداري
                (PIN 2019 أو كلمة مرور الإدارة) للمتابعة.
              </p>
            </div>
            <div>
              <label
                htmlFor="dev-auth-code"
                className="block text-xs font-bold text-slate-300 mb-1.5"
              >
                رمز المصادقة للمطورين
              </label>
              <input
                id="dev-auth-code"
                type="password"
                dir="ltr"
                required
                value={pinOrPassword}
                onChange={(e) => {
                  setPinOrPassword(e.target.value);
                  setAuthError("");
                }}
                placeholder="••••"
                className="h-11 w-full rounded-xl border border-white/10 bg-[#0B0F19] px-4 font-mono text-sm text-white focus:border-emerald-500 focus:outline-none"
              />
            </div>
            {authError && (
              <p className="rounded-lg border border-rose-500/35 bg-rose-500/10 px-3 py-2 text-xs font-semibold text-rose-300">
                {authError}
              </p>
            )}
            <button
              type="submit"
              className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-600 py-3 text-xs font-extrabold text-white hover:bg-emerald-500 cursor-pointer"
            >
              <KeyRound className="h-4 w-4" />
              <span>تحقق وفتح خيارات المطورين</span>
            </button>
          </form>
        ) : (
          <div className="flex flex-1 flex-col overflow-hidden">
            {/* Tabs */}
            <div className="flex flex-wrap items-center gap-1 border-b border-white/10 bg-[#0B0F19] px-6 py-2.5">
              {(
                [
                  {
                    id: "config",
                    label: "إعدادات الموقع",
                    icon: Settings2,
                  },
                  {
                    id: "users",
                    label: "إدارة المستخدمين",
                    icon: Users,
                  },
                  {
                    id: "logs",
                    label: `سجلات النظام (${systemLogs.length})`,
                    icon: Activity,
                  },
                ] as const
              ).map((tab) => {
                const Icon = tab.icon;
                const active = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setActiveTab(tab.id)}
                    className={`inline-flex items-center gap-1.5 rounded-lg px-3.5 py-2 text-xs font-bold transition-colors cursor-pointer ${
                      active
                        ? "bg-violet-600 text-white"
                        : "text-slate-400 hover:bg-white/5 hover:text-white"
                    }`}
                  >
                    <Icon className="h-3.5 w-3.5" />
                    <span>{tab.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto p-6 space-y-5">
              {activeTab === "config" && (
                <div className="space-y-5">
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <div className="rounded-xl border border-white/10 bg-[#0B0F19] p-4 space-y-3">
                      <p className="text-xs font-extrabold text-white">
                        حالة شاشة الصيانة
                      </p>
                      <p className="text-[11px] text-slate-400">
                        تفعيل أو تعطيل بوابة الساعة 10:00 بالليل فوراً.
                      </p>
                      <button
                        type="button"
                        onClick={() => {
                          onToggleMaintenance(!maintenanceActive);
                          onAddLog(
                            "INFO",
                            !maintenanceActive
                              ? "تم تفعيل شاشة الصيانة من خيارات المطورين"
                              : "تم تجاوز شاشة الصيانة من خيارات المطورين"
                          );
                        }}
                        className={`w-full rounded-lg py-2 text-xs font-bold cursor-pointer ${
                          maintenanceActive
                            ? "bg-amber-600 text-white hover:bg-amber-500"
                            : "bg-emerald-600/20 border border-emerald-500/40 text-emerald-300 hover:bg-emerald-600/30"
                        }`}
                      >
                        {maintenanceActive
                          ? "تعطيل شاشة الصيانة الآن"
                          : "إعادة تفعيل شاشة الصيانة"}
                      </button>
                    </div>

                    <div className="rounded-xl border border-white/10 bg-[#0B0F19] p-4 space-y-3">
                      <p className="text-xs font-extrabold text-white">
                        وضع سطح المكتب (Desktop UI)
                      </p>
                      <p className="text-[11px] text-slate-400">
                        تبديل كثافة الشبكة وإتاحة شريط المطورين السريع.
                      </p>
                      <button
                        type="button"
                        onClick={() => onToggleDesktopMode(!desktopMode)}
                        className={`w-full rounded-lg py-2 text-xs font-bold cursor-pointer ${
                          desktopMode
                            ? "bg-emerald-600 text-white"
                            : "border border-white/15 bg-white/5 text-slate-200 hover:bg-white/10"
                        }`}
                      >
                        {desktopMode
                          ? "وضع سطح المكتب: مفعّل"
                          : "تفعيل وضع سطح المكتب"}
                      </button>
                    </div>
                  </div>

                  {/* Quick Theme Selector */}
                  <div className="rounded-xl border border-white/10 bg-[#0B0F19] p-4 space-y-3">
                    <p className="text-xs font-extrabold text-white">
                      تبديل الزينة والثيم المباشر
                    </p>
                    <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                      {THEME_OPTIONS.map((opt) => (
                        <button
                          key={opt.id}
                          type="button"
                          onClick={() => onChangeTheme(opt.id)}
                          className={`rounded-lg border px-3 py-2 text-xs font-bold cursor-pointer ${
                            themeDecoration === opt.id
                              ? "border-emerald-400 bg-emerald-500/20 text-emerald-200"
                              : "border-white/10 bg-[#111827] text-slate-300 hover:text-white"
                          }`}
                        >
                          {opt.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Chat Route Quick Config */}
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      onSaveAssistantConfig(urlDraft, titleDraft);
                      onAddLog("INFO", "تم تحديث إعدادات رابط المحادثة ومهندس الأكواد");
                    }}
                    className="rounded-xl border border-white/10 bg-[#0B0F19] p-4 space-y-3"
                  >
                    <p className="text-xs font-extrabold text-emerald-300">
                      إعداد مسار مهندس الأكواد الذكي
                    </p>
                    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                      <input
                        type="text"
                        dir="ltr"
                        value={urlDraft}
                        onChange={(e) => setUrlDraft(e.target.value)}
                        className="h-10 rounded-lg border border-white/10 bg-[#111827] px-3 font-mono text-xs text-white"
                      />
                      <input
                        type="text"
                        value={titleDraft}
                        onChange={(e) => setTitleDraft(e.target.value)}
                        className="h-10 rounded-lg border border-white/10 bg-[#111827] px-3 text-xs text-white"
                      />
                    </div>
                    <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-400">
                      <span className="font-mono">
                        Project: {firebaseConfig.projectId} · {FIREBASE_HOSTING_SITE}
                      </span>
                      <button
                        type="submit"
                        className="rounded-lg bg-violet-600 px-4 py-2 text-xs font-bold text-white hover:bg-violet-500 cursor-pointer"
                      >
                        حفظ إعدادات الموقع
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {activeTab === "users" && (
                <div className="space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2 text-xs font-bold text-slate-300">
                      <ShieldCheck className="h-4 w-4 text-emerald-400" />
                      <span>
                        دليل الأشخاص والحسابات ({usersList.length})
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => void loadUsersFromFirestore()}
                      disabled={loadingUsers}
                      className="inline-flex items-center gap-1.5 rounded-lg border border-white/15 bg-white/5 px-3 py-1.5 text-xs font-bold text-slate-200 hover:bg-white/10 cursor-pointer"
                    >
                      <RefreshCw
                        className={`h-3.5 w-3.5 ${
                          loadingUsers ? "animate-spin" : ""
                        }`}
                      />
                      <span>تحديث القائمة</span>
                    </button>
                  </div>

                  {/* Search & Quick Add / Enable Person (e.g. amirbaqir226) */}
                  <div className="rounded-xl border border-emerald-500/30 bg-[#0B0F19] p-3.5 space-y-3">
                    <div className="relative">
                      <Search className="pointer-events-none absolute right-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
                      <input
                        type="text"
                        value={userSearchQuery}
                        onChange={(e) => setUserSearchQuery(e.target.value)}
                        placeholder="ابحث بالاسم أو المعرّف (مثل amirbaqir226) أو البريد..."
                        className="h-9 w-full rounded-lg border border-white/10 bg-[#111827] pr-9 pl-3 text-xs text-white focus:border-emerald-400 focus:outline-none"
                      />
                    </div>

                    <div className="grid grid-cols-1 gap-2 sm:grid-cols-4">
                      <input
                        type="text"
                        dir="ltr"
                        value={newPersonInput}
                        onChange={(e) => setNewPersonInput(e.target.value)}
                        placeholder="@username أو email"
                        className="h-9 rounded-lg border border-white/10 bg-[#111827] px-3 font-mono text-xs text-emerald-300 focus:border-violet-400 focus:outline-none"
                      />
                      <input
                        type="text"
                        value={newPersonName}
                        onChange={(e) => setNewPersonName(e.target.value)}
                        placeholder="الاسم المعروض"
                        className="h-9 rounded-lg border border-white/10 bg-[#111827] px-3 text-xs text-white focus:border-violet-400 focus:outline-none"
                      />
                      <select
                        value={newPersonRole}
                        onChange={(e) =>
                          setNewPersonRole(e.target.value as UserRole)
                        }
                        className="h-9 rounded-lg border border-white/10 bg-[#111827] px-2 text-xs text-white focus:border-violet-400 focus:outline-none"
                      >
                        <option value="developer">مطور (Developer)</option>
                        <option value="director">مدير (Director)</option>
                        <option value="moderator">مشرف (Moderator)</option>
                        <option value="admin">مسؤول (Admin)</option>
                        <option value="user">عضو (User)</option>
                      </select>
                      <button
                        type="button"
                        disabled={addingPerson || !newPersonInput.trim()}
                        onClick={() => {
                          void (async () => {
                            setAddingPerson(true);
                            try {
                              const res = await fetch("/api/directory/people", {
                                method: "POST",
                                headers: { "Content-Type": "application/json" },
                                body: JSON.stringify({
                                  username: newPersonInput.trim(),
                                  displayName:
                                    newPersonName.trim() ||
                                    newPersonInput.trim().replace(/^@/, ""),
                                  role: newPersonRole,
                                  enabled: true,
                                }),
                              });
                              if (res.ok) {
                                setNewPersonInput("");
                                setNewPersonName("");
                                await loadUsersFromFirestore();
                                onAddLog(
                                  "AUTH",
                                  `تم تفعيل الشخص في الدليل بنجاح`
                                );
                              }
                            } finally {
                              setAddingPerson(false);
                            }
                          })();
                        }}
                        className="inline-flex h-9 items-center justify-center gap-1.5 rounded-lg bg-emerald-600 px-3 text-xs font-bold text-white hover:bg-emerald-500 disabled:opacity-45 cursor-pointer"
                      >
                        <UserPlus className="h-3.5 w-3.5" />
                        <span>تفعيل / إضافة</span>
                      </button>
                    </div>
                  </div>

                  {usersList.length === 0 ? (
                    <div className="rounded-xl border border-white/10 bg-[#0B0F19] p-6 text-center text-xs text-slate-400">
                      {loadingUsers
                        ? "جارٍ جلب قائمة المستخدمين..."
                        : "لا توجد حسابات مطابقة حالياً."}
                    </div>
                  ) : (
                    <div className="space-y-2.5">
                      {usersList
                        .filter((u) => {
                          const q = userSearchQuery.trim().toLowerCase();
                          if (!q) return true;
                          return (
                            u.name.toLowerCase().includes(q) ||
                            u.handle.toLowerCase().includes(q) ||
                            u.email.toLowerCase().includes(q)
                          );
                        })
                        .map((u) => {
                          const isFounder =
                            u.handle.toLowerCase() === OWNER_PERSON.handle ||
                            isOwnerEmail(u.email);
                          return (
                            <div
                              key={u.id}
                              className={`flex flex-wrap items-center justify-between gap-3 rounded-xl border p-3.5 ${
                                isFounder
                                  ? "border-amber-400/40 bg-[#15120A]"
                                  : "border-white/10 bg-[#0B0F19]"
                              }`}
                            >
                              <div className="flex items-center gap-3 min-w-0">
                                <img
                                  src={u.avatarUrl}
                                  alt={u.name}
                                  referrerPolicy="no-referrer"
                                  className="h-10 w-10 rounded-full border border-violet-500/40 object-cover shrink-0"
                                />
                                <div className="min-w-0">
                                  <p className="flex items-center gap-1.5 truncate text-xs font-extrabold text-white">
                                    <span>{u.name}</span>
                                    <span
                                      dir="ltr"
                                      className="font-mono text-emerald-400"
                                    >
                                      {u.handle}
                                    </span>
                                    {isFounder && (
                                      <span className="inline-flex items-center gap-1 rounded bg-amber-500/20 px-1.5 py-0.5 text-[10px] font-extrabold text-amber-300">
                                        <Crown className="h-3 w-3" />
                                        <span>مفعّل</span>
                                      </span>
                                    )}
                                  </p>
                                  <p className="text-[11px] text-slate-400">
                                    {u.city} · الرتبة: {u.role} ·{" "}
                                    {u.email ? (
                                      <span dir="ltr" className="font-mono text-slate-300">
                                        {u.email}
                                      </span>
                                    ) : (
                                      `سطح المكتب: ${u.desktopMode ? "مفعّل" : "عادي"}`
                                    )}
                                  </p>
                                </div>
                              </div>

                              <div className="flex flex-wrap items-center gap-1.5">
                                {(isAuthorized || isFirebaseAdminEmail) && !isFounder && (
                                  <select
                                    value={u.role}
                                    onChange={(e) => {
                                      const nextRole = e.target.value as UserRole;
                                      void (async () => {
                                        setUsersList((prev) =>
                                          prev.map((item) =>
                                            item.id === u.id
                                              ? { ...item, role: nextRole }
                                              : item
                                          )
                                        );
                                        await updateUserRoleByAdminInFirestore(
                                          u.id,
                                          nextRole
                                        ).catch(() => undefined);
                                        await fetch("/api/directory/people", {
                                          method: "POST",
                                          headers: {
                                            "Content-Type": "application/json",
                                          },
                                          body: JSON.stringify({
                                            username: u.handle.replace(/^@/, ""),
                                            displayName: u.name,
                                            email: u.email,
                                            role: nextRole,
                                          }),
                                        }).catch(() => undefined);
                                        onAddLog(
                                          "AUTH",
                                          `تحديث رتبة ${u.handle} إلى ${nextRole}`
                                        );
                                      })();
                                    }}
                                    className="h-8 rounded-lg border border-white/15 bg-[#111827] px-2 text-[11px] font-bold text-slate-200 cursor-pointer"
                                  >
                                    <option value="user">user</option>
                                    <option value="developer">developer</option>
                                    <option value="director">director</option>
                                    <option value="moderator">moderator</option>
                                    <option value="admin">admin</option>
                                  </select>
                                )}

                                <button
                                  type="button"
                                  onClick={() => void handleCopyUid(u.id)}
                                  className="inline-flex items-center gap-1 rounded-lg border border-white/10 bg-white/5 px-2.5 py-1.5 font-mono text-[11px] text-slate-300 hover:bg-white/10 cursor-pointer"
                                >
                                  <Copy className="h-3 w-3" />
                                  <span>
                                    {copiedId === u.id
                                      ? "تم النسخ"
                                      : `${u.id.slice(0, 10)}...`}
                                  </span>
                                </button>
                              </div>
                            </div>
                          );
                        })}
                    </div>
                  )}

                  {/* Admin & Supervisor Role Requests Review Section */}
                  <div className="rounded-xl border border-amber-500/30 bg-[#0B0F19] p-4 space-y-3">
                    <div className="flex items-center justify-between gap-2">
                      <span className="inline-flex items-center gap-1.5 text-xs font-extrabold text-amber-300">
                        <Crown className="h-4 w-4" />
                        <span>طلبات رتبة مدير / مشرف ({roleRequests.length})</span>
                      </span>
                    </div>

                    {roleRequests.length === 0 ? (
                      <p className="text-[11px] text-slate-400">
                        لا توجد طلبات رتبة معلّقة حالياً.
                      </p>
                    ) : (
                      <div className="space-y-2">
                        {roleRequests.map((req) => (
                          <div
                            key={req.id}
                            className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-white/10 bg-[#111827] p-3"
                          >
                            <div className="min-w-0">
                              <p className="text-xs font-bold text-white">
                                {req.fullName}{" "}
                                <span
                                  dir="ltr"
                                  className="font-mono text-amber-300 text-[11px]"
                                >
                                  ({req.email})
                                </span>
                              </p>
                              <p className="text-[11px] text-slate-400">
                                الطلب: {req.requestedRole} · الحالة:{" "}
                                <span className="font-bold text-emerald-300">
                                  {req.status}
                                </span>
                                {req.note ? ` · ${req.note}` : ""}
                              </p>
                            </div>
                            <div className="flex items-center gap-1.5">
                              <button
                                type="button"
                                onClick={() => {
                                  void (async () => {
                                    setRoleRequests((prev) =>
                                      prev.map((r) =>
                                        r.id === req.id
                                          ? { ...r, status: "approved" }
                                          : r
                                      )
                                    );
                                    await fetch(
                                      `/api/role-requests/${encodeURIComponent(
                                        req.id
                                      )}`,
                                      {
                                        method: "PATCH",
                                        headers: {
                                          "Content-Type": "application/json",
                                        },
                                        body: JSON.stringify({
                                          status: "approved",
                                        }),
                                      }
                                    ).catch(() => undefined);
                                    await updateRoleRequestStatusInFirestore(
                                      req.id,
                                      "approved"
                                    ).catch(() => undefined);
                                    onAddLog(
                                      "AUTH",
                                      `تمت الموافقة على طلب ${req.fullName}`
                                    );
                                  })();
                                }}
                                className="inline-flex items-center gap-1 rounded-lg bg-emerald-600/25 border border-emerald-500/40 px-2.5 py-1 text-[11px] font-bold text-emerald-200 hover:bg-emerald-600/40 cursor-pointer"
                              >
                                <CheckCircle2 className="h-3 w-3" />
                                <span>موافقة</span>
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  void (async () => {
                                    setRoleRequests((prev) =>
                                      prev.map((r) =>
                                        r.id === req.id
                                          ? { ...r, status: "rejected" }
                                          : r
                                      )
                                    );
                                    await fetch(
                                      `/api/role-requests/${encodeURIComponent(
                                        req.id
                                      )}`,
                                      {
                                        method: "PATCH",
                                        headers: {
                                          "Content-Type": "application/json",
                                        },
                                        body: JSON.stringify({
                                          status: "rejected",
                                        }),
                                      }
                                    ).catch(() => undefined);
                                    await updateRoleRequestStatusInFirestore(
                                      req.id,
                                      "rejected"
                                    ).catch(() => undefined);
                                    onAddLog(
                                      "AUTH",
                                      `تم رفض طلب ${req.fullName}`
                                    );
                                  })();
                                }}
                                className="inline-flex items-center gap-1 rounded-lg bg-rose-600/20 border border-rose-500/40 px-2.5 py-1 text-[11px] font-bold text-rose-200 hover:bg-rose-600/35 cursor-pointer"
                              >
                                <XCircle className="h-3 w-3" />
                                <span>رفض</span>
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {activeTab === "logs" && (
                <div className="space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex flex-wrap gap-1.5">
                      {(["ALL", "AUTH", "CLOUD", "FIRESTORE", "INFO"] as const).map(
                        (lvl) => (
                          <button
                            key={lvl}
                            type="button"
                            onClick={() => setLogFilter(lvl)}
                            className={`rounded-lg px-2.5 py-1 font-mono text-[11px] font-bold cursor-pointer ${
                              logFilter === lvl
                                ? "bg-emerald-600 text-white"
                                : "border border-white/10 bg-[#0B0F19] text-slate-400 hover:text-white"
                            }`}
                          >
                            {lvl}
                          </button>
                        )
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={handleExportLogs}
                        className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-500/35 bg-emerald-500/15 px-3 py-1.5 text-xs font-bold text-emerald-300 hover:bg-emerald-500/25 cursor-pointer"
                      >
                        <Download className="h-3.5 w-3.5" />
                        <span>تصدير JSON</span>
                      </button>
                      <button
                        type="button"
                        onClick={onClearLogs}
                        className="inline-flex items-center gap-1 rounded-lg border border-rose-500/35 bg-rose-500/10 px-3 py-1.5 text-xs font-bold text-rose-300 hover:bg-rose-500/20 cursor-pointer"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                        <span>مسح</span>
                      </button>
                    </div>
                  </div>

                  <div className="max-h-72 overflow-y-auto rounded-xl border border-white/10 bg-[#080C15] p-3 font-mono text-xs space-y-2">
                    {filteredLogs.length === 0 ? (
                      <p className="text-center text-slate-500 py-6">
                        لا توجد سجلات مطابقة في هذه الجلسة.
                      </p>
                    ) : (
                      filteredLogs.map((entry) => (
                        <div
                          key={entry.id}
                          className="flex flex-wrap items-baseline justify-between gap-2 border-b border-white/5 pb-2 last:border-0"
                        >
                          <div className="flex items-baseline gap-2 min-w-0">
                            <span
                              className={`shrink-0 rounded px-1.5 py-0.5 text-[10px] font-bold ${
                                entry.level === "AUTH"
                                  ? "bg-violet-500/20 text-violet-300"
                                  : entry.level === "CLOUD"
                                  ? "bg-sky-500/20 text-sky-300"
                                  : entry.level === "FIRESTORE"
                                  ? "bg-amber-500/20 text-amber-300"
                                  : "bg-emerald-500/20 text-emerald-300"
                              }`}
                            >
                              {entry.level}
                            </span>
                            <span className="text-slate-200 break-words">
                              {entry.message}
                            </span>
                          </div>
                          <span dir="ltr" className="text-[10px] text-slate-500 shrink-0">
                            {entry.timestamp}
                          </span>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
