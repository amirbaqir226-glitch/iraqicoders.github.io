import React, { useEffect, useRef, useState } from "react";
import { GripHorizontal, Volume2, X } from "lucide-react";
import { speakArabicText, stopArabicSpeech } from "../services/speechEngine";

interface FloatingArabicSpeakerProps {
  isEnabled: boolean;
  onClose: () => void;
}

export const FloatingArabicSpeaker: React.FC<FloatingArabicSpeakerProps> = ({
  isEnabled,
  onClose,
}) => {
  const [pos, setPos] = useState<{ x: number; y: number }>({ x: 20, y: 120 });
  const [lastSpoken, setLastSpoken] = useState<string>(
    "اضغط على أي زر أو كلمة ليقرأها باللغة العربية الفصحى"
  );

  const draggingRef = useRef(false);
  const movedRef = useRef(false);
  const offsetRef = useRef({ dx: 0, dy: 0 });

  useEffect(() => {
    if (!isEnabled) {
      stopArabicSpeech();
      return;
    }

    speakArabicText(
      "تم تفعيل زر السماعة. اضغط على أي كلمة أو زر لقراءته باللغة العربية الفصحى.",
      { voiceProfile: "fusha-clear" }
    );

    const handleGlobalClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement | null;
      if (!target) return;
      if (target.closest("[data-speaker-widget='true']")) return;

      const textCarrier = target.closest(
        "button, a, h1, h2, h3, h4, p, span, label, li, strong"
      ) as HTMLElement | null;
      const rawText = (
        textCarrier?.getAttribute("aria-label") ||
        textCarrier?.innerText ||
        target.innerText ||
        ""
      )
        .replace(/\s+/g, " ")
        .trim();

      if (!rawText) return;
      const spokenSnippet = rawText.slice(0, 180);
      setLastSpoken(spokenSnippet);
      speakArabicText(spokenSnippet, { voiceProfile: "fusha-clear", rate: 0.96 });
    };

    document.addEventListener("click", handleGlobalClick, true);
    return () => {
      document.removeEventListener("click", handleGlobalClick, true);
      stopArabicSpeech();
    };
  }, [isEnabled]);

  if (!isEnabled) return null;

  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if ((e.target as HTMLElement).closest("button[data-speaker-close='true']")) {
      return;
    }
    draggingRef.current = true;
    movedRef.current = false;
    offsetRef.current = {
      dx: e.clientX - pos.x,
      dy: e.clientY - pos.y,
    };
    e.currentTarget.setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!draggingRef.current) return;
    movedRef.current = true;
    const maxX = Math.max(20, window.innerWidth - 220);
    const maxY = Math.max(20, window.innerHeight - 80);
    setPos({
      x: Math.min(maxX, Math.max(8, e.clientX - offsetRef.current.dx)),
      y: Math.min(maxY, Math.max(8, e.clientY - offsetRef.current.dy)),
    });
  };

  const handlePointerUp = () => {
    draggingRef.current = false;
  };

  return (
    <div
      data-speaker-widget="true"
      style={{ left: `${pos.x}px`, top: `${pos.y}px` }}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerUp}
      className="fixed z-50 flex flex-col gap-1.5 select-none touch-none"
    >
      {/* Unified Draggable Speaker Circle + Attached X Button */}
      <div className="flex items-center gap-1.5 rounded-full border border-emerald-400/60 bg-[#0D1628]/95 p-1.5 shadow-[0_12px_32px_rgba(16,185,129,0.35)] backdrop-blur-md cursor-grab active:cursor-grabbing">
        <button
          type="button"
          onClick={() => {
            if (movedRef.current) return;
            speakArabicText(lastSpoken, { voiceProfile: "fusha-clear" });
          }}
          title="اسحبني لأي مكان — اضغط لإعادة القراءة بالعربية الفصحى"
          aria-label="زر السماعة العائم"
          className="flex h-11 w-11 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-sky-600 text-white shadow-lg"
        >
          <Volume2 className="h-5 w-5" />
        </button>

        <div className="flex items-center gap-1 px-1.5 text-[11px] font-extrabold text-emerald-200">
          <GripHorizontal className="h-3.5 w-3.5 text-slate-400" />
          <span className="max-w-[115px] truncate">{lastSpoken}</span>
        </div>

        {/* Attached X button moves seamlessly with speaker */}
        <button
          type="button"
          data-speaker-close="true"
          onClick={(e) => {
            e.stopPropagation();
            stopArabicSpeech();
            onClose();
          }}
          title="إيقاف السماعة والقراءة الصوتية فوراً"
          aria-label="إغلاق زر السماعة"
          className="flex h-9 w-9 items-center justify-center rounded-full border border-rose-400/50 bg-rose-500/20 text-rose-200 transition-colors hover:bg-rose-500 hover:text-white cursor-pointer"
        >
          <X className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
};
