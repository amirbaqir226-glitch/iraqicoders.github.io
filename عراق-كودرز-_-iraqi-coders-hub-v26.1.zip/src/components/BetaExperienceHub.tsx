import React, { useEffect, useRef, useState } from "react";
import {
  AlertTriangle,
  Archive,
  Box,
  CheckCircle2,
  Code2,
  Cpu,
  Download,
  FlaskConical,
  Gamepad2,
  GraduationCap,
  Lock,
  Play,
  Plus,
  Save,
  Settings2,
  ShieldCheck,
  Sparkles,
  Wand2,
  X,
} from "lucide-react";
import {
  BETA_PROGRAMMING_LANGUAGES,
  REQUIRED_CODE_SEAL,
} from "../data/siteConfig";
import { buildKrookProjectZipBlob } from "../services/packageBuilder";
import {
  BetaBrowserInspection,
  CustomNationalityCard,
  GmailConfirmRequest,
  PlatformMessageRecord,
  ProgrammingLanguageId,
  PublishedMiniProject,
  SchoolUpdateItem,
  UserProfile,
  UserRole,
} from "../types";
import { AdminRankMiniApp } from "./AdminRankMiniApp";

export type BetaTabId = "school" | "games" | "plus" | "programmer" | "mini-apps";

interface BetaExperienceHubProps {
  betaEnabled: boolean;
  browserInspection: BetaBrowserInspection;
  googleBetaJoined: boolean;
  activeProgLang: ProgrammingLanguageId;
  fantasyMode: boolean;
  user: UserProfile | null;
  userRole: UserRole;
  schoolUpdates: SchoolUpdateItem[];
  publishedMiniApps: PublishedMiniProject[];
  allNationalities: CustomNationalityCard[];
  requestedTab?: { tab: BetaTabId; nonce: number };
  onToggleBeta: (enabled: boolean) => void;
  onToggleGoogleBetaJoined: (joined: boolean) => void;
  onChangeProgLang: (lang: ProgrammingLanguageId) => void;
  onToggleFantasyMode: (enabled: boolean) => void;
  onPublishMiniProject: (proj: PublishedMiniProject) => void;
  onAddSchoolUpdate: (item: SchoolUpdateItem) => void;
  onNationalityLoaded: (card: CustomNationalityCard) => void;
  onAddPlatformMessage: (msg: PlatformMessageRecord) => void;
  onRequestSendGmail: (req: GmailConfirmRequest) => void;
  onOpenDeveloperCategory: () => void;
  onShowToast: (msg: string) => void;
}

function autoFixSourceCode(code: string, lang: ProgrammingLanguageId): string {
  let fixed = code.replace(/\r\n/g, "\n").trim();
  const openParens = (fixed.match(/\(/g) || []).length;
  const closeParens = (fixed.match(/\)/g) || []).length;
  if (openParens > closeParens) {
    fixed += ")".repeat(openParens - closeParens);
  }
  const openBraces = (fixed.match(/\{/g) || []).length;
  const closeBraces = (fixed.match(/\}/g) || []).length;
  if (openBraces > closeBraces) {
    fixed += "\n" + "}".repeat(openBraces - closeBraces);
  }
  if (lang === "python" && /def\s+\w+\([^)]*\)\s*$/m.test(fixed)) {
    fixed = fixed.replace(/^(def\s+\w+\([^)]*\))\s*$/gm, "$1:");
  }
  return fixed;
}

function hasValidEndSeal(code: string): boolean {
  return code.trimEnd().endsWith(REQUIRED_CODE_SEAL);
}

const PubgMiniBattleGame: React.FC<{ onWin?: () => void }> = ({ onWin }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [score, setScore] = useState(0);
  const [hp, setHp] = useState(100);
  const [aliveEnemies, setAliveEnemies] = useState(6);
  const [status, setStatus] = useState<"idle" | "playing" | "won" | "lost">(
    "idle"
  );

  const playerRef = useRef({ x: 210, y: 130 });
  const targetRef = useRef({ x: 210, y: 130 });
  const bulletsRef = useRef<Array<{ x: number; y: number; vx: number; vy: number }>>([]);
  const enemiesRef = useRef<Array<{ x: number; y: number; vx: number; vy: number }>>([]);
  const zoneRadiusRef = useRef(200);

  const startMatch = () => {
    playerRef.current = { x: 210, y: 130 };
    targetRef.current = { x: 210, y: 130 };
    bulletsRef.current = [];
    enemiesRef.current = Array.from({ length: 6 }, (_, idx) => ({
      x: 40 + ((idx * 73) % 340),
      y: idx % 2 === 0 ? 35 : 225,
      vx: (idx % 2 === 0 ? 1 : -1) * 1.15,
      vy: (idx % 3 === 0 ? 0.9 : -0.9),
    }));
    zoneRadiusRef.current = 210;
    setHp(100);
    setScore(0);
    setAliveEnemies(6);
    setStatus("playing");
  };

  useEffect(() => {
    if (status !== "playing") return;

    const timer = window.setInterval(() => {
      const cv = canvasRef.current;
      if (!cv) return;
      const ctx = cv.getContext("2d");
      if (!ctx) return;

      // Move player smoothly toward pointer target
      const p = playerRef.current;
      const t = targetRef.current;
      p.x += (t.x - p.x) * 0.14;
      p.y += (t.y - p.y) * 0.14;

      // Shrink blue safe zone slowly
      zoneRadiusRef.current = Math.max(70, zoneRadiusRef.current - 0.12);
      const distCenter = Math.hypot(p.x - cv.width / 2, p.y - cv.height / 2);
      if (distCenter > zoneRadiusRef.current) {
        setHp((prev) => {
          const nxt = Math.max(0, prev - 0.5);
          if (nxt <= 0) setStatus("lost");
          return nxt;
        });
      }

      // Move bullets
      bulletsRef.current = bulletsRef.current
        .map((b) => ({ ...b, x: b.x + b.vx, y: b.y + b.vy }))
        .filter((b) => b.x > 0 && b.x < cv.width && b.y > 0 && b.y < cv.height);

      // Update enemies & collisions
      const remainingEnemies: typeof enemiesRef.current = [];
      for (const en of enemiesRef.current) {
        en.x += en.vx;
        en.y += en.vy;
        if (en.x < 16 || en.x > cv.width - 16) en.vx *= -1;
        if (en.y < 16 || en.y > cv.height - 16) en.vy *= -1;

        const hitBulletIdx = bulletsRef.current.findIndex(
          (b) => Math.hypot(b.x - en.x, b.y - en.y) < 15
        );
        if (hitBulletIdx !== -1) {
          bulletsRef.current.splice(hitBulletIdx, 1);
          setScore((s) => s + 25);
          continue;
        }
        if (Math.hypot(en.x - p.x, en.y - p.y) < 18) {
          setHp((prev) => {
            const nxt = Math.max(0, prev - 1.2);
            if (nxt <= 0) setStatus("lost");
            return nxt;
          });
        }
        remainingEnemies.push(en);
      }

      enemiesRef.current = remainingEnemies;
      setAliveEnemies(remainingEnemies.length);
      if (remainingEnemies.length === 0) {
        setStatus("won");
        onWin?.();
      }

      // Render battleground
      ctx.fillStyle = "#0F1B14";
      ctx.fillRect(0, 0, cv.width, cv.height);

      // Grid lines
      ctx.strokeStyle = "rgba(255,255,255,0.06)";
      for (let gx = 0; gx < cv.width; gx += 40) {
        ctx.beginPath();
        ctx.moveTo(gx, 0);
        ctx.lineTo(gx, cv.height);
        ctx.stroke();
      }

      // Safe zone circle
      ctx.strokeStyle = "#38BDF8";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(cv.width / 2, cv.height / 2, zoneRadiusRef.current, 0, Math.PI * 2);
      ctx.stroke();

      // Enemies
      for (const en of enemiesRef.current) {
        ctx.fillStyle = "#F43F5E";
        ctx.beginPath();
        ctx.arc(en.x, en.y, 9, 0, Math.PI * 2);
        ctx.fill();
      }

      // Bullets
      ctx.fillStyle = "#FBBF24";
      for (const b of bulletsRef.current) {
        ctx.beginPath();
        ctx.arc(b.x, b.y, 3.5, 0, Math.PI * 2);
        ctx.fill();
      }

      // Player
      ctx.fillStyle = "#34D399";
      ctx.beginPath();
      ctx.arc(p.x, p.y, 10, 0, Math.PI * 2);
      ctx.fill();
    }, 30);

    return () => window.clearInterval(timer);
  }, [status, onWin]);

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (status !== "playing") return;
    const cv = canvasRef.current;
    if (!cv) return;
    const rect = cv.getBoundingClientRect();
    const mx = ((e.clientX - rect.left) / rect.width) * cv.width;
    const my = ((e.clientY - rect.top) / rect.height) * cv.height;
    targetRef.current = { x: mx, y: my };

    const angle = Math.atan2(my - playerRef.current.y, mx - playerRef.current.x);
    bulletsRef.current.push({
      x: playerRef.current.x,
      y: playerRef.current.y,
      vx: Math.cos(angle) * 7.5,
      vy: Math.sin(angle) * 7.5,
    });
  };

  return (
    <div className="rounded-2xl border border-emerald-400/35 bg-[#080D18] p-4 space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
        <div className="flex items-center gap-2 font-extrabold text-emerald-300">
          <Gamepad2 className="h-4 w-4" />
          <span>ساحة بغداد الملكية — لعبة تشبه ببجي (Beta Arena)</span>
        </div>
        <div className="flex items-center gap-3 font-mono tabular-nums">
          <span className="text-emerald-300">الصحة: {Math.round(hp)}%</span>
          <span className="text-rose-300">الخصوم: {aliveEnemies}</span>
          <span className="text-amber-300">النقاط: {score}</span>
        </div>
      </div>

      <div className="relative overflow-hidden rounded-xl border border-white/10 bg-[#070B12] flex justify-center">
        <canvas
          ref={canvasRef}
          width={420}
          height={250}
          onClick={handleCanvasClick}
          className="w-full max-w-[520px] h-auto cursor-crosshair touch-none"
        />
        {status !== "playing" && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-black/70 p-4 text-center backdrop-blur-xs">
            <p className="text-base font-extrabold text-white">
              {status === "won"
                ? "🏆 عشاء الدجاج! انتصرت في المعركة!"
                : status === "lost"
                ? "تم القضاء عليك داخل المنطقة الزرقاء!"
                : "انقر داخل الخريطة للتحرك وإطلاق النار على الخصوم داخل الزون"}
            </p>
            <button
              type="button"
              onClick={startMatch}
              className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-5 py-2.5 text-xs font-extrabold text-white hover:bg-emerald-500 cursor-pointer"
            >
              <Play className="h-4 w-4" />
              <span>{status === "idle" ? "ابدأ معركة البقاء" : "العب جولة جديدة"}</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export const BetaExperienceHub: React.FC<BetaExperienceHubProps> = ({
  betaEnabled,
  browserInspection,
  googleBetaJoined,
  activeProgLang,
  fantasyMode,
  user,
  userRole,
  schoolUpdates,
  publishedMiniApps,
  allNationalities,
  requestedTab,
  onToggleBeta,
  onToggleGoogleBetaJoined,
  onChangeProgLang,
  onToggleFantasyMode,
  onPublishMiniProject,
  onAddSchoolUpdate,
  onNationalityLoaded,
  onAddPlatformMessage,
  onRequestSendGmail,
  onOpenDeveloperCategory,
  onShowToast,
}) => {
  const [activeTab, setActiveTab] = useState<BetaTabId>("school");

  const isProgrammerUnlocked =
    userRole === "developer" || userRole === "director" || userRole === "admin";
  const isStaffMiniAppAllowed =
    userRole === "admin" ||
    userRole === "developer" ||
    userRole === "moderator" ||
    userRole === "director";

  useEffect(() => {
    if (requestedTab && requestedTab.nonce > 0) {
      setActiveTab(requestedTab.tab);
    }
  }, [requestedTab]);

  // المبرمج IDE state
  const currentLangMeta =
    BETA_PROGRAMMING_LANGUAGES.find((l) => l.id === activeProgLang) ||
    BETA_PROGRAMMING_LANGUAGES[0];

  const [ideTitle, setIdeTitle] = useState("مغامرة عراقي كودرز");
  const [ideDesc, setIdeDesc] = useState("تطبيق أو لعبة مصغرة مبنية داخل بيئة المبرمج");
  const [ideKind, setIdeKind] = useState<"game" | "app">("game");
  const [ideIs3D, setIdeIs3D] = useState(false);
  const [ideLang, setIdeLang] = useState<ProgrammingLanguageId>(activeProgLang);
  const [ideCode, setIdeCode] = useState<string>(currentLangMeta.sampleCode);
  const [ideConsole, setIdeConsole] = useState<string>(
    "جاهز لكتابة الكود بأي لغة برمجة مع التصحيح التلقائي..."
  );
  const [ideSealError, setIdeSealError] = useState(false);
  const [savePromptOpen, setSavePromptOpen] = useState(false);

  // Regular user mini-project runner modal
  const [runningMiniProject, setRunningMiniProject] =
    useState<PublishedMiniProject | null>(null);

  // School update creator (for authorized staff)
  const [schoolTitleDraft, setSchoolTitleDraft] = useState("");
  const [schoolDetailsDraft, setSchoolDetailsDraft] = useState("");

  useEffect(() => {
    setIdeLang(activeProgLang);
  }, [activeProgLang]);

  const executeIdeCode = (codeToRun: string) => {
    const autoFixed = autoFixSourceCode(codeToRun, ideLang);
    if (autoFixed !== codeToRun) {
      setIdeCode(autoFixed);
    }

    if (!hasValidEndSeal(autoFixed)) {
      setIdeSealError(true);
      setIdeConsole(
        `خطأ في نهاية الكود: يجب وضع «${REQUIRED_CODE_SEAL}» في نهاية الكود لتشغيل اللعبة أو التطبيق!`
      );
      onShowToast(`أضف «${REQUIRED_CODE_SEAL}» في نهاية الكود للتشغيل.`);
      return;
    }

    setIdeSealError(false);
    setIdeConsole(
      `[OK] تم تصحيح الكود تلقائياً وتشغيله بنجاح بلغة ${ideLang.toUpperCase()} (${
        ideIs3D ? "3D Engine" : "2D Canvas"
      }) · الختم: "${REQUIRED_CODE_SEAL}" متطابق ✓`
    );
    onShowToast("تم تشغيل الكود وتصحيحه تلقائياً بنجاح!");
  };

  const handleQuickFixEndSealAndRun = () => {
    const trimmed = ideCode.trimEnd();
    const nextCode = trimmed
      ? `${trimmed}\n${REQUIRED_CODE_SEAL}`
      : REQUIRED_CODE_SEAL;
    setIdeCode(nextCode);
    setIdeSealError(false);
    executeIdeCode(nextCode);
  };

  const handleDownloadKrookZip = (proj?: {
    title: string;
    kind: "game" | "app";
    is3D: boolean;
    lang: ProgrammingLanguageId;
    code: string;
    author: string;
  }) => {
    const target = proj || {
      title: ideTitle.trim() || "مشروع عراقي كودرز",
      kind: ideKind,
      is3D: ideIs3D,
      lang: ideLang,
      code: ideCode,
      author: user?.name || "فريق عراقي كودرز",
    };

    const { blob, zipFileName, krookFileName } = buildKrookProjectZipBlob({
      title: target.title,
      language: target.lang,
      isGame: target.kind === "game",
      is3D: target.is3D,
      sourceCode: target.code,
      author: target.author,
    });

    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = zipFileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    onShowToast(`تم تنزيل ${zipFileName} (يحتوي ملف كروك ${krookFileName})!`);
  };

  const handlePublishAsMiniInsideSite = () => {
    if (!hasValidEndSeal(ideCode)) {
      setIdeSealError(true);
      onShowToast(`يجب أن ينتهي الكود بـ «${REQUIRED_CODE_SEAL}» قبل الحفظ.`);
      return;
    }

    const newProj: PublishedMiniProject = {
      id: `mini-${Date.now()}`,
      title: ideTitle.trim() || "تطبيق عراقي مصغر",
      description: ideDesc.trim() || "نسخة مصغرة تعمل مباشرة داخل الموقع",
      kind: ideKind,
      language: ideLang,
      is3D: ideIs3D,
      code: ideCode,
      authorName: user?.name || "مطور عراقي",
      authorHandle: user?.handle || "@iraqi_dev",
      authorRole: userRole,
      createdAt: "الآن",
    };

    onPublishMiniProject(newProj);
    setSavePromptOpen(false);
    setActiveTab("mini-apps");
  };

  return (
    <section
      id="beta-hub"
      className="scroll-mt-24 border-b border-white/10 py-14 lg:py-20"
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 space-y-6">
        {/* Auto Browser Inspection & Beta Activation Header */}
        <div
          className={`rounded-3xl border p-5 sm:p-7 ${
            betaEnabled
              ? "border-violet-400/50 bg-gradient-to-br from-[#14102A] via-[#0E1424] to-[#0D1F22]"
              : "border-white/10 bg-[#0E1424]"
          }`}
        >
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div className="space-y-2 max-w-2xl">
              <div className="inline-flex items-center gap-2 rounded-lg border border-violet-400/40 bg-violet-600/20 px-2.5 py-1 text-xs font-extrabold text-violet-200">
                <FlaskConical className="h-4 w-4" />
                <span>النسخة التجريبية المستقبلية (Beta Auto-Check)</span>
              </div>
              <h2 className="text-2xl font-extrabold text-white sm:text-3xl">
                {betaEnabled
                  ? "أهلاً بك في مستقبل عراقي كودرز (البيتا مفعّلة)"
                  : "تجريبية — مزايا المستقبل بانتظارك"}
              </h2>
              <p className="text-xs leading-relaxed text-slate-300 sm:text-sm">
                فحص المتصفح التلقائي:{" "}
                <strong className="text-emerald-300">
                  {browserInspection.browserName} ({browserInspection.browserVersion})
                </strong>{" "}
                · {browserInspection.reasonLabel}
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2.5">
              <button
                type="button"
                onClick={() => onToggleGoogleBetaJoined(!googleBetaJoined)}
                className={`inline-flex items-center gap-2 rounded-xl border px-3.5 py-2.5 text-xs font-bold cursor-pointer ${
                  googleBetaJoined
                    ? "border-sky-400/55 bg-sky-500/20 text-sky-200"
                    : "border-white/15 bg-white/5 text-slate-300 hover:text-white"
                }`}
              >
                <ShieldCheck className="h-4 w-4" />
                <span>
                  {googleBetaJoined
                    ? "منضم إلى Google Beta (تلقائي ✓)"
                    : "تسجيل انضمام Google Beta للتشغيل التلقائي"}
                </span>
              </button>

              <button
                type="button"
                onClick={() => onToggleBeta(!betaEnabled)}
                className={`inline-flex items-center gap-2 rounded-xl px-5 py-2.5 text-xs font-extrabold shadow-lg cursor-pointer ${
                  betaEnabled
                    ? "bg-rose-600/80 text-white hover:bg-rose-500"
                    : "version-glow bg-gradient-to-l from-violet-600 to-sky-600 text-white hover:opacity-95"
                }`}
              >
                <FlaskConical className="h-4 w-4" />
                <span>
                  {betaEnabled
                    ? "العودة للنسخة الرئيسية"
                    : "استعمال النسخة التجريبية الآن"}
                </span>
              </button>
            </div>
          </div>

          {/* Language Active Indicator when Beta is ON */}
          {betaEnabled && (
            <div className="mt-5 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-white/10 bg-[#080C15]/90 px-4 py-3 text-xs">
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-bold text-slate-400">
                  لغة برمجة الموقع الحالية:
                </span>
                <span className="rounded-md bg-emerald-500/20 border border-emerald-400/40 px-2.5 py-0.5 font-mono font-extrabold text-emerald-300">
                  {currentLangMeta.name} (.{currentLangMeta.extension})
                </span>
                <span className="text-slate-400 hidden sm:inline">
                  — {currentLangMeta.tagline}
                </span>
              </div>

              <button
                type="button"
                onClick={() => onToggleFantasyMode(!fantasyMode)}
                className={`inline-flex items-center gap-1.5 rounded-xl border px-3.5 py-1.5 text-xs font-extrabold cursor-pointer ${
                  fantasyMode
                    ? "border-pink-400 bg-pink-500/25 text-pink-200"
                    : "border-pink-400/40 bg-pink-500/10 text-pink-200 hover:bg-pink-500/20"
                }`}
              >
                <Sparkles className="h-3.5 w-3.5" />
                <span>
                  {fantasyMode
                    ? "عالم الخيال والحلويات: مفعّل ✨"
                    : "الانضمام إلى عالم الخيال ✨"}
                </span>
              </button>
            </div>
          )}
        </div>

        {/* Full Futuristic Modules when Beta Enabled */}
        {betaEnabled && (
          <div className="space-y-6">
            {/* Beta Sub-Tabs */}
            <div className="flex flex-wrap gap-2">
              {(
                [
                  {
                    id: "school" as BetaTabId,
                    label: "مدرسة ميسون للبنين",
                    icon: GraduationCap,
                  },
                  {
                    id: "games" as BetaTabId,
                    label: "ألعاب البيتا (مثل ببجي)",
                    icon: Gamepad2,
                  },
                  {
                    id: "mini-apps" as BetaTabId,
                    label: `الألعاب والتطبيقات المصغرة (${publishedMiniApps.length})`,
                    icon: Box,
                  },
                  {
                    id: "programmer" as BetaTabId,
                    label: "المبرمج وتحكم البيانات",
                    icon: Code2,
                  },
                  {
                    id: "plus" as BetaTabId,
                    label: "إعدادات بلس واللغة",
                    icon: Settings2,
                  },
                ] as const
              ).map((tab) => {
                const Icon = tab.icon;
                const active = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setActiveTab(tab.id)}
                    className={`inline-flex items-center gap-2 rounded-xl border px-4 py-2.5 text-xs font-extrabold transition-all cursor-pointer ${
                      active
                        ? "border-emerald-400 bg-emerald-600/25 text-emerald-200 shadow-md"
                        : "border-white/10 bg-[#0E1424] text-slate-300 hover:text-white"
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                    <span>{tab.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Tab 1: Maysoon Boys School Special Update */}
            {activeTab === "school" && (
              <div className="rounded-3xl border border-sky-400/35 bg-[#0D1526] p-6 space-y-5">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <span className="text-xs font-extrabold text-sky-300">
                      تحديث خاص وحصري في النسخة التجريبية
                    </span>
                    <h3 className="text-xl font-extrabold text-white mt-0.5">
                      بوابة مدرسة ميسون للبنين في المدينة
                    </h3>
                  </div>
                  <span className="rounded-xl border border-sky-400/40 bg-sky-500/15 px-3 py-1.5 text-xs font-bold text-sky-200">
                    نشاط المدرسة البرمجي
                  </span>
                </div>

                <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                  {schoolUpdates.map((item) => (
                    <div
                      key={item.id}
                      className="rounded-2xl border border-white/10 bg-[#080C15] p-4 space-y-2"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="rounded-md bg-sky-500/20 px-2 py-0.5 text-[11px] font-bold text-sky-300">
                          {item.badge}
                        </span>
                        <span className="text-[11px] text-slate-500">
                          {item.createdAt}
                        </span>
                      </div>
                      <h4 className="text-base font-extrabold text-white">
                        {item.title}
                      </h4>
                      <p className="text-xs leading-relaxed text-slate-300">
                        {item.details}
                      </p>
                      <p className="text-[11px] text-emerald-300 font-bold">
                        الناشر: {item.authorName}
                      </p>
                    </div>
                  ))}
                </div>

                {isProgrammerUnlocked && (
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      if (!schoolTitleDraft.trim() || !schoolDetailsDraft.trim())
                        return;
                      onAddSchoolUpdate({
                        id: `sch-${Date.now()}`,
                        title: schoolTitleDraft.trim(),
                        details: schoolDetailsDraft.trim(),
                        badge: "مدرسة ميسون للبنين",
                        authorName: user?.name || "إدارة المدرسة والمنصة",
                        createdAt: "الآن",
                      });
                      setSchoolTitleDraft("");
                      setSchoolDetailsDraft("");
                    }}
                    className="rounded-2xl border border-white/10 bg-[#080C15] p-4 space-y-3"
                  >
                    <p className="text-xs font-extrabold text-sky-200">
                      إضافة إعلان جديد لمدرسة ميسون للبنين في المدينة:
                    </p>
                    <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                      <input
                        type="text"
                        value={schoolTitleDraft}
                        onChange={(e) => setSchoolTitleDraft(e.target.value)}
                        placeholder="عنوان الخبر أو المسابقة..."
                        className="h-10 rounded-xl border border-white/10 bg-[#0E1424] px-3 text-xs text-white"
                      />
                      <input
                        type="text"
                        value={schoolDetailsDraft}
                        onChange={(e) => setSchoolDetailsDraft(e.target.value)}
                        placeholder="تفاصيل التحديث لطلبة المدرسة..."
                        className="h-10 rounded-xl border border-white/10 bg-[#0E1424] px-3 text-xs text-white"
                      />
                    </div>
                    <button
                      type="submit"
                      className="inline-flex items-center gap-1.5 rounded-xl bg-sky-600 px-4 py-2 text-xs font-bold text-white hover:bg-sky-500 cursor-pointer"
                    >
                      <Plus className="h-3.5 w-3.5" />
                      <span>نشر في بوابة مدرسة ميسون</span>
                    </button>
                  </form>
                )}
              </div>
            )}

            {/* Tab 2: PUBG-style Mini Battle Royale */}
            {activeTab === "games" && (
              <div className="space-y-4">
                <PubgMiniBattleGame
                  onWin={() => onShowToast("انتصرت في جولة البقاء في ميدان بغداد!")}
                />
              </div>
            )}

            {/* Tab 3: Published Mini-Apps & Mini-Games (+ Exclusive Admin Rank & Nationality Mini-App for Staff) */}
            {activeTab === "mini-apps" && (
              <div className="space-y-6">
                {/* Exclusive Staff Mini-App: Completely hidden & gated from regular users */}
                {isStaffMiniAppAllowed && (
                  <AdminRankMiniApp
                    user={user}
                    userRole={userRole}
                    allNationalities={allNationalities}
                    onNationalityLoaded={onNationalityLoaded}
                    onAddPlatformMessage={onAddPlatformMessage}
                    onRequestSendGmail={onRequestSendGmail}
                    onShowToast={onShowToast}
                  />
                )}

                <div className="rounded-3xl border border-emerald-400/30 bg-[#0E1424] p-6 space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <h3 className="text-lg font-extrabold text-white">
                        المشاريع والتطبيقات والألعاب المصغرة
                      </h3>
                      <p className="text-xs text-slate-400">
                        {isProgrammerUnlocked
                          ? "اضغط «افتح اللعبة» أو «افتح التطبيق» للتشغيل، أو أنشئ مشروعاً جديداً من تبويب المبرمج."
                          : "اضغط على «افتح اللعبة» أو «افتح التطبيق» لتشغيل النسخ المصغرة مباشرة داخل الموقع!"}
                      </p>
                    </div>

                    {/* Creator button ONLY visible to developer/director/admin, hidden from regular users */}
                    {isProgrammerUnlocked && (
                      <button
                        type="button"
                        onClick={() => setActiveTab("programmer")}
                        className="inline-flex items-center gap-1.5 rounded-xl bg-emerald-600 px-4 py-2 text-xs font-extrabold text-white hover:bg-emerald-500 cursor-pointer"
                      >
                        <Plus className="h-4 w-4" />
                        <span>أنشئ تطبيقك المصغر أو لعبتك المصغرة</span>
                      </button>
                    )}
                  </div>

                  <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                  {publishedMiniApps.map((item) => (
                    <div
                      key={item.id}
                      className="rounded-2xl border border-white/10 bg-[#080C15] p-4 flex flex-col justify-between gap-3"
                    >
                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between gap-2">
                          <span
                            className={`rounded-md px-2 py-0.5 text-[10px] font-extrabold ${
                              item.kind === "game"
                                ? "bg-violet-500/20 text-violet-200 border border-violet-400/40"
                                : "bg-sky-500/20 text-sky-200 border border-sky-400/40"
                            }`}
                          >
                            {item.kind === "game" ? "لعبة مصغرة" : "تطبيق مصغر"} ·{" "}
                            {item.language.toUpperCase()}
                          </span>
                          <span className="text-[11px] text-slate-500">
                            {item.authorName}
                          </span>
                        </div>
                        <h4 className="text-base font-extrabold text-white">
                          {item.title}
                        </h4>
                        <p className="text-xs text-slate-300 leading-relaxed">
                          {item.description}
                        </p>
                      </div>

                      <div className="flex flex-wrap items-center gap-2 pt-1">
                        <button
                          type="button"
                          onClick={() => setRunningMiniProject(item)}
                          className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-emerald-600 py-2.5 px-3 text-xs font-extrabold text-white hover:bg-emerald-500 cursor-pointer"
                        >
                          <Play className="h-3.5 w-3.5" />
                          <span>
                            {item.kind === "game" ? "افتح اللعبة" : "افتح التطبيق"}
                          </span>
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            handleDownloadKrookZip({
                              title: item.title,
                              kind: item.kind,
                              is3D: item.is3D,
                              lang: item.language,
                              code: item.code,
                              author: item.authorName,
                            })
                          }
                          title="تنزيل ZIP يحتوي ملف .krok"
                          className="inline-flex items-center gap-1 rounded-xl border border-white/15 bg-white/5 py-2.5 px-3 text-xs font-bold text-slate-200 hover:bg-white/10 cursor-pointer"
                        >
                          <Download className="h-3.5 w-3.5" />
                          <span>.krok ZIP</span>
                        </button>
                      </div>
                    </div>
                  ))}
                  </div>
                </div>
              </div>
            )}

            {/* Tab 4: المبرمج IDE (Locked gray with "المفتاح هو أن تكون مطوراً أو مسؤولاً" for normal users) */}
            {activeTab === "programmer" && (
              <div className="rounded-3xl border border-white/15 bg-[#0D1322] p-6">
                {!isProgrammerUnlocked ? (
                  <div className="rounded-2xl border border-slate-600/40 bg-slate-800/40 p-8 text-center space-y-4">
                    <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl border border-slate-500/40 bg-slate-700/50 text-slate-300">
                      <Lock className="h-7 w-7" />
                    </div>
                    <h3 className="text-lg font-extrabold text-slate-200">
                      خيار «المبرمج» مغلق للمستخدم العادي
                    </h3>
                    <p className="text-sm font-bold text-amber-300">
                      المفتاح هو أن تكون مطوراً أو مسؤولاً
                    </p>
                    <p className="mx-auto max-w-md text-xs text-slate-400">
                      افتح إعدادات حسابك من صورتك الشخصية وأكمل مهام «فئة المطور»
                      لكسب شارة المطور وفتح بيئة البرمجة وتحكم البيانات الكاملة.
                    </p>
                    <button
                      type="button"
                      onClick={onOpenDeveloperCategory}
                      className="rounded-xl bg-slate-600 px-5 py-2.5 text-xs font-extrabold text-white hover:bg-slate-500 cursor-pointer"
                    >
                      الذهاب إلى فئة المطور
                    </button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <div>
                        <h3 className="text-lg font-extrabold text-white">
                          المبرمج IDE · بناء الألعاب والتطبيقات وتحكم البيانات
                        </h3>
                        <p className="text-xs text-slate-400">
                          يكتشف الأخطاء ويصلحها تلقائياً — ويشترط وجود{" "}
                          <code
                            dir="ltr"
                            className="rounded bg-emerald-500/15 px-1.5 py-0.5 text-emerald-300 font-bold"
                          >
                            {REQUIRED_CODE_SEAL}
                          </code>{" "}
                          في نهاية الكود للتشغيل والحفظ.
                        </p>
                      </div>

                      <div className="flex flex-wrap items-center gap-2">
                        <button
                          type="button"
                          onClick={() => setIdeIs3D(!ideIs3D)}
                          className={`rounded-xl border px-3 py-1.5 text-xs font-extrabold cursor-pointer ${
                            ideIs3D
                              ? "border-violet-400 bg-violet-600/25 text-violet-200"
                              : "border-white/15 bg-white/5 text-slate-300"
                          }`}
                        >
                          النمط: {ideIs3D ? "ثلاثي الأبعاد 3D" : "ثنائي الأبعاد 2D"}
                        </button>
                        <button
                          type="button"
                          onClick={() => setIdeKind(ideKind === "game" ? "app" : "game")}
                          className="rounded-xl border border-sky-400/40 bg-sky-500/15 px-3 py-1.5 text-xs font-extrabold text-sky-200 cursor-pointer"
                        >
                          النوع: {ideKind === "game" ? "لعبة" : "تطبيق"}
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                      <input
                        type="text"
                        value={ideTitle}
                        onChange={(e) => setIdeTitle(e.target.value)}
                        placeholder="اسم التطبيق أو اللعبة"
                        className="h-10 rounded-xl border border-white/15 bg-[#080C15] px-3 text-xs text-white"
                      />
                      <input
                        type="text"
                        value={ideDesc}
                        onChange={(e) => setIdeDesc(e.target.value)}
                        placeholder="وصف مختصر للمشروع"
                        className="h-10 rounded-xl border border-white/15 bg-[#080C15] px-3 text-xs text-white"
                      />
                      <select
                        value={ideLang}
                        onChange={(e) => {
                          const next = e.target.value as ProgrammingLanguageId;
                          setIdeLang(next);
                          onChangeProgLang(next);
                          const found = BETA_PROGRAMMING_LANGUAGES.find(
                            (l) => l.id === next
                          );
                          if (found) setIdeCode(found.sampleCode);
                        }}
                        className="h-10 rounded-xl border border-white/15 bg-[#080C15] px-3 text-xs text-emerald-300 font-bold"
                      >
                        {BETA_PROGRAMMING_LANGUAGES.map((l) => (
                          <option key={l.id} value={l.id}>
                            لغة: {l.name} (.{l.extension})
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Code Editor Area */}
                    <div className="overflow-hidden rounded-2xl border border-white/15 bg-[#050811]">
                      <div className="flex items-center justify-between border-b border-white/10 bg-[#0A1020] px-4 py-2 text-xs">
                        <span className="font-mono text-emerald-300">
                          main.{currentLangMeta.extension}
                        </span>
                        <button
                          type="button"
                          onClick={() => {
                            const fixed = autoFixSourceCode(ideCode, ideLang);
                            setIdeCode(fixed);
                            onShowToast("تم فحص وتصحيح صياغة الكود تلقائياً.");
                          }}
                          className="inline-flex items-center gap-1 rounded-lg bg-violet-600/30 border border-violet-400/40 px-2.5 py-1 text-[11px] font-bold text-violet-200 hover:bg-violet-600/50 cursor-pointer"
                        >
                          <Wand2 className="h-3 w-3" />
                          <span>تصحيح تلقائي</span>
                        </button>
                      </div>

                      <textarea
                        rows={8}
                        dir="ltr"
                        value={ideCode}
                        onChange={(e) => {
                          setIdeCode(e.target.value);
                          setIdeSealError(false);
                        }}
                        className="w-full bg-transparent p-4 font-mono text-xs text-slate-100 focus:outline-none"
                      />

                      {/* ERROR & QUICK-FIX BUTTON STRICTLY AT THE END OF THE CODE */}
                      {ideSealError && (
                        <div className="border-t border-rose-500/40 bg-rose-950/50 p-3 flex flex-wrap items-center justify-between gap-2">
                          <div className="flex items-center gap-2 text-xs font-bold text-rose-200">
                            <AlertTriangle className="h-4 w-4 text-rose-400 shrink-0" />
                            <span>
                              خطأ في نهاية الكود: مفقود «
                              <code dir="ltr" className="font-mono text-amber-300">
                                {REQUIRED_CODE_SEAL}
                              </code>
                              » (مع مسافتين)
                            </span>
                          </div>
                          <button
                            type="button"
                            onClick={handleQuickFixEndSealAndRun}
                            className="inline-flex items-center gap-1.5 rounded-xl bg-emerald-600 px-3.5 py-2 text-xs font-extrabold text-white hover:bg-emerald-500 cursor-pointer"
                          >
                            <Sparkles className="h-3.5 w-3.5" />
                            <span>
                              إصلاح سريع: أضف «{REQUIRED_CODE_SEAL}» آخر الكود وشغّل
                            </span>
                          </button>
                        </div>
                      )}
                    </div>

                    {/* Bottom Action Bar */}
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <div className="rounded-xl border border-white/10 bg-[#050811] px-3.5 py-2 text-xs font-mono text-emerald-300 flex-1 min-w-[220px]">
                        {ideConsole}
                      </div>

                      <div className="flex flex-wrap items-center gap-2">
                        <button
                          type="button"
                          onClick={() => executeIdeCode(ideCode)}
                          className="inline-flex items-center gap-1.5 rounded-xl bg-emerald-600 px-4 py-2.5 text-xs font-extrabold text-white hover:bg-emerald-500 cursor-pointer"
                        >
                          <Play className="h-4 w-4" />
                          <span>تشغيل اللعبة / التطبيق</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => setSavePromptOpen(true)}
                          className="inline-flex items-center gap-1.5 rounded-xl bg-violet-600 px-4 py-2.5 text-xs font-extrabold text-white hover:bg-violet-500 cursor-pointer"
                        >
                          <Save className="h-4 w-4" />
                          <span>حفظ وتصدير</span>
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Tab 5: Plus Settings & Language Switcher + Fantasy World + Secret Messages */}
            {activeTab === "plus" && (
              <div className="rounded-3xl border border-violet-400/35 bg-[#0E1424] p-6 space-y-6">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <h3 className="text-lg font-extrabold text-white">
                      إعدادات بلس (Plus Settings)
                    </h3>
                    <p className="text-xs text-slate-400">
                      بدّل لغة البرمجة الافتراضية للمنصة (بدون تغيير العربية في الواجهة)، أو افتح المبرمج وعالم الخيال والرسائل السرية.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => onToggleFantasyMode(!fantasyMode)}
                    className="inline-flex items-center gap-2 rounded-xl border border-pink-400/50 bg-pink-500/20 px-4 py-2 text-xs font-extrabold text-pink-200 hover:bg-pink-500/30 cursor-pointer"
                  >
                    <Sparkles className="h-4 w-4" />
                    <span>
                      {fantasyMode
                        ? "مغادرة عالم الخيال"
                        : "الانضمام إلى عالم الخيال ☁️🍬"}
                    </span>
                  </button>
                </div>

                {/* Change Programming Language of the Site */}
                <div className="space-y-3">
                  <p className="text-xs font-extrabold text-emerald-300">
                    اختر لغة البرمجة للموقع والبيئة التجريبية:
                  </p>
                  <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3 lg:grid-cols-6">
                    {BETA_PROGRAMMING_LANGUAGES.map((lang) => {
                      const active = activeProgLang === lang.id;
                      return (
                        <button
                          key={lang.id}
                          type="button"
                          onClick={() => {
                            onChangeProgLang(lang.id);
                            setIdeCode(lang.sampleCode);
                            onShowToast(
                              `تم تحويل لغة البرمجة الافتراضية للموقع إلى ${lang.name}`
                            );
                          }}
                          className={`rounded-2xl border p-3 text-right transition-all cursor-pointer ${
                            active
                              ? "border-emerald-400 bg-emerald-500/20 text-white shadow-lg"
                              : "border-white/10 bg-[#080C15] text-slate-300 hover:border-white/25"
                          }`}
                        >
                          <div className="font-mono text-xs font-extrabold text-emerald-300">
                            {lang.name}
                          </div>
                          <div className="mt-1 text-[10px] text-slate-400 leading-snug">
                            {lang.tagline}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Secret Messages & Quick Programmer Jump */}
                <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                  <div className="rounded-2xl border border-amber-400/35 bg-[#15120A] p-4 space-y-2">
                    <div className="flex items-center gap-2 text-xs font-extrabold text-amber-300">
                      <Cpu className="h-4 w-4" />
                      <span>رسائل بلس السرية للمطورين</span>
                    </div>
                    <p className="text-xs leading-relaxed text-amber-100/90">
                      رسالة سرية #1329: كل مشروع تحفظه بصيغة <code dir="ltr">.krok</code>{" "}
                      داخل ملف ZIP يمكن استيراده مباشرة إلى برامج إنشاء الألعاب وتطبيقات
                      أندرويد، وتذكر دائماً ختم <code dir="ltr">Iraqi Coders  1329</code> في نهاية الكود!
                    </p>
                  </div>

                  <div className="rounded-2xl border border-white/10 bg-[#080C15] p-4 flex flex-col justify-between gap-3">
                    <div>
                      <p className="text-xs font-extrabold text-white">
                        اختصار خيار «المبرمج» وتحكم البيانات
                      </p>
                      <p className="text-[11px] text-slate-400 mt-1">
                        {isProgrammerUnlocked
                          ? "صلاحيتك مفتوحة! ادخل محرر الألعاب والتطبيقات والتصدير."
                          : "مقفل للمستخدم العادي — المفتاح هو أن تكون مطوراً أو مسؤولاً."}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setActiveTab("programmer")}
                      className={`inline-flex items-center justify-center gap-2 rounded-xl py-2.5 text-xs font-extrabold cursor-pointer ${
                        isProgrammerUnlocked
                          ? "bg-emerald-600 text-white hover:bg-emerald-500"
                          : "bg-slate-700 text-slate-300"
                      }`}
                    >
                      {isProgrammerUnlocked ? (
                        <>
                          <Code2 className="h-4 w-4" />
                          <span>فتح «المبرمج» الآن</span>
                        </>
                      ) : (
                        <>
                          <Lock className="h-4 w-4" />
                          <span>المبرمج (مقفل)</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Save Choice Prompt Modal: Convert to In-Site Mini App vs Download .krok ZIP */}
      {savePromptOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="خيارات حفظ المشروع"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm"
          onClick={() => setSavePromptOpen(false)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-md rounded-3xl border border-violet-400/45 bg-[#0E1424] p-6 shadow-2xl space-y-4"
          >
            <div className="flex items-center justify-between">
              <h3 className="text-base font-extrabold text-white">
                كيف تريد حفظ «{ideTitle}»؟
              </h3>
              <button
                type="button"
                onClick={() => setSavePromptOpen(false)}
                className="rounded-lg p-1 text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              اختر تحويل المشروع إلى نسخة مصغرة يلعبها ويستخدمها الجميع داخل الموقع،
              أو تنزيله كملف مضغوط ZIP يحتوي ملف كروك <code dir="ltr">.krok</code>.
            </p>

            <div className="space-y-2.5">
              <button
                type="button"
                onClick={handlePublishAsMiniInsideSite}
                className="flex w-full items-center justify-between rounded-2xl border border-emerald-400/50 bg-emerald-600/20 p-4 text-right text-xs font-extrabold text-emerald-200 hover:bg-emerald-600/30 cursor-pointer"
              >
                <div>
                  <p>1. تحويل إلى نسخة مصغرة داخل الموقع</p>
                  <p className="text-[11px] font-normal text-slate-300 mt-0.5">
                    يظهر للمستخدمين العاديين مع زر «افتح اللعبة» أو «افتح التطبيق»
                  </p>
                </div>
                <CheckCircle2 className="h-5 w-5 shrink-0" />
              </button>

              <button
                type="button"
                onClick={() => {
                  handleDownloadKrookZip();
                  setSavePromptOpen(false);
                }}
                className="flex w-full items-center justify-between rounded-2xl border border-sky-400/50 bg-sky-600/20 p-4 text-right text-xs font-extrabold text-sky-200 hover:bg-sky-600/30 cursor-pointer"
              >
                <div>
                  <p>2. تنزيل ملف مضغوط ZIP يحتوي ملف كروك (.krok)</p>
                  <p className="text-[11px] font-normal text-slate-300 mt-0.5">
                    جاهز لبرامج صنع الألعاب والتطبيقات على الهاتف والكمبيوتر
                  </p>
                </div>
                <Archive className="h-5 w-5 shrink-0" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Interactive Runner Modal when clicking "افتح اللعبة" / "افتح التطبيق" */}
      {runningMiniProject && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={runningMiniProject.title}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm"
          onClick={() => setRunningMiniProject(null)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-2xl rounded-3xl border border-emerald-400/45 bg-[#0D1424] p-6 shadow-2xl space-y-4"
          >
            <div className="flex items-center justify-between gap-3">
              <div>
                <span className="text-[11px] font-bold text-emerald-300">
                  {runningMiniProject.kind === "game"
                    ? "تشغيل اللعبة المصغرة"
                    : "تشغيل التطبيق المصغر"}{" "}
                  · {runningMiniProject.language.toUpperCase()}
                </span>
                <h3 className="text-lg font-extrabold text-white">
                  {runningMiniProject.title}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setRunningMiniProject(null)}
                className="rounded-lg p-1.5 text-slate-400 hover:bg-white/10 hover:text-white cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {runningMiniProject.kind === "game" ? (
              <PubgMiniBattleGame />
            ) : (
              <div className="rounded-2xl border border-sky-400/35 bg-[#080C15] p-5 space-y-3">
                <p className="text-sm font-bold text-white">
                  {runningMiniProject.description}
                </p>
                <pre
                  dir="ltr"
                  className="overflow-x-auto rounded-xl border border-white/10 bg-[#04070E] p-3 font-mono text-xs text-emerald-300"
                >
                  {runningMiniProject.code}
                </pre>
                <div className="rounded-xl border border-emerald-400/35 bg-emerald-500/10 p-3 text-xs font-bold text-emerald-200">
                  التطبيق يعمل بنجاح ✓ · المؤلف: {runningMiniProject.authorName}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </section>
  );
};
