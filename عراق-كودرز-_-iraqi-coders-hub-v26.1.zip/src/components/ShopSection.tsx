import React, { useMemo, useState } from "react";
import {
  CheckCircle2,
  Coins,
  Copy,
  ExternalLink,
  ImageIcon,
  Minus,
  PackagePlus,
  Plus,
  Receipt,
  Search,
  ShieldCheck,
  ShoppingBag,
  ShoppingCart,
  Tag,
  Trash2,
  X,
} from "lucide-react";
import {
  canPublishShopProduct,
  COMMUNITY_CHANNELS,
  formatIqdPrice,
  formatUsdPrice,
  REQUIRED_INVOICE_SIGNATURE,
  SECRET_FULL_DISCOUNT_CODE,
  SHOP_PRODUCTS,
  SHOP_PUBLISH_SETTINGS,
  SHOP_SETTINGS,
  WHATSAPP_OWNER_PHONE,
  WHATSAPP_OWNER_URL,
} from "../data/siteConfig";
import {
  OrderContactChannel,
  ShopAvailability,
  ShopCartItem,
  ShopCategoryId,
  ShopOrderRecord,
  ShopProduct,
  UserProfile,
  UserRole,
} from "../types";
import { SocialBrandIcon } from "./CommunityLinksSection";

interface ShopSectionProps {
  user: UserProfile | null;
  userRole: UserRole;
  customProducts: ShopProduct[];
  cart: ShopCartItem[];
  orders: ShopOrderRecord[];
  isCartOpen: boolean;
  onSetCartOpen: (open: boolean) => void;
  onAddToCart: (product: ShopProduct, openDrawer?: boolean) => void;
  onUpdateQuantity: (productId: string, delta: number) => void;
  onRemoveFromCart: (productId: string) => void;
  onClearCart: () => void;
  onSubmitOrder: (order: ShopOrderRecord) => void;
  onPublishProduct: (product: ShopProduct) => void;
  onDeleteCustomProduct?: (productId: string) => void;
  onOpenCurrencyStore: () => void;
  onShowToast: (msg: string) => void;
}

type SortMode = "default" | "price-asc" | "offers";
type DrawerTab = "cart" | "orders" | "publish";

const PUBLISH_CATEGORY_LABELS: Record<
  Exclude<ShopCategoryId, "all">,
  string
> = {
  web: "مواقع وتطبيقات",
  games: "ألعاب ومودات",
  services: "خدمات برمجية",
  tools: "أدوات مطورين",
};

const AVAILABILITY_LABELS: Record<ShopAvailability, string> = {
  available: "متوفر الآن",
  special_offer: "عرض خاص",
  limited: "كمية / حجز محدود",
  out_of_stock: "غير متوفر",
};

export const ShopSection: React.FC<ShopSectionProps> = ({
  user,
  userRole,
  customProducts,
  cart,
  orders,
  isCartOpen,
  onSetCartOpen,
  onAddToCart,
  onUpdateQuantity,
  onRemoveFromCart,
  onClearCart,
  onSubmitOrder,
  onPublishProduct,
  onDeleteCustomProduct,
  onOpenCurrencyStore,
  onShowToast,
}) => {
  const [selectedCategory, setSelectedCategory] =
    useState<ShopCategoryId>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [sortMode, setSortMode] = useState<SortMode>("default");
  const [drawerTab, setDrawerTab] = useState<DrawerTab>("cart");

  // Promo & Checkout Form State
  const [promoInput, setPromoInput] = useState("");
  const [appliedPromoCode, setAppliedPromoCode] = useState<string>("");
  const [draftInvoiceId, setDraftInvoiceId] = useState<string>("");
  const [signedInvoiceInput, setSignedInvoiceInput] = useState<string>("");
  const [signedInvoiceError, setSignedInvoiceError] = useState<string>("");
  const [customerName, setCustomerName] = useState(user?.name || "");
  const [contactChannel, setContactChannel] =
    useState<OrderContactChannel>("whatsapp");
  const [contactValue, setContactValue] = useState(
    user?.email || user?.handle || ""
  );
  const [orderNotes, setOrderNotes] = useState("");
  const [confirmedOrder, setConfirmedOrder] = useState<ShopOrderRecord | null>(
    null
  );

  // Publish Custom Product Form State (Privileged Roles Only)
  const [pubTitle, setPubTitle] = useState("");
  const [pubDescription, setPubDescription] = useState("");
  const [pubPriceUsd, setPubPriceUsd] = useState("15");
  const [pubPriceIqd, setPubPriceIqd] = useState(
    String(15 * SHOP_SETTINGS.iqdPerUsd)
  );
  const [pubCategory, setPubCategory] =
    useState<Exclude<ShopCategoryId, "all">>("tools");
  const [pubAvailability, setPubAvailability] =
    useState<ShopAvailability>("available");
  const [pubDeliveryTime, setPubDeliveryTime] = useState<string>(
    SHOP_PUBLISH_SETTINGS.defaultDeliveryTime
  );
  const [pubImageUrl, setPubImageUrl] = useState("");
  const [pubExternalUrl, setPubExternalUrl] = useState("");
  const [pubFeaturesText, setPubFeaturesText] = useState("");
  const [publishedConfirmationTitle, setPublishedConfirmationTitle] =
    useState("");

  // Strict Role Guard (Developer / Moderator / Admin only)
  const canPublish = canPublishShopProduct(userRole);
  const effectiveDrawerTab: DrawerTab =
    drawerTab === "publish" && !canPublish ? "cart" : drawerTab;

  const handleSelectDrawerTab = (nextTab: DrawerTab) => {
    if (nextTab === "publish" && !canPublish) {
      onShowToast(
        "ميزة «انشر منتجك الخاص» متاحة للمطورين والمشرفين والمسؤولين فقط."
      );
      setDrawerTab("cart");
      return;
    }
    setDrawerTab(nextTab);
  };

  const allProducts = useMemo(
    () => [...customProducts, ...SHOP_PRODUCTS],
    [customProducts]
  );

  const handleUsdPriceInput = (raw: string) => {
    setPubPriceUsd(raw);
    const parsed = Number(raw);
    if (!raw.trim() || Number.isNaN(parsed) || parsed < 0) {
      setPubPriceIqd("");
      return;
    }
    setPubPriceIqd(String(Math.round(parsed * SHOP_SETTINGS.iqdPerUsd)));
  };

  const handleIqdPriceInput = (raw: string) => {
    setPubPriceIqd(raw);
    const parsed = Number(raw);
    if (!raw.trim() || Number.isNaN(parsed) || parsed < 0) {
      setPubPriceUsd("");
      return;
    }
    const converted = Number((parsed / SHOP_SETTINGS.iqdPerUsd).toFixed(2));
    setPubPriceUsd(String(converted));
  };

  const handlePublishSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!canPublish) {
      onShowToast("غير مصرح لك بنشر المنتجات في المتجر.");
      setDrawerTab("cart");
      return;
    }

    const cleanTitle = pubTitle.trim();
    const cleanDescription = pubDescription.trim();
    const usdFromInput = Number(pubPriceUsd);
    const iqdFromInput = Number(pubPriceIqd);
    const resolvedUsd =
      !Number.isNaN(usdFromInput) && usdFromInput > 0
        ? Number(usdFromInput.toFixed(2))
        : !Number.isNaN(iqdFromInput) && iqdFromInput > 0
        ? Number((iqdFromInput / SHOP_SETTINGS.iqdPerUsd).toFixed(2))
        : 0;

    if (!cleanTitle || !cleanDescription) {
      onShowToast("يرجى كتابة اسم المنتج والوصف قبل النشر.");
      return;
    }

    if (resolvedUsd <= 0) {
      onShowToast("يرجى إدخال سعر صالح بالدولار أو الدينار العراقي.");
      return;
    }

    const safeHttpUrl = (val: string): string | undefined => {
      const trimmed = val.trim();
      if (!trimmed) return undefined;
      return /^https?:\/\//i.test(trimmed) ? trimmed : undefined;
    };

    const parsedFeatures = pubFeaturesText
      .split(/\n|،|,/)
      .map((item) => item.trim())
      .filter(Boolean)
      .slice(0, 5);

    const accentByCategory: Record<
      Exclude<ShopCategoryId, "all">,
      ShopProduct["accentColor"]
    > = {
      web: "emerald",
      games: "violet",
      services: "sky",
      tools: "amber",
    };

    const newProduct: ShopProduct = {
      id: `prod-custom-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      title: cleanTitle,
      category: pubCategory,
      categoryLabel: PUBLISH_CATEGORY_LABELS[pubCategory],
      description: cleanDescription,
      features:
        parsedFeatures.length > 0
          ? parsedFeatures
          : [
              `منشور بواسطة ${user?.name || SHOP_PUBLISH_SETTINGS.roleLabels[userRole]}`,
              "مضاف مباشرة إلى متجر عراقي كودرز",
            ],
      priceUsd: resolvedUsd,
      availability: pubAvailability,
      availabilityLabel: AVAILABILITY_LABELS[pubAvailability],
      deliveryTime:
        pubDeliveryTime.trim() || SHOP_PUBLISH_SETTINGS.defaultDeliveryTime,
      accentColor: accentByCategory[pubCategory],
      imageUrl: safeHttpUrl(pubImageUrl),
      externalUrl: safeHttpUrl(pubExternalUrl),
      publishedBy: user?.handle || user?.name || SHOP_PUBLISH_SETTINGS.roleLabels[userRole],
      publishedByRole: userRole,
      isCustomPublished: true,
      createdAt: new Date().toISOString(),
    };

    onPublishProduct(newProduct);
    setPublishedConfirmationTitle(newProduct.title);
    setPubTitle("");
    setPubDescription("");
    setPubImageUrl("");
    setPubExternalUrl("");
    setPubFeaturesText("");
  };

  // Filter & Sort Products
  const filteredProducts = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    const list = allProducts.filter((p) => {
      const catMatch =
        selectedCategory === "all" || p.category === selectedCategory;
      const queryMatch =
        !q ||
        p.title.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.categoryLabel.toLowerCase().includes(q) ||
        (p.publishedBy || "").toLowerCase().includes(q);
      return catMatch && queryMatch;
    });

    if (sortMode === "price-asc") {
      return [...list].sort((a, b) => a.priceUsd - b.priceUsd);
    }
    if (sortMode === "offers") {
      return [...list].sort((a, b) => {
        const aOffer = a.availability === "special_offer" ? 0 : 1;
        const bOffer = b.availability === "special_offer" ? 0 : 1;
        return aOffer - bOffer;
      });
    }
    return list;
  }, [allProducts, selectedCategory, searchQuery, sortMode]);

  // Cart Calculations (Exact Arithmetic)
  const cartSummary = useMemo(() => {
    const detailedItems = cart
      .map((item) => {
        const product = allProducts.find((p) => p.id === item.productId);
        if (!product) return null;
        const lineTotalUsd = Number((product.priceUsd * item.quantity).toFixed(2));
        const originalLineUsd = product.originalPriceUsd
          ? Number((product.originalPriceUsd * item.quantity).toFixed(2))
          : lineTotalUsd;
        const lineSavingsUsd = Math.max(
          0,
          Number((originalLineUsd - lineTotalUsd).toFixed(2))
        );
        return {
          product,
          quantity: item.quantity,
          lineTotalUsd,
          lineSavingsUsd,
        };
      })
      .filter(Boolean) as {
      product: ShopProduct;
      quantity: number;
      lineTotalUsd: number;
      lineSavingsUsd: number;
    }[];

    const totalItemsCount = detailedItems.reduce(
      (sum, entry) => sum + entry.quantity,
      0
    );
    const subtotalUsd = Number(
      detailedItems.reduce((sum, entry) => sum + entry.lineTotalUsd, 0).toFixed(2)
    );
    const offerSavingsUsd = Number(
      detailedItems
        .reduce((sum, entry) => sum + entry.lineSavingsUsd, 0)
        .toFixed(2)
    );

    const isSecretFullDiscount =
      appliedPromoCode.trim().replace(/\s+/g, " ") ===
      SECRET_FULL_DISCOUNT_CODE;

    const matchedPromo = isSecretFullDiscount
      ? undefined
      : SHOP_SETTINGS.promoCodes.find(
          (p) => p.code.toUpperCase() === appliedPromoCode.toUpperCase()
        );
    const promoDiscountUsd = isSecretFullDiscount
      ? subtotalUsd
      : matchedPromo
      ? Number(((subtotalUsd * matchedPromo.discountPercent) / 100).toFixed(2))
      : 0;

    const finalTotalUsd = isSecretFullDiscount
      ? 0
      : Math.max(0, Number((subtotalUsd - promoDiscountUsd).toFixed(2)));
    const finalTotalIqd = isSecretFullDiscount
      ? 0
      : Math.round(finalTotalUsd * SHOP_SETTINGS.iqdPerUsd);

    return {
      detailedItems,
      totalItemsCount,
      subtotalUsd,
      offerSavingsUsd,
      isSecretFullDiscount,
      matchedPromo,
      promoDiscountUsd,
      finalTotalUsd,
      finalTotalIqd,
    };
  }, [allProducts, cart, appliedPromoCode]);

  const generatedUnsignedInvoice = useMemo(() => {
    if (!cartSummary.isSecretFullDiscount || cartSummary.detailedItems.length === 0) {
      return "";
    }
    const invoiceNo = draftInvoiceId || "ICH-202600";
    const buyer = (customerName || user?.name || "عميل متجر عراقي كودرز").trim();
    const lines = [
      "=== فاتورة طلب · متجر عراقي كودرز ===",
      `رقم الفاتورة: ${invoiceNo}`,
      `العميل: ${buyer}`,
      `كود الخصم المطبق: ${SECRET_FULL_DISCOUNT_CODE}`,
      "العناصر المطلوبة:",
      ...cartSummary.detailedItems.map(
        (entry) =>
          `- ${entry.product.title} × ${entry.quantity} (السعر الأصلي: ${formatUsdPrice(
            entry.lineTotalUsd
          )})`
      ),
      "الإجمالي المستحق بعد الخصم: $0 (0 د.ع)",
      `للتوقيع والاعتماد عبر واتساب: ${WHATSAPP_OWNER_PHONE}`,
    ];
    return lines.join("\n");
  }, [
    cartSummary.isSecretFullDiscount,
    cartSummary.detailedItems,
    draftInvoiceId,
    customerName,
    user?.name,
  ]);

  const handleApplyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    const normalized = promoInput.trim().replace(/\s+/g, " ");
    if (!normalized) return;

    if (normalized === SECRET_FULL_DISCOUNT_CODE) {
      setAppliedPromoCode(SECRET_FULL_DISCOUNT_CODE);
      setDraftInvoiceId(`ICH-${String(Date.now()).slice(-6)}`);
      setSignedInvoiceInput("");
      setSignedInvoiceError("");
      onShowToast(
        "تم تفعيل الخصم الكامل ($0)! انسخ الفاتورة وأرسلها إلى واتساب المتجر لتوقيعها."
      );
      return;
    }

    const cleanUpper = normalized.toUpperCase();
    const found = SHOP_SETTINGS.promoCodes.find((p) => p.code === cleanUpper);
    if (!found) {
      onShowToast("كود الخصم غير صحيح.");
      return;
    }
    setAppliedPromoCode(found.code);
    setSignedInvoiceInput("");
    setSignedInvoiceError("");
    onShowToast(`تم تفعيل ${found.label} (${found.code}) بنجاح!`);
  };

  const handleCopyUnsignedInvoice = async () => {
    if (!generatedUnsignedInvoice) return;
    try {
      await navigator.clipboard.writeText(generatedUnsignedInvoice);
      onShowToast(
        "تم نسخ الفاتورة! أرسلها الآن إلى واتساب المتجر (+9647762110049) للحصول على التوقيع."
      );
    } catch {
      onShowToast("حدد نص الفاتورة أعلاه وانسخه لإرساله إلى الواتساب.");
    }
  };

  const handleCompleteOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (cartSummary.detailedItems.length === 0) {
      onShowToast("سلة الشراء فارغة. أضف منتجاً أو خدمة أولاً.");
      return;
    }

    let verifiedSignedText: string | undefined;
    if (cartSummary.isSecretFullDiscount) {
      const trimmedEnd = signedInvoiceInput.trimEnd();
      if (!trimmedEnd.trim()) {
        const msg =
          "يرجى لصق «الفاتورة مع التوقيع» بعد إرسالها إلى واتساب صاحب المتجر (+9647762110049) واستلامها موقّعة.";
        setSignedInvoiceError(msg);
        onShowToast(msg);
        return;
      }
      const bodyBeforeSig = trimmedEnd.endsWith(REQUIRED_INVOICE_SIGNATURE)
        ? trimmedEnd
            .slice(0, trimmedEnd.length - REQUIRED_INVOICE_SIGNATURE.length)
            .trim()
        : "";
      if (
        !trimmedEnd.endsWith(REQUIRED_INVOICE_SIGNATURE) ||
        bodyBeforeSig.length === 0
      ) {
        const msg =
          "تم رفض الفاتورة: هذه الفاتورة غير موقّعة وتحتاج إلى التوقيع المعتمد من صاحب المتجر في نهايتها عبر واتساب (+9647762110049).";
        setSignedInvoiceError(msg);
        onShowToast("الفاتورة مرفوضة — تحتاج التوقيع المعتمد في نهايتها.");
        return;
      }
      setSignedInvoiceError("");
      verifiedSignedText = trimmedEnd;
    }

    const cleanName = (customerName || user?.name || "").trim();
    const cleanContact = (
      contactValue ||
      user?.email ||
      (cartSummary.isSecretFullDiscount ? WHATSAPP_OWNER_PHONE : "")
    ).trim();
    if (!cleanName || !cleanContact) {
      onShowToast("يرجى كتابة الاسم الكامل وبيانات التواصل لتأكيد الطلب.");
      return;
    }

    const orderRecord: ShopOrderRecord = {
      id:
        cartSummary.isSecretFullDiscount && draftInvoiceId
          ? draftInvoiceId
          : `ICH-${String(Date.now()).slice(-6)}`,
      customerName: cleanName,
      contactChannel,
      contactValue: cleanContact,
      notes: orderNotes.trim(),
      items: cartSummary.detailedItems.map((entry) => ({
        productId: entry.product.id,
        title: entry.product.title,
        unitPriceUsd: entry.product.priceUsd,
        quantity: entry.quantity,
        lineTotalUsd: entry.lineTotalUsd,
      })),
      subtotalUsd: cartSummary.subtotalUsd,
      savingsUsd: cartSummary.offerSavingsUsd,
      promoCode: cartSummary.isSecretFullDiscount
        ? SECRET_FULL_DISCOUNT_CODE
        : cartSummary.matchedPromo?.code,
      promoDiscountUsd: cartSummary.promoDiscountUsd,
      totalUsd: cartSummary.finalTotalUsd,
      totalIqd: cartSummary.finalTotalIqd,
      signedInvoiceVerified: Boolean(verifiedSignedText),
      signedInvoiceText: verifiedSignedText,
      createdAt: new Date().toLocaleString("ar-IQ"),
    };

    onSubmitOrder(orderRecord);
    setConfirmedOrder(orderRecord);
    setOrderNotes("");
    setAppliedPromoCode("");
    setPromoInput("");
    setDraftInvoiceId("");
    setSignedInvoiceInput("");
    setSignedInvoiceError("");
    onClearCart();
  };

  const handleCopyReceipt = async (order: ShopOrderRecord) => {
    const lines = [
      `طلب جديد من متجر عراقي كودرز (${order.id})`,
      `العميل: ${order.customerName}`,
      `التواصل (${order.contactChannel}): ${order.contactValue}`,
      `العناصر:`,
      ...order.items.map(
        (it) => `- ${it.title} × ${it.quantity} = ${formatUsdPrice(it.lineTotalUsd)}`
      ),
      `الإجمالي النهائي: ${formatUsdPrice(order.totalUsd)} (${order.totalIqd.toLocaleString("en-US")} د.ع)`,
      order.notes ? `ملاحظات: ${order.notes}` : "",
    ]
      .filter(Boolean)
      .join("\n");

    try {
      await navigator.clipboard.writeText(lines);
      onShowToast("تم نسخ تفاصيل الطلب والفاتورة بنجاح!");
    } catch {
      onShowToast("تم تجهيز الفاتورة أعلاه يمكنك مشاركتها مباشرة.");
    }
  };

  return (
    <section
      id={SHOP_SETTINGS.sectionId}
      className="scroll-mt-24 border-b border-white/10 py-14 lg:py-20"
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section Header + Cart & Coins Store Controls */}
        <div className="mb-8 flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <div className="mb-2 flex items-center gap-2 text-xs font-bold text-emerald-400">
              <ShoppingBag className="h-4 w-4" />
              <span>نظام البيع والشراء المباشر · تسليم سريع</span>
            </div>
            <h2
              className="text-2xl font-extrabold text-white sm:text-3xl"
              style={{ textWrap: "balance" }}
            >
              {SHOP_SETTINGS.title}
            </h2>
            <p className="mt-2 max-w-2xl text-sm leading-relaxed text-slate-400">
              {SHOP_SETTINGS.subtitle}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={onOpenCurrencyStore}
              className="inline-flex items-center gap-2 rounded-xl border border-amber-400/35 bg-amber-500/10 px-4 py-2.5 text-xs font-bold text-amber-200 transition-colors hover:bg-amber-500/20 whitespace-nowrap cursor-pointer"
            >
              <Coins className="h-4 w-4 text-amber-400" />
              <span>متجر العملات والسكنات</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setConfirmedOrder(null);
                setDrawerTab("cart");
                onSetCartOpen(true);
              }}
              className="inline-flex items-center gap-2.5 rounded-xl bg-emerald-600 px-5 py-2.5 text-xs font-extrabold text-white shadow-lg transition-colors hover:bg-emerald-500 whitespace-nowrap cursor-pointer"
            >
              <ShoppingCart className="h-4 w-4" />
              <span>سلة المشتريات</span>
              <span className="rounded-md bg-black/25 px-2 py-0.5 font-mono tabular-nums">
                {cartSummary.totalItemsCount} · {formatUsdPrice(cartSummary.finalTotalUsd)}
              </span>
            </button>
          </div>
        </div>

        {/* Category Filter Tabs + Search + Sort */}
        <div className="mb-7 flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
          <div
            role="tablist"
            aria-label="تصنيفات المتجر"
            className="flex flex-wrap items-center gap-1.5 rounded-xl border border-white/10 bg-[#0E1424] p-1"
          >
            {SHOP_SETTINGS.categories.map((cat) => {
              const active = selectedCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  type="button"
                  role="tab"
                  aria-selected={active}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`rounded-lg px-3.5 py-2 text-xs font-bold transition-colors whitespace-nowrap cursor-pointer ${
                    active
                      ? "bg-violet-600 text-white"
                      : "text-slate-300 hover:bg-white/5 hover:text-white"
                  }`}
                >
                  {cat.label}
                </button>
              );
            })}
          </div>

          <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
            <div className="relative flex-1 sm:w-64">
              <Search className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <input
                type="search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="ابحث عن منتج أو خدمة..."
                className="h-10 w-full rounded-xl border border-white/10 bg-[#0E1424] pr-9 pl-3 text-xs text-white placeholder:text-slate-500 focus:border-emerald-400 focus:outline-none"
              />
            </div>

            <select
              aria-label="ترتيب المنتجات"
              value={sortMode}
              onChange={(e) => setSortMode(e.target.value as SortMode)}
              className="h-10 rounded-xl border border-white/10 bg-[#0E1424] px-3 text-xs font-bold text-slate-200 focus:border-emerald-400 focus:outline-none"
            >
              <option value="default">الترتيب الافتراضي</option>
              <option value="offers">العروض الخاصة أولاً</option>
              <option value="price-asc">الأقل سعراً أولاً</option>
            </select>
          </div>
        </div>

        {/* Product & Services Catalog Grid */}
        {filteredProducts.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-white/15 bg-[#0E1424] p-10 text-center">
            <p className="text-sm font-bold text-slate-300">
              لا توجد منتجات مطابقة لبحثك «{searchQuery}».
            </p>
            <button
              type="button"
              onClick={() => {
                setSearchQuery("");
                setSelectedCategory("all");
              }}
              className="mt-3 rounded-lg border border-white/15 bg-white/5 px-4 py-2 text-xs font-bold text-emerald-300 hover:bg-white/10 cursor-pointer"
            >
              عرض جميع المنتجات
            </button>
          </div>
        ) : (
          <div className="desktop-grid-3 grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
            {filteredProducts.map((product) => {
              const inCartItem = cart.find((c) => c.productId === product.id);
              const isOutOfStock = product.availability === "out_of_stock";

              const availabilityTone =
                product.availability === "special_offer"
                  ? "text-amber-300"
                  : product.availability === "limited"
                  ? "text-sky-300"
                  : product.availability === "out_of_stock"
                  ? "text-rose-400"
                  : "text-emerald-400";

              return (
                <article
                  key={product.id}
                  className="glass-surface flex flex-col justify-between rounded-2xl border border-white/10 p-6 transition-transform duration-150 hover:-translate-y-0.5 hover:border-emerald-400/35"
                >
                  <div>
                    {product.imageUrl && (
                      <div className="mb-4 overflow-hidden rounded-xl border border-white/10 bg-[#0B0F19]">
                        <img
                          src={product.imageUrl}
                          alt={product.title}
                          loading="lazy"
                          onError={(e) => {
                            e.currentTarget.style.display = "none";
                          }}
                          className="h-40 w-full object-cover"
                        />
                      </div>
                    )}

                    {/* Clean unboxed metadata + 1 availability label */}
                    <div className="mb-3 flex items-center justify-between gap-2 text-xs">
                      <span className="font-semibold text-slate-400 truncate">
                        {product.categoryLabel} · {product.deliveryTime}
                      </span>
                      <span className={`font-extrabold shrink-0 ${availabilityTone}`}>
                        {product.availabilityLabel}
                      </span>
                    </div>

                    <h3 className="text-lg font-extrabold text-white leading-snug">
                      {product.title}
                    </h3>

                    {product.isCustomPublished && product.publishedBy && (
                      <p className="mt-1 text-[11px] font-bold text-sky-300">
                        منشور بواسطة {product.publishedBy}
                      </p>
                    )}

                    <p className="mt-2 text-xs sm:text-sm leading-relaxed text-slate-300">
                      {product.description}
                    </p>

                    <ul className="mt-4 space-y-1.5 text-xs text-slate-400">
                      {product.features.map((feat) => (
                        <li key={feat} className="flex items-start gap-2">
                          <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-400" />
                          <span>{feat}</span>
                        </li>
                      ))}
                    </ul>

                    {product.externalUrl && (
                      <a
                        href={product.externalUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="mt-3 inline-flex items-center gap-1.5 text-xs font-bold text-sky-300 hover:text-sky-200"
                      >
                        <ExternalLink className="h-3.5 w-3.5" />
                        <span>معاينة / رابط المنتج</span>
                      </a>
                    )}
                  </div>

                  {/* Pricing + Purchase Controls */}
                  <div className="mt-6 border-t border-white/10 pt-4 space-y-3">
                    <div className="flex items-baseline justify-between gap-3">
                      <div className="flex items-baseline gap-2">
                        <span className="text-2xl font-extrabold text-white font-mono tabular-nums">
                          {formatUsdPrice(product.priceUsd)}
                        </span>
                        {product.originalPriceUsd && (
                          <span className="text-xs text-slate-500 line-through font-mono tabular-nums">
                            {formatUsdPrice(product.originalPriceUsd)}
                          </span>
                        )}
                      </div>
                      <span className="text-xs font-bold text-emerald-300 tabular-nums">
                        ≈ {formatIqdPrice(product.priceUsd)}
                      </span>
                    </div>

                    {isOutOfStock ? (
                      <button
                        type="button"
                        disabled
                        className="w-full rounded-xl bg-white/5 py-2.5 text-xs font-bold text-slate-500 cursor-not-allowed"
                      >
                        غير متوفر حالياً
                      </button>
                    ) : inCartItem ? (
                      <div className="flex items-center gap-2">
                        <div className="inline-flex items-center rounded-xl border border-emerald-400/35 bg-emerald-500/10 p-1">
                          <button
                            type="button"
                            onClick={() => onUpdateQuantity(product.id, -1)}
                            aria-label={`إنقاص كمية ${product.title}`}
                            className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-200 hover:bg-white/10 cursor-pointer"
                          >
                            <Minus className="h-3.5 w-3.5" />
                          </button>
                          <span className="min-w-[2rem] text-center text-xs font-extrabold text-white tabular-nums">
                            {inCartItem.quantity}
                          </span>
                          <button
                            type="button"
                            onClick={() => onUpdateQuantity(product.id, 1)}
                            aria-label={`زيادة كمية ${product.title}`}
                            className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-200 hover:bg-white/10 cursor-pointer"
                          >
                            <Plus className="h-3.5 w-3.5" />
                          </button>
                        </div>

                        <button
                          type="button"
                          onClick={() => {
                            setConfirmedOrder(null);
                            setDrawerTab("cart");
                            onSetCartOpen(true);
                          }}
                          className="flex-1 rounded-xl bg-emerald-600 py-2.5 text-xs font-extrabold text-white hover:bg-emerald-500 cursor-pointer whitespace-nowrap"
                        >
                          إتمام الشراء
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => onAddToCart(product, false)}
                          className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-xl border border-white/15 bg-white/5 py-2.5 px-3 text-xs font-extrabold text-white transition-colors hover:border-emerald-400/50 hover:bg-emerald-500/15 cursor-pointer whitespace-nowrap"
                        >
                          <ShoppingCart className="h-3.5 w-3.5 text-emerald-400" />
                          <span>أضف للسلة</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            setConfirmedOrder(null);
                            setDrawerTab("cart");
                            onAddToCart(product, true);
                          }}
                          className="flex-1 rounded-xl bg-violet-600 py-2.5 px-3 text-xs font-extrabold text-white transition-colors hover:bg-violet-500 cursor-pointer whitespace-nowrap"
                        >
                          شراء الآن
                        </button>
                      </div>
                    )}
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </div>

      {/* Cart & Checkout Slide-Over Drawer */}
      {isCartOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="shop-cart-drawer-title"
          className="fixed inset-0 z-50 flex justify-start bg-black/75 backdrop-blur-sm"
          onClick={() => onSetCartOpen(false)}
        >
          <aside
            onClick={(e) => e.stopPropagation()}
            className="flex h-full w-full max-w-lg flex-col border-l border-white/15 bg-[#0B0F19] shadow-2xl overflow-hidden"
          >
            {/* Drawer Header */}
            <div className="flex items-center justify-between gap-3 border-b border-white/10 bg-[#0E1424] px-5 py-4">
              <div className="flex items-center gap-2.5">
                <div className="flex h-9 w-9 items-center justify-center rounded-xl border border-emerald-400/40 bg-emerald-500/15 text-emerald-300">
                  <ShoppingBag className="h-4 w-4" />
                </div>
                <div>
                  <h3
                    id="shop-cart-drawer-title"
                    className="text-base font-extrabold text-white"
                  >
                    سلة المشتريات وإتمام الطلب
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    حساب الإجمالي التلقائي بالدولار والدينار العراقي
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => onSetCartOpen(false)}
                aria-label="إغلاق سلة المشتريات"
                className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 bg-white/5 text-slate-300 hover:bg-white/10 hover:text-white cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Tabs: Cart vs Order History (+ Exclusive Publish Tab for Developer/Moderator/Admin) */}
            <div className="flex items-center gap-1 border-b border-white/10 bg-[#0D1322] px-5 py-2.5">
              <button
                type="button"
                onClick={() => handleSelectDrawerTab("cart")}
                className={`flex-1 rounded-lg py-2 px-2 text-xs font-extrabold transition-colors whitespace-nowrap cursor-pointer ${
                  effectiveDrawerTab === "cart"
                    ? "bg-emerald-600 text-white"
                    : "text-slate-300 hover:bg-white/5"
                }`}
              >
                سلة الشراء ({cartSummary.totalItemsCount})
              </button>
              <button
                type="button"
                onClick={() => handleSelectDrawerTab("orders")}
                className={`flex-1 rounded-lg py-2 px-2 text-xs font-extrabold transition-colors whitespace-nowrap cursor-pointer ${
                  effectiveDrawerTab === "orders"
                    ? "bg-violet-600 text-white"
                    : "text-slate-300 hover:bg-white/5"
                }`}
              >
                طلباتي المؤكدة ({orders.length})
              </button>
              {canPublish && (
                <button
                  type="button"
                  onClick={() => handleSelectDrawerTab("publish")}
                  className={`flex-1 inline-flex items-center justify-center gap-1 rounded-lg py-2 px-2 text-xs font-extrabold transition-colors whitespace-nowrap cursor-pointer ${
                    effectiveDrawerTab === "publish"
                      ? "bg-sky-600 text-white"
                      : "border border-sky-400/30 bg-sky-500/10 text-sky-300 hover:bg-sky-500/20"
                  }`}
                >
                  <PackagePlus className="h-3.5 w-3.5 shrink-0" />
                  <span>{SHOP_PUBLISH_SETTINGS.tabLabel}</span>
                </button>
              )}
            </div>

            <div className="flex-1 overflow-y-auto p-5 space-y-5">
              {effectiveDrawerTab === "publish" && canPublish ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-between gap-2 rounded-xl border border-sky-400/35 bg-sky-500/10 p-3 text-xs">
                    <div className="flex items-center gap-2 text-sky-200 font-bold">
                      <ShieldCheck className="h-4 w-4 shrink-0 text-sky-400" />
                      <span>
                        صلاحية النشر مفعّلة:{" "}
                        {SHOP_PUBLISH_SETTINGS.roleLabels[userRole]}
                      </span>
                    </div>
                  </div>

                  {publishedConfirmationTitle && (
                    <div className="flex items-center justify-between gap-2 rounded-xl border border-emerald-400/40 bg-emerald-500/15 p-3 text-xs font-bold text-emerald-200">
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-400" />
                        <span>
                          تم نشر «{publishedConfirmationTitle}» وإضافته للمتجر بنجاح!
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => setPublishedConfirmationTitle("")}
                        className="text-[11px] text-emerald-300 underline cursor-pointer"
                      >
                        إخفاء
                      </button>
                    </div>
                  )}

                  <form onSubmit={handlePublishSubmit} className="space-y-3.5">
                    <div>
                      <label className="block text-[11px] font-bold text-slate-300 mb-1">
                        اسم المنتج أو الخدمة *
                      </label>
                      <input
                        type="text"
                        required
                        value={pubTitle}
                        onChange={(e) => setPubTitle(e.target.value)}
                        placeholder="مثال: سكربت متجر Roblox متكامل"
                        className="h-10 w-full rounded-xl border border-white/10 bg-[#0E1424] px-3 text-xs text-white focus:border-sky-400 focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-slate-300 mb-1">
                        وصف المنتج *
                      </label>
                      <textarea
                        rows={3}
                        required
                        value={pubDescription}
                        onChange={(e) => setPubDescription(e.target.value)}
                        placeholder="اشرح مميزات المنتج وما يحصل عليه المشتري..."
                        className="w-full rounded-xl border border-white/10 bg-[#0E1424] p-3 text-xs text-white focus:border-sky-400 focus:outline-none"
                      />
                    </div>

                    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                      <div>
                        <label className="block text-[11px] font-bold text-slate-300 mb-1">
                          السعر بالدولار ($) *
                        </label>
                        <input
                          type="number"
                          dir="ltr"
                          min="0.5"
                          step="0.5"
                          required
                          value={pubPriceUsd}
                          onChange={(e) => handleUsdPriceInput(e.target.value)}
                          placeholder="15"
                          className="h-10 w-full rounded-xl border border-white/10 bg-[#0E1424] px-3 font-mono text-xs text-emerald-300 focus:border-sky-400 focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-slate-300 mb-1">
                          أو بالدينار العراقي (د.ع)
                        </label>
                        <input
                          type="number"
                          dir="ltr"
                          min="500"
                          step="500"
                          value={pubPriceIqd}
                          onChange={(e) => handleIqdPriceInput(e.target.value)}
                          placeholder="22500"
                          className="h-10 w-full rounded-xl border border-white/10 bg-[#0E1424] px-3 font-mono text-xs text-amber-300 focus:border-sky-400 focus:outline-none"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                      <div>
                        <label className="block text-[11px] font-bold text-slate-300 mb-1">
                          التصنيف
                        </label>
                        <select
                          value={pubCategory}
                          onChange={(e) =>
                            setPubCategory(
                              e.target.value as Exclude<ShopCategoryId, "all">
                            )
                          }
                          className="h-10 w-full rounded-xl border border-white/10 bg-[#0E1424] px-3 text-xs text-white focus:border-sky-400 focus:outline-none"
                        >
                          <option value="web">مواقع وتطبيقات</option>
                          <option value="games">ألعاب ومودات</option>
                          <option value="services">خدمات برمجية</option>
                          <option value="tools">أدوات مطورين</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-slate-300 mb-1">
                          حالة التوفر
                        </label>
                        <select
                          value={pubAvailability}
                          onChange={(e) =>
                            setPubAvailability(
                              e.target.value as ShopAvailability
                            )
                          }
                          className="h-10 w-full rounded-xl border border-white/10 bg-[#0E1424] px-3 text-xs text-white focus:border-sky-400 focus:outline-none"
                        >
                          <option value="available">متوفر الآن</option>
                          <option value="special_offer">عرض خاص</option>
                          <option value="limited">كمية / حجز محدود</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-slate-300 mb-1">
                        رابط الصورة (اختياري)
                      </label>
                      <div className="relative">
                        <ImageIcon className="pointer-events-none absolute right-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-500" />
                        <input
                          type="url"
                          dir="ltr"
                          value={pubImageUrl}
                          onChange={(e) => setPubImageUrl(e.target.value)}
                          placeholder="https://example.com/product-cover.jpg"
                          className="h-10 w-full rounded-xl border border-white/10 bg-[#0E1424] pr-9 pl-3 font-mono text-xs text-white focus:border-sky-400 focus:outline-none"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                      <div>
                        <label className="block text-[11px] font-bold text-slate-300 mb-1">
                          رابط المنتج / المعاينة (اختياري)
                        </label>
                        <input
                          type="url"
                          dir="ltr"
                          value={pubExternalUrl}
                          onChange={(e) => setPubExternalUrl(e.target.value)}
                          placeholder="https://..."
                          className="h-10 w-full rounded-xl border border-white/10 bg-[#0E1424] px-3 font-mono text-xs text-white focus:border-sky-400 focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-slate-300 mb-1">
                          مدة التسليم
                        </label>
                        <input
                          type="text"
                          value={pubDeliveryTime}
                          onChange={(e) => setPubDeliveryTime(e.target.value)}
                          placeholder="تسليم فوري"
                          className="h-10 w-full rounded-xl border border-white/10 bg-[#0E1424] px-3 text-xs text-white focus:border-sky-400 focus:outline-none"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-slate-300 mb-1">
                        مميزات مختصرة (افصل بفاصلة أو سطر جديد - اختياري)
                      </label>
                      <input
                        type="text"
                        value={pubFeaturesText}
                        onChange={(e) => setPubFeaturesText(e.target.value)}
                        placeholder="دعم فني سريع، كود نظيف، تحديثات مجانية"
                        className="h-10 w-full rounded-xl border border-white/10 bg-[#0E1424] px-3 text-xs text-white focus:border-sky-400 focus:outline-none"
                      />
                    </div>

                    <button
                      type="submit"
                      className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-l from-sky-600 to-emerald-600 py-3 text-xs font-extrabold text-white shadow-lg transition-opacity hover:opacity-95 cursor-pointer"
                    >
                      <PackagePlus className="h-4 w-4" />
                      <span>حفظ ونشر المنتج في المتجر</span>
                    </button>
                  </form>

                  {customProducts.length > 0 && (
                    <div className="space-y-2 border-t border-white/10 pt-3">
                      <p className="text-xs font-extrabold text-slate-300">
                        المنتجات المنشورة عبر الفريق ({customProducts.length})
                      </p>
                      <div className="space-y-2">
                        {customProducts.map((cp) => (
                          <div
                            key={cp.id}
                            className="flex items-center justify-between gap-2 rounded-xl border border-white/10 bg-[#111827] px-3 py-2 text-xs"
                          >
                            <div className="min-w-0">
                              <p className="font-bold text-white truncate">
                                {cp.title}
                              </p>
                              <p className="text-[11px] text-slate-400">
                                {formatUsdPrice(cp.priceUsd)} · {cp.categoryLabel}
                              </p>
                            </div>
                            {onDeleteCustomProduct && (
                              <button
                                type="button"
                                onClick={() => onDeleteCustomProduct(cp.id)}
                                aria-label={`حذف ${cp.title}`}
                                className="inline-flex h-7 w-7 shrink-0 items-center justify-center rounded-lg text-slate-400 hover:bg-rose-500/15 hover:text-rose-300 cursor-pointer"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </button>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ) : effectiveDrawerTab === "orders" ? (
                orders.length === 0 ? (
                  <div className="rounded-2xl border border-dashed border-white/15 p-8 text-center text-xs text-slate-400">
                    لم تقم بإتمام أي طلب شراء بعد. أضف منتجاتك من المتجر وأكمل الطلب لتظهر فواتيرك هنا.
                  </div>
                ) : (
                  <div className="space-y-3">
                    {orders.map((ord) => (
                      <div
                        key={ord.id}
                        className="rounded-2xl border border-white/10 bg-[#111827] p-4 space-y-2.5"
                      >
                        <div className="flex items-center justify-between gap-2 text-xs">
                          <span className="font-mono font-extrabold text-emerald-300">
                            {ord.id}
                          </span>
                          <span className="text-[11px] text-slate-400">
                            {ord.createdAt}
                          </span>
                        </div>
                        <p className="text-xs font-bold text-white">
                          {ord.customerName} · {ord.contactValue}
                        </p>
                        <ul className="space-y-1 text-xs text-slate-300 border-t border-white/10 pt-2">
                          {ord.items.map((it) => (
                            <li
                              key={`${ord.id}-${it.productId}`}
                              className="flex justify-between gap-2"
                            >
                              <span className="truncate">
                                {it.title} × {it.quantity}
                              </span>
                              <span className="font-mono tabular-nums shrink-0">
                                {formatUsdPrice(it.lineTotalUsd)}
                              </span>
                            </li>
                          ))}
                        </ul>
                        <div className="flex items-center justify-between border-t border-white/10 pt-2 text-xs font-extrabold text-white">
                          <span>الإجمالي</span>
                          <span className="font-mono tabular-nums text-emerald-300">
                            {formatUsdPrice(ord.totalUsd)} (
                            {ord.totalIqd.toLocaleString("en-US")} د.ع)
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )
              ) : confirmedOrder ? (
                /* Verified Order Confirmation Receipt */
                <div className="rounded-2xl border border-emerald-500/40 bg-emerald-500/10 p-5 space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-500/20 text-emerald-300">
                      <Receipt className="h-6 w-6" />
                    </div>
                    <div>
                      <p className="text-xs font-bold text-emerald-300">
                        {confirmedOrder.signedInvoiceVerified
                          ? "تمت الشراء بنجاح"
                          : "تم تأكيد الطلب بنجاح"}
                      </p>
                      <h4 className="text-base font-extrabold text-white">
                        {confirmedOrder.signedInvoiceVerified
                          ? `تمت الشراء بنجاح · رقم الفاتورة: ${confirmedOrder.id}`
                          : `رقم الفاتورة: ${confirmedOrder.id}`}
                      </h4>
                    </div>
                  </div>

                  <div className="rounded-xl border border-white/10 bg-[#0B0F19] p-4 space-y-2 text-xs">
                    <div className="flex justify-between">
                      <span className="text-slate-400">العميل:</span>
                      <span className="font-bold text-white">
                        {confirmedOrder.customerName}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">التواصل:</span>
                      <span className="font-bold text-white">
                        {confirmedOrder.contactValue}
                      </span>
                    </div>
                    <div className="border-t border-white/10 pt-2 space-y-1.5">
                      {confirmedOrder.items.map((it) => (
                        <div
                          key={it.productId}
                          className="flex justify-between gap-2 text-slate-200"
                        >
                          <span>
                            {it.title} × {it.quantity}
                          </span>
                          <span className="font-mono tabular-nums">
                            {formatUsdPrice(it.lineTotalUsd)}
                          </span>
                        </div>
                      ))}
                    </div>
                    <div className="flex justify-between border-t border-white/10 pt-2 text-sm font-extrabold text-emerald-300">
                      <span>الإجمالي المستحق</span>
                      <span className="font-mono tabular-nums">
                        {formatUsdPrice(confirmedOrder.totalUsd)} ·{" "}
                        {confirmedOrder.totalIqd.toLocaleString("en-US")} د.ع
                      </span>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => void handleCopyReceipt(confirmedOrder)}
                    className="inline-flex w-full items-center justify-center gap-2 rounded-xl border border-white/15 bg-white/5 py-2.5 text-xs font-bold text-white hover:bg-white/10 cursor-pointer"
                  >
                    <Copy className="h-4 w-4 text-emerald-400" />
                    <span>نسخ تفاصيل الطلب والفاتورة</span>
                  </button>

                  <div className="space-y-2 pt-1">
                    <p className="text-xs font-bold text-slate-300">
                      أرسل رقم الفاتورة مباشرة لإكمال التفعيل والتسليم:
                    </p>
                    <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
                      {COMMUNITY_CHANNELS.map((ch) => (
                        <a
                          key={ch.id}
                          href={ch.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center justify-center gap-1.5 rounded-xl border border-white/15 bg-[#0E1424] py-2.5 px-3 text-xs font-bold text-white hover:border-emerald-400/50 hover:text-emerald-300"
                        >
                          <SocialBrandIcon id={ch.id} className="h-4 w-4" />
                          <span>{ch.englishName}</span>
                        </a>
                      ))}
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => setConfirmedOrder(null)}
                    className="w-full rounded-xl bg-violet-600 py-2.5 text-xs font-extrabold text-white hover:bg-violet-500 cursor-pointer"
                  >
                    العودة للتسوق
                  </button>
                </div>
              ) : cartSummary.detailedItems.length === 0 ? (
                <div className="rounded-2xl border border-dashed border-white/15 p-8 text-center space-y-3">
                  <ShoppingCart className="mx-auto h-10 w-10 text-slate-500" />
                  <p className="text-sm font-bold text-white">
                    سلة المشتريات فارغة حالياً
                  </p>
                  <p className="text-xs text-slate-400">
                    اختر أي منتج أو خدمة برمجية من المتجر لإضافتها وحساب التكلفة الإجمالية.
                  </p>
                </div>
              ) : (
                <>
                  {/* Itemized Cart List */}
                  <div className="space-y-3">
                    {cartSummary.detailedItems.map(({ product, quantity, lineTotalUsd }) => (
                      <div
                        key={product.id}
                        className="rounded-2xl border border-white/10 bg-[#111827] p-3.5 space-y-2.5"
                      >
                        <div className="flex items-start justify-between gap-3">
                          <div className="min-w-0">
                            <p className="text-xs font-extrabold text-white truncate">
                              {product.title}
                            </p>
                            <p className="mt-0.5 text-[11px] text-slate-400">
                              سعر الوحدة: {formatUsdPrice(product.priceUsd)} (
                              {formatIqdPrice(product.priceUsd)})
                            </p>
                          </div>
                          <button
                            type="button"
                            onClick={() => onRemoveFromCart(product.id)}
                            aria-label={`حذف ${product.title}`}
                            className="inline-flex h-7 w-7 shrink-0 items-center justify-center rounded-lg text-slate-400 hover:bg-rose-500/15 hover:text-rose-300 cursor-pointer"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="inline-flex items-center rounded-lg border border-white/10 bg-[#0B0F19] p-0.5">
                            <button
                              type="button"
                              onClick={() => onUpdateQuantity(product.id, -1)}
                              aria-label="إنقاص الكمية"
                              className="inline-flex h-7 w-7 items-center justify-center rounded-md text-slate-300 hover:bg-white/10 cursor-pointer"
                            >
                              <Minus className="h-3 w-3" />
                            </button>
                            <span className="min-w-[1.75rem] text-center text-xs font-bold text-white tabular-nums">
                              {quantity}
                            </span>
                            <button
                              type="button"
                              onClick={() => onUpdateQuantity(product.id, 1)}
                              aria-label="زيادة الكمية"
                              className="inline-flex h-7 w-7 items-center justify-center rounded-md text-slate-300 hover:bg-white/10 cursor-pointer"
                            >
                              <Plus className="h-3 w-3" />
                            </button>
                          </div>

                          <span className="text-sm font-extrabold text-emerald-300 font-mono tabular-nums">
                            {formatUsdPrice(lineTotalUsd)}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Promo Code Box (Clean & Hint-Free) */}
                  <form
                    onSubmit={handleApplyPromo}
                    className="flex items-center gap-2 rounded-xl border border-white/10 bg-[#0E1424] p-2.5"
                  >
                    <Tag className="h-4 w-4 shrink-0 text-amber-400" />
                    <input
                      type="text"
                      value={promoInput}
                      onChange={(e) => setPromoInput(e.target.value)}
                      placeholder="أدخل كود الخصم..."
                      className="h-8 min-w-0 flex-1 bg-transparent text-xs text-white placeholder:text-slate-500 focus:outline-none"
                    />
                    <button
                      type="submit"
                      className="rounded-lg bg-amber-500 px-3 py-1.5 text-[11px] font-extrabold text-slate-950 hover:bg-amber-400 cursor-pointer"
                    >
                      تطبيق
                    </button>
                  </form>

                  {/* Accurate Pricing Breakdown */}
                  <div className="rounded-2xl border border-emerald-500/25 bg-[#0E1424] p-4 space-y-2 text-xs">
                    <div className="flex justify-between text-slate-300">
                      <span>المجموع الفرعي ({cartSummary.totalItemsCount} عناصر)</span>
                      <span className="font-mono tabular-nums">
                        {formatUsdPrice(cartSummary.subtotalUsd)}
                      </span>
                    </div>

                    {cartSummary.offerSavingsUsd > 0 && (
                      <div className="flex justify-between text-amber-300">
                        <span>توفير العروض الخاصة</span>
                        <span className="font-mono tabular-nums">
                          -{formatUsdPrice(cartSummary.offerSavingsUsd)}
                        </span>
                      </div>
                    )}

                    {cartSummary.promoDiscountUsd > 0 && (
                      <div className="flex justify-between text-emerald-300">
                        <span>
                          خصم الكود (
                          {cartSummary.isSecretFullDiscount
                            ? SECRET_FULL_DISCOUNT_CODE
                            : cartSummary.matchedPromo?.code}
                          )
                        </span>
                        <span className="font-mono tabular-nums">
                          -{formatUsdPrice(cartSummary.promoDiscountUsd)}
                        </span>
                      </div>
                    )}

                    <div className="flex items-baseline justify-between border-t border-white/10 pt-2.5 text-sm font-extrabold text-white">
                      <span>الإجمالي النهائي</span>
                      <div className="text-left">
                        <span className="block text-base text-emerald-300 font-mono tabular-nums">
                          {formatUsdPrice(cartSummary.finalTotalUsd)}
                        </span>
                        <span className="block text-[11px] text-slate-400 tabular-nums">
                          ({cartSummary.finalTotalIqd.toLocaleString("en-US")} د.ع)
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Invoice Dispatch + Signature Verification Step when 100% Promo is Active */}
                  {cartSummary.isSecretFullDiscount && (
                    <div className="rounded-2xl border border-emerald-400/45 bg-[#091A16] p-4 space-y-3">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <p className="text-xs font-extrabold text-emerald-300">
                            خطوة الفاتورة والتوقيع المعتمد
                          </p>
                          <p className="mt-0.5 text-[11px] leading-relaxed text-slate-300">
                            انسخ الفاتورة أدناه وأرسلها عبر واتساب إلى صاحب المتجر (
                            <span dir="ltr" className="font-mono text-emerald-300">
                              {WHATSAPP_OWNER_PHONE}
                            </span>
                            ) ليقوم بتوقيعها وإرجاعها لك، ثم الصق الفاتورة الموقّعة هنا.
                          </p>
                        </div>
                        <Receipt className="h-5 w-5 shrink-0 text-emerald-400" />
                      </div>

                      <pre
                        dir="rtl"
                        className="whitespace-pre-wrap rounded-xl border border-white/10 bg-[#0B0F19] p-3 text-[11px] leading-relaxed text-slate-200 font-sans select-all"
                      >
                        {generatedUnsignedInvoice}
                      </pre>

                      <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                        <button
                          type="button"
                          onClick={() => void handleCopyUnsignedInvoice()}
                          className="inline-flex items-center justify-center gap-1.5 rounded-xl border border-white/15 bg-white/5 py-2.5 px-3 text-xs font-extrabold text-white hover:bg-white/10 cursor-pointer"
                        >
                          <Copy className="h-3.5 w-3.5 text-emerald-400" />
                          <span>نسخ الفاتورة</span>
                        </button>

                        <a
                          href={`${WHATSAPP_OWNER_URL}?text=${encodeURIComponent(
                            generatedUnsignedInvoice
                          )}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center justify-center gap-1.5 rounded-xl bg-emerald-600 py-2.5 px-3 text-xs font-extrabold text-white hover:bg-emerald-500 transition-colors"
                        >
                          <SocialBrandIcon id="whatsapp" className="h-4 w-4" />
                          <span>إرسال إلى واتساب المتجر</span>
                        </a>
                      </div>

                      <div className="space-y-1.5 pt-1">
                        <label
                          htmlFor="signed-invoice-textarea"
                          className="block text-xs font-extrabold text-white"
                        >
                          الفاتورة مع التوقيع *
                        </label>
                        <textarea
                          id="signed-invoice-textarea"
                          rows={4}
                          value={signedInvoiceInput}
                          onChange={(e) => {
                            setSignedInvoiceInput(e.target.value);
                            if (signedInvoiceError) setSignedInvoiceError("");
                          }}
                          placeholder="الصق هنا الفاتورة الموقّعة التي أرجعها لك صاحب المتجر عبر الواتساب..."
                          className="w-full rounded-xl border border-emerald-400/35 bg-[#0B0F19] p-3 text-xs text-white placeholder:text-slate-500 focus:border-emerald-400 focus:outline-none"
                        />
                        {signedInvoiceError && (
                          <div
                            role="alert"
                            className="rounded-xl border border-rose-500/45 bg-rose-500/15 px-3 py-2 text-[11px] font-bold text-rose-200"
                          >
                            {signedInvoiceError}
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Checkout Form */}
                  <form onSubmit={handleCompleteOrder} className="space-y-3 pt-1">
                    <h4 className="text-xs font-extrabold text-white">
                      بيانات إتمام الطلب والتسليم
                    </h4>

                    <div>
                      <label className="block text-[11px] font-bold text-slate-400 mb-1">
                        الاسم الكامل
                      </label>
                      <input
                        type="text"
                        required
                        value={customerName}
                        onChange={(e) => setCustomerName(e.target.value)}
                        placeholder="مثال: أمير باقر"
                        className="h-10 w-full rounded-xl border border-white/10 bg-[#0E1424] px-3 text-xs text-white focus:border-emerald-400 focus:outline-none"
                      />
                    </div>

                    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                      <div>
                        <label className="block text-[11px] font-bold text-slate-400 mb-1">
                          وسيلة التواصل المفضلة
                        </label>
                        <select
                          value={contactChannel}
                          onChange={(e) =>
                            setContactChannel(
                              e.target.value as OrderContactChannel
                            )
                          }
                          className="h-10 w-full rounded-xl border border-white/10 bg-[#0E1424] px-3 text-xs text-white focus:border-emerald-400 focus:outline-none"
                        >
                          <option value="whatsapp">واتساب (WhatsApp)</option>
                          <option value="telegram">تليجرام (Telegram)</option>
                          <option value="discord">دسكورد (Discord)</option>
                          <option value="email">البريد الإلكتروني</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-slate-400 mb-1">
                          رقم الهاتف أو المعرف
                        </label>
                        <input
                          type="text"
                          required
                          value={contactValue}
                          onChange={(e) => setContactValue(e.target.value)}
                          placeholder="@username أو رقم الواتساب"
                          className="h-10 w-full rounded-xl border border-white/10 bg-[#0E1424] px-3 text-xs text-white focus:border-emerald-400 focus:outline-none"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-slate-400 mb-1">
                        ملاحظات إضافية (اختياري)
                      </label>
                      <textarea
                        rows={2}
                        value={orderNotes}
                        onChange={(e) => setOrderNotes(e.target.value)}
                        placeholder="تفاصيل مشروعك أو وقت التواصل المفضل..."
                        className="w-full rounded-xl border border-white/10 bg-[#0E1424] p-3 text-xs text-white focus:border-emerald-400 focus:outline-none"
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full rounded-xl bg-gradient-to-l from-violet-600 to-emerald-600 py-3 text-xs font-extrabold text-white shadow-lg transition-opacity hover:opacity-95 cursor-pointer"
                    >
                      {cartSummary.isSecretFullDiscount
                        ? "تحقق من الفاتورة الموقّعة وإتمام الشراء ($0)"
                        : `تأكيد الطلب (${formatUsdPrice(cartSummary.finalTotalUsd)})`}
                    </button>
                  </form>
                </>
              )}
            </div>
          </aside>
        </div>
      )}
    </section>
  );
};
