import React, { useState } from "react";
import {
  CheckCircle2,
  Code2,
  Crown,
  Hammer,
  MessageSquarePlus,
  Plus,
  Send,
  ShieldCheck,
  Sparkles,
  Trophy,
  X,
  XCircle,
} from "lucide-react";
import { DEV_HAMMER_EMBLEM, SITE_IDENTITY_EMBLEM } from "../data/initialData";
import { canCreateChallenge, SHOP_PUBLISH_SETTINGS } from "../data/siteConfig";
import { ChallengeItem, UserProfile, UserRole } from "../types";

interface ChallengesSectionProps {
  challenges: ChallengeItem[];
  user: UserProfile | null;
  userRole: UserRole;
  onCreateChallenge: (challenge: ChallengeItem) => void;
  onAddComment: (challengeId: string, content: string) => void;
  onShowToast: (msg: string) => void;
}

export const ChallengesSection: React.FC<ChallengesSectionProps> = ({
  challenges,
  user,
  userRole,
  onCreateChallenge,
  onAddComment,
  onShowToast,
}) => {
  const canCreate = canCreateChallenge(userRole);

  // Answers chosen by visitor per challenge: challengeId -> "A" | "B"
  const [selectedAnswers, setSelectedAnswers] = useState<
    Record<string, "A" | "B">
  >({});
  const [commentDrafts, setCommentDrafts] = useState<Record<string, string>>({});

  // Create Challenge Modal
  const [creatorOpen, setCreatorOpen] = useState(false);
  const [titleDraft, setTitleDraft] = useState("");
  const [questionDraft, setQuestionDraft] = useState("");
  const [codeSnippetDraft, setCodeSnippetDraft] = useState("");
  const [buttonALabelDraft, setButtonALabelDraft] = useState("نعم");
  const [buttonBLabelDraft, setButtonBLabelDraft] = useState("لا");
  const [correctButtonDraft, setCorrectButtonDraft] = useState<"A" | "B">("A");

  const handleSubmitNewChallenge = (e: React.FormEvent) => {
    e.preventDefault();
    if (!canCreateChallenge(userRole)) {
      onShowToast("هذه الميزة للمطورين والمدراء والمسؤولين فقط.");
      return;
    }
    if (!titleDraft.trim() || !questionDraft.trim()) {
      onShowToast("أدخل عنوان التحدي ونص السؤال أولاً.");
      return;
    }

    const publisherAvatar =
      userRole === "admin"
        ? SITE_IDENTITY_EMBLEM
        : userRole === "developer"
        ? DEV_HAMMER_EMBLEM
        : user?.avatarUrl || DEV_HAMMER_EMBLEM;

    const newItem: ChallengeItem = {
      id: `chal-${Date.now()}`,
      title: titleDraft.trim(),
      question: questionDraft.trim(),
      codeSnippet: codeSnippetDraft.trim() || undefined,
      buttonALabel: buttonALabelDraft.trim() || "نعم",
      buttonBLabel: buttonBLabelDraft.trim() || "لا",
      correctButton: correctButtonDraft,
      publisherName: user?.name || (userRole === "admin" ? "أمير باقر" : "مطور عراقي"),
      publisherHandle: user?.handle || "@iraqi_dev",
      publisherAvatar,
      publisherRole: userRole,
      createdAt: "الآن",
      comments: [],
    };

    onCreateChallenge(newItem);
    setTitleDraft("");
    setQuestionDraft("");
    setCodeSnippetDraft("");
    setButtonALabelDraft("نعم");
    setButtonBLabelDraft("لا");
    setCorrectButtonDraft("A");
    setCreatorOpen(false);
  };

  const handleChooseAnswer = (challenge: ChallengeItem, choice: "A" | "B") => {
    setSelectedAnswers((prev) => ({ ...prev, [challenge.id]: choice }));
    if (choice === challenge.correctButton) {
      onShowToast(`أحسنت! إجابة صحيحة في «${challenge.title}».`);
    } else {
      onShowToast("إجابة خاطئة! جرّب الزر الآخر أو شاركنا رأيك بالتعليقات.");
    }
  };

  return (
    <section
      id="challenges"
      className="scroll-mt-24 border-b border-white/10 py-14 lg:py-20"
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 space-y-8">
        {/* Section Header */}
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 text-xs font-extrabold text-amber-300">
              <Trophy className="h-4 w-4" />
              <span>التحديات البرمجية المباشرة</span>
            </div>
            <h2 className="text-2xl font-extrabold text-white sm:text-3xl">
              قسم التحديات ({challenges.length})
            </h2>
            <p className="max-w-2xl text-sm text-slate-400">
              اختبر مهارتك في تحديات المسؤولين والمطورين التفاعلية — الإجابة
              الصحيحة تتوهج بالأخضر والخاطئة بالأحمر، مع مساحة للتعليق والمناقشة.
            </p>
          </div>

          {/* Strictly visible ONLY for developer, director, admin */}
          {canCreate && (
            <button
              type="button"
              onClick={() => setCreatorOpen(true)}
              className="version-glow inline-flex items-center gap-2 rounded-xl bg-gradient-to-l from-amber-500 to-emerald-600 px-5 py-3 text-xs font-extrabold text-white shadow-lg transition-transform hover:-translate-y-0.5 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Plus className="h-4 w-4" />
              <span>أنشئ تحديك الخاص</span>
            </button>
          )}
        </div>

        {/* Challenges Grid */}
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          {challenges.map((ch) => {
            const chosen = selectedAnswers[ch.id];
            const isAdminPublisher = ch.publisherRole === "admin";
            const isDevPublisher = ch.publisherRole === "developer";
            const isDirectorPublisher = ch.publisherRole === "director";

            const getBtnClass = (btnId: "A" | "B") => {
              if (!chosen || chosen !== btnId) {
                return "border-white/15 bg-[#121A2F] text-slate-100 hover:border-violet-400/60 hover:bg-violet-600/15";
              }
              if (btnId === ch.correctButton) {
                return "border-emerald-400 bg-emerald-600 text-white shadow-[0_0_24px_rgba(16,185,129,0.5)]";
              }
              return "border-rose-400 bg-rose-600 text-white shadow-[0_0_24px_rgba(244,63,94,0.45)]";
            };

            return (
              <article
                key={ch.id}
                className={`relative overflow-hidden rounded-3xl border p-5 sm:p-6 flex flex-col justify-between gap-5 ${
                  isAdminPublisher
                    ? "border-amber-400/45 bg-[#13111C]"
                    : isDevPublisher
                    ? "border-sky-400/40 bg-[#0D1526]"
                    : "border-emerald-400/35 bg-[#0E1726]"
                }`}
              >
                {/* Admin Site Identity Background Watermark */}
                {isAdminPublisher && (
                  <div
                    aria-hidden="true"
                    className="pointer-events-none absolute inset-0 opacity-20"
                  >
                    <img
                      src={SITE_IDENTITY_EMBLEM}
                      alt=""
                      className="h-full w-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#0D111C] via-[#0D111C]/85 to-transparent" />
                  </div>
                )}

                <div className="relative z-10 space-y-4">
                  {/* Publisher Badge Header */}
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 pb-3">
                    <div className="flex items-center gap-3 min-w-0">
                      {isAdminPublisher ? (
                        <img
                          src={SITE_IDENTITY_EMBLEM}
                          alt="شعار هوية الموقع"
                          className="h-11 w-11 rounded-xl border-2 border-amber-400 object-cover shrink-0 shadow-md"
                        />
                      ) : isDevPublisher ? (
                        <div className="relative h-11 w-11 shrink-0 overflow-hidden rounded-xl border-2 border-sky-400 bg-[#081020]">
                          <img
                            src={DEV_HAMMER_EMBLEM}
                            alt="مطرقة المطور"
                            className="h-full w-full object-cover"
                          />
                        </div>
                      ) : (
                        <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-emerald-400/50 bg-emerald-500/20 text-emerald-300">
                          <ShieldCheck className="h-6 w-6" />
                        </div>
                      )}

                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="text-xs font-extrabold text-white truncate">
                            {ch.publisherName}
                          </p>
                          <span
                            className={`inline-flex items-center gap-1 rounded-md border px-2 py-0.5 text-[10px] font-extrabold shrink-0 ${
                              isAdminPublisher
                                ? "border-amber-400/60 bg-amber-500/20 text-amber-200"
                                : isDevPublisher
                                ? "border-sky-400/55 bg-sky-500/20 text-sky-200"
                                : isDirectorPublisher
                                ? "border-emerald-400/55 bg-emerald-500/20 text-emerald-200"
                                : "border-white/15 bg-white/5 text-slate-300"
                            }`}
                          >
                            {isAdminPublisher ? (
                              <>
                                <Crown className="h-3 w-3" />
                                <span>مسؤول</span>
                              </>
                            ) : isDevPublisher ? (
                              <>
                                <Hammer className="h-3 w-3" />
                                <span>مطور</span>
                              </>
                            ) : (
                              <span>مدير</span>
                            )}
                          </span>
                        </div>
                        <p className="text-[11px] font-mono text-slate-400 truncate">
                          {ch.publisherHandle} · {ch.createdAt}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Title & Question */}
                  <div className="space-y-2">
                    <h3 className="text-lg font-extrabold text-white">
                      {ch.title}
                    </h3>
                    <p className="text-sm leading-relaxed text-slate-200">
                      {ch.question}
                    </p>
                  </div>

                  {ch.codeSnippet && (
                    <pre
                      dir="ltr"
                      className="overflow-x-auto rounded-xl border border-white/10 bg-[#060911] p-3 font-mono text-xs text-emerald-300"
                    >
                      {ch.codeSnippet}
                    </pre>
                  )}

                  {/* Two Editable Answer Buttons (Green if Right, Red if Wrong) */}
                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                    {(["A", "B"] as const).map((btnId) => {
                      const label = btnId === "A" ? ch.buttonALabel : ch.buttonBLabel;
                      const isSelected = chosen === btnId;
                      const isRight = btnId === ch.correctButton;
                      return (
                        <button
                          key={btnId}
                          type="button"
                          onClick={() => handleChooseAnswer(ch, btnId)}
                          className={`flex items-center justify-between gap-2 rounded-xl border px-4 py-3 text-xs font-extrabold transition-all cursor-pointer ${getBtnClass(
                            btnId
                          )}`}
                        >
                          <span>{label}</span>
                          {isSelected &&
                            (isRight ? (
                              <CheckCircle2 className="h-4 w-4 shrink-0" />
                            ) : (
                              <XCircle className="h-4 w-4 shrink-0" />
                            ))}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Challenge Comments Section */}
                <div className="relative z-10 space-y-3 border-t border-white/10 pt-3">
                  <div className="flex items-center gap-1.5 text-[11px] font-bold text-slate-400">
                    <MessageSquarePlus className="h-3.5 w-3.5 text-emerald-400" />
                    <span>التعليقات والحلول ({ch.comments.length})</span>
                  </div>

                  {ch.comments.length > 0 && (
                    <div className="max-h-28 space-y-1.5 overflow-y-auto pr-1">
                      {ch.comments.map((cm) => (
                        <div
                          key={cm.id}
                          className="rounded-xl border border-white/10 bg-[#080C15]/85 px-3 py-2 text-xs"
                        >
                          <div className="flex items-center justify-between gap-2">
                            <span className="font-extrabold text-emerald-300">
                              {cm.authorName} (
                              {SHOP_PUBLISH_SETTINGS.roleLabels[cm.authorRole] ||
                                cm.authorRole}
                              )
                            </span>
                            <span className="text-[10px] text-slate-500">
                              {cm.createdAt}
                            </span>
                          </div>
                          <p className="mt-1 text-slate-200">{cm.content}</p>
                        </div>
                      ))}
                    </div>
                  )}

                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      const text = (commentDrafts[ch.id] || "").trim();
                      if (!text) return;
                      onAddComment(ch.id, text);
                      setCommentDrafts((prev) => ({ ...prev, [ch.id]: "" }));
                    }}
                    className="flex items-center gap-2"
                  >
                    <input
                      type="text"
                      value={commentDrafts[ch.id] || ""}
                      onChange={(e) =>
                        setCommentDrafts((prev) => ({
                          ...prev,
                          [ch.id]: e.target.value,
                        }))
                      }
                      placeholder="أضف تعليقك أو اشرح حلك للتحدي..."
                      className="h-9 min-w-0 flex-1 rounded-xl border border-white/10 bg-[#080C15] px-3 text-xs text-white placeholder:text-slate-500 focus:border-emerald-400 focus:outline-none"
                    />
                    <button
                      type="submit"
                      aria-label="إرسال التعليق"
                      className="inline-flex h-9 items-center gap-1 rounded-xl bg-violet-600 px-3 text-xs font-bold text-white hover:bg-violet-500 cursor-pointer shrink-0"
                    >
                      <Send className="h-3.5 w-3.5" />
                      <span>نشر</span>
                    </button>
                  </form>
                </div>
              </article>
            );
          })}
        </div>
      </div>

      {/* Challenge Creator Modal (Strictly guarded for Developer / Director / Admin) */}
      {creatorOpen && canCreate && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="إنشاء تحدٍ جديد"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm"
          onClick={() => setCreatorOpen(false)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-3xl border border-amber-400/40 bg-[#0E1424] p-6 shadow-2xl space-y-4"
          >
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-amber-400" />
                <h3 className="text-lg font-extrabold text-white">
                  أنشئ تحديك الخاص
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setCreatorOpen(false)}
                aria-label="إغلاق"
                className="rounded-lg p-1.5 text-slate-400 hover:bg-white/10 hover:text-white cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <form onSubmit={handleSubmitNewChallenge} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  عنوان التحدي
                </label>
                <input
                  type="text"
                  required
                  value={titleDraft}
                  onChange={(e) => setTitleDraft(e.target.value)}
                  placeholder="مثال: تحدي سرعة بناء واجهات Python و Web"
                  className="h-10 w-full rounded-xl border border-white/15 bg-[#080C15] px-3 text-xs text-white focus:border-amber-400 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  سؤال أو فكرة التحدي
                </label>
                <textarea
                  rows={3}
                  required
                  value={questionDraft}
                  onChange={(e) => setQuestionDraft(e.target.value)}
                  placeholder="اكتب سؤال التحدي الذي سيجيب عليه المشاركون..."
                  className="w-full rounded-xl border border-white/15 bg-[#080C15] p-3 text-xs text-white focus:border-amber-400 focus:outline-none"
                />
              </div>

              <div>
                <label className="flex items-center gap-1.5 text-xs font-bold text-slate-300 mb-1">
                  <Code2 className="h-3.5 w-3.5 text-emerald-400" />
                  <span>كود مرفق (اختياري)</span>
                </label>
                <textarea
                  rows={2}
                  dir="ltr"
                  value={codeSnippetDraft}
                  onChange={(e) => setCodeSnippetDraft(e.target.value)}
                  placeholder="print('Iraqi Coders Challenge')"
                  className="w-full rounded-xl border border-white/15 bg-[#060911] p-3 font-mono text-xs text-emerald-300 focus:border-emerald-400 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    اسم الزر الأول (الأصل: نعم)
                  </label>
                  <input
                    type="text"
                    required
                    value={buttonALabelDraft}
                    onChange={(e) => setButtonALabelDraft(e.target.value)}
                    className="h-10 w-full rounded-xl border border-white/15 bg-[#080C15] px-3 text-xs text-white focus:border-emerald-400 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    اسم الزر الثاني (الأصل: لا)
                  </label>
                  <input
                    type="text"
                    required
                    value={buttonBLabelDraft}
                    onChange={(e) => setButtonBLabelDraft(e.target.value)}
                    className="h-10 w-full rounded-xl border border-white/15 bg-[#080C15] px-3 text-xs text-white focus:border-rose-400 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <p className="text-xs font-bold text-slate-300 mb-2">
                  حدد أي زر هو الإجابة الصحيحة (يضيء بالأخضر):
                </p>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setCorrectButtonDraft("A")}
                    className={`rounded-xl border py-2.5 text-xs font-extrabold cursor-pointer ${
                      correctButtonDraft === "A"
                        ? "border-emerald-400 bg-emerald-600/25 text-emerald-200"
                        : "border-white/10 bg-[#080C15] text-slate-400"
                    }`}
                  >
                    الصحيح: {buttonALabelDraft || "نعم"}
                  </button>
                  <button
                    type="button"
                    onClick={() => setCorrectButtonDraft("B")}
                    className={`rounded-xl border py-2.5 text-xs font-extrabold cursor-pointer ${
                      correctButtonDraft === "B"
                        ? "border-emerald-400 bg-emerald-600/25 text-emerald-200"
                        : "border-white/10 bg-[#080C15] text-slate-400"
                    }`}
                  >
                    الصحيح: {buttonBLabelDraft || "لا"}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                className="w-full rounded-xl bg-gradient-to-l from-amber-500 to-emerald-600 py-3 text-xs font-extrabold text-white shadow-lg hover:opacity-95 cursor-pointer"
              >
                حفظ ونشر التحدي الآن
              </button>
            </form>
          </div>
        </div>
      )}
    </section>
  );
};
