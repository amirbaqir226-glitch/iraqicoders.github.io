import React from "react";
import {
  Eye,
  Globe,
  Lock,
  PartyPopper,
  Play,
  Puzzle,
  Sparkles,
  Trash2,
} from "lucide-react";
import { PlatformAiUpdate, PlatformUpdateVisibility } from "../types";

interface WorkerCelebrationHeaderProps {
  displayVersion: string;
  extensionMode: boolean;
  updates: PlatformAiUpdate[];
  currentUserId: string;
  isAdminPrivileged: boolean;
  onToggleVisibility: (
    updateId: string,
    visibility: PlatformUpdateVisibility
  ) => void;
  onExecuteUpdateAction: (update: PlatformAiUpdate) => void;
  onDeleteUpdate: (updateId: string) => void;
  onJumpToPairing: () => void;
}

const CheerWorkerSvg: React.FC<{
  helmetColor: string;
  vestColor: string;
  flagLabel: string;
  delayClass?: string;
}> = ({ helmetColor, vestColor, flagLabel, delayClass = "" }) => (
  <div className={`flex flex-col items-center gap-1 ${delayClass}`}>
    <div className="rounded-md border border-emerald-400/40 bg-emerald-500/15 px-2 py-0.5 text-[10px] font-extrabold text-emerald-200 whitespace-nowrap">
      {flagLabel}
    </div>
    <svg viewBox="0 0 64 76" className="h-14 w-12 sm:h-16 sm:w-14" aria-hidden="true">
      <path d="M16 22 C16 10, 48 10, 48 22 Z" fill={helmetColor} />
      <rect x="12" y="20" width="40" height="4" rx="2" fill={helmetColor} />
      <circle cx="32" cy="31" r="9.5" fill="#F3C69F" />
      <circle cx="28.5" cy="30" r="1.4" fill="#0F172A" />
      <circle cx="35.5" cy="30" r="1.4" fill="#0F172A" />
      <path
        d="M28 34.5 Q32 38.5 36 34.5"
        fill="none"
        stroke="#0F172A"
        strokeWidth="1.6"
        strokeLinecap="round"
      />
      <rect x="21" y="42" width="22" height="20" rx="4" fill={vestColor} />
      <rect x="10" y="34" width="11" height="4.5" rx="2" fill="#F3C69F" transform="rotate(-28 15 36)" />
      <rect x="43" y="34" width="11" height="4.5" rx="2" fill="#F3C69F" transform="rotate(28 49 36)" />
      <rect x="23" y="62" width="6" height="10" rx="2" fill="#334155" />
      <rect x="35" y="62" width="6" height="10" rx="2" fill="#334155" />
    </svg>
  </div>
);

const ACCENT_MAP: Record<
  PlatformAiUpdate["accentColor"],
  { border: string; badge: string; button: string }
> = {
  blue: {
    border: "border-sky-500/40 bg-sky-500/10",
    badge: "text-sky-300",
    button: "bg-sky-600 hover:bg-sky-500 text-white",
  },
  emerald: {
    border: "border-emerald-500/40 bg-emerald-500/10",
    badge: "text-emerald-300",
    button: "bg-emerald-600 hover:bg-emerald-500 text-white",
  },
  violet: {
    border: "border-violet-500/40 bg-violet-500/10",
    badge: "text-violet-300",
    button: "bg-violet-600 hover:bg-violet-500 text-white",
  },
  amber: {
    border: "border-amber-500/40 bg-amber-500/10",
    badge: "text-amber-300",
    button: "bg-amber-600 hover:bg-amber-500 text-white",
  },
};

export const WorkerCelebrationHeader: React.FC<
  WorkerCelebrationHeaderProps
> = ({
  displayVersion,
  extensionMode,
  updates,
  currentUserId,
  isAdminPrivileged,
  onToggleVisibility,
  onExecuteUpdateAction,
  onDeleteUpdate,
  onJumpToPairing,
}) => {
  const isFutureMode = Number(displayVersion) >= 100;

  return (
    <section
      id="worker-celebration"
      aria-label="احتفالية فريق العمال بالإصدار 26.5"
      className="scroll-mt-24 border-b border-white/10 bg-[#0D1322] py-5"
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 space-y-4">
        <div
          className={`celebration-ribbon relative overflow-hidden rounded-2xl border px-5 py-4 sm:px-6 ${
            isFutureMode
              ? "v999-future-glow border-sky-400/50"
              : "border-emerald-400/35"
          }`}
        >
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div className="space-y-1.5 min-w-0">
              <div className="flex flex-wrap items-center gap-2 text-xs font-extrabold">
                <span className="inline-flex items-center gap-1.5 text-amber-300">
                  <PartyPopper className="h-4 w-4 shrink-0 confetti-float" />
                  <span>احتفالية عمال مصنع عراقي كودرز</span>
                </span>
                <span aria-hidden="true" className="text-slate-500">
                  ·
                </span>
                <span className="font-mono text-emerald-300 tabular-nums">
                  الإصدار {displayVersion}
                </span>
                {extensionMode && (
                  <>
                    <span aria-hidden="true" className="text-slate-500">
                      ·
                    </span>
                    <button
                      type="button"
                      onClick={onJumpToPairing}
                      className="inline-flex items-center gap-1 text-sky-300 hover:text-sky-200 underline underline-offset-4 cursor-pointer"
                    >
                      <Puzzle className="h-3.5 w-3.5" />
                      <span>وضع الإضافة متزامن</span>
                    </button>
                  </>
                )}
              </div>

              <h2 className="text-base sm:text-lg font-extrabold text-white">
                فريق المصنع يحتفل بإطلاق التحديث الأسطوري v{displayVersion}
              </h2>

              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-3xl">
                تمت إزالة نظام الإدارة القديم بالكامل وتجهيز وضع{" "}
                <strong className="text-sky-300">الإضافة والاقتران الأزرق</strong>،
                وشريط الترقية المستقبلي حتى{" "}
                <strong className="font-mono text-emerald-300">v999.9</strong>،
                ومولّد التحديثات الحي بالذكاء الاصطناعي.
              </p>
            </div>

            <div className="flex items-end justify-center gap-4 shrink-0 pt-1">
              <CheerWorkerSvg
                helmetColor="#F59E0B"
                vestColor="#2563EB"
                flagLabel={`v${displayVersion} 🎉`}
                delayClass="worker-cheer"
              />
              <CheerWorkerSvg
                helmetColor="#10B981"
                vestColor="#7C3AED"
                flagLabel="أبطال الكود"
                delayClass="worker-cheer"
              />
              <CheerWorkerSvg
                helmetColor="#38BDF8"
                vestColor="#059669"
                flagLabel="مصنع العراق"
                delayClass="worker-cheer"
              />
            </div>
          </div>
        </div>

        {/* Live AI-Generated Features Dock (Visible to All if Public, Creator/Admin if Private) */}
        {updates.length > 0 && (
          <div className="space-y-3">
            <div className="flex items-center justify-between gap-2 text-xs font-bold text-slate-300">
              <div className="inline-flex items-center gap-1.5">
                <Sparkles className="h-4 w-4 text-sky-400" />
                <span>الميزات والتحديثات المباشرة المولّدة بالذكاء الاصطناعي</span>
              </div>
              <span className="font-mono text-slate-400 tabular-nums">
                {updates.length} ميزة نشطة
              </span>
            </div>

            <div className="desktop-grid-3 grid grid-cols-1 gap-3 md:grid-cols-2 lg:grid-cols-3">
              {updates.map((upd) => {
                const style = ACCENT_MAP[upd.accentColor] || ACCENT_MAP.blue;
                const canManage =
                  isAdminPrivileged ||
                  upd.authorId === currentUserId ||
                  upd.authorId === "local-admin-dev";

                return (
                  <div
                    key={upd.id}
                    className={`flex flex-col justify-between rounded-2xl border p-4 ${style.border}`}
                  >
                    <div>
                      <div className="mb-2 flex items-center justify-between gap-2 text-[11px] font-bold">
                        <span className={style.badge}>
                          {upd.badgeText} · v{upd.targetVersion}
                        </span>
                        <span
                          className={`inline-flex items-center gap-1 ${
                            upd.visibility === "public"
                              ? "text-emerald-300"
                              : "text-amber-300"
                          }`}
                        >
                          {upd.visibility === "public" ? (
                            <>
                              <Globe className="h-3 w-3" />
                              <span>عام للجميع</span>
                            </>
                          ) : (
                            <>
                              <Lock className="h-3 w-3" />
                              <span>خاص للمنشئ</span>
                            </>
                          )}
                        </span>
                      </div>

                      <h3 className="text-sm font-extrabold text-white mb-1">
                        {upd.title}
                      </h3>
                      <p className="text-xs text-slate-300 leading-relaxed mb-3">
                        {upd.description}
                      </p>
                    </div>

                    <div className="space-y-2.5 pt-2 border-t border-white/10">
                      <button
                        type="button"
                        onClick={() => onExecuteUpdateAction(upd)}
                        className={`inline-flex w-full items-center justify-center gap-1.5 rounded-xl px-3 py-2 text-xs font-extrabold transition-colors cursor-pointer ${style.button}`}
                      >
                        <Play className="h-3.5 w-3.5" />
                        <span>{upd.actionLabel}</span>
                      </button>

                      {canManage && (
                        <div className="flex items-center justify-between gap-2">
                          <div
                            role="group"
                            aria-label="تحديد ظهور الميزة"
                            className="inline-flex flex-1 items-center gap-1 rounded-lg border border-white/10 bg-[#0B0F19] p-0.5"
                          >
                            <button
                              type="button"
                              onClick={() => onToggleVisibility(upd.id, "public")}
                              aria-pressed={upd.visibility === "public"}
                              className={`flex-1 inline-flex items-center justify-center gap-1 rounded-md px-2 py-1.5 text-[11px] font-extrabold transition-colors cursor-pointer ${
                                upd.visibility === "public"
                                  ? "bg-emerald-600 text-white"
                                  : "text-slate-400 hover:text-white"
                              }`}
                            >
                              <Eye className="h-3 w-3" />
                              <span>عام</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => onToggleVisibility(upd.id, "private")}
                              aria-pressed={upd.visibility === "private"}
                              className={`flex-1 inline-flex items-center justify-center gap-1 rounded-md px-2 py-1.5 text-[11px] font-extrabold transition-colors cursor-pointer ${
                                upd.visibility === "private"
                                  ? "bg-amber-600 text-white"
                                  : "text-slate-400 hover:text-white"
                              }`}
                            >
                              <Lock className="h-3 w-3" />
                              <span>خاص</span>
                            </button>
                          </div>

                          <button
                            type="button"
                            onClick={() => onDeleteUpdate(upd.id)}
                            title="حذف الميزة"
                            aria-label="حذف الميزة"
                            className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-rose-500/30 bg-rose-500/10 text-rose-300 hover:bg-rose-500/20 cursor-pointer shrink-0"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
