import React, { useEffect, useRef, useState } from "react";
import {
  Award,
  Camera,
  Check,
  CheckCircle2,
  Circle,
  Code2,
  Coins,
  Copy,
  Crown,
  Download,
  FolderArchive,
  Globe,
  HardDrive,
  Keyboard,
  Lock,
  Mail,
  Monitor,
  Palette,
  Save,
  Send,
  Shield,
  ShieldCheck,
  Smartphone,
  Sparkles,
  Trash2,
  User as UserIcon,
  Volume2,
  Wifi,
  WifiOff,
  X,
} from "lucide-react";
import { APP_VERSION, OWNER_PERSON, STORAGE_KEYS } from "../config/firebase";
import { DEFAULT_DEVELOPER_AVATAR, PRESET_AVATARS } from "../data/initialData";
import { BETA_PROGRAMMING_LANGUAGES } from "../data/siteConfig";
import { PWAInstallButton, useOnlineStatus } from "../hooks/usePWA";
import { AdVisibilityResult } from "../services/adManager";
import {
  DownloadedPackRecord,
  downloadOfflinePack,
  DownloadProgressSnapshot,
  loadDownloadedPacks,
  OFFLINE_DOWNLOAD_PACKS,
  OfflinePackId,
  removeOfflinePack,
} from "../services/offlineDownloads";
import {
  AdminRoleRequest,
  ProgrammingLanguageId,
  ThemeDecoration,
  UserProfile,
  UserRole,
} from "../types";
import { THEME_OPTIONS } from "./ThemeDecorationLayer";

interface AccountSettingsDrawerProps {
  isOpen: boolean;
  user: UserProfile | null;
  userRole: UserRole;
  themeDecoration: ThemeDecoration;
  desktopMode: boolean;
  secretDevUnlocked: boolean;
  codeRunsCount: number;
  hasUsedBridge: boolean;
  dnsAdBlockEnabled: boolean;
  adVisibility: AdVisibilityResult;
  speakerEnabled: boolean;
  betaEnabled: boolean;
  activeProgLang: ProgrammingLanguageId;
  kidsMode?: boolean;
  initialScrollTarget?:
    | "developer-category"
    | "admin-request"
    | "ad-dns-settings"
    | "speaker-settings"
    | "downloads"
    | null;
  onClose: () => void;
  onSaveProfile: (updates: {
    name: string;
    handle: string;
    city: string;
    avatarUrl: string;
    themeDecoration: ThemeDecoration;
    desktopMode: boolean;
  }) => void;
  onChangeTheme: (theme: ThemeDecoration) => void;
  onToggleDesktopMode: (enabled: boolean) => void;
  onToggleDnsAdBlock: (enabled: boolean) => void;
  onToggleSpeaker: (enabled: boolean) => void;
  onOpenBetaPlusSettings: () => void;
  onOpenCurrencyStore: () => void;
  onOpenVipShop: () => void;
  onBecomeDeveloper: () => void;
  onSubmitAdminRoleRequest: (req: {
    fullName: string;
    email: string;
    requestedRole: "admin" | "supervisor";
    note: string;
  }) => Promise<AdminRoleRequest>;
  onUnlockSecretDev: () => void;
  onOpenDeveloperOptions: () => void;
  onOpenAuth: () => void;
  onExitKidsMode?: () => void;
  iphoneFontEnabled?: boolean;
  onToggleIPhoneFont?: (enabled: boolean) => void;
  onOpenIPhoneKeyboard?: () => void;
  canExportSiteZip?: boolean;
  siteArchiveMeta?: {
    downloadUrl: string;
    sizeBytes: number;
    fileCount: number;
  } | null;
  siteArchiveProgress?: {
    active: boolean;
    percent: number;
    loadedMb: string;
    totalMb: string;
  } | null;
  onDownloadSiteArchive?: () => Promise<void> | void;
  onNotifySiteArchiveStarted?: (msg: string) => void;
}

const IRAQI_CITIES = [
  "بغداد",
  "البصرة",
  "أربيل",
  "النجف",
  "كربلاء",
  "الموصل",
  "السليمانية",
  "بابل",
  "ذي قار",
  "الأنبار",
];

function resizeAvatarToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const size = 160;
        const canvas = document.createElement("canvas");
        canvas.width = size;
        canvas.height = size;
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          reject(new Error("Canvas not available"));
          return;
        }
        const minSide = Math.min(img.width, img.height);
        const sx = (img.width - minSide) / 2;
        const sy = (img.height - minSide) / 2;
        ctx.drawImage(img, sx, sy, minSide, minSide, 0, 0, size, size);
        resolve(canvas.toDataURL("image/jpeg", 0.82));
      };
      img.onerror = () => reject(new Error("تعذر قراءة ملف الصورة"));
      img.src = String(reader.result || "");
    };
    reader.onerror = () => reject(new Error("تعذر فتح الصورة"));
    reader.readAsDataURL(file);
  });
}

export const AccountSettingsDrawer: React.FC<AccountSettingsDrawerProps> = ({
  isOpen,
  user,
  userRole,
  themeDecoration,
  desktopMode,
  secretDevUnlocked,
  codeRunsCount,
  hasUsedBridge,
  dnsAdBlockEnabled,
  adVisibility,
  speakerEnabled,
  betaEnabled,
  activeProgLang,
  kidsMode = false,
  initialScrollTarget,
  onClose,
  onSaveProfile,
  onChangeTheme,
  onToggleDesktopMode,
  onToggleDnsAdBlock,
  onToggleSpeaker,
  onOpenBetaPlusSettings,
  onOpenCurrencyStore,
  onOpenVipShop,
  onBecomeDeveloper,
  onSubmitAdminRoleRequest,
  onUnlockSecretDev,
  onOpenDeveloperOptions,
  onOpenAuth,
  onExitKidsMode,
  iphoneFontEnabled = true,
  onToggleIPhoneFont,
  onOpenIPhoneKeyboard,
  canExportSiteZip = false,
  siteArchiveMeta = null,
  siteArchiveProgress = null,
  onDownloadSiteArchive,
  onNotifySiteArchiveStarted,
}) => {
  const [nameDraft, setNameDraft] = useState(user?.name || "مطور عراقي");
  const [handleDraft, setHandleDraft] = useState(user?.handle || "@iraqi_dev");
  const [cityDraft, setCityDraft] = useState(user?.city || "بغداد");
  const [avatarDraft, setAvatarDraft] = useState(
    user?.avatarUrl || DEFAULT_DEVELOPER_AVATAR
  );
  const [themeDraft, setThemeDraft] = useState<ThemeDecoration>(themeDecoration);
  const [desktopDraft, setDesktopDraft] = useState<boolean>(desktopMode);
  const [avatarError, setAvatarError] = useState("");
  const [savedNotice, setSavedNotice] = useState(false);
  const [copiedOwnerEmail, setCopiedOwnerEmail] = useState(false);
  const [copiedZipLink, setCopiedZipLink] = useState(false);
  const [secretTapCount, setSecretTapCount] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Offline Downloads Manager State
  const isOnline = useOnlineStatus();
  const [downloadedPacks, setDownloadedPacks] = useState<
    DownloadedPackRecord[]
  >(() => loadDownloadedPacks());
  const [activeDownloadProgress, setActiveDownloadProgress] =
    useState<DownloadProgressSnapshot | null>(null);
  const [downloadStatusNotice, setDownloadStatusNotice] = useState<string>("");

  // "فئة المطور" (Developer Category) Interactive Tasks
  const [devTasks, setDevTasks] = useState<{
    identityReady: boolean;
    bridgeOrCodeTested: boolean;
    pledgeAccepted: boolean;
  }>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.DEV_TASKS);
      if (saved) {
        return JSON.parse(saved) as {
          identityReady: boolean;
          bridgeOrCodeTested: boolean;
          pledgeAccepted: boolean;
        };
      }
    } catch {
      // Safe fallback
    }
    return {
      identityReady: true,
      bridgeOrCodeTested: false,
      pledgeAccepted: false,
    };
  });

  // Admin / Supervisor Management Contact Form
  const [reqFullName, setReqFullName] = useState(user?.name || "");
  const [reqEmail, setReqEmail] = useState(user?.email || "");
  const [reqRoleType, setReqRoleType] = useState<"admin" | "supervisor">(
    "supervisor"
  );
  const [reqNote, setReqNote] = useState("");
  const [reqSubmitting, setReqSubmitting] = useState(false);
  const [submittedRequest, setSubmittedRequest] =
    useState<AdminRoleRequest | null>(() => {
      try {
        const saved = localStorage.getItem(STORAGE_KEYS.ROLE_REQUESTS);
        if (saved) {
          const list = JSON.parse(saved) as AdminRoleRequest[];
          return list[0] || null;
        }
      } catch {
        // Safe fallback
      }
      return null;
    });

  useEffect(() => {
    if (!isOpen) return;
    setNameDraft(user?.name || "مطور عراقي");
    setHandleDraft(user?.handle || "@iraqi_dev");
    setCityDraft(user?.city || "بغداد");
    setAvatarDraft(user?.avatarUrl || DEFAULT_DEVELOPER_AVATAR);
    setThemeDraft(themeDecoration);
    setDesktopDraft(desktopMode);
    if (user?.name && !reqFullName) setReqFullName(user.name);
    if (user?.email && !reqEmail) setReqEmail(user.email);
    setAvatarError("");
    setSavedNotice(false);
  }, [isOpen, user, themeDecoration, desktopMode, reqFullName, reqEmail]);

  // Auto-mark task 2 if user ran playground or used extension bridge
  useEffect(() => {
    if (codeRunsCount > 0 || hasUsedBridge) {
      setDevTasks((prev) => {
        if (prev.bridgeOrCodeTested) return prev;
        const next = { ...prev, bridgeOrCodeTested: true };
        try {
          localStorage.setItem(STORAGE_KEYS.DEV_TASKS, JSON.stringify(next));
        } catch {
          // Safe no-op
        }
        return next;
      });
    }
  }, [codeRunsCount, hasUsedBridge]);

  // Scroll smoothly into target section when opened via menu or ad banner
  useEffect(() => {
    if (!isOpen || !initialScrollTarget) return;
    const timer = window.setTimeout(() => {
      const targetId =
        initialScrollTarget === "developer-category"
          ? "developer-category-section"
          : initialScrollTarget === "ad-dns-settings"
          ? "ad-dns-settings-section"
          : initialScrollTarget === "speaker-settings"
          ? "speaker-settings-section"
          : initialScrollTarget === "downloads"
          ? "downloads-offline-section"
          : "admin-request-section";
      document
        .getElementById(targetId)
        ?.scrollIntoView({ behavior: "smooth", block: "center" });
    }, 180);
    return () => window.clearTimeout(timer);
  }, [isOpen, initialScrollTarget]);

  if (!isOpen) return null;

  const isDevOrAdmin =
    userRole === "developer" ||
    userRole === "director" ||
    userRole === "moderator" ||
    userRole === "admin";
  const canAccessDeveloperOptions =
    isDevOrAdmin &&
    (desktopMode || desktopDraft || secretDevUnlocked || userRole === "admin");

  const identityCompleted =
    devTasks.identityReady &&
    nameDraft.trim().length >= 2 &&
    handleDraft.trim().length >= 2;
  const allDevTasksCompleted =
    identityCompleted && devTasks.bridgeOrCodeTested && devTasks.pledgeAccepted;

  const toggleDevTask = (
    key: "identityReady" | "bridgeOrCodeTested" | "pledgeAccepted"
  ) => {
    setDevTasks((prev) => {
      const next = { ...prev, [key]: !prev[key] };
      try {
        localStorage.setItem(STORAGE_KEYS.DEV_TASKS, JSON.stringify(next));
      } catch {
        // Safe no-op
      }
      return next;
    });
  };

  const handleAvatarFileSelect = async (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setAvatarError("");
    try {
      const dataUrl = await resizeAvatarToDataUrl(file);
      if (dataUrl.length > 115000) {
        setAvatarError("حجم الصورة كبير جداً بعد الضغط، اختر صورة أصغر.");
        return;
      }
      setAvatarDraft(dataUrl);
    } catch {
      setAvatarError("تعذر معالجة الصورة المختارة. جرب صورة PNG أو JPG.");
    }
  };

  const handleSecretVersionTap = () => {
    const next = secretTapCount + 1;
    setSecretTapCount(next);
    if (next >= 3 && !secretDevUnlocked) {
      onUnlockSecretDev();
    }
  };

  const handleSubmitProfile = (e: React.FormEvent) => {
    e.preventDefault();
    const normalizedHandle = handleDraft.trim().startsWith("@")
      ? handleDraft.trim()
      : `@${handleDraft.trim() || "iraqi_dev"}`;

    onSaveProfile({
      name: nameDraft.trim() || "مطور عراقي",
      handle: normalizedHandle.slice(0, 40),
      city: cityDraft,
      avatarUrl: avatarDraft.trim() || DEFAULT_DEVELOPER_AVATAR,
      themeDecoration: themeDraft,
      desktopMode: desktopDraft,
    });
    setSavedNotice(true);
    window.setTimeout(() => setSavedNotice(false), 2600);
  };

  const handleSendAdminRoleRequest = async () => {
    if (!reqFullName.trim() || !reqEmail.trim() || !reqEmail.includes("@")) {
      return;
    }
    setReqSubmitting(true);
    try {
      const created = await onSubmitAdminRoleRequest({
        fullName: reqFullName.trim(),
        email: reqEmail.trim(),
        requestedRole: reqRoleType,
        note: reqNote.trim(),
      });
      setSubmittedRequest(created);
      setReqNote("");
    } finally {
      setReqSubmitting(false);
    }
  };

  const handleStartOfflineDownload = async (packId: OfflinePackId) => {
    if (activeDownloadProgress) return;
    setDownloadStatusNotice("");
    const targetPack = OFFLINE_DOWNLOAD_PACKS.find((p) => p.id === packId);
    if (!targetPack) return;

    setActiveDownloadProgress({
      packId,
      percent: 0,
      downloadedMb: 0,
      totalMb: targetPack.sizeMb,
    });

    try {
      const updated = await downloadOfflinePack(packId, (snap) => {
        setActiveDownloadProgress(snap);
      });
      setDownloadedPacks(updated);
      setDownloadStatusNotice(
        `تم تنزيل «${targetPack.title}» (${targetPack.sizeMb} MB) بنجاح — متاح الآن بدون إنترنت.`
      );
    } catch {
      setDownloadStatusNotice(
        "تعذر إكمال التنزيل المحلي. تأكد من اتصالك بالإنترنت وأعد المحاولة."
      );
    } finally {
      setActiveDownloadProgress(null);
    }
  };

  const handleDeleteOfflinePack = async (packId: OfflinePackId) => {
    if (activeDownloadProgress) return;
    const updated = await removeOfflinePack(packId);
    setDownloadedPacks(updated);
    setDownloadStatusNotice("تم حذف الحزمة المحفوظة من ذاكرة المتصفح.");
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="account-settings-title"
      className="fixed inset-0 z-50 flex justify-end bg-black/75 backdrop-blur-sm"
      onClick={onClose}
    >
      <aside
        onClick={(e) => e.stopPropagation()}
        className="flex h-full w-full max-w-lg flex-col border-r border-white/15 bg-[#0E1424] shadow-2xl overflow-y-auto"
      >
        {/* Top Bar */}
        <div className="sticky top-0 z-10 flex items-center justify-between gap-4 border-b border-white/10 bg-[#0E1424]/95 px-6 py-4 backdrop-blur-md">
          <div>
            <h2
              id="account-settings-title"
              className="text-lg font-extrabold text-white"
            >
              الملف الشخصي والرتب وفئة المطور
            </h2>
            <button
              type="button"
              onClick={handleSecretVersionTap}
              title="انقر 3 مرات لفتح وضع المطورين السري"
              className="mt-0.5 text-xs text-slate-400 hover:text-violet-300 cursor-pointer"
            >
              الإصدار {APP_VERSION} · مرّر للأسفل للوصول إلى «فئة المطور»
            </button>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="إغلاق إعدادات الحساب"
            className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 bg-white/5 text-slate-300 hover:bg-white/10 hover:text-white cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmitProfile} className="flex-1 space-y-6 p-6">
          {!user && (
            <div className="flex items-center justify-between gap-3 rounded-xl border border-violet-500/35 bg-violet-600/12 px-4 py-3">
              <p className="text-xs leading-relaxed text-violet-200">
                سجّل الدخول بحساب Google لحفظ تعديلات حسابك ورتبتك سحابياً.
              </p>
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenAuth();
                }}
                className="rounded-lg bg-violet-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-violet-500 shrink-0 cursor-pointer"
              >
                تسجيل الدخول
              </button>
            </div>
          )}

          {/* Current Rank Overview Card */}
          <div className="rounded-2xl border border-blue-500/35 bg-[#101729] p-4 space-y-2.5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                {userRole === "admin" ? (
                  <Crown className="h-4 w-4 text-amber-400" />
                ) : userRole === "director" ||
                  userRole === "moderator" ||
                  userRole === "developer" ? (
                  <Award className="h-4 w-4 text-emerald-400" />
                ) : (
                  <UserIcon className="h-4 w-4 text-sky-400" />
                )}
                <span className="text-xs font-extrabold text-white">
                  رتبتك الحالية في المنصة:
                </span>
              </div>

              <span
                className={`rounded-lg border px-2.5 py-1 text-[11px] font-extrabold ${
                  userRole === "admin"
                    ? "border-amber-400/50 bg-amber-500/15 text-amber-300"
                    : userRole === "director" || userRole === "moderator"
                    ? "border-violet-400/50 bg-violet-500/15 text-violet-300"
                    : userRole === "developer"
                    ? "border-emerald-400/50 bg-emerald-500/15 text-emerald-300"
                    : "border-sky-400/40 bg-sky-500/10 text-sky-300"
                }`}
              >
                {userRole === "admin"
                  ? "مسؤول الموقع (رافع الراس)"
                  : userRole === "director"
                  ? "مدير معتمد (Director)"
                  : userRole === "moderator"
                  ? "مشرف معتمد (Moderator)"
                  : userRole === "developer"
                  ? "مطور معتمد (شارة المطور)"
                  : "عضو عادي (وصول كامل للمنصة والجسر)"}
              </span>
            </div>

            <p className="text-[11px] leading-relaxed text-slate-300">
              {userRole === "admin"
                ? "تمتلك صلاحيات الإدارة الكاملة، إنشاء التحديات، فتح بيئة «المبرمج»، ونشر المنتجات."
                : userRole === "director"
                ? "تمتلك رتبة المدير (Director) وإنشاء التحديات وفتح بيئة «المبرمج» والنشر في المتجر."
                : userRole === "moderator"
                ? "تمتلك صلاحية المشرف لنشر المنتجات الخاصة في المتجر وإخفاء الإعلانات تلقائياً."
                : userRole === "developer"
                ? "تم منحك شارة المطور، إنشاء التحديات، بيئة «المبرمج» في النسخة التجريبية، واستوديو (/)."
                : "مرّر للأسفل لتفعيل «زر السماعة»، أو إكمال مهام «فئة المطور»، أو طلب رتبة مدير/مشرف."}
            </p>
          </div>

          {/* Section 1: Avatar Picker & Upload */}
          <div className="rounded-2xl border border-white/10 bg-[#0B0F19] p-4 space-y-4">
            <div className="flex items-center gap-4">
              <img
                src={avatarDraft}
                alt={nameDraft}
                referrerPolicy="no-referrer"
                className="h-16 w-16 rounded-full border-2 border-violet-500/60 object-cover shrink-0"
              />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-extrabold text-white truncate">
                  {nameDraft || "مطور عراقي"}
                </p>
                <p
                  dir="ltr"
                  className="text-xs font-mono text-emerald-400 truncate text-right"
                >
                  {handleDraft}
                </p>
                <div className="mt-2 flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-white/15 bg-white/5 px-3 py-1.5 text-xs font-bold text-slate-200 hover:bg-white/10 cursor-pointer"
                  >
                    <Camera className="h-3.5 w-3.5 text-emerald-400" />
                    <span>رفع صورة من جهازك</span>
                  </button>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleAvatarFileSelect}
                    className="hidden"
                  />
                </div>
              </div>
            </div>

            {avatarError && (
              <p className="text-xs font-semibold text-rose-300">
                {avatarError}
              </p>
            )}

            <div>
              <p className="mb-2 text-xs font-bold text-slate-400">
                أو اختر أفاتار جاهز للمطورين:
              </p>
              <div className="grid grid-cols-4 gap-2">
                {PRESET_AVATARS.map((preset) => {
                  const selected = avatarDraft === preset.url;
                  return (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() => setAvatarDraft(preset.url)}
                      className={`flex flex-col items-center gap-1.5 rounded-xl border p-2 text-[11px] font-semibold transition-colors cursor-pointer ${
                        selected
                          ? "border-emerald-400 bg-emerald-500/15 text-emerald-200"
                          : "border-white/10 bg-[#111827] text-slate-300 hover:border-white/25"
                      }`}
                    >
                      <img
                        src={preset.url}
                        alt={preset.label}
                        className="h-9 w-9 rounded-full object-cover"
                      />
                      <span className="truncate w-full text-center">
                        {preset.label}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <label
                htmlFor="settings-avatar-url"
                className="block text-xs font-bold text-slate-300 mb-1.5"
              >
                رابط الصورة الشخصية (URL)
              </label>
              <input
                id="settings-avatar-url"
                type="url"
                dir="ltr"
                value={avatarDraft.startsWith("data:") ? "" : avatarDraft}
                onChange={(e) => setAvatarDraft(e.target.value)}
                placeholder="https://..."
                className="h-10 w-full rounded-xl border border-white/10 bg-[#111827] px-3 font-mono text-xs text-white placeholder:text-slate-500 focus:border-violet-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Section 2: Identity Fields */}
          <div className="rounded-2xl border border-white/10 bg-[#0B0F19] p-4 space-y-4">
            <div className="flex items-center gap-2 text-sm font-extrabold text-white">
              <UserIcon className="h-4 w-4 text-violet-400" />
              <span>بيانات الهوية والمعرّف</span>
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <label
                  htmlFor="settings-display-name"
                  className="block text-xs font-bold text-slate-300 mb-1.5"
                >
                  الاسم المعروض
                </label>
                <input
                  id="settings-display-name"
                  type="text"
                  required
                  maxLength={120}
                  value={nameDraft}
                  onChange={(e) => setNameDraft(e.target.value)}
                  className="h-10 w-full rounded-xl border border-white/10 bg-[#111827] px-3 text-xs text-white focus:border-violet-500 focus:outline-none"
                />
              </div>

              <div>
                <label
                  htmlFor="settings-handle"
                  className="block text-xs font-bold text-slate-300 mb-1.5"
                >
                  معرّف المطور (User ID / Handle)
                </label>
                <input
                  id="settings-handle"
                  type="text"
                  dir="ltr"
                  required
                  maxLength={40}
                  value={handleDraft}
                  onChange={(e) => setHandleDraft(e.target.value)}
                  placeholder="@iraqi_coder"
                  className="h-10 w-full rounded-xl border border-white/10 bg-[#111827] px-3 font-mono text-xs text-emerald-300 focus:border-violet-500 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label
                htmlFor="settings-city"
                className="block text-xs font-bold text-slate-300 mb-1.5"
              >
                المحافظة
              </label>
              <select
                id="settings-city"
                value={cityDraft}
                onChange={(e) => setCityDraft(e.target.value)}
                className="h-10 w-full rounded-xl border border-white/10 bg-[#111827] px-3 text-xs text-white focus:border-violet-500 focus:outline-none"
              >
                {IRAQI_CITIES.map((city) => (
                  <option key={city} value={city}>
                    {city}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Section 3: Theme Decorations */}
          <div className="rounded-2xl border border-white/10 bg-[#0B0F19] p-4 space-y-3">
            <div className="flex items-center gap-2 text-sm font-extrabold text-white">
              <Palette className="h-4 w-4 text-emerald-400" />
              <span>الثيمات والزينات التفاعلية</span>
            </div>
            <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
              {THEME_OPTIONS.map((opt) => {
                const active = themeDraft === opt.id;
                return (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => {
                      setThemeDraft(opt.id);
                      onChangeTheme(opt.id);
                    }}
                    className={`flex flex-col items-start gap-1 rounded-xl border p-3 text-right transition-all cursor-pointer ${
                      active
                        ? "border-emerald-400/70 bg-emerald-500/12"
                        : "border-white/10 bg-[#111827] hover:border-white/25"
                    }`}
                  >
                    <div className="flex w-full items-center justify-between gap-2">
                      <span className="text-xs font-extrabold text-white">
                        {opt.label}
                      </span>
                      <span
                        className="h-3 w-3 rounded-full shrink-0"
                        style={{ backgroundColor: opt.accentHex }}
                      />
                    </div>
                    <p className="text-[11px] leading-relaxed text-slate-400">
                      {opt.subtitle}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Section 4: Mobile vs Desktop Mode & Hidden Developer Options */}
          <div className="rounded-2xl border border-white/10 bg-[#0B0F19] p-4 space-y-3">
            <div>
              <p className="text-xs font-extrabold text-white">
                وضع العرض (تبديل الموبايل وسطح المكتب)
              </p>
              <p className="text-[11px] text-slate-400 mt-0.5">
                يتكيف وضع الموبايل تلقائياً مع شاشة الهاتف، بينما يفرض وضع سطح
                المكتب عرض 1240px الكامل.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => {
                  setDesktopDraft(false);
                  onToggleDesktopMode(false);
                }}
                className={`inline-flex items-center justify-center gap-2 rounded-xl border py-2.5 text-xs font-extrabold transition-colors cursor-pointer ${
                  !desktopDraft
                    ? "border-violet-400 bg-violet-600/25 text-white"
                    : "border-white/10 bg-[#111827] text-slate-400 hover:text-white"
                }`}
              >
                <span>وضع الموبايل</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setDesktopDraft(true);
                  onToggleDesktopMode(true);
                }}
                className={`inline-flex items-center justify-center gap-2 rounded-xl border py-2.5 text-xs font-extrabold transition-colors cursor-pointer ${
                  desktopDraft
                    ? "border-emerald-400 bg-emerald-600/25 text-emerald-200"
                    : "border-white/10 bg-[#111827] text-slate-400 hover:text-white"
                }`}
              >
                <Monitor className="h-4 w-4" />
                <span>وضع سطح المكتب</span>
              </button>
            </div>

            {canAccessDeveloperOptions ? (
              <div className="rounded-xl border border-violet-500/40 bg-violet-600/15 p-3 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="inline-flex items-center gap-1.5 text-xs font-extrabold text-violet-200">
                    <Code2 className="h-4 w-4 text-emerald-400" />
                    <span>خيارات المطورين (مفتوحة)</span>
                  </span>
                  <ShieldCheck className="h-4 w-4 text-emerald-400" />
                </div>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenDeveloperOptions();
                  }}
                  className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-violet-600 py-2 text-xs font-extrabold text-white hover:bg-violet-500 cursor-pointer"
                >
                  <Code2 className="h-4 w-4" />
                  <span>فتح خيارات المطورين</span>
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2 rounded-xl border border-white/10 bg-[#111827] px-3 py-2.5 text-[11px] text-slate-400">
                <Lock className="h-3.5 w-3.5 text-amber-400 shrink-0" />
                <span>
                  {isDevOrAdmin
                    ? "فعّل «وضع سطح المكتب» أو اضغط 3 مرات على رقم الإصدار لفتح خيارات المطورين."
                    : "أكمل مهام «فئة المطور» أدناه للحصول على شارة المطور وصلاحياتها."}
                </span>
              </div>
            )}
          </div>

          {/* Section 4.5: Site Ads Management & In-Site DNS Toggle */}
          <div
            id="ad-dns-settings-section"
            className="rounded-2xl border border-sky-500/35 bg-[#09121E] p-4 space-y-3.5"
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-2.5">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-sky-400/40 bg-sky-500/15 text-sky-300">
                  <Globe className="h-4 w-4" />
                </div>
                <div>
                  <h3 className="text-sm font-extrabold text-white">
                    إدارة الإعلانات ووضع DNS من الموقع
                  </h3>
                  <p className="text-[11px] leading-relaxed text-slate-400 mt-0.5">
                    تختفي الإعلانات تلقائياً لمشتركي VIP (مدفوع أو عملات)، رتبة
                    المشرف، أو عند تفعيل وضع DNS مباشرة من هنا.
                  </p>
                </div>
              </div>
            </div>

            {/* Live Verification Status Banner */}
            <div
              className={`rounded-xl border px-3.5 py-2.5 text-xs font-bold flex items-center gap-2 ${
                adVisibility.isExempt
                  ? "border-emerald-400/45 bg-emerald-500/12 text-emerald-200"
                  : "border-amber-400/35 bg-amber-500/10 text-amber-200"
              }`}
            >
              <Shield className="h-4 w-4 shrink-0" />
              <span>{adVisibility.reasonLabel}</span>
            </div>

            {/* Direct In-Site DNS Toggle */}
            <div className="flex items-center justify-between gap-3 rounded-xl border border-white/10 bg-[#0B0F19] p-3">
              <div>
                <p className="text-xs font-extrabold text-white">
                  تفعيل وضع DNS لحجب الإعلانات (إعدادات الموقع)
                </p>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  يعمل مباشرة داخل المتصفح دون الحاجة لتعديل إعدادات الهاتف، ويُحفظ
                  تفضيلك تلقائياً.
                </p>
              </div>

              <button
                type="button"
                role="switch"
                aria-checked={dnsAdBlockEnabled}
                onClick={() => onToggleDnsAdBlock(!dnsAdBlockEnabled)}
                className={`relative inline-flex h-7 w-13 shrink-0 items-center rounded-full border transition-colors cursor-pointer ${
                  dnsAdBlockEnabled
                    ? "border-emerald-400 bg-emerald-600"
                    : "border-white/20 bg-slate-700"
                }`}
              >
                <span
                  className={`inline-block h-5 w-5 transform rounded-full bg-white transition-transform ${
                    dnsAdBlockEnabled ? "-translate-x-7" : "-translate-x-1"
                  }`}
                />
              </button>
            </div>

            {/* 3 Exemption Conditions Breakdown */}
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-3 text-[11px]">
              <div
                className={`rounded-xl border px-3 py-2 font-bold ${
                  adVisibility.activeRules.vipSubscription
                    ? "border-emerald-400/45 bg-emerald-500/10 text-emerald-200"
                    : "border-white/10 bg-[#0B0F19] text-slate-400"
                }`}
              >
                1. اشتراك VIP:{" "}
                {adVisibility.activeRules.vipSubscription ? "مفعّل ✓" : "غير مشترك"}
              </div>
              <div
                className={`rounded-xl border px-3 py-2 font-bold ${
                  adVisibility.activeRules.supervisorRole
                    ? "border-emerald-400/45 bg-emerald-500/10 text-emerald-200"
                    : "border-white/10 bg-[#0B0F19] text-slate-400"
                }`}
              >
                2. رتبة المشرف:{" "}
                {adVisibility.activeRules.supervisorRole ? "مفعّل ✓" : "عضو عادي"}
              </div>
              <div
                className={`rounded-xl border px-3 py-2 font-bold ${
                  adVisibility.activeRules.siteDnsMode
                    ? "border-emerald-400/45 bg-emerald-500/10 text-emerald-200"
                    : "border-white/10 bg-[#0B0F19] text-slate-400"
                }`}
              >
                3. وضع DNS الموقع:{" "}
                {adVisibility.activeRules.siteDnsMode ? "مفعّل ✓" : "متوقف"}
              </div>
            </div>

            {!adVisibility.activeRules.vipSubscription && (
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenCurrencyStore();
                  }}
                  className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-xl border border-amber-400/40 bg-amber-500/10 py-2 px-3 text-[11px] font-extrabold text-amber-200 hover:bg-amber-500/20 cursor-pointer"
                >
                  <Coins className="h-3.5 w-3.5" />
                  <span>اشترك VIP بالعملات</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenVipShop();
                  }}
                  className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-xl border border-violet-400/40 bg-violet-600/20 py-2 px-3 text-[11px] font-extrabold text-violet-200 hover:bg-violet-600/30 cursor-pointer"
                >
                  <Crown className="h-3.5 w-3.5" />
                  <span>اشتراك VIP من المتجر</span>
                </button>
              </div>
            )}
          </div>

          {/* Section 4.6: زر السماعة (Arabic Accessibility Speaker - Main & Beta) + Beta Plus Shortcut */}
          <div
            id="speaker-settings-section"
            className="rounded-2xl border border-emerald-500/35 bg-[#091815] p-4 space-y-3.5"
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-2.5">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-emerald-400/40 bg-emerald-500/15 text-emerald-300">
                  <Volume2 className="h-4 w-4" />
                </div>
                <div>
                  <h3 className="text-sm font-extrabold text-white">
                    زر السماعة (قراءة النصوص بالعربية الفصحى)
                  </h3>
                  <p className="text-[11px] leading-relaxed text-slate-400 mt-0.5">
                    متاح في النسخة الأساسية والنسخة التجريبية: عند تفعيله تظهر دائرة سماعة عائمة قابلة للسحب مع زر X لإيقاف القراءة فوراً.
                  </p>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between gap-3 rounded-xl border border-white/10 bg-[#0B0F19] p-3">
              <div>
                <p className="text-xs font-extrabold text-white">
                  تفعيل زر السماعة الفصحى (مساعدة المكفوفين والمبتدئين)
                </p>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  اضغط على أي زر أو عنوان أو كلمة في الموقع ليقرأها بصوت عربي فصيح.
                </p>
              </div>

              <button
                type="button"
                role="switch"
                aria-checked={speakerEnabled}
                onClick={() => onToggleSpeaker(!speakerEnabled)}
                className={`relative inline-flex h-7 w-13 shrink-0 items-center rounded-full border transition-colors cursor-pointer ${
                  speakerEnabled
                    ? "border-emerald-400 bg-emerald-600"
                    : "border-white/20 bg-slate-700"
                }`}
              >
                <span
                  className={`inline-block h-5 w-5 transform rounded-full bg-white transition-transform ${
                    speakerEnabled ? "-translate-x-7" : "-translate-x-1"
                  }`}
                />
              </button>
            </div>

            {betaEnabled && (
              <div className="rounded-xl border border-fuchsia-400/40 bg-fuchsia-500/10 p-3 flex flex-wrap items-center justify-between gap-2">
                <div className="text-[11px]">
                  <p className="font-extrabold text-fuchsia-200">
                    إعدادات بلس (النسخة التجريبية مفعّلة)
                  </p>
                  <p className="text-slate-300 mt-0.5">
                    لغة المحرك الحالية:{" "}
                    <span className="font-mono font-bold text-amber-300">
                      {BETA_PROGRAMMING_LANGUAGES.find((l) => l.id === activeProgLang)?.name ||
                        activeProgLang}
                    </span>
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenBetaPlusSettings();
                  }}
                  className="rounded-lg bg-fuchsia-600 px-3 py-1.5 text-[11px] font-extrabold text-white hover:bg-fuchsia-500 cursor-pointer"
                >
                  فتح إعدادات بلس والمبرمج
                </button>
              </div>
            )}
          </div>

          {/* Section 4.7: التحميلات (Downloads & Offline Site Access) */}
          <div
            id="downloads-offline-section"
            className="rounded-2xl border border-indigo-400/40 bg-[#0B1120] p-4 space-y-3.5"
          >
            <div className="flex flex-wrap items-start justify-between gap-2.5">
              <div className="flex items-start gap-2.5">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-indigo-400/40 bg-indigo-500/15 text-indigo-300">
                  <HardDrive className="h-4 w-4" />
                </div>
                <div>
                  <h3 className="text-sm font-extrabold text-white">
                    التحميلات (تصفح الموقع بدون إنترنت)
                  </h3>
                  <p className="text-[11px] leading-relaxed text-slate-400 mt-0.5">
                    اختر الأقسام التي ترغب بحفظها محلياً أو قم بتنزيل الموقع بالكامل
                    بمدة تحميل تتناسب مع حجم كل حزمة بالميغابايت.
                  </p>
                </div>
              </div>

              <span
                className={`inline-flex items-center gap-1 rounded-lg border px-2.5 py-1 text-[10px] font-extrabold shrink-0 ${
                  isOnline
                    ? "border-emerald-400/40 bg-emerald-500/15 text-emerald-200"
                    : "border-amber-400/50 bg-amber-500/15 text-amber-200"
                }`}
              >
                {isOnline ? (
                  <>
                    <Wifi className="h-3 w-3" />
                    <span>متصل (التصفح المباشر)</span>
                  </>
                ) : (
                  <>
                    <WifiOff className="h-3 w-3" />
                    <span>وضع عدم الاتصال</span>
                  </>
                )}
              </span>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-white/10 bg-[#080C17] px-3 py-2.5 text-[11px] text-slate-300">
              <span className="leading-relaxed">
                عند وجود إنترنت يبقى التصفح المباشر والحي مفعّلاً دائماً، بينما
                تتطلب الميزات السحابية وتأكيد الطلبات ومساعدي الذكاء الاصطناعي
                اتصالاً بالإنترنت.
              </span>
              <PWAInstallButton />
            </div>

            {downloadStatusNotice && (
              <div className="rounded-xl border border-emerald-400/40 bg-emerald-500/12 px-3 py-2 text-[11px] font-bold text-emerald-200">
                {downloadStatusNotice}
              </div>
            )}

            <div className="space-y-2.5">
              {OFFLINE_DOWNLOAD_PACKS.map((pack) => {
                const savedRecord = downloadedPacks.find((d) => d.id === pack.id);
                const isDownloadingThis =
                  activeDownloadProgress?.packId === pack.id;
                const anotherDownloading =
                  Boolean(activeDownloadProgress) && !isDownloadingThis;

                return (
                  <div
                    key={pack.id}
                    className={`rounded-xl border p-3 transition-colors space-y-2 ${
                      pack.isFullSite
                        ? "border-emerald-400/45 bg-gradient-to-l from-emerald-500/12 to-indigo-500/12"
                        : savedRecord
                        ? "border-indigo-400/40 bg-indigo-500/10"
                        : "border-white/10 bg-[#0E1424]"
                    }`}
                  >
                    <div className="flex flex-wrap items-start justify-between gap-2">
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="text-xs font-extrabold text-white">
                            {pack.title}
                          </span>
                          <span
                            dir="ltr"
                            className="rounded-md border border-white/15 bg-black/35 px-2 py-0.5 font-mono text-[10px] font-bold text-sky-300 tabular-nums"
                          >
                            {pack.sizeMb} MB
                          </span>
                          {savedRecord && !isDownloadingThis && (
                            <span className="inline-flex items-center gap-1 rounded-md border border-emerald-400/40 bg-emerald-500/15 px-2 py-0.5 text-[10px] font-extrabold text-emerald-200">
                              <CheckCircle2 className="h-3 w-3" />
                              <span>محمّل بدون نت</span>
                            </span>
                          )}
                        </div>
                        <p className="mt-1 text-[11px] leading-relaxed text-slate-400">
                          {pack.description}
                        </p>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          type="button"
                          disabled={isDownloadingThis || anotherDownloading}
                          onClick={() => void handleStartOfflineDownload(pack.id)}
                          className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-[11px] font-extrabold transition-colors cursor-pointer disabled:opacity-50 ${
                            pack.isFullSite
                              ? "bg-emerald-600 text-white hover:bg-emerald-500"
                              : "bg-indigo-600 text-white hover:bg-indigo-500"
                          }`}
                        >
                          <Download className="h-3.5 w-3.5" />
                          <span>
                            {isDownloadingThis
                              ? `جاري التنزيل ${activeDownloadProgress?.percent}%`
                              : savedRecord
                              ? `تحديث (${pack.sizeMb} MB)`
                              : pack.isFullSite
                              ? `تنزيل كل الموقع (${pack.sizeMb} MB)`
                              : `تنزيل (${pack.sizeMb} MB)`}
                          </span>
                        </button>

                        {savedRecord && !isDownloadingThis && (
                          <button
                            type="button"
                            onClick={() => void handleDeleteOfflinePack(pack.id)}
                            aria-label={`حذف تنزيل ${pack.title}`}
                            title="حذف الملفات المحفوظة لهذه الحزمة"
                            className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-white/10 bg-white/5 text-slate-400 hover:border-rose-400/40 hover:bg-rose-500/15 hover:text-rose-300 cursor-pointer"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        )}
                      </div>
                    </div>

                    {isDownloadingThis && activeDownloadProgress && (
                      <div className="space-y-1 pt-1">
                        <div className="flex items-center justify-between text-[10px] font-mono text-emerald-300 tabular-nums">
                          <span>
                            {activeDownloadProgress.downloadedMb} MB /{" "}
                            {activeDownloadProgress.totalMb} MB
                          </span>
                          <span>{activeDownloadProgress.percent}%</span>
                        </div>
                        <div className="h-2 w-full overflow-hidden rounded-full bg-black/50">
                          <div
                            className="h-full rounded-full bg-gradient-to-l from-emerald-400 to-indigo-400 transition-all duration-150"
                            style={{
                              width: `${activeDownloadProgress.percent}%`,
                            }}
                          />
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* iPhone Pack (Font + Emojis + Keyboard) + Ready-to-Deploy Website Folder ZIP Export */}
            <div className="space-y-3 border-t border-white/10 pt-3">
              <div className="rounded-xl border border-sky-400/40 bg-[#081221] p-3.5 space-y-2.5">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-start gap-2">
                    <Smartphone className="h-4 w-4 text-sky-400 shrink-0 mt-0.5" />
                    <div>
                      <p className="text-xs font-extrabold text-white">
                        حزمة الآيفون (الخط + الإيموجيات + الكيبورد)
                      </p>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        خط الآيفون وإيموجيات الآيفون مع كيبورد iOS تفاعلي يكتب في أي حقل بالموقع.
                      </p>
                    </div>
                  </div>
                  {onToggleIPhoneFont && (
                    <button
                      type="button"
                      role="switch"
                      aria-checked={iphoneFontEnabled}
                      onClick={() => onToggleIPhoneFont(!iphoneFontEnabled)}
                      className={`relative inline-flex h-6 w-11 shrink-0 items-center rounded-full border transition-colors cursor-pointer ${
                        iphoneFontEnabled
                          ? "border-emerald-400 bg-emerald-600"
                          : "border-white/20 bg-slate-700"
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          iphoneFontEnabled ? "-translate-x-6" : "-translate-x-1"
                        }`}
                      />
                    </button>
                  )}
                </div>

                {onOpenIPhoneKeyboard && (
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onOpenIPhoneKeyboard();
                    }}
                    className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-[#0A84FF] py-2 text-xs font-extrabold text-white hover:bg-[#1E8FFF] cursor-pointer"
                  >
                    <Keyboard className="h-4 w-4" />
                    <span>فتح كيبورد وإيموجيات الآيفون الآن</span>
                  </button>
                )}
              </div>

              {(userRole === "admin" || canExportSiteZip) && onDownloadSiteArchive && (
                <div className="rounded-xl border border-emerald-400/50 bg-gradient-to-l from-emerald-500/15 to-sky-500/15 p-3.5 space-y-2.5">
                  <div className="flex items-start gap-2.5">
                    <FolderArchive className="h-5 w-5 text-emerald-300 shrink-0 mt-0.5" />
                    <div>
                      <p className="text-xs font-extrabold text-white">
                        خاص بالمسؤولين: نزل ملف الموقع (.ZIP)
                      </p>
                      <p className="text-[11px] leading-relaxed text-slate-300 mt-0.5">
                        ملف مضغوط بداخله مجلد يضم جميع ملفات الموقع الجاهزة للنشر
                        والكود المصدري الكامل لإنشاء نسخة مطابقة.
                      </p>
                      {siteArchiveMeta && (
                        <p className="text-[11px] font-bold text-emerald-300 tabular-nums mt-1">
                          جاهز فوراً · {siteArchiveMeta.fileCount} ملف حقيقي ·{" "}
                          {(siteArchiveMeta.sizeBytes / (1024 * 1024)).toFixed(1)} MB
                        </p>
                      )}
                    </div>
                  </div>

                  {siteArchiveMeta?.downloadUrl ? (
                    <a
                      href={siteArchiveMeta.downloadUrl}
                      download="iraqi-coders-website-complete.zip"
                      onClick={() =>
                        onNotifySiteArchiveStarted?.(
                          "بدأ التنزيل الحقيقي لملف الموقع المضغوط في المتصفح!"
                        )
                      }
                      className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-600 py-2.5 px-4 text-xs font-extrabold text-white shadow-lg hover:bg-emerald-500 transition-colors cursor-pointer"
                    >
                      <Download className="h-4 w-4" />
                      <span>نزل ملف الموقع (.ZIP) الآن</span>
                    </a>
                  ) : (
                    <button
                      type="button"
                      onClick={() => void onDownloadSiteArchive()}
                      className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-600 py-2.5 px-4 text-xs font-extrabold text-white shadow-lg hover:bg-emerald-500 transition-colors cursor-pointer"
                    >
                      <Download className="h-4 w-4" />
                      <span>نزل ملف الموقع (.ZIP)</span>
                    </button>
                  )}

                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      disabled={Boolean(siteArchiveProgress?.active)}
                      onClick={() => void onDownloadSiteArchive()}
                      className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-lg border border-emerald-400/35 bg-emerald-950/60 py-2 px-3 text-[11px] font-bold text-emerald-200 hover:bg-emerald-900/70 disabled:opacity-60 cursor-pointer"
                    >
                      <FolderArchive className="h-3.5 w-3.5" />
                      <span>
                        {siteArchiveProgress?.active
                          ? `جاري التحميل ${siteArchiveProgress.percent}%`
                          : "تنزيل مع مؤشر التقدم %"}
                      </span>
                    </button>

                    {siteArchiveMeta?.downloadUrl && (
                      <button
                        type="button"
                        onClick={() => {
                          const fullUrl = new URL(
                            siteArchiveMeta.downloadUrl,
                            window.location.origin
                          ).toString();
                          void navigator.clipboard
                            .writeText(fullUrl)
                            .then(() => {
                              setCopiedZipLink(true);
                              onNotifySiteArchiveStarted?.(
                                "تم نسخ رابط التنزيل المباشر للملف!"
                              );
                              window.setTimeout(
                                () => setCopiedZipLink(false),
                                2500
                              );
                            });
                        }}
                        className="inline-flex items-center justify-center gap-1.5 rounded-lg border border-white/15 bg-white/5 py-2 px-3 text-[11px] font-bold text-slate-200 hover:bg-white/10 cursor-pointer"
                      >
                        {copiedZipLink ? (
                          <Check className="h-3.5 w-3.5 text-emerald-400" />
                        ) : (
                          <Copy className="h-3.5 w-3.5" />
                        )}
                        <span>{copiedZipLink ? "تم النسخ" : "نسخ الرابط"}</span>
                      </button>
                    )}
                  </div>

                  {siteArchiveProgress && (
                    <div className="space-y-1 pt-0.5">
                      <div className="flex items-center justify-between text-[11px] font-bold text-emerald-200 tabular-nums">
                        <span>
                          {siteArchiveProgress.active
                            ? "جاري التحميل من السيرفر..."
                            : "تم حفظ الملف بنجاح 100%!"}
                        </span>
                        <span>
                          {siteArchiveProgress.loadedMb} /{" "}
                          {siteArchiveProgress.totalMb} MB (
                          {siteArchiveProgress.percent}%)
                        </span>
                      </div>
                      <div className="h-1.5 w-full overflow-hidden rounded-full bg-black/40">
                        <div
                          className="h-full bg-emerald-400 transition-all duration-150"
                          style={{ width: `${siteArchiveProgress.percent}%` }}
                        />
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Section 5: "فئة المطور" (Developer Category) Task Checklist -> Instant Badge + Permissions */}
          <div
            id="developer-category-section"
            className="rounded-2xl border border-emerald-500/40 bg-[#0B141D] p-4 space-y-3"
          >
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Award className="h-5 w-5 text-emerald-400" />
                <div>
                  <h3 className="text-sm font-extrabold text-white">
                    فئة المطور (Developer Category)
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    أكمل المهام المطلوبة واحصل فوراً على شارة وصلاحيات المطور
                  </p>
                </div>
              </div>
              {isDevOrAdmin && (
                <span className="inline-flex items-center gap-1 rounded-lg border border-emerald-400/50 bg-emerald-500/20 px-2.5 py-1 text-[11px] font-extrabold text-emerald-200">
                  <CheckCircle2 className="h-3.5 w-3.5" />
                  <span>شارة مطور مفعّلة</span>
                </span>
              )}
            </div>

            <div className="space-y-2">
              <button
                type="button"
                onClick={() => toggleDevTask("identityReady")}
                className={`flex w-full items-center justify-between gap-3 rounded-xl border p-3 text-right transition-colors cursor-pointer ${
                  identityCompleted
                    ? "border-emerald-400/45 bg-emerald-500/10 text-emerald-100"
                    : "border-white/10 bg-[#0B0F19] text-slate-300"
                }`}
              >
                <div className="flex items-center gap-2.5">
                  {identityCompleted ? (
                    <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
                  ) : (
                    <Circle className="h-4 w-4 text-slate-500 shrink-0" />
                  )}
                  <span className="text-xs font-bold">
                    1. تجهيز الاسم والمعرّف البرمجي ({handleDraft})
                  </span>
                </div>
                <span className="text-[10px] font-bold text-emerald-300">
                  {identityCompleted ? "مكتمل" : "انقر للتأكيد"}
                </span>
              </button>

              <button
                type="button"
                onClick={() => toggleDevTask("bridgeOrCodeTested")}
                className={`flex w-full items-center justify-between gap-3 rounded-xl border p-3 text-right transition-colors cursor-pointer ${
                  devTasks.bridgeOrCodeTested
                    ? "border-emerald-400/45 bg-emerald-500/10 text-emerald-100"
                    : "border-white/10 bg-[#0B0F19] text-slate-300"
                }`}
              >
                <div className="flex items-center gap-2.5">
                  {devTasks.bridgeOrCodeTested ? (
                    <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
                  ) : (
                    <Circle className="h-4 w-4 text-slate-500 shrink-0" />
                  )}
                  <span className="text-xs font-bold">
                    2. استكشاف جسر الإضافة أو تشغيل محرر الكود
                  </span>
                </div>
                <span className="text-[10px] font-bold text-sky-300">
                  {devTasks.bridgeOrCodeTested ? "مكتمل" : "تأكيد الاستكشاف"}
                </span>
              </button>

              <button
                type="button"
                onClick={() => toggleDevTask("pledgeAccepted")}
                className={`flex w-full items-center justify-between gap-3 rounded-xl border p-3 text-right transition-colors cursor-pointer ${
                  devTasks.pledgeAccepted
                    ? "border-emerald-400/45 bg-emerald-500/10 text-emerald-100"
                    : "border-white/10 bg-[#0B0F19] text-slate-300"
                }`}
              >
                <div className="flex items-center gap-2.5">
                  {devTasks.pledgeAccepted ? (
                    <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
                  ) : (
                    <Circle className="h-4 w-4 text-slate-500 shrink-0" />
                  )}
                  <span className="text-xs font-bold">
                    3. التعهد بالالتزام بمعايير عراقي كودرز ومشاريع المجتمع
                  </span>
                </div>
                <span className="text-[10px] font-bold text-amber-300">
                  {devTasks.pledgeAccepted ? "موافق" : "أوافق"}
                </span>
              </button>
            </div>

            {userRole === "user" && (
              <button
                type="button"
                disabled={!allDevTasksCompleted}
                onClick={onBecomeDeveloper}
                className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-l from-emerald-600 to-blue-600 py-2.5 text-xs font-extrabold text-white shadow-lg transition-opacity hover:opacity-95 disabled:opacity-45 cursor-pointer"
              >
                <Sparkles className="h-4 w-4" />
                <span>
                  {allDevTasksCompleted
                    ? "إتمام المهام واستلام شارة المطور الآن"
                    : "أكمل المهام الثلاثة أعلاه لتفعيل شارة المطور"}
                </span>
              </button>
            )}
          </div>

          {/* Section 6: Admin / Supervisor Role Request (Contact Management with Name & Email) */}
          <div
            id="admin-request-section"
            className="rounded-2xl border border-amber-500/35 bg-[#15120A] p-4 space-y-3"
          >
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Crown className="h-5 w-5 text-amber-400" />
                <div>
                  <h3 className="text-sm font-extrabold text-white">
                    طلب رتبة مدير / مشرف (التواصل مع الإدارة)
                  </h3>
                  <p className="text-[11px] text-slate-300">
                    المسؤول:{" "}
                    <span className="font-bold text-amber-200">
                      {OWNER_PERSON.displayName}
                    </span>{" "}
                    (<span dir="ltr" className="font-mono text-emerald-300">{OWNER_PERSON.handle}</span>){" "}
                    ·{" "}
                    <span dir="ltr" className="font-mono text-amber-300">
                      {OWNER_PERSON.email}
                    </span>
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  void navigator.clipboard
                    ?.writeText(OWNER_PERSON.email)
                    .then(() => {
                      setCopiedOwnerEmail(true);
                      window.setTimeout(() => setCopiedOwnerEmail(false), 1800);
                    })
                    .catch(() => undefined);
                }}
                className="inline-flex items-center gap-1 rounded-lg border border-amber-400/35 bg-amber-500/10 px-2.5 py-1 text-[11px] font-bold text-amber-200 hover:bg-amber-500/20 cursor-pointer"
              >
                {copiedOwnerEmail ? (
                  <>
                    <Check className="h-3 w-3 text-emerald-400" />
                    <span>تم النسخ</span>
                  </>
                ) : (
                  <>
                    <Copy className="h-3 w-3" />
                    <span>نسخ البريد</span>
                  </>
                )}
              </button>
            </div>

            <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
              <input
                type="text"
                placeholder="الاسم الكامل"
                value={reqFullName}
                onChange={(e) => setReqFullName(e.target.value)}
                className="h-10 rounded-xl border border-white/15 bg-[#0B0F19] px-3 text-xs text-white focus:border-amber-400 focus:outline-none"
              />
              <input
                type="email"
                dir="ltr"
                placeholder="name@example.com"
                value={reqEmail}
                onChange={(e) => setReqEmail(e.target.value)}
                className="h-10 rounded-xl border border-white/15 bg-[#0B0F19] px-3 font-mono text-xs text-white focus:border-amber-400 focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setReqRoleType("supervisor")}
                className={`rounded-xl border py-2 text-xs font-extrabold cursor-pointer ${
                  reqRoleType === "supervisor"
                    ? "border-amber-400 bg-amber-500/20 text-amber-200"
                    : "border-white/10 bg-[#0B0F19] text-slate-400"
                }`}
              >
                رتبة مشرف
              </button>
              <button
                type="button"
                onClick={() => setReqRoleType("admin")}
                className={`rounded-xl border py-2 text-xs font-extrabold cursor-pointer ${
                  reqRoleType === "admin"
                    ? "border-amber-400 bg-amber-500/20 text-amber-200"
                    : "border-white/10 bg-[#0B0F19] text-slate-400"
                }`}
              >
                رتبة مدير
              </button>
            </div>

            <input
              type="text"
              placeholder="ملاحظة قصيرة أو سبب الطلب (اختياري)..."
              value={reqNote}
              onChange={(e) => setReqNote(e.target.value)}
              className="h-10 w-full rounded-xl border border-white/15 bg-[#0B0F19] px-3 text-xs text-white focus:border-amber-400 focus:outline-none"
            />

            <button
              type="button"
              disabled={
                reqSubmitting ||
                !reqFullName.trim() ||
                !reqEmail.trim() ||
                !reqEmail.includes("@")
              }
              onClick={() => void handleSendAdminRoleRequest()}
              className="inline-flex w-full items-center justify-center gap-2 rounded-xl border border-amber-400/45 bg-amber-500/20 py-2.5 text-xs font-extrabold text-amber-200 hover:bg-amber-500/30 disabled:opacity-50 cursor-pointer"
            >
              <Mail className="h-3.5 w-3.5" />
              <Send className="h-3.5 w-3.5" />
              <span>
                {reqSubmitting
                  ? "جاري إرسال الطلب..."
                  : "إرسال الطلب إلى الإدارة"}
              </span>
            </button>

            {submittedRequest && (
              <div className="rounded-xl border border-emerald-400/35 bg-emerald-500/10 px-3 py-2 text-[11px] font-bold text-emerald-200">
                تم تسجيل طلبك ({submittedRequest.fullName} ·{" "}
                <span dir="ltr" className="font-mono">
                  {submittedRequest.email}
                </span>
                ) — الحالة: قيد مراجعة الإدارة.
              </div>
            )}
          </div>

          {savedNotice && (
            <div className="flex items-center gap-2 rounded-xl border border-emerald-500/40 bg-emerald-500/15 px-4 py-3 text-xs font-bold text-emerald-300">
              <Check className="h-4 w-4 shrink-0" />
              <span>تم حفظ إعدادات الحساب والزينة بنجاح!</span>
            </div>
          )}

          <div className="flex items-center gap-3 pt-1">
            <button
              type="submit"
              className="inline-flex flex-1 items-center justify-center gap-2 rounded-xl bg-emerald-600 py-3 text-xs font-extrabold text-white hover:bg-emerald-500 cursor-pointer"
            >
              <Save className="h-4 w-4" />
              <span>حفظ جميع التعديلات</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl border border-white/15 bg-white/5 px-4 py-3 text-xs font-bold text-slate-300 hover:bg-white/10 cursor-pointer"
            >
              إغلاق
            </button>
          </div>

          {/* Bottom Exit Button from Kids Mode -> Returns Smoothly to Global Site */}
          {kidsMode && onExitKidsMode && (
            <div className="border-t border-white/15 pt-4">
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onExitKidsMode();
                }}
                className="inline-flex w-full items-center justify-center gap-2 rounded-2xl border-2 border-violet-400/60 bg-gradient-to-l from-violet-600/35 to-emerald-600/35 py-3.5 px-4 text-xs font-extrabold text-white shadow-lg transition-transform hover:scale-[1.01] cursor-pointer"
              >
                <Globe className="h-4 w-4 text-emerald-300" />
                <span>أنا كبير لكن لا أريد أسوي التحقق</span>
              </button>
              <p className="mt-1.5 text-center text-[11px] text-slate-400">
                ينقلك بسلاسة وفوراً إلى النسخة العالمية المعتادة من موقع عراقي كودرز.
              </p>
            </div>
          )}
        </form>
      </aside>
    </div>
  );
};
