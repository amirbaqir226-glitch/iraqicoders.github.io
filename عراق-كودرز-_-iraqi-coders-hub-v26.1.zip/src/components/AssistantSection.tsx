import React, { useState } from "react";
import {
  Code2,
  Play,
  Send,
  Settings2,
} from "lucide-react";

export interface GeneratedCodeBundle {
  id: number;
  label: string;
  html: string;
  css: string;
  js: string;
}

interface AssistantSectionProps {
  assistantTitle?: string;
  onOpenAdmin: () => void;
  onInjectCodeToPlayground: (bundle: GeneratedCodeBundle) => void;
}

type DimensionChoice = "2D" | "3D";
type PlatformChoice = "Web (HTML/JS)" | "Roblox (Luau)" | "Minecraft Bedrock";
type MechanicChoice = "جمع النقاط وتفادي العقبات" | "تصويب وتفاعل سريع" | "تطبيق وأداة ذكية";

interface ArchitectMessage {
  id: string;
  role: "ai" | "user";
  text: string;
}

function buildGeneratedBundle(
  requestText: string,
  dim: DimensionChoice,
  platform: PlatformChoice,
  mechanic: MechanicChoice
): GeneratedCodeBundle {
  const safeTitle = requestText.slice(0, 42) || "مشروع عراقي كودرز";

  if (mechanic === "تطبيق وأداة ذكية") {
    return {
      id: Date.now(),
      label: `${safeTitle} (${platform})`,
      html: `<div class="app-shell" dir="rtl">
  <header>
    <span>${platform} · ${dim}</span>
    <h2>${safeTitle}</h2>
  </header>
  <div class="input-row">
    <input id="taskInput" type="text" placeholder="أضف مهمة أو فكرة برمجية..." />
    <button id="addBtn">إضافة</button>
  </div>
  <ul id="list"></ul>
</div>`,
      css: `body {
  margin: 0;
  min-height: 100vh;
  display: grid;
  place-items: center;
  background: #0b0f19;
  color: #f8fafc;
  font-family: 'Cairo', system-ui, sans-serif;
}
.app-shell {
  width: min(92%, 420px);
  padding: 24px;
  border-radius: 16px;
  background: #111827;
  border: 1px solid rgba(139, 92, 246, 0.35);
}
header span { font-size: 11px; color: #34d399; font-weight: 700; }
header h2 { margin: 6px 0 16px; font-size: 20px; }
.input-row { display: flex; gap: 8px; margin-bottom: 14px; }
input {
  flex: 1; padding: 10px 12px; border-radius: 10px;
  border: 1px solid #334155; background: #0b0f19; color: #fff; font-family: inherit;
}
button {
  padding: 10px 16px; border: 0; border-radius: 10px;
  background: #7c3aed; color: #fff; font-family: inherit; font-weight: 700; cursor: pointer;
}
ul { list-style: none; padding: 0; margin: 0; display: grid; gap: 8px; }
li {
  padding: 10px 12px; border-radius: 10px; background: #1e293b;
  display: flex; justify-content: space-between; align-items: center; font-size: 13px;
}`,
      js: `const input = document.getElementById('taskInput');
const btn = document.getElementById('addBtn');
const list = document.getElementById('list');

function addItem() {
  const val = input.value.trim();
  if (!val) return;
  const li = document.createElement('li');
  li.innerHTML = '<span>' + val + '</span><button onclick="this.parentElement.remove()">حذف</button>';
  list.appendChild(li);
  input.value = '';
  console.log('تمت إضافة عنصر جديد:', val);
}
btn.onclick = addItem;`,
    };
  }

  // Interactive 2D / 3D-perspective Canvas Game
  const is3D = dim === "3D";
  return {
    id: Date.now(),
    label: `لعبة ${dim} · ${platform}`,
    html: `<div class="game-wrap" dir="rtl">
  <div class="hud">
    <span>النمط: ${dim} (${platform})</span>
    <strong>النقاط: <span id="score">0</span></strong>
  </div>
  <canvas id="gameCanvas" width="380" height="220"></canvas>
  <p class="hint">انقر داخل الملعب للتحكم وجمع النجوم!</p>
</div>`,
    css: `body {
  margin: 0;
  min-height: 100vh;
  display: grid;
  place-items: center;
  background: #0b0f19;
  color: #f8fafc;
  font-family: 'Cairo', system-ui, sans-serif;
}
.game-wrap {
  padding: 16px;
  border-radius: 16px;
  background: #111827;
  border: 1px solid rgba(16, 185, 129, 0.35);
  text-align: center;
}
.hud {
  display: flex; justify-content: space-between; font-size: 13px; margin-bottom: 10px; color: #34d399;
}
canvas {
  border-radius: 12px;
  background: ${is3D ? "linear-gradient(180deg, #1e1b4b 0%, #090d16 100%)" : "#080c15"};
  border: 1px solid rgba(255,255,255,0.1);
  cursor: pointer;
}
.hint { margin: 8px 0 0; font-size: 12px; color: #94a3b8; }`,
    js: `const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const scoreEl = document.getElementById('score');
let score = 0;
let target = { x: 180, y: 110, r: 16 };

function spawn() {
  target.x = 30 + Math.random() * (canvas.width - 60);
  target.y = 30 + Math.random() * (canvas.height - 60);
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ${
    is3D
      ? `// شبكة منظور ثلاثي الأبعاد
  ctx.strokeStyle = 'rgba(139, 92, 246, 0.25)';
  for (let i = 0; i < 8; i++) {
    ctx.beginPath();
    ctx.moveTo(i * 55, canvas.height);
    ctx.lineTo(canvas.width / 2 + (i - 3.5) * 18, 40);
    ctx.stroke();
  }`
      : ""
  }
  ctx.beginPath();
  ctx.arc(target.x, target.y, target.r, 0, Math.PI * 2);
  ctx.fillStyle = '#10b981';
  ctx.fill();
  ctx.strokeStyle = '#a78bfa';
  ctx.lineWidth = 3;
  ctx.stroke();
}

canvas.addEventListener('click', (e) => {
  const rect = canvas.getBoundingClientRect();
  const mx = e.clientX - rect.left;
  const my = e.clientY - rect.top;
  const dist = Math.hypot(mx - target.x, my - target.y);
  if (dist <= target.r + 12) {
    score += 10;
    scoreEl.textContent = String(score);
    console.log('إصابة ناجحة! مجموع النقاط:', score);
    spawn();
    draw();
  }
});

draw();`,
  };
}

export const AssistantSection: React.FC<AssistantSectionProps> = ({
  onOpenAdmin,
  onInjectCodeToPlayground,
}) => {
  const [userPrompt, setUserPrompt] = useState("");
  const [step, setStep] = useState<"idle" | "clarifying" | "ready">("idle");
  const [pendingProjectRequest, setPendingProjectRequest] = useState("");
  const [dimension, setDimension] = useState<DimensionChoice>("2D");
  const [platform, setPlatform] = useState<PlatformChoice>("Web (HTML/JS)");
  const [mechanic, setMechanic] = useState<MechanicChoice>("جمع النقاط وتفادي العقبات");
  const [generatedBundle, setGeneratedBundle] = useState<GeneratedCodeBundle | null>(
    null
  );
  const [architectLog, setArchitectLog] = useState<ArchitectMessage[]>([
    {
      id: "arch-init",
      role: "ai",
      text: "اطلب مني بناء لعبة أو تطبيق (مثلاً: «ابني لي لعبة»)، وسأسألك أولاً أسئلة توضيحية (2D/3D، المنصة، الميكانيكية) قبل توليد ملفات الكود النهائية!",
    },
  ]);

  const handleRequestSubmit = (text: string) => {
    const clean = text.trim();
    if (!clean) return;

    setPendingProjectRequest(clean);
    setStep("clarifying");
    setGeneratedBundle(null);
    setArchitectLog((prev) => [
      ...prev,
      { id: `u-${Date.now()}`, role: "user", text: clean },
      {
        id: `ai-${Date.now() + 1}`,
        role: "ai",
        text: "ممتاز! قبل توليد الكود النهائي، حدد هذه الخيارات الثلاثة: هل تريده 2D أم 3D؟ وعلى أي منصة؟ وما هي ميكانيكية اللعب أو العمل المطلوبة؟",
      },
    ]);
    setUserPrompt("");
  };

  const handleGenerateFinalCode = () => {
    const bundle = buildGeneratedBundle(
      pendingProjectRequest,
      dimension,
      platform,
      mechanic
    );
    setGeneratedBundle(bundle);
    setStep("ready");
    setArchitectLog((prev) => [
      ...prev,
      {
        id: `ai-done-${Date.now()}`,
        role: "ai",
        text: `تم توليد ملفات الكود (${dimension} · ${platform} · ${mechanic})! اضغط على «إرسال وتشغيل في محرر الكود» لتجربته فوراً.`,
      },
    ]);
  };

  return (
    <section id="assistant" className="scroll-mt-24 border-b border-white/10 py-14 lg:py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="glass-surface rounded-3xl border border-white/10 p-5 sm:p-8 flex flex-col justify-between space-y-5 min-w-0">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Code2 className="h-5 w-5 text-emerald-400" />
              <h3 className="text-lg font-extrabold text-white">
                مهندس الأكواد الذكي (أسئلة توضيحية ➔ محرر الكود)
              </h3>
            </div>

            <button
              type="button"
              onClick={onOpenAdmin}
              className="inline-flex items-center gap-2 rounded-lg border border-white/15 bg-white/5 px-4 py-2 text-xs font-bold text-slate-300 transition-colors hover:border-violet-500/40 hover:text-white whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Settings2 className="h-4 w-4 text-violet-400" />
              <span>دخول المسؤول</span>
            </button>
          </div>

            {/* Conversation History */}
            <div className="max-h-44 overflow-y-auto rounded-2xl border border-white/10 bg-[#080C15] p-4 space-y-3">
              {architectLog.map((item) => (
                <div
                  key={item.id}
                  className={`flex ${
                    item.role === "user" ? "justify-start" : "justify-end"
                  }`}
                >
                  <div
                    className={`max-w-[88%] rounded-xl px-3.5 py-2.5 text-xs leading-relaxed ${
                      item.role === "user"
                        ? "bg-violet-600/25 border border-violet-500/35 text-white"
                        : "bg-[#141C2F] border border-white/10 text-slate-200"
                    }`}
                  >
                    {item.text}
                  </div>
                </div>
              ))}
            </div>

            {/* Quick Request Prompts */}
            {step === "idle" && (
              <div className="flex flex-wrap gap-2">
                {[
                  "ابني لي لعبة تفاعلية سريعة",
                  "اصنع لي تطبيق إدارة مهام",
                  "صمم لي لعبة تصويب فضائية",
                ].map((q) => (
                  <button
                    key={q}
                    type="button"
                    onClick={() => handleRequestSubmit(q)}
                    className="rounded-lg border border-violet-500/30 bg-violet-600/15 px-3 py-1.5 text-xs font-bold text-violet-200 hover:bg-violet-600/30 cursor-pointer"
                  >
                    {q}
                  </button>
                ))}
              </div>
            )}

            {/* Step 1: Clarifying Questions UI */}
            {step === "clarifying" && (
              <div className="rounded-2xl border border-emerald-500/35 bg-[#0B0F19] p-4 space-y-3">
                <p className="text-xs font-extrabold text-emerald-300">
                  الأسئلة التوضيحية قبل توليد الكود:
                </p>

                <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-400 mb-1">
                      1. الأبعاد
                    </label>
                    <select
                      value={dimension}
                      onChange={(e) => setDimension(e.target.value as DimensionChoice)}
                      className="h-9 w-full rounded-lg border border-white/10 bg-[#111827] px-2.5 text-xs text-white"
                    >
                      <option value="2D">ثنائي الأبعاد (2D)</option>
                      <option value="3D">ثلاثي الأبعاد (3D)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-400 mb-1">
                      2. المنصة
                    </label>
                    <select
                      value={platform}
                      onChange={(e) => setPlatform(e.target.value as PlatformChoice)}
                      className="h-9 w-full rounded-lg border border-white/10 bg-[#111827] px-2.5 text-xs text-white"
                    >
                      <option value="Web (HTML/JS)">Web (HTML/JS)</option>
                      <option value="Roblox (Luau)">Roblox (Luau)</option>
                      <option value="Minecraft Bedrock">Minecraft Bedrock</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-400 mb-1">
                      3. الميكانيكية
                    </label>
                    <select
                      value={mechanic}
                      onChange={(e) => setMechanic(e.target.value as MechanicChoice)}
                      className="h-9 w-full rounded-lg border border-white/10 bg-[#111827] px-2.5 text-xs text-white"
                    >
                      <option value="جمع النقاط وتفادي العقبات">
                        جمع النقاط وتفادي العقبات
                      </option>
                      <option value="تصويب وتفاعل سريع">تصويب وتفاعل سريع</option>
                      <option value="تطبيق وأداة ذكية">تطبيق وأداة ذكية</option>
                    </select>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleGenerateFinalCode}
                  className="w-full rounded-xl bg-emerald-600 py-2.5 text-xs font-extrabold text-white hover:bg-emerald-500 cursor-pointer"
                >
                  تأكيد الإجابات وتوليد الكود النهائي
                </button>
              </div>
            )}

            {/* Step 2: Generated Code Ready to Paste into Live Playground */}
            {step === "ready" && generatedBundle && (
              <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-emerald-500/40 bg-emerald-500/10 p-4">
                <div>
                  <p className="text-xs font-extrabold text-emerald-300">
                    الكود جاهز: {generatedBundle.label}
                  </p>
                  <p className="text-[11px] text-slate-300">
                    اضغط لنقل ملفات HTML و CSS و JS مباشرة إلى المحرر وتشغيلها.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => onInjectCodeToPlayground(generatedBundle)}
                  className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-4 py-2.5 text-xs font-extrabold text-white hover:bg-emerald-500 cursor-pointer"
                >
                  <Play className="h-3.5 w-3.5" />
                  <span>لصق وتشغيل في محرر الكود</span>
                </button>
              </div>
            )}

            {/* Prompt Input */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleRequestSubmit(userPrompt);
              }}
              className="flex items-center gap-2"
            >
              <input
                type="text"
                value={userPrompt}
                onChange={(e) => setUserPrompt(e.target.value)}
                placeholder="اطلب بناء لعبة أو تطبيق (مثلاً: ابني لي لعبة فضاء)..."
                className="h-11 min-w-0 flex-1 rounded-xl border border-white/10 bg-[#0B0F19] px-4 text-xs text-white placeholder:text-slate-500 focus:border-violet-500 focus:outline-none"
              />
              <button
                type="submit"
                className="inline-flex h-11 items-center gap-2 rounded-xl bg-violet-600 px-5 text-xs font-bold text-white hover:bg-violet-500 cursor-pointer"
              >
                <span>طلب</span>
                <Send className="h-4 w-4" />
              </button>
            </form>
        </div>
      </div>
    </section>
  );
};
