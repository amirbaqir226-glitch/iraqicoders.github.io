import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowUp,
  Check,
  Copy,
  Delete,
  Globe,
  Keyboard,
  Smile,
  X,
} from "lucide-react";
import {
  backspaceInTarget,
  insertTextIntoTarget,
  IOS_ARABIC_ROWS,
  IOS_ENGLISH_ROWS_LOWER,
  IOS_ENGLISH_ROWS_UPPER,
  IOS_NUMBERS_ROWS,
  IPHONE_EMOJI_CATEGORIES,
  isEditableInputElement,
} from "../data/iphoneKit";

interface IPhoneKeyboardProps {
  isOpen: boolean;
  onClose: () => void;
  onShowToast?: (msg: string) => void;
}

type KeyboardMode = "ar" | "en" | "num" | "emoji";

export const IPhoneKeyboard: React.FC<IPhoneKeyboardProps> = ({
  isOpen,
  onClose,
  onShowToast,
}) => {
  const [mode, setMode] = useState<KeyboardMode>("ar");
  const [shiftActive, setShiftActive] = useState(false);
  const [emojiCategory, setEmojiCategory] = useState("faces");
  const [recentEmojis, setRecentEmojis] = useState<string[]>([
    "🇮🇶",
    "🔥",
    "❤️",
    "🚀",
    "😂",
    "😎",
    "💻",
    "✨",
  ]);
  const [scratchValue, setScratchValue] = useState("");
  const [activeTargetLabel, setActiveTargetLabel] = useState(
    "حقل كيبورد الآيفون السريع"
  );
  const [copiedScratch, setCopiedScratch] = useState(false);

  const lastExternalInputRef = useRef<
    HTMLInputElement | HTMLTextAreaElement | null
  >(null);
  const scratchInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (typeof document === "undefined") return;

    const handleFocusIn = (e: FocusEvent) => {
      const target = e.target as Element | null;
      if (!isEditableInputElement(target)) return;
      if (target.dataset.iphoneScratch === "true") return;
      lastExternalInputRef.current = target;
      const label =
        target.getAttribute("placeholder") ||
        target.getAttribute("aria-label") ||
        "حقل النص النشط";
      setActiveTargetLabel(label.slice(0, 42));
    };

    document.addEventListener("focusin", handleFocusIn);
    return () => document.removeEventListener("focusin", handleFocusIn);
  }, []);

  const currentEmojiList = useMemo(() => {
    const cat = IPHONE_EMOJI_CATEGORIES.find((c) => c.id === emojiCategory);
    return cat ? cat.emojis : IPHONE_EMOJI_CATEGORIES[0].emojis;
  }, [emojiCategory]);

  if (!isOpen) return null;

  const getTargetInput = (): HTMLInputElement | HTMLTextAreaElement | null => {
    const ext = lastExternalInputRef.current;
    if (ext && document.contains(ext) && isEditableInputElement(ext)) {
      return ext;
    }
    return scratchInputRef.current;
  };

  const handleInsert = (text: string, isEmoji = false) => {
    const target = getTargetInput();
    if (!target) return;
    insertTextIntoTarget(target, text);
    if (isEmoji) {
      setRecentEmojis((prev) =>
        [text, ...prev.filter((e) => e !== text)].slice(0, 12)
      );
    }
    if (mode === "en" && shiftActive) {
      setShiftActive(false);
    }
  };

  const handleBackspace = () => {
    const target = getTargetInput();
    if (!target) return;
    backspaceInTarget(target);
  };

  const handleCopyScratch = async () => {
    const target = getTargetInput();
    const val = target?.value || scratchValue;
    if (!val) return;
    try {
      await navigator.clipboard.writeText(val);
      setCopiedScratch(true);
      onShowToast?.("تم نسخ النص وإيموجيات الآيفون بنجاح!");
      window.setTimeout(() => setCopiedScratch(false), 1800);
    } catch {
      onShowToast?.("حدد النص أعلاه لنسخه.");
    }
  };

  const handleCycleLanguage = () => {
    setMode((prev) => (prev === "ar" ? "en" : "ar"));
  };

  const letterRows =
    mode === "ar"
      ? IOS_ARABIC_ROWS
      : mode === "num"
      ? IOS_NUMBERS_ROWS
      : shiftActive
      ? IOS_ENGLISH_ROWS_UPPER
      : IOS_ENGLISH_ROWS_LOWER;

  return (
    <div
      role="region"
      aria-label="كيبورد وإيموجيات الآيفون التفاعلية"
      data-dom-scan-ignore="true"
      className="fixed inset-x-0 bottom-0 z-[75] px-2 pb-2 sm:px-4 sm:pb-3 pointer-events-none"
    >
      <div
        onMouseDown={(e) => {
          const target = e.target as HTMLElement;
          if (!target.closest("input[data-iphone-scratch='true']")) {
            e.preventDefault();
          }
        }}
        className="pointer-events-auto mx-auto max-w-2xl overflow-hidden rounded-3xl border border-white/15 bg-[#1C1C1E]/95 shadow-[0_-12px_45px_rgba(0,0,0,0.75)] backdrop-blur-2xl"
      >
        {/* Top iOS Accessory Bar */}
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 bg-[#2C2C2E]/90 px-3 py-2">
          <div className="flex items-center gap-2 min-w-0">
            <span className="inline-flex h-7 w-7 items-center justify-center rounded-xl bg-gradient-to-br from-sky-500 to-indigo-600 text-white shrink-0">
              <Keyboard className="h-3.5 w-3.5" />
            </span>
            <div className="min-w-0">
              <p className="text-[11px] font-extrabold text-white truncate">
                كيبورد وإيموجيات الآيفون (iOS)
              </p>
              <p className="text-[10px] text-sky-300 truncate">
                يكتب في: {activeTargetLabel}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            {(
              [
                { id: "ar", label: "عربي" },
                { id: "en", label: "EN" },
                { id: "num", label: "123" },
                { id: "emoji", label: "إيموجي 😀" },
              ] as { id: KeyboardMode; label: string }[]
            ).map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setMode(tab.id)}
                className={`rounded-lg px-2.5 py-1 text-[11px] font-bold transition-colors cursor-pointer ${
                  mode === tab.id
                    ? "bg-[#0A84FF] text-white"
                    : "bg-white/10 text-slate-200 hover:bg-white/15"
                }`}
              >
                {tab.label}
              </button>
            ))}

            <button
              type="button"
              onClick={onClose}
              aria-label="إغلاق كيبورد الآيفون"
              className="inline-flex h-7 w-7 items-center justify-center rounded-lg bg-white/10 text-slate-300 hover:bg-rose-500/25 hover:text-white cursor-pointer mr-1"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>

        {/* Built-in Quick Compose & Copy Strip */}
        <div className="flex items-center gap-2 border-b border-white/10 bg-[#141416] px-3 py-1.5">
          <input
            ref={scratchInputRef}
            data-iphone-scratch="true"
            type="text"
            value={scratchValue}
            onChange={(e) => setScratchValue(e.target.value)}
            onFocus={() => {
              lastExternalInputRef.current = null;
              setActiveTargetLabel("حقل كيبورد الآيفون السريع");
            }}
            placeholder="اكتب هنا بخط وإيموجيات الآيفون أو اضغط أي حقل بالموقع..."
            className="h-8 flex-1 rounded-xl border border-white/10 bg-[#2C2C2E] px-3 text-xs text-white placeholder:text-slate-400 focus:border-[#0A84FF] focus:outline-none iphone-emoji-font"
          />
          <button
            type="button"
            onClick={() => void handleCopyScratch()}
            className="inline-flex h-8 items-center gap-1 rounded-xl bg-emerald-600 px-3 text-[11px] font-bold text-white hover:bg-emerald-500 cursor-pointer shrink-0"
          >
            {copiedScratch ? (
              <>
                <Check className="h-3.5 w-3.5" />
                <span>نُسخ</span>
              </>
            ) : (
              <>
                <Copy className="h-3.5 w-3.5" />
                <span>نسخ</span>
              </>
            )}
          </button>
        </div>

        {/* Keyboard Body */}
        {mode === "emoji" ? (
          <div className="p-2.5 space-y-2.5">
            {/* Recent iPhone Emojis */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
              <span className="text-[10px] font-bold text-slate-400 shrink-0 pl-1">
                الأكثر استخداماً:
              </span>
              {recentEmojis.map((em) => (
                <button
                  key={`rec-${em}`}
                  type="button"
                  onClick={() => handleInsert(em, true)}
                  className="iphone-emoji-font inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-white/5 text-xl hover:bg-white/15 active:scale-95 cursor-pointer"
                >
                  {em}
                </button>
              ))}
            </div>

            {/* Category Tabs */}
            <div className="flex items-center gap-1 overflow-x-auto">
              {IPHONE_EMOJI_CATEGORIES.map((cat) => (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setEmojiCategory(cat.id)}
                  className={`inline-flex items-center gap-1 rounded-xl px-2.5 py-1 text-[11px] font-bold whitespace-nowrap cursor-pointer transition-colors ${
                    emojiCategory === cat.id
                      ? "bg-[#3A3A3C] text-white"
                      : "text-slate-400 hover:bg-white/5 hover:text-slate-200"
                  }`}
                >
                  <span className="iphone-emoji-font text-sm">{cat.icon}</span>
                  <span>{cat.label}</span>
                </button>
              ))}
            </div>

            {/* Emoji Grid */}
            <div className="grid max-h-44 grid-cols-8 sm:grid-cols-10 gap-1 overflow-y-auto rounded-2xl bg-[#141416] p-2">
              {currentEmojiList.map((emoji) => (
                <button
                  key={emoji}
                  type="button"
                  onClick={() => handleInsert(emoji, true)}
                  className="iphone-emoji-font flex h-9 items-center justify-center rounded-xl text-2xl transition-transform hover:bg-white/10 active:scale-90 cursor-pointer"
                >
                  {emoji}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div dir="ltr" className="p-2 sm:p-2.5 space-y-1.5">
            {letterRows.map((row, rowIdx) => (
              <div
                key={`row-${mode}-${rowIdx}`}
                className="flex items-center justify-center gap-1 sm:gap-1.5"
              >
                {rowIdx === 2 && mode === "en" && (
                  <button
                    type="button"
                    onClick={() => setShiftActive((s) => !s)}
                    aria-label="Shift"
                    className={`ios-keycap inline-flex h-10 w-10 sm:w-12 items-center justify-center rounded-lg text-xs font-bold cursor-pointer ${
                      shiftActive
                        ? "bg-white text-slate-950"
                        : "bg-[#464649] text-white"
                    }`}
                  >
                    <ArrowUp className="h-4 w-4" />
                  </button>
                )}

                {row.map((keyChar) => (
                  <button
                    key={keyChar}
                    type="button"
                    onClick={() => handleInsert(keyChar)}
                    className="ios-keycap flex h-10 flex-1 max-w-[44px] items-center justify-center rounded-lg bg-[#636366] text-sm sm:text-base font-medium text-white hover:bg-[#7A7A7E] cursor-pointer"
                  >
                    {keyChar}
                  </button>
                ))}

                {rowIdx === 2 && (
                  <button
                    type="button"
                    onClick={handleBackspace}
                    aria-label="حذف حرف"
                    className="ios-keycap inline-flex h-10 w-11 sm:w-13 items-center justify-center rounded-lg bg-[#464649] text-white hover:bg-[#5A5A5E] cursor-pointer"
                  >
                    <Delete className="h-4 w-4" />
                  </button>
                )}
              </div>
            ))}

            {/* Bottom iOS Action Row */}
            <div className="flex items-center gap-1.5 pt-0.5">
              <button
                type="button"
                onClick={() => setMode(mode === "num" ? "ar" : "num")}
                className="ios-keycap h-10 px-3 rounded-lg bg-[#464649] text-xs font-bold text-white hover:bg-[#5A5A5E] cursor-pointer"
              >
                {mode === "num" ? "أ ب ت" : "123"}
              </button>

              <button
                type="button"
                onClick={handleCycleLanguage}
                title="تبديل اللغة"
                aria-label="تبديل لغة الكيبورد"
                className="ios-keycap inline-flex h-10 w-10 items-center justify-center rounded-lg bg-[#464649] text-white hover:bg-[#5A5A5E] cursor-pointer"
              >
                <Globe className="h-4 w-4" />
              </button>

              <button
                type="button"
                onClick={() => setMode("emoji")}
                title="إيموجيات الآيفون"
                aria-label="فتح لوحة إيموجيات الآيفون"
                className="ios-keycap inline-flex h-10 w-10 items-center justify-center rounded-lg bg-[#464649] text-amber-300 hover:bg-[#5A5A5E] cursor-pointer"
              >
                <Smile className="h-4 w-4" />
              </button>

              <button
                type="button"
                onClick={() => handleInsert(" ")}
                className="ios-keycap h-10 flex-1 rounded-lg bg-[#636366] text-xs font-semibold text-slate-100 hover:bg-[#7A7A7E] cursor-pointer"
              >
                {mode === "ar" ? "مسافة · iPhone" : "space"}
              </button>

              <button
                type="button"
                onClick={() => {
                  const target = getTargetInput();
                  if (target instanceof HTMLTextAreaElement) {
                    handleInsert("\n");
                  } else {
                    onClose();
                  }
                }}
                className="ios-keycap h-10 px-4 rounded-lg bg-[#0A84FF] text-xs font-extrabold text-white hover:bg-[#1E8FFF] cursor-pointer"
              >
                {mode === "ar" ? "تم" : "Return"}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
