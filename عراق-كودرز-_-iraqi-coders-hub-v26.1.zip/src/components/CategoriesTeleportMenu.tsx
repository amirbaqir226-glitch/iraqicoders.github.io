import React, { useMemo, useState } from "react";
import {
  Archive,
  Cloud,
  Code2,
  Coins,
  Cpu,
  Crown,
  Gamepad2,
  Layers,
  Link2,
  MessageSquare,
  PartyPopper,
  Puzzle,
  Rocket,
  Search,
  ShoppingBag,
  Sparkles,
  UserCheck,
  X,
} from "lucide-react";
import { COMMUNITY_CHANNELS } from "../data/siteConfig";
import { CloudFileItem, PlatformAiUpdate, ProjectItem, UserRole } from "../types";
import { SocialBrandIcon } from "./CommunityLinksSection";

export interface TeleportAction {
  id: string;
  label: string;
  subtitle?: string;
  targetSectionId?: string;
  communityFilter?: "all" | "roblox" | "minecraft" | "forum";
  actionType?:
    | "scroll"
    | "store"
    | "shop-cart"
    | "owl"
    | "secret-console"
    | "secret-code-editor"
    | "dev-category"
    | "admin-request"
    | "ad-dns-settings"
    | "speaker-settings"
    | "lazy-bridge"
    | "messages-center"
    | "network-voice"
    | "admin-rank-miniapp"
    | "downloads-settings"
    | "iphone-keyboard";
}

interface CategoriesTeleportMenuProps {
  isOpen: boolean;
  userRole?: UserRole;
  projects: ProjectItem[];
  publicCloudFiles: CloudFileItem[];
  liveUpdates: PlatformAiUpdate[];
  onClose: () => void;
  onTeleport: (action: TeleportAction) => void;
}

export const CategoriesTeleportMenu: React.FC<
  CategoriesTeleportMenuProps
> = ({
  isOpen,
  userRole = "user",
  projects,
  publicCloudFiles,
  liveUpdates,
  onClose,
  onTeleport,
}) => {
  const [search, setSearch] = useState("");

  const categories = useMemo(() => {
    const codeEditorsAndLibraries: TeleportAction[] = [
      {
        id: "tool-omni-studio",
        label: "استوديو «انشئ كل شيء» (مواقع · تطبيقات · APK · API)",
        subtitle: "توليد وبناء المواقع والتطبيقات والألعاب والإضافات بالذكاء الاصطناعي",
        targetSectionId: "omni-studio",
      },
      {
        id: "tool-secret-ide",
        label: "محرر الأكواد السري (بيئة بدون روت)",
        subtitle: "بناء واختبار السكربتات والبوتات والمشاريع والملفات الـ 6",
        actionType: "secret-code-editor",
      },
      {
        id: "tool-playground",
        label: "محرر الكود المباشر (Code Editor)",
        subtitle: "كتابة وتشغيل HTML / CSS / JS فورياً",
        targetSectionId: "playground",
      },
      {
        id: "tool-libraries",
        label: "المكتبات والأكواد الجاهزة (Libraries)",
        subtitle: "قوالب Luau و Minecraft وواجهة الويب والداشبورد",
        targetSectionId: "playground",
      },
      {
        id: "tool-bot",
        label: "مهندس الأكواد الذكي",
        subtitle: "أسئلة توضيحية وتوليد مشاريع مباشرة في المحرر",
        targetSectionId: "assistant",
      },
    ];

    const dataServersAndCloud: TeleportAction[] = [
      {
        id: "server-data-center",
        label: "مركز البيانات (Data Center & Cloud)",
        subtitle: "إدارة الملفات والسيرفرات ومزامنة Firestore",
        targetSectionId: "cloud-hub",
      },
      {
        id: "server-dom-pairing",
        label: "نظام فحص الشاشة والاقتران (DOM Scanner)",
        subtitle: "مصادقة فورية أونلاين وفتح تحكم الإدارة",
        targetSectionId: "extension-pairing",
      },
      ...publicCloudFiles.slice(0, 3).map((cf) => ({
        id: `cloud-${cf.id}`,
        label: cf.title,
        subtitle: `${cf.fileName} · في مركز البيانات`,
        targetSectionId: "cloud-hub",
      })),
    ];

    const gamesItems: TeleportAction[] = [
      {
        id: "games-all",
        label: "الألعاب ومشاريع المجتمع (Games)",
        subtitle: "Roblox Luau و Minecraft Bedrock",
        targetSectionId: "community-projects",
        communityFilter: "all",
      },
      {
        id: "games-roblox",
        label: "ألعاب Roblox (Luau)",
        subtitle: "سكربتات وحلبات روبلوكس",
        targetSectionId: "community-projects",
        communityFilter: "roblox",
      },
      {
        id: "games-minecraft",
        label: "مودات Minecraft ومصانع Bedrock",
        subtitle: "حزم .mcaddon و .mcworld",
        targetSectionId: "community-projects",
        communityFilter: "minecraft",
      },
      {
        id: "games-studio",
        label: "مصنع الألعاب وتطبيقات APK (/)",
        subtitle: "توليد حزم أندرويد وماينكرافت حقيقية",
        actionType: "secret-console",
      },
      ...projects.slice(0, 4).map((p) => ({
        id: `proj-${p.id}`,
        label: p.title,
        subtitle: p.categoryLabel,
        targetSectionId: `project-card-${p.id}`,
      })),
    ];

    const specialFeatures: TeleportAction[] = [
      {
        id: "spec-mediafire",
        label: "تنزيل IraqiCodersAdmin.zip (MediaFire)",
        subtitle: "حزمة الإضافة الرسمية للموبايل والكمبيوتر",
        targetSectionId: "ext-mediafire-download",
      },
      {
        id: "spec-lazy-bridge",
        label: "الجسر العائم «ما بيا حيل» — Cyber-Admin (1,050+ أداة)",
        subtitle: "فتح فوري للوحة التحكم والأدوات التنفيذية بدون رمز اقتران",
        targetSectionId: "ext-lazy-bridge",
        actionType: "lazy-bridge",
      },
      {
        id: "spec-future-slider",
        label: "معاينة المستقبل v999.9",
        subtitle: "شريط الترقية المستقبلي",
        targetSectionId: "version-future-slider",
      },
      {
        id: "spec-celebration",
        label: "احتفالية فريق العمال والمصنع",
        subtitle: "تحديث المنصة v26.5",
        targetSectionId: "worker-celebration",
      },
      {
        id: "spec-store",
        label: "متجر العملات والزينة",
        subtitle: "تحويل وقت التفاعل إلى عملات رقمية",
        actionType: "store",
      },
      {
        id: "spec-owl",
        label: "طائر دولينجو البني وكواليس الكوميديا",
        subtitle: "مفاجأة المطورين",
        actionType: "owl",
      },
    ];

    const dynamicAdditions: TeleportAction[] = [
      {
        id: "add-generator",
        label: "مولّد الإضافات والتحديثات بالذكاء الاصطناعي",
        subtitle: "إضافة ميزات عامة أو خاصة مباشرة",
        targetSectionId: "ai-live-updates",
      },
      ...liveUpdates.map((u) => ({
        id: `live-upd-${u.id}`,
        label: u.title,
        subtitle: `${u.badgeText} · v${u.targetVersion}`,
        targetSectionId: "ai-live-updates",
      })),
    ];

    const communityAndRanks: TeleportAction[] = [
      {
        id: "rank-challenges",
        label: "قسم التحديات التفاعلية (صح / خطأ)",
        subtitle: "تحديات المطورين والمدراء مع التعليقات المباشرة",
        targetSectionId: "challenges",
      },
      {
        id: "rank-beta-hub",
        label: "النسخة التجريبية · مدرسة ميسون · ببجي · المبرمج",
        subtitle: "فحص المتصفح، إعدادات بلس، لعبة باتل رويال، وعالم الخيال",
        targetSectionId: "beta-hub",
      },
      {
        id: "rank-speaker-a11y",
        label: "زر السماعة (القراءة بالعربية الفصحى)",
        subtitle: "مساعد صوتي عائم قابل للسحب للمكفوفين والمبتدئين",
        actionType: "speaker-settings",
      },
      {
        id: "rank-forum",
        label: "منتدى المطورين والنقاشات",
        subtitle: "المواضيع والردود والإعجابات",
        targetSectionId: "community-forum",
        communityFilter: "forum",
      },
      {
        id: "rank-messages-center",
        label: "تحقق من الرسائل وإشعارات Gmail",
        subtitle: "الرسائل الصادرة والواردة وتفعيل تنبيهات البريد",
        actionType: "messages-center",
      },
      {
        id: "rank-network-voice",
        label: "صوت الشبكة و«أنشئ جنسيتك الخاصة»",
        subtitle: "بث صوت الشبكة وإصدار بطاقة الجنسية بواجهتين",
        actionType: "network-voice",
      },
      ...(userRole === "admin" ||
      userRole === "developer" ||
      userRole === "moderator" ||
      userRole === "director"
        ? [
            {
              id: "rank-admin-miniapp",
              label: "التطبيق المصغر الإداري (الرتب + خذ جنسية الناس)",
              subtitle: "تعيين المشرفين والمطورين والمسؤولين وإشعارات Gmail",
              actionType: "admin-rank-miniapp" as const,
            },
          ]
        : []),
      {
        id: "rank-dev",
        label: "فئة المطور (مهام الشارة والصلاحيات)",
        subtitle: "أكمل المهام واحصل على شارة المطور",
        actionType: "dev-category",
      },
      {
        id: "rank-admin",
        label: "طلب رتبة مدير / مشرف",
        subtitle: "التواصل مع الإدارة بالاسم والإيميل",
        actionType: "admin-request",
      },
      {
        id: "rank-contact-channels",
        label: "قنوات التواصل الرسمية (Telegram · WhatsApp · Discord)",
        subtitle: "روابط الانضمام المباشر للمجتمع وواتساب المتجر",
        targetSectionId: "contact-channels",
      },
      {
        id: "rank-downloads-offline",
        label: "التحميلات (تصفح الموقع بدون إنترنت)",
        subtitle: "تنزيل أقسام محددة أو كل الموقع مع أحجام بالميغابايت",
        actionType: "downloads-settings",
      },
      {
        id: "rank-iphone-keyboard",
        label: "كيبورد وإيموجيات الآيفون (iOS)",
        subtitle: "فتح كيبورد الآيفون العربي/الإنجليزي وإيموجيات الآيفون",
        actionType: "iphone-keyboard",
      },
    ];

    const shopAndSales: TeleportAction[] = [
      {
        id: "shop-catalog",
        label: "متجر عراقي كودرز والخدمات البرمجية",
        subtitle: "شراء المواقع، السكربتات، حزم الألعاب، والخدمات",
        targetSectionId: "shop",
      },
      {
        id: "shop-open-cart",
        label: "سلة المشتريات وإتمام الطلب",
        subtitle: "مراجعة العناصر، حساب الإجمالي، وتأكيد الشراء",
        actionType: "shop-cart",
      },
      {
        id: "shop-coins",
        label: "متجر العملات والسكنات",
        subtitle: "تحويل وقت التفاعل إلى عملات رقمية",
        actionType: "store",
      },
      {
        id: "shop-ad-dns",
        label: "إعدادات الإعلانات ووضع DNS",
        subtitle: "تفعيل وضع DNS أو VIP لإخفاء الإعلانات بالكامل",
        actionType: "ad-dns-settings",
      },
    ];

    return [
      {
        id: "cat-shop",
        title: "المتجر ونظام البيع والشراء",
        icon: ShoppingBag,
        accent: "text-emerald-300 border-emerald-500/35 bg-emerald-500/10",
        items: shopAndSales,
      },
      {
        id: "cat-editors",
        title: "محرر الأكواد السري والمكتبات",
        icon: Code2,
        accent: "text-emerald-300 border-emerald-500/35 bg-emerald-500/10",
        items: codeEditorsAndLibraries,
      },
      {
        id: "cat-servers",
        title: "مركز البيانات والسحابة",
        icon: Cpu,
        accent: "text-cyan-300 border-cyan-500/35 bg-cyan-500/10",
        items: dataServersAndCloud,
      },
      {
        id: "cat-games",
        title: "الألعاب والمودات",
        icon: Gamepad2,
        accent: "text-violet-300 border-violet-500/35 bg-violet-500/10",
        items: gamesItems,
      },
      {
        id: "cat-special",
        title: "الحاجات الخاصة والإضافة والجسر العائم",
        icon: Sparkles,
        accent: "text-sky-300 border-sky-500/35 bg-sky-500/10",
        items: specialFeatures,
      },
      {
        id: "cat-additions",
        title: "الإضافات والتحديثات الجديدة",
        icon: Layers,
        accent: "text-amber-300 border-amber-500/35 bg-amber-500/10",
        items: dynamicAdditions,
      },
      {
        id: "cat-ranks",
        title: "المجتمع وفئة المطور والرتب",
        icon: UserCheck,
        accent: "text-fuchsia-300 border-fuchsia-500/35 bg-fuchsia-500/10",
        items: communityAndRanks,
      },
    ];
  }, [projects, publicCloudFiles, liveUpdates, userRole]);

  const filteredCategories = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return categories;
    return categories
      .map((cat) => ({
        ...cat,
        items: cat.items.filter(
          (item) =>
            item.label.toLowerCase().includes(q) ||
            (item.subtitle || "").toLowerCase().includes(q) ||
            cat.title.toLowerCase().includes(q)
        ),
      }))
      .filter((cat) => cat.items.length > 0);
  }, [categories, search]);

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="categories-teleport-title"
      className="fixed inset-0 z-50 flex justify-start bg-black/75 backdrop-blur-sm"
      onClick={onClose}
    >
      <aside
        onClick={(e) => e.stopPropagation()}
        className="flex h-full w-full max-w-md flex-col border-l border-white/15 bg-[#0B0F19] shadow-2xl overflow-hidden"
      >
        {/* Drawer Header */}
        <div className="flex items-center justify-between gap-3 border-b border-white/10 bg-[#0E1424] px-5 py-4">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl border border-sky-400/40 bg-sky-500/15 text-sky-300">
              <Rocket className="h-4 w-4" />
            </div>
            <div>
              <h2
                id="categories-teleport-title"
                className="text-base font-extrabold text-white"
              >
                التنقل السريع · محرر الأكواد السري
              </h2>
              <p className="text-[11px] text-slate-400">
                محرر الأكواد السري، مركز البيانات، لوحة ما بيا حيل والألعاب
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="إغلاق قائمة الأقسام"
            className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 bg-white/5 text-slate-300 hover:bg-white/10 hover:text-white cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Instant Search Filter */}
        <div className="border-b border-white/10 px-5 py-3 bg-[#0D1322]">
          <div className="relative">
            <Search className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="ابحث عن لعبة، إضافة، ما بيا حيل، فئة المطور..."
              className="h-10 w-full rounded-xl border border-white/10 bg-[#0B0F19] pr-9 pl-3 text-xs text-white placeholder:text-slate-500 focus:border-sky-400 focus:outline-none"
            />
          </div>
        </div>

        {/* Dynamic Categorized List */}
        <div className="flex-1 overflow-y-auto p-5 space-y-5">
          {filteredCategories.map((cat) => {
            const CatIcon = cat.icon;
            return (
              <div key={cat.id} className="space-y-2.5">
                <div className="flex items-center gap-2 text-xs font-extrabold text-white">
                  <span
                    className={`inline-flex h-7 w-7 items-center justify-center rounded-lg border ${cat.accent}`}
                  >
                    <CatIcon className="h-3.5 w-3.5" />
                  </span>
                  <span>{cat.title}</span>
                  <span className="text-[11px] font-mono text-slate-500 tabular-nums">
                    ({cat.items.length})
                  </span>
                </div>

                <div className="grid grid-cols-1 gap-2">
                  {cat.items.map((item) => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => onTeleport(item)}
                      className="group flex items-center justify-between gap-3 rounded-xl border border-white/10 bg-[#101729] px-3.5 py-2.5 text-right transition-colors hover:border-sky-400/55 hover:bg-sky-500/10 cursor-pointer"
                    >
                      <div className="min-w-0">
                        <p className="truncate text-xs font-extrabold text-white group-hover:text-sky-200">
                          {item.label}
                        </p>
                        {item.subtitle && (
                          <p className="truncate text-[11px] text-slate-400 mt-0.5">
                            {item.subtitle}
                          </p>
                        )}
                      </div>
                      <span className="shrink-0 rounded-md border border-white/10 bg-white/5 px-2 py-0.5 text-[10px] font-bold text-sky-300 group-hover:border-sky-400/40">
                        انتقال
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            );
          })}

          {filteredCategories.length === 0 && (
            <div className="rounded-xl border border-dashed border-white/15 p-6 text-center text-xs text-slate-400">
              لا توجد أقسام مطابقة لبحثك «{search}».
            </div>
          )}

          {/* Direct Official Social Channels */}
          <div className="rounded-2xl border border-white/10 bg-[#0E1424] p-4 space-y-2.5">
            <p className="text-xs font-extrabold text-white">
              روابط المجتمع والتواصل المباشر
            </p>
            <div className="grid grid-cols-3 gap-2">
              {COMMUNITY_CHANNELS.map((ch) => (
                <a
                  key={ch.id}
                  href={ch.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-1.5 rounded-xl border border-white/15 bg-white/5 py-2 px-2 text-[11px] font-bold text-slate-200 transition-colors hover:border-emerald-400/50 hover:text-emerald-300"
                >
                  <SocialBrandIcon id={ch.id} className="h-3.5 w-3.5 shrink-0" />
                  <span>{ch.englishName}</span>
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Footer Quick Icons Legend */}
        <div className="border-t border-white/10 bg-[#0E1424] px-5 py-3 flex items-center justify-between text-[11px] text-slate-400">
          <span className="inline-flex items-center gap-1.5">
            <Code2 className="h-3.5 w-3.5 text-emerald-400" />
            <Cloud className="h-3.5 w-3.5 text-sky-400" />
            <Archive className="h-3.5 w-3.5 text-violet-400" />
            <Coins className="h-3.5 w-3.5 text-amber-400" />
            <Crown className="h-3.5 w-3.5 text-amber-300" />
            <Link2 className="h-3.5 w-3.5 text-blue-400" />
            <Puzzle className="h-3.5 w-3.5 text-sky-300" />
            <PartyPopper className="h-3.5 w-3.5 text-amber-300" />
            <MessageSquare className="h-3.5 w-3.5 text-emerald-300" />
          </span>
          <span>انتقال فوري بدون تمرير طويل</span>
        </div>
      </aside>
    </div>
  );
};
