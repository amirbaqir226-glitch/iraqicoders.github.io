import React from "react";
import {
  Award,
  Coins,
  Crown,
  FlaskConical,
  Infinity as InfinityIcon,
  Keyboard,
  LogOut,
  Mail,
  Menu,
  Monitor,
  Puzzle,
  Radio,
  Settings,
  ShoppingCart,
  Smartphone,
  Sparkles,
  User as UserIcon,
} from "lucide-react";
import {
  COMMUNITY_CHANNELS,
  NAV_LINKS_CONFIG,
  SITE_INFO,
} from "../data/siteConfig";
import { UserProfile, UserRole } from "../types";
import { BrownDuolingoIcon } from "./BrownDuolingoModal";
import { SocialBrandIcon } from "./CommunityLinksSection";
import { FantasyTopCloud } from "./ThemeDecorationLayer";

interface NavbarProps {
  user: UserProfile | null;
  userRole: UserRole;
  desktopMode: boolean;
  extensionMode: boolean;
  displayVersion: string;
  coins: number;
  isAdminPrivileged: boolean;
  equippedSkin: string;
  hasVipBadge: boolean;
  onSelectDeviceContext: (ctx: "mobile" | "desktop" | "extension") => void;
  onOpenAuth: () => void;
  onOpenAccountSettings: () => void;
  onOpenCategoriesMenu: () => void;
  onLogout: () => void;
  onOpenBrownOwl: () => void;
  onOpenSecretConsole: () => void;
  onOpenCurrencyStore: () => void;
  cartItemCount: number;
  betaEnabled: boolean;
  fantasyMode: boolean;
  kidsMode?: boolean;
  unreadMessagesCount?: number;
  onToggleBeta: () => void;
  onOpenShopCart: () => void;
  onOpenMessages: () => void;
  onOpenNetworkVoice: () => void;
  iphoneKeyboardOpen?: boolean;
  onToggleIPhoneKeyboard?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  user,
  userRole,
  desktopMode,
  extensionMode,
  displayVersion,
  coins,
  isAdminPrivileged,
  equippedSkin,
  hasVipBadge,
  onSelectDeviceContext,
  onOpenAuth,
  onOpenAccountSettings,
  onOpenCategoriesMenu,
  onLogout,
  onOpenBrownOwl,
  onOpenSecretConsole,
  onOpenCurrencyStore,
  cartItemCount,
  betaEnabled,
  fantasyMode,
  kidsMode = false,
  unreadMessagesCount = 0,
  onToggleBeta,
  onOpenShopCart,
  onOpenMessages,
  onOpenNetworkVoice,
  iphoneKeyboardOpen = false,
  onToggleIPhoneKeyboard,
}) => {
  const canUseDevTools =
    userRole === "developer" ||
    userRole === "director" ||
    userRole === "moderator" ||
    userRole === "admin";

  const avatarSkinClass =
    equippedSkin === "skin-gold-frame"
      ? "border-2 border-amber-400 shadow-[0_0_12px_rgba(245,158,11,0.65)]"
      : equippedSkin === "skin-baghdad-neon"
      ? "border-2 border-emerald-400 ring-2 ring-violet-500/70 shadow-[0_0_12px_rgba(16,185,129,0.6)]"
      : "border border-violet-400/60";

  const navLinks = NAV_LINKS_CONFIG;

  return (
    <header
      className={`sticky top-0 z-40 border-b backdrop-blur-md transition-colors ${
        fantasyMode
          ? "border-pink-400/35 bg-gradient-to-l from-[#1C0F2E]/95 via-[#0F1730]/95 to-[#0E1E2B]/95 shadow-[0_4px_25px_rgba(244,114,182,0.18)]"
          : "border-white/10 bg-[#0B0F19]/90"
      }`}
    >
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-2 px-3 py-2.5 sm:gap-3 sm:px-6 sm:py-3 lg:px-8 relative">
        {/* Zone 1: Brand Wordmark + Glowing Version Badge */}
        <a
          href="#hero"
          className="flex items-center gap-2 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-500 rounded-md"
        >
          <span
            className={`text-base font-extrabold tracking-tight sm:text-xl ${
              kidsMode
                ? "bg-gradient-to-l from-amber-300 via-pink-300 to-sky-300 bg-clip-text text-transparent"
                : fantasyMode
                ? "bg-gradient-to-l from-pink-300 via-sky-200 to-amber-200 bg-clip-text text-transparent"
                : "text-white"
            }`}
          >
            {kidsMode
              ? "عراقي كيدز · Iraqi Kids 🎈"
              : fantasyMode
              ? "عالم خيال عراقي كودرز ✨"
              : SITE_INFO.brandName}
          </span>
          <span className="version-glow rounded-md border border-violet-400/45 bg-violet-600/25 px-2 py-0.5 text-[11px] font-extrabold text-emerald-300 whitespace-nowrap shrink-0 tabular-nums sm:px-2.5 sm:text-xs">
            الإصدار {displayVersion}
          </span>
        </a>

        {/* Zone 2: Clean Single-Line Navigation Links (Hidden in Kids Mode for simplicity) */}
        {!kidsMode && (
          <nav
            aria-label="التنقل الرئيسي"
            className="desktop-nav-bar hidden lg:flex items-center gap-4 text-xs xl:text-sm font-semibold text-slate-300"
          >
            {navLinks.map((item) => (
              <a
                key={item.label}
                href={item.href}
                target={item.external ? "_blank" : undefined}
                rel={item.external ? "noopener noreferrer" : undefined}
                className="whitespace-nowrap shrink-0 py-1 transition-colors duration-150 hover:text-emerald-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-500 rounded"
              >
                {item.label}
              </a>
            ))}

            <a
              href={SITE_INFO.botExternalUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="version-glow inline-flex items-center gap-1.5 rounded-lg border border-emerald-400/40 bg-emerald-500/15 px-3 py-1.5 text-xs font-extrabold text-emerald-300 transition-colors hover:bg-emerald-500/25 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Sparkles className="h-3.5 w-3.5" />
              <span>{SITE_INFO.botButtonLabel}</span>
            </a>
          </nav>
        )}

        {/* Zone 3: Check Messages + Network Voice + Device Switcher + Profile + Categories */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          {/* Pillar 8 Top Buttons: "تحقق من الرسائل" & "صوت الشبكة" */}
          {!kidsMode && (
            <>
              <button
                type="button"
                onClick={onOpenMessages}
                title="تحقق من الرسائل الصادرة والواردة وتفعيل إشعارات Gmail"
                aria-label="تحقق من الرسائل"
                className="relative inline-flex h-9 items-center gap-1.5 rounded-lg border border-sky-400/45 bg-sky-500/15 px-2.5 text-[11px] font-extrabold text-sky-200 transition-colors hover:bg-sky-500/25 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Mail className="h-3.5 w-3.5 shrink-0" />
                <span>تحقق من الرسائل</span>
                {unreadMessagesCount > 0 && (
                  <span className="inline-flex h-4 min-w-[16px] items-center justify-center rounded-full bg-rose-500 px-1 text-[10px] font-extrabold text-white tabular-nums">
                    {unreadMessagesCount}
                  </span>
                )}
              </button>

              <button
                type="button"
                onClick={onOpenNetworkVoice}
                title="صوت الشبكة وخيار أنشئ جنسيتك الخاصة"
                aria-label="صوت الشبكة"
                className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-emerald-400/45 bg-emerald-500/15 px-2.5 text-[11px] font-extrabold text-emerald-200 transition-colors hover:bg-emerald-500/25 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Radio className="h-3.5 w-3.5 shrink-0" />
                <span className="hidden sm:inline">صوت الشبكة</span>
              </button>

              {onToggleIPhoneKeyboard && (
                <button
                  type="button"
                  onClick={onToggleIPhoneKeyboard}
                  aria-pressed={iphoneKeyboardOpen}
                  title="فتح كيبورد وإيموجيات الآيفون التفاعلية"
                  aria-label="كيبورد الآيفون"
                  className={`inline-flex h-9 items-center gap-1.5 rounded-lg border px-2.5 text-[11px] font-extrabold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    iphoneKeyboardOpen
                      ? "border-sky-300 bg-[#0A84FF] text-white"
                      : "border-white/20 bg-white/5 text-slate-200 hover:border-sky-400/50 hover:text-sky-200"
                  }`}
                >
                  <Keyboard className="h-3.5 w-3.5 shrink-0" />
                  <span className="hidden md:inline">كيبورد الآيفون</span>
                </button>
              )}
            </>
          )}

          {/* Mobile / Desktop / Extension Multi-Context Selector (Hidden in Kids Mode) */}
          {!kidsMode && (
            <div
              role="group"
              aria-label="تبديل وضع العرض: الموبايل وسطح المكتب والإضافة"
              className="inline-flex items-center gap-0.5 rounded-lg border border-white/15 bg-[#0E1424] p-0.5 shrink-0"
            >
            <button
              type="button"
              onClick={() => onSelectDeviceContext("mobile")}
              aria-pressed={!desktopMode}
              title="الموبايل (يتزامن تلقائياً مع الإضافة)"
              className={`inline-flex items-center gap-1 rounded-md px-2 py-1.5 text-[11px] font-bold transition-colors whitespace-nowrap cursor-pointer ${
                !desktopMode
                  ? "bg-violet-600 text-white"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              <Smartphone className="h-3.5 w-3.5 shrink-0" />
              <span className="hidden md:inline">الموبايل</span>
            </button>
            <button
              type="button"
              onClick={() => onSelectDeviceContext("desktop")}
              aria-pressed={desktopMode}
              title="سطح المكتب (يتزامن تلقائياً مع الإضافة)"
              className={`inline-flex items-center gap-1 rounded-md px-2 py-1.5 text-[11px] font-bold transition-colors whitespace-nowrap cursor-pointer ${
                desktopMode
                  ? "bg-emerald-600 text-white"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              <Monitor className="h-3.5 w-3.5 shrink-0" />
              <span className="hidden md:inline">سطح المكتب</span>
            </button>
            <button
              type="button"
              onClick={() => onSelectDeviceContext("extension")}
              aria-pressed={extensionMode}
              title="الإضافة (تتزامن تلقائياً عند اختيار الموبايل أو سطح المكتب)"
              className={`inline-flex items-center gap-1 rounded-md px-2 py-1.5 text-[11px] font-bold transition-colors whitespace-nowrap cursor-pointer ${
                extensionMode
                  ? "bg-blue-600 text-white"
                  : "text-slate-400 hover:text-white"
              }`}
            >
                <Puzzle className="h-3.5 w-3.5 shrink-0" />
                <span className="hidden sm:inline">الإضافة</span>
              </button>
            </div>
          )}

          {!kidsMode && (
            <>
              {/* Beta ("تجريبية") Toggle Button Directly Beside "الإضافة" */}
              <button
                type="button"
                onClick={onToggleBeta}
                aria-pressed={betaEnabled}
                title="فتح أو تفعيل النسخة التجريبية (مدرسة ميسون + إعدادات بلس + المبرمج + عالم الخيال)"
                className={`inline-flex h-9 items-center gap-1 rounded-lg border px-2.5 text-[11px] font-extrabold transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                  betaEnabled
                    ? "version-glow border-fuchsia-400/65 bg-gradient-to-l from-fuchsia-600/80 to-violet-600/80 text-white"
                    : "border-fuchsia-500/35 bg-fuchsia-500/10 text-fuchsia-300 hover:bg-fuchsia-500/20"
                }`}
              >
                <FlaskConical className="h-3.5 w-3.5 shrink-0" />
                <span>تجريبية</span>
              </button>

              {/* Shop Cart Drawer Trigger */}
              <button
                type="button"
                onClick={onOpenShopCart}
                title="سلة المشتريات والمتجر"
                aria-label="سلة المشتريات والمتجر"
                className="relative inline-flex h-9 sm:h-10 items-center gap-1.5 rounded-xl border border-emerald-400/35 bg-emerald-500/10 px-2.5 text-xs font-extrabold text-emerald-300 transition-colors hover:bg-emerald-500/20 shrink-0 cursor-pointer"
              >
                <ShoppingCart className="h-4 w-4" />
                <span className="tabular-nums">{cartItemCount}</span>
              </button>

              {/* Compact Community Links (Telegram, WhatsApp, Discord) on Wide Desktop */}
              <div className="hidden xl:inline-flex items-center gap-1 shrink-0">
                {COMMUNITY_CHANNELS.map((ch) => (
                  <a
                    key={ch.id}
                    href={ch.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    title={ch.name}
                    aria-label={ch.name}
                    className="inline-flex h-9 w-9 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-slate-300 transition-colors hover:border-emerald-400/45 hover:text-emerald-300"
                  >
                    <SocialBrandIcon id={ch.id} className="h-4 w-4" />
                  </a>
                ))}
              </div>

              {/* Currency Store Trigger */}
              <button
                type="button"
                onClick={onOpenCurrencyStore}
                title="متجر العملات ووقت التفاعل"
                aria-label="متجر العملات ووقت التفاعل"
                className={`inline-flex h-9 sm:h-10 items-center gap-1.5 rounded-xl border px-2.5 text-xs font-extrabold transition-colors shrink-0 cursor-pointer ${
                  isAdminPrivileged
                    ? "border-amber-400/55 bg-amber-500/15 text-amber-200 hover:bg-amber-500/25"
                    : "border-amber-400/35 bg-[#17130A] text-amber-300 hover:border-amber-400/60"
                }`}
              >
                {isAdminPrivileged ? (
                  <>
                    <Crown className="h-3.5 w-3.5 text-amber-400" />
                    <InfinityIcon className="h-4 w-4 text-amber-300" />
                  </>
                ) : (
                  <>
                    <Coins className="h-3.5 w-3.5 text-amber-400" />
                    <span className="tabular-nums">{coins}</span>
                  </>
                )}
              </button>

              {/* Brown Duolingo Owl + Secret '/' Console */}
              <div className="hidden sm:inline-flex items-center gap-1 shrink-0">
                <button
                  type="button"
                  onClick={onOpenBrownOwl}
                  title="تحدث مع طائر دولينجو البني"
                  aria-label="تحدث مع طائر دولينجو البني"
                  className="inline-flex h-9 w-9 sm:h-10 sm:w-10 items-center justify-center rounded-xl border border-amber-700/45 bg-[#2A1C11] transition-transform duration-150 hover:scale-105 hover:border-amber-500/70 shrink-0 cursor-pointer"
                >
                  <BrownDuolingoIcon className="h-6 w-6 sm:h-7 sm:w-7" />
                </button>

                <button
                  type="button"
                  onClick={onOpenSecretConsole}
                  title={
                    canUseDevTools
                      ? "وحدة المطور السرية / (إنشاء حزم APK ومودات)"
                      : "أكمل «فئة المطور» عبر صورتك الشخصية لفتح استوديو /"
                  }
                  aria-label="فتح وحدة أوامر المطور السرية"
                  dir="ltr"
                  className={`inline-flex h-9 w-9 sm:h-10 sm:w-10 items-center justify-center rounded-xl border font-mono text-base font-extrabold transition-transform duration-150 hover:scale-105 shrink-0 cursor-pointer ${
                    canUseDevTools
                      ? "border-emerald-400/40 bg-black text-emerald-400 hover:border-emerald-300 hover:shadow-[0_0_16px_rgba(16,185,129,0.45)]"
                      : "border-slate-700 bg-black/70 text-slate-500 hover:border-amber-400/50 hover:text-amber-300"
                  }`}
                >
                  /
                </button>
              </div>
            </>
          )}

          {/* Right Icon Cluster Container (Supports Glowing Cloud in Fantasy World) */}
          <div className="relative flex items-center gap-1.5 shrink-0">
            {fantasyMode && <FantasyTopCloud className="-top-2.5 left-1 right-1" />}

            {/* Profile Picture / Settings */}
            {user ? (
              <div className="flex items-center gap-1.5 sm:gap-2">
                <button
                  type="button"
                  onClick={onOpenAccountSettings}
                  title="افتح ملفك الشخصي — مرّر للأسفل للوصول إلى «فئة المطور» و«زر السماعة»"
                  aria-label="افتح ملفك الشخصي وإعدادات فئة المطور"
                  className="group flex items-center gap-1.5 sm:gap-2 rounded-xl border border-white/10 bg-white/5 px-2 py-1 sm:px-2.5 sm:py-1.5 transition-colors hover:border-violet-400/50 hover:bg-violet-600/15 cursor-pointer"
                >
                  <img
                    src={user.avatarUrl}
                    alt={user.name}
                    referrerPolicy="no-referrer"
                    className={`h-7 w-7 sm:h-8 sm:w-8 rounded-full object-cover shrink-0 ${avatarSkinClass}`}
                  />
                  <div className="hidden sm:flex flex-col text-right leading-tight">
                    <span className="inline-flex items-center gap-1 text-xs font-bold text-white max-w-[125px] truncate">
                      <span className="truncate">{user.name}</span>
                      {isAdminPrivileged ? (
                        <Crown className="h-3 w-3 shrink-0 text-amber-400" />
                      ) : userRole === "developer" ||
                        userRole === "director" ||
                        userRole === "moderator" ||
                        hasVipBadge ? (
                        <Award className="h-3 w-3 shrink-0 text-emerald-400" />
                      ) : null}
                    </span>
                    <span className="text-[10px] font-bold text-emerald-400 max-w-[130px] truncate text-right">
                      {userRole === "admin"
                        ? user.handle?.toLowerCase() === "@amirbaqir226"
                          ? "Master Admin · مطور رئيسي"
                          : "مدير / مسؤول"
                        : userRole === "director"
                        ? "مدير (Director)"
                        : userRole === "moderator"
                        ? "مشرف معتمد"
                        : userRole === "developer"
                        ? "مطور معتمد"
                        : "فئة المطور ▾"}
                    </span>
                  </div>
                  <Settings className="hidden sm:block h-3.5 w-3.5 text-slate-400 transition-transform group-hover:rotate-45 group-hover:text-emerald-300 shrink-0" />
                </button>

                <button
                  type="button"
                  onClick={onLogout}
                  title="تسجيل الخروج"
                  aria-label="تسجيل الخروج"
                  className="hidden md:inline-flex h-9 items-center gap-1.5 rounded-lg border border-white/10 bg-white/5 px-2.5 text-xs font-semibold text-slate-200 transition-colors hover:border-rose-500/40 hover:bg-rose-500/15 hover:text-rose-200 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <LogOut className="h-3.5 w-3.5" />
                  <span>خروج</span>
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={onOpenAccountSettings}
                  title="الملف الشخصي وفئة المطور وزر السماعة"
                  aria-label="الملف الشخصي وفئة المطور وزر السماعة"
                  className="inline-flex h-9 w-9 sm:h-10 sm:w-10 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-slate-300 transition-colors hover:border-violet-400/45 hover:text-white cursor-pointer shrink-0"
                >
                  <UserIcon className="h-4 w-4 text-sky-300" />
                </button>
                <button
                  type="button"
                  onClick={onOpenAuth}
                  className="inline-flex h-9 items-center gap-1.5 rounded-lg bg-violet-600 px-2.5 sm:px-3.5 text-xs font-bold text-white transition-all duration-150 hover:bg-violet-500 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <span className="hidden sm:inline">دخول Google</span>
                  <span className="sm:hidden">دخول</span>
                </button>
              </div>
            )}

            {/* Clean Hamburger Menu Button (☰) Next to User Profile Picture */}
            {!kidsMode && (
              <button
                type="button"
                onClick={onOpenCategoriesMenu}
                title="الأقسام والتنقل الفوري (ألعاب، تحديات، تجربة، إضافات)"
                aria-label="فتح قائمة الأقسام والتنقل الفوري"
                className="inline-flex h-9 w-9 sm:h-10 sm:w-10 items-center justify-center rounded-xl border border-sky-400/45 bg-sky-500/15 text-sky-200 transition-colors hover:bg-sky-500/25 hover:text-white cursor-pointer shrink-0"
              >
                <Menu className="h-5 w-5" />
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
