import React, { useState } from "react";
import { Check, Copy, Download, FileCode2, X } from "lucide-react";
import { ProjectItem } from "../types";

interface ProjectModalProps {
  project: ProjectItem | null;
  onClose: () => void;
  onDownload: (project: ProjectItem) => void;
}

export const ProjectModal: React.FC<ProjectModalProps> = ({
  project,
  onClose,
  onDownload,
}) => {
  const [copied, setCopied] = useState(false);

  if (!project) return null;

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(project.codePreview);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      // Safe no-op
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="project-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-3xl max-h-[90vh] overflow-y-auto rounded-2xl border border-white/15 bg-[#0E1424] shadow-2xl"
      >
        {/* Header */}
        <div className="flex items-start justify-between gap-4 border-b border-white/10 px-6 py-5">
          <div>
            <div className="mb-1 flex flex-wrap items-center gap-2 text-xs text-slate-400">
              <span className="font-bold text-emerald-400">{project.categoryLabel}</span>
              <span aria-hidden="true">·</span>
              <span>{project.version}</span>
              <span aria-hidden="true">·</span>
              <span>المطور: {project.author} ({project.city})</span>
            </div>
            <h3 id="project-modal-title" className="text-xl font-extrabold text-white">
              {project.title}
            </h3>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="إغلاق النافذة"
            className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 bg-white/5 text-slate-300 hover:bg-white/10 hover:text-white cursor-pointer shrink-0"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          <p className="text-sm leading-relaxed text-slate-300">{project.summary}</p>

          {/* Installation Steps */}
          <div>
            <h4 className="text-sm font-bold text-white mb-2.5">خطوات التشغيل السريع</h4>
            <ol className="space-y-2 text-xs text-slate-300 list-decimal list-inside">
              {project.installSteps.map((step, idx) => (
                <li key={idx} className="leading-relaxed">
                  {step}
                </li>
              ))}
            </ol>
          </div>

          {/* Code Block */}
          <div className="overflow-hidden rounded-xl border border-white/10 bg-[#080C15]">
            <div className="flex items-center justify-between border-b border-white/10 px-4 py-2.5">
              <span className="inline-flex items-center gap-2 font-mono text-xs text-slate-300">
                <FileCode2 className="h-4 w-4 text-violet-400" />
                <span>{project.fileName}</span>
              </span>
              <button
                type="button"
                onClick={handleCopy}
                className="inline-flex items-center gap-1.5 rounded-md border border-white/10 bg-white/5 px-2.5 py-1 text-xs font-semibold text-slate-200 hover:bg-white/10 cursor-pointer"
              >
                {copied ? (
                  <>
                    <Check className="h-3.5 w-3.5 text-emerald-400" />
                    <span>تم النسخ</span>
                  </>
                ) : (
                  <>
                    <Copy className="h-3.5 w-3.5" />
                    <span>نسخ الكود</span>
                  </>
                )}
              </button>
            </div>
            <pre
              dir="ltr"
              className="max-h-72 overflow-auto p-4 font-mono text-xs leading-6 text-slate-200"
            >
              <code>{project.codePreview}</code>
            </pre>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-white/10 bg-[#0B0F19] px-6 py-4">
          <span className="text-xs text-slate-400 tabular-nums">
            عدد التحميلات: {project.downloads.toLocaleString("en-US")}
          </span>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg border border-white/10 px-4 py-2 text-xs font-bold text-slate-300 hover:bg-white/5 cursor-pointer"
            >
              إغلاق
            </button>
            <button
              type="button"
              onClick={() => onDownload(project)}
              className="inline-flex items-center gap-2 rounded-lg bg-emerald-600 px-5 py-2 text-xs font-bold text-white transition-colors hover:bg-emerald-500 cursor-pointer"
            >
              <Download className="h-4 w-4" />
              <span>تحميل الملف ({project.fileName})</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
