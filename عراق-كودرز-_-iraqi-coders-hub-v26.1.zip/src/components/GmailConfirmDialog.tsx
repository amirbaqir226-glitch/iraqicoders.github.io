import React, { useState } from "react";
import { CheckCircle2, Mail, Send, ShieldAlert, X } from "lucide-react";
import { getGmailAccessToken, setGmailAccessToken } from "../config/firebase";
import { authorizeGmailViaGooglePopup } from "../services/gmailService";
import { GmailConfirmRequest } from "../types";

interface GmailConfirmDialogProps {
  request: GmailConfirmRequest | null;
  onCancel: () => void;
  onConfirmSend: (req: GmailConfirmRequest) => Promise<void>;
}

export const GmailConfirmDialog: React.FC<GmailConfirmDialogProps> = ({
  request,
  onCancel,
  onConfirmSend,
}) => {
  const [sending, setSending] = useState(false);
  const [authorizing, setAuthorizing] = useState(false);
  const [error, setError] = useState("");
  const [hasToken, setHasToken] = useState<boolean>(() => Boolean(getGmailAccessToken()));

  if (!request) return null;

  const tokenReady = Boolean(getGmailAccessToken()) || hasToken;

  const handleAuthorizeGmail = async () => {
    setError("");
    setAuthorizing(true);
    try {
      const res = await authorizeGmailViaGooglePopup();
      if (!res.token) {
        setError("تعذر الحصول على رمز صلاحية Gmail من Google.");
        return;
      }
      setGmailAccessToken(res.token);
      setHasToken(true);
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "تم إلغاء التفويض أو تعذر الاتصال بحساب Google."
      );
    } finally {
      setAuthorizing(false);
    }
  };

  const handleConfirm = async () => {
    setError("");
    setSending(true);
    try {
      await onConfirmSend(request);
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "فشل إرسال الرسالة عبر Gmail."
      );
    } finally {
      setSending(false);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="gmail-confirm-title"
      className="fixed inset-0 z-[70] flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm"
      onClick={onCancel}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-lg overflow-hidden rounded-3xl border border-emerald-400/45 bg-[#0D1424] shadow-2xl"
      >
        <div className="flex items-center justify-between gap-3 border-b border-white/10 bg-[#0A101E] px-5 py-4">
          <div className="flex items-center gap-2.5">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl border border-emerald-400/45 bg-emerald-500/15 text-emerald-300">
              <Mail className="h-5 w-5" />
            </div>
            <div>
              <h3
                id="gmail-confirm-title"
                className="text-sm sm:text-base font-extrabold text-white"
              >
                تأكيد إرسال رسالة عبر تطبيق Gmail
              </h3>
              <p className="text-[11px] text-slate-400">
                سيتم إرسال البريد من حسابك المرتبط في Google بعد موافقتك المباشرة
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onCancel}
            aria-label="إغلاق نافذة تأكيد الإرسال"
            className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-white/10 bg-white/5 text-slate-300 hover:text-white cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          <div className="rounded-2xl border border-white/10 bg-[#080C15] p-4 space-y-2.5 text-xs">
            <div className="flex items-center justify-between gap-2">
              <span className="text-slate-400 font-bold">المستلم (To):</span>
              <span dir="ltr" className="font-mono font-bold text-emerald-300">
                {request.to}
              </span>
            </div>
            <div className="flex items-center justify-between gap-2">
              <span className="text-slate-400 font-bold">الموضوع:</span>
              <span className="font-extrabold text-white text-left">
                {request.subject}
              </span>
            </div>
            <div className="border-t border-white/10 pt-2.5">
              <span className="block text-slate-400 font-bold mb-1">
                معاينة نص الإشعار:
              </span>
              <p className="rounded-xl border border-white/10 bg-[#0D1424] p-3 text-slate-100 leading-relaxed whitespace-pre-wrap">
                {request.previewText || request.textBody || ""}
              </p>
            </div>
          </div>

          {!tokenReady && (
            <div className="rounded-2xl border border-amber-400/40 bg-amber-500/10 p-3.5 space-y-2.5">
              <div className="flex items-start gap-2 text-xs font-bold text-amber-200">
                <ShieldAlert className="h-4 w-4 text-amber-400 shrink-0 mt-0.5" />
                <span>
                  لم يتم تفويض صلاحية إرسال Gmail في هذه الجلسة بعد. يمكنك ربط حساب Google الآن لإرسال الإشعار مباشرة إلى صندوق Gmail الخاص بالمستلم.
                </span>
              </div>
              <button
                type="button"
                disabled={authorizing}
                onClick={() => void handleAuthorizeGmail()}
                className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-amber-500 py-2 text-xs font-extrabold text-slate-950 hover:bg-amber-400 disabled:opacity-60 cursor-pointer"
              >
                <CheckCircle2 className="h-4 w-4" />
                <span>
                  {authorizing
                    ? "جاري فتح نافذة Google..."
                    : "تفويض حساب Google لإرسال Gmail الآن"}
                </span>
              </button>
            </div>
          )}

          {error && (
            <div className="rounded-xl border border-rose-500/40 bg-rose-500/15 px-3.5 py-2.5 text-xs font-bold text-rose-200">
              {error}
            </div>
          )}

          <div className="flex flex-wrap items-center gap-2.5 pt-1">
            <button
              type="button"
              disabled={sending || !tokenReady}
              onClick={() => void handleConfirm()}
              className="inline-flex flex-1 items-center justify-center gap-2 rounded-xl bg-emerald-600 px-4 py-3 text-xs font-extrabold text-white hover:bg-emerald-500 disabled:opacity-45 cursor-pointer"
            >
              <Send className="h-4 w-4" />
              <span>
                {sending
                  ? "جاري الإرسال إلى Gmail..."
                  : "تأكيد وإرسال الإشعار عبر Gmail"}
              </span>
            </button>
            <button
              type="button"
              onClick={onCancel}
              className="rounded-xl border border-white/15 bg-white/5 px-4 py-3 text-xs font-bold text-slate-300 hover:bg-white/10 cursor-pointer"
            >
              إلغاء
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
