import "dotenv/config";
import crypto from "crypto";
import express from "express";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import zlib from "zlib";
import { GoogleGenAI, Type } from "@google/genai";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const EMBEDDED_MANIFEST_JSON = `{
  "manifest_version": 3,
  "name": "Iraqi Coders Admin Pro",
  "version": "4.0.0",
  "description": "Iraqi Coders Official Advanced Extension",
  "permissions": ["storage", "tabs", "scripting", "activeTab"],
  "host_permissions": ["https://iraqi-coders-hub-v26-1.ai.studio/*"],
  "background": { "service_worker": "background.js" },
  "action": { "default_popup": "popup.html" }
}`;

const EMBEDDED_POPUP_HTML = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>إدارة عراقي كودرز الاحترافية</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <div class="container">
    <h2>منصة عراقي كودرز</h2>
    <button id="openBridgeBtn" class="main-btn">تفعيل الشاشة العائمة فوراً</button>
    <div id="status">جاهز للاستخدام</div>
  </div>
  <script src="popup.js"></script>
</body>
</html>`;

const EMBEDDED_STYLES_CSS = `body {
  width: 280px;
  background: #0f172a;
  color: #f8fafc;
  font-family: 'Segoe UI', Tahoma, sans-serif;
  margin: 0;
  padding: 15px;
}
.container { display: flex; flex-direction: column; align-items: center; }
h2 { font-size: 15px; color: #38bdf8; margin-bottom: 12px; }
.main-btn { width: 100%; padding: 10px; background: #0284c7; border: none; color: white; font-weight: bold; border-radius: 6px; cursor: pointer; transition: 0.2s; }
.main-btn:hover { background: #0369a1; }
#status { font-size: 11px; color: #94a3b8; margin-top: 10px; text-align: center; }`;

const EMBEDDED_POPUP_JS = `document.getElementById('openBridgeBtn').addEventListener('click', () => {
  const statusDiv = document.getElementById('status');
  statusDiv.style.color = '#38bdf8';
  statusDiv.innerText = 'جاري حقن الشاشة العائمة للمطورين...';
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs[0]) return;
    chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      func: () => {
        if (document.getElementById('iraqi-admin-floating-panel')) return;
        const panel = document.createElement('div');
        panel.id = 'iraqi-admin-floating-panel';
        panel.innerHTML = \`
          <div style="position:fixed; top:10px; right:10px; z-index:999999; background:#0f172a; color:#fff; border:2px solid #38bdf8; padding:15px; border-radius:10px; width:260px; box-shadow:0 10px 25px rgba(0,0,0,0.5); font-family:sans-serif;">
            <h3 style="margin:0 0 10px 0; color:#38bdf8; font-size:14px; text-align:center;">لوحة تحكم عراقي كودرز</h3>
            <p style="font-size:11px; color:#94a3b8; margin:0 0 10px 0; text-align:center;">تم تفعيل صلاحيات المطورين والمشرفين بنجاح!</p>
            <button id="closePanel" style="width:100%; background:#ef4444; border:none; color:#fff; padding:6px; border-radius:4px; cursor:pointer; font-weight:bold;">إغلاق لوحة التحكم</button>
          </div>
        \`;
        document.body.appendChild(panel);
        document.getElementById('closePanel').onclick = () => panel.remove();
      }
    }, () => {
      statusDiv.style.color = '#4ade80';
      statusDiv.innerText = 'تم فتح الشاشة العائمة بنجاح!';
    });
  });
});`;

const EMBEDDED_CONFIG_JSON = `{
  "platform_name": "Iraqi Coders",
  "version": "4.0.0",
  "environment": "production",
  "features": {
    "floating_bridge": true,
    "dev_tools": true,
    "auto_inject": true,
    "secret_ide": true
  }
}`;

const EMBEDDED_BACKGROUND_JS = `chrome.runtime.onInstalled.addListener(() => {
  console.log("Iraqi Coders Pro Extension with 6 Files Initialized Successfully.");
});`;

const EMBEDDED_EXTENSION_CONFIG = JSON.parse(EMBEDDED_CONFIG_JSON) as {
  platform_name: string;
  version: string;
  environment: string;
  features: {
    floating_bridge: boolean;
    dev_tools: boolean;
    auto_inject: boolean;
    secret_ide: boolean;
  };
};

const EMBEDDED_EXTENSION_FILES = [
  {
    path: "manifest.json",
    sizeBytes: EMBEDDED_MANIFEST_JSON.length,
    content: EMBEDDED_MANIFEST_JSON,
    isBinary: false,
  },
  {
    path: "popup.html",
    sizeBytes: EMBEDDED_POPUP_HTML.length,
    content: EMBEDDED_POPUP_HTML,
    isBinary: false,
  },
  {
    path: "styles.css",
    sizeBytes: EMBEDDED_STYLES_CSS.length,
    content: EMBEDDED_STYLES_CSS,
    isBinary: false,
  },
  {
    path: "popup.js",
    sizeBytes: EMBEDDED_POPUP_JS.length,
    content: EMBEDDED_POPUP_JS,
    isBinary: false,
  },
  {
    path: "config.json",
    sizeBytes: EMBEDDED_CONFIG_JSON.length,
    content: EMBEDDED_CONFIG_JSON,
    isBinary: false,
  },
  {
    path: "background.js",
    sizeBytes: EMBEDDED_BACKGROUND_JS.length,
    content: EMBEDDED_BACKGROUND_JS,
    isBinary: false,
  },
];

interface ExtensionPairingSession {
  id: string;
  code: string;
  extensionName: string;
  browser: string;
  status: "waiting" | "pending_confirm" | "paired" | "rejected" | "revoked";
  feedbackMessage: string;
  createdAt: string;
  updatedAt: string;
  expiresAtMs: number;
}

interface ExtensionPackageConfig {
  archiveName: string;
  downloadUrl: string;
  label: string;
  updatedAt: string;
}

interface StoredRoleRequest {
  id: string;
  fullName: string;
  email: string;
  requestedRole: "admin" | "supervisor";
  note: string;
  status: "pending" | "reviewed" | "approved" | "rejected";
  createdAt: string;
}

interface StoredPlatformUpdate {
  id: string;
  authorId: string;
  authorName: string;
  title: string;
  description: string;
  badgeText: string;
  accentColor: "blue" | "emerald" | "violet" | "amber";
  featureType: "banner" | "widget" | "theme" | "tool";
  actionLabel: string;
  actionPayload: string;
  targetVersion: string;
  visibility: "public" | "private";
  createdAt: string;
  isAiGenerated: boolean;
}

const extensionPairingStore = new Map<string, ExtensionPairingSession>();
const platformUpdatesStore = new Map<string, StoredPlatformUpdate>();
const roleRequestsStore = new Map<string, StoredRoleRequest>();

const ALLOWED_SHOP_PUBLISH_ROLES = new Set(["developer", "moderator", "admin"]);

interface StoredShopProduct {
  id: string;
  title: string;
  category: "web" | "games" | "services" | "tools";
  categoryLabel: string;
  description: string;
  features: string[];
  priceUsd: number;
  originalPriceUsd?: number;
  availability: "available" | "special_offer" | "limited" | "out_of_stock";
  availabilityLabel: string;
  deliveryTime: string;
  accentColor: "emerald" | "violet" | "sky" | "amber";
  imageUrl?: string;
  externalUrl?: string;
  publishedBy: string;
  publishedByRole: "developer" | "moderator" | "admin";
  isCustomPublished: true;
  createdAt: string;
}

const customShopProductsStore = new Map<string, StoredShopProduct>();

const ALLOWED_CHALLENGE_CREATE_ROLES = new Set(["developer", "director", "admin"]);

interface StoredChallengeComment {
  id: string;
  authorName: string;
  authorRole: "user" | "developer" | "moderator" | "director" | "admin";
  content: string;
  createdAt: string;
}

interface StoredChallenge {
  id: string;
  title: string;
  question: string;
  codeSnippet?: string;
  buttonALabel: string;
  buttonBLabel: string;
  correctButton: "A" | "B";
  publisherName: string;
  publisherHandle: string;
  publisherRole: "developer" | "director" | "admin";
  createdAt: string;
  comments: StoredChallengeComment[];
}

interface StoredBetaMiniProject {
  id: string;
  title: string;
  description: string;
  kind: "game" | "app";
  language: string;
  is3D: boolean;
  code: string;
  authorName: string;
  authorHandle: string;
  authorRole: "developer" | "director" | "admin";
  createdAt: string;
}

interface StoredSchoolUpdate {
  id: string;
  title: string;
  details: string;
  badge: string;
  authorName: string;
  createdAt: string;
}

const challengesStore = new Map<string, StoredChallenge>();
const betaMiniProjectsStore = new Map<string, StoredBetaMiniProject>();
const schoolUpdatesStore = new Map<string, StoredSchoolUpdate>();

interface DirectoryPerson {
  id: string;
  username: string;
  displayName: string;
  handle: string;
  email: string;
  city: string;
  role: "user" | "developer" | "moderator" | "director" | "admin";
  enabled: boolean;
  verified: boolean;
  updatedAt: string;
}

const directoryPeopleStore = new Map<string, DirectoryPerson>([
  [
    "amirbaqir226",
    {
      id: "owner-amirbaqir226",
      username: "amirbaqir226",
      displayName: "أمير باقر",
      handle: "@amirbaqir226",
      email: "amirbaqir226@gmail.com",
      city: "بغداد",
      role: "admin",
      enabled: true,
      verified: true,
      updatedAt: new Date().toISOString(),
    },
  ],
]);

interface StoredNationalityCard {
  id: string;
  ownerUid: string;
  ownerHandle: string;
  ownerEmail: string;
  numericId: string;
  fullName: string;
  governorate: string;
  nationalityCode: string;
  specialty: string;
  titleRank: string;
  rankTitle: string;
  bio: string;
  frontPhotoUrl: string;
  backEmblemUrl: string;
  frontPhotoDataUrl: string;
  backPhotoDataUrl: string;
  issuedAt: string;
  updatedAt: string;
  verified: boolean;
}

interface StoredPlatformMessage {
  id: string;
  direction: "incoming" | "outgoing";
  source: "platform" | "gmail";
  senderEmail: string;
  senderName: string;
  recipientEmail: string;
  recipientIdentifier: string;
  subject: string;
  body: string;
  rankGranted?: "user" | "developer" | "moderator" | "director" | "admin";
  sentViaGmail: boolean;
  gmailSynced?: boolean;
  read: boolean;
  createdAt: string;
}

const nationalitiesStore = new Map<string, StoredNationalityCard>();
const platformMessagesStore: StoredPlatformMessage[] = [
  {
    id: "msg-welcome-boot",
    direction: "incoming",
    source: "platform",
    senderEmail: "amirbaqir226@gmail.com",
    senderName: "إدارة عراقي كودرز",
    recipientEmail: "all@iraqicoders.iq",
    recipientIdentifier: "@all",
    subject: "مرحباً بك في نظام رسائل عراقي كودرز",
    body: "يمكنك الآن التحقق من رسائلك الواردة والصادرة وتفعيل إشعارات Gmail الحقيقية في أعلى الموقع.",
    sentViaGmail: false,
    read: false,
    createdAt: new Date().toISOString(),
  },
];

const ALLOWED_STAFF_RANK_ASSIGN_ROLES = new Set([
  "developer",
  "moderator",
  "director",
  "admin",
]);

function buildServerRankNotificationCopy(
  role: "moderator" | "developer" | "admin"
): { subject: string; body: string; arabicTitle: string } {
  if (role === "moderator") {
    return {
      subject: "مرحبا بك، لقد عيناك كمشرف",
      body: "مبروك لقد أصبحت مشرف",
      arabicTitle: "مشرف معتمد",
    };
  }
  if (role === "developer") {
    return {
      subject: "مرحبا بك، تم تعيينك كمطور",
      body: "مبروك لقد أصبحت مطور",
      arabicTitle: "مطور معتمد",
    };
  }
  return {
    subject: "مرحبا بك، تم تعيينك كمسؤول",
    body: "مبروك لقد صرت مسؤول",
    arabicTitle: "مسؤول المنصة",
  };
}
const extensionPackageConfig: ExtensionPackageConfig = {
  archiveName: "IraqiCodersAdmin.zip",
  downloadUrl:
    "https://www.mediafire.com/file/0no84g8ycn72347/IraqiCodersAdmin.zip/file",
  label: "إضافة إدارة عراقي كودرز (MediaFire ZIP)",
  updatedAt: new Date().toISOString(),
};

function normalizeCode(raw: unknown): string {
  return String(raw || "")
    .trim()
    .toUpperCase()
    .replace(/[^A-Z0-9-]/g, "")
    .slice(0, 20);
}

function generateExtensionCode(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let suffix = "";
  for (let i = 0; i < 4; i++) {
    suffix += chars[Math.floor(Math.random() * chars.length)];
  }
  return `EXT-${suffix}`;
}

function getAiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

function buildFallbackGeneratedFeature(
  prompt: string,
  targetVersion: string
): {
  title: string;
  description: string;
  badgeText: string;
  accentColor: "blue" | "emerald" | "violet" | "amber";
  featureType: "banner" | "widget" | "theme" | "tool";
  actionLabel: string;
  actionPayload: string;
} {
  const cleanPrompt = prompt.trim().slice(0, 120) || "ميزة تفاعلية جديدة";
  const lower = cleanPrompt.toLowerCase();

  let accentColor: "blue" | "emerald" | "violet" | "amber" = "blue";
  let featureType: "banner" | "widget" | "theme" | "tool" = "widget";
  let badgeText = "إضافة ذكية";
  let actionLabel = "تفعيل الآن";

  if (lower.includes("ثيم") || lower.includes("زينة") || lower.includes("احتفال")) {
    accentColor = "amber";
    featureType = "theme";
    badgeText = "زينة تفاعلية";
    actionLabel = "تطبيق الزينة";
  } else if (lower.includes("أداة") || lower.includes("كود") || lower.includes("فحص")) {
    accentColor = "emerald";
    featureType = "tool";
    badgeText = "أداة مطور";
    actionLabel = "تشغيل الأداة";
  } else if (lower.includes("إعلان") || lower.includes("شريط") || lower.includes("تحديث")) {
    accentColor = "violet";
    featureType = "banner";
    badgeText = "إشعار فوري";
    actionLabel = "عرض التفاصيل";
  }

  return {
    title: cleanPrompt,
    description: `ميزة مباشرة تم توليدها لإصدار ${targetVersion} استجابة لطلب الإدارة: «${cleanPrompt}» مع دعم التبديل الفوري بين العام والخاص.`,
    badgeText,
    accentColor,
    featureType,
    actionLabel,
    actionPayload: `// Iraqi Coders v${targetVersion} Live Module\nconsole.log("تم تفعيل الميزة: ${cleanPrompt.replace(/"/g, "'")}");`,
  };
}

function buildFallbackIraqiBotReply(message: string): string {
  const lower = message.toLowerCase();
  if (lower.includes("luau") || lower.includes("roblox") || lower.includes("روبلوكس")) {
    return "أهلاً بالمطور العراقي! للعمل على Roblox Luau أنصح باستخدام `CollectionService` لربط السكربتات وتمرير البيانات عبر `RemoteEvent` بشكل آمن من السيرفر.\n\n```lua\nlocal Players = game:GetService('Players')\nPlayers.PlayerAdded:Connect(function(player)\n  print('نورت ماب عراقي كودرز:', player.Name)\nend)\n```";
  }
  if (lower.includes("minecraft") || lower.includes("ماينكرافت") || lower.includes("mcaddon")) {
    return "لإنشاء إضافة Minecraft Bedrock (.mcaddon) متوافقة مع الإصدار الحديث، اجمع مجلد `behavior_pack` و `resource_pack` بملفي `manifest.json` بمعرّفات UUID مختلفة، أو استخدم استوديو `/` المدمج لبنائها وتنزيلها بضغطة زر!";
  }
  if (lower.includes("اقتران") || lower.includes("إضافة") || lower.includes("extension")) {
    return "لاقتران إضافة «إدارة عراقي كودرز»، اضغط على كلمة (اقتران) الزرقاء لتوليد الرمز، وعند إدخال الرمز في الإضافة ستظهر لك نافذة التأكيد «هل تسمح بالاقتران والتحكم الكامل بالموقع؟» لتختار نعم أو لا فوراً.";
  }
  return `هلا والله بك في **Iraqi Bots** المدمج داخل عراقي كودرز v26.5!\nسؤالك: «${message.slice(0, 80)}»\nأقدر أساعدك بكتابة سكربتات Roblox Luau، حزم Minecraft Bedrock، وتطوير واجهات HTML/JS أو تجربة الأكواد في المحرر المباشر.`;
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: "6mb" }));

  // Browser Extension Pairing API Routes ("إدارة عراقي كودرز")
  app.post("/api/extension/pairing/create", (req, res) => {
    const requestedCode = normalizeCode(req.body?.code);
    const code = requestedCode.length >= 4 ? requestedCode : generateExtensionCode();
    const id = String(req.body?.id || `extpair-${Date.now()}`)
      .replace(/[^a-zA-Z0-9_-]/g, "")
      .slice(0, 128);
    const extensionName = String(
      req.body?.extensionName || "إدارة عراقي كودرز"
    ).slice(0, 100);
    const browser = String(req.body?.browser || "Chrome / Edge Extension").slice(0, 60);
    const nowIso = new Date().toISOString();

    const session: ExtensionPairingSession = {
      id,
      code,
      extensionName,
      browser,
      status: "waiting",
      feedbackMessage: "تم توليد الرمز. أدخله في إضافة «إدارة عراقي كودرز» للمتابعة.",
      createdAt: nowIso,
      updatedAt: nowIso,
      expiresAtMs: Date.now() + 20 * 60 * 1000,
    };

    extensionPairingStore.set(code, session);
    res.json({ session });
  });

  // Triggered when the "إدارة عراقي كودرز" extension submits a pairing code -> moves to pending_confirm modal
  app.post("/api/extension/pairing/request", (req, res) => {
    const code = normalizeCode(req.body?.code);
    const extensionName = String(
      req.body?.extensionName || "إدارة عراقي كودرز"
    ).slice(0, 100);
    const browser = String(req.body?.browser || "Chrome / Edge Extension").slice(0, 60);

    if (!code || code.length < 4) {
      res.status(400).json({ error: "أدخل رمز اقتران صحيح مثل EXT-7429." });
      return;
    }

    const existing = extensionPairingStore.get(code);
    const nowIso = new Date().toISOString();

    if (existing && Date.now() > existing.expiresAtMs) {
      extensionPairingStore.delete(code);
      res.status(410).json({
        error: "انتهت صلاحية رمز الاقتران، قم بتوليد رمز جديد من الموقع.",
      });
      return;
    }

    const updated: ExtensionPairingSession = existing
      ? {
          ...existing,
          extensionName,
          browser,
          status: "pending_confirm",
          feedbackMessage: "تم إرسال الطلب من إضافة «إدارة عراقي كودرز» — بانتظار قرار الموقع (نعم / لا).",
          updatedAt: nowIso,
        }
      : {
          id: `extpair-${Date.now()}`,
          code,
          extensionName,
          browser,
          status: "pending_confirm",
          feedbackMessage: "تم إرسال الطلب من إضافة «إدارة عراقي كودرز» — بانتظار قرار الموقع (نعم / لا).",
          createdAt: nowIso,
          updatedAt: nowIso,
          expiresAtMs: Date.now() + 25 * 60 * 1000,
        };

    extensionPairingStore.set(code, updated);
    res.json({ session: updated });
  });

  // Interactive Decision from Website Modal ("هل تسمح بالاقتران والتحكم الكامل بالموقع؟" -> نعم / لا)
  app.post("/api/extension/pairing/confirm", (req, res) => {
    const code = normalizeCode(req.body?.code);
    const allow = Boolean(req.body?.allow);
    const existing = extensionPairingStore.get(code);
    const nowIso = new Date().toISOString();

    if (!code) {
      res.status(400).json({ error: "رمز الاقتران مفقود." });
      return;
    }

    const feedbackMessage = allow
      ? "تم السماح بالاقتران والتحكم الكامل بالموقع بنجاح! واجهة الإضافة العائمة متصلة الآن."
      : "تم رفض طلب الاقتران والتحكم الكامل بالموقع من قِبل المستخدم.";

    const nextStatus = allow ? "paired" : "rejected";
    const updated: ExtensionPairingSession = existing
      ? {
          ...existing,
          status: nextStatus,
          feedbackMessage,
          updatedAt: nowIso,
        }
      : {
          id: `extpair-${Date.now()}`,
          code,
          extensionName: "إدارة عراقي كودرز",
          browser: "Chrome / Edge Extension",
          status: nextStatus,
          feedbackMessage,
          createdAt: nowIso,
          updatedAt: nowIso,
          expiresAtMs: Date.now() + 30 * 60 * 1000,
        };

    extensionPairingStore.set(code, updated);
    res.json({ session: updated });
  });

  app.post("/api/extension/pairing/verify", (req, res) => {
    const code = normalizeCode(req.body?.code);
    const extensionName = String(
      req.body?.extensionName || "إدارة عراقي كودرز"
    ).slice(0, 100);
    const browser = String(req.body?.browser || "Chrome Extension v26.5").slice(0, 60);
    const domMatched = Boolean(req.body?.domMatched);

    if (!code || code.length < 4) {
      res.status(400).json({
        error: "أدخل رمز اقتران صحيح مثل IRAQI-CODE-777 أو EXT-7429.",
      });
      return;
    }

    const existing = extensionPairingStore.get(code);
    const nowIso = new Date().toISOString();

    if (existing && Date.now() > existing.expiresAtMs) {
      extensionPairingStore.delete(code);
      res.status(410).json({
        error: "انتهت صلاحية رمز اقتران الإضافة، أنشئ رمزاً جديداً.",
      });
      return;
    }

    const successFeedback = domMatched
      ? "تم فحص الشاشة أونلاين ومطابقة الرمز بنجاح! تم فتح التحكم الكامل للمدير والمطور فوراً."
      : "تم السماح بالاقتران والتحكم الكامل بالموقع بنجاح!";

    const updated: ExtensionPairingSession = existing
      ? {
          ...existing,
          status: "paired",
          extensionName,
          browser,
          feedbackMessage: successFeedback,
          updatedAt: nowIso,
        }
      : {
          id: `extpair-${Date.now()}`,
          code,
          extensionName,
          browser,
          status: "paired",
          feedbackMessage: successFeedback,
          createdAt: nowIso,
          updatedAt: nowIso,
          expiresAtMs: Date.now() + 30 * 60 * 1000,
        };

    extensionPairingStore.set(code, updated);
    res.json({ session: updated });
  });

  app.get("/api/extension/pairing/status/:code", (req, res) => {
    const code = normalizeCode(req.params.code);
    const session = extensionPairingStore.get(code);
    if (!session) {
      res.status(404).json({
        status: "unpaired",
        feedbackMessage: "لا توجد جلسة اقتران نشطة لهذا الرمز.",
      });
      return;
    }
    if (Date.now() > session.expiresAtMs) {
      extensionPairingStore.delete(code);
      res.json({
        status: "expired",
        feedbackMessage: "انتهت صلاحية رمز الاقتران.",
      });
      return;
    }
    res.json({
      status: session.status,
      feedbackMessage: session.feedbackMessage,
      session,
    });
  });

  app.post("/api/extension/pairing/unlink", (req, res) => {
    const code = normalizeCode(req.body?.code);
    if (code && extensionPairingStore.has(code)) {
      const current = extensionPairingStore.get(code)!;
      extensionPairingStore.set(code, {
        ...current,
        status: "revoked",
        feedbackMessage: "تم إلغاء الاقتران وفصل إضافة «إدارة عراقي كودرز».",
        updatedAt: new Date().toISOString(),
      });
    }
    res.json({ ok: true, status: "revoked" });
  });

  // Official MediaFire ZIP Package Endpoint
  app.get("/api/extension/package", (_req, res) => {
    res.json({ config: extensionPackageConfig });
  });

  // Embedded 6-File Extension Core Endpoint (No manual sideloading required)
  app.get("/api/extension/embedded-core", (_req, res) => {
    res.json({
      extensionName: "Iraqi Coders Admin Pro",
      version: EMBEDDED_EXTENSION_CONFIG.version,
      config: EMBEDDED_EXTENSION_CONFIG,
      files: EMBEDDED_EXTENSION_FILES,
    });
  });

  // Directory People API (ensures amirbaqir226 & team members are enabled & manageable)
  app.get("/api/directory/people", (req, res) => {
    const q = String(req.query.q || "").trim().toLowerCase();
    const list = Array.from(directoryPeopleStore.values()).filter((person) => {
      if (!q) return true;
      return (
        person.username.toLowerCase().includes(q) ||
        person.displayName.toLowerCase().includes(q) ||
        person.handle.toLowerCase().includes(q) ||
        person.email.toLowerCase().includes(q)
      );
    });
    res.json({ people: list });
  });

  app.post("/api/directory/people", (req, res) => {
    const rawIdentifier = String(
      req.body?.username || req.body?.handle || req.body?.email || ""
    ).trim();
    const cleanUsername = rawIdentifier
      .replace(/^@/, "")
      .split("@")[0]
      .replace(/[^a-zA-Z0-9_.-]/g, "")
      .toLowerCase()
      .slice(0, 40);

    if (!cleanUsername) {
      res.status(400).json({ error: "أدخل اسم مستخدم أو معرّف صالح." });
      return;
    }

    const isOwner = cleanUsername === "amirbaqir226";
    const displayName = String(
      req.body?.displayName || (isOwner ? "أمير باقر" : cleanUsername)
    )
      .trim()
      .slice(0, 120);
    const email = String(
      req.body?.email ||
        (isOwner ? "amirbaqir226@gmail.com" : `${cleanUsername}@iraqicoders.iq`)
    )
      .trim()
      .slice(0, 254);
    const roleRaw = String(req.body?.role || "developer");
    const role: "user" | "developer" | "moderator" | "director" | "admin" = isOwner
      ? "admin"
      : roleRaw === "admin" ||
        roleRaw === "developer" ||
        roleRaw === "moderator" ||
        roleRaw === "director"
      ? roleRaw
      : "user";

    const existing = directoryPeopleStore.get(cleanUsername);
    const record: DirectoryPerson = {
      id: existing?.id || (isOwner ? "owner-amirbaqir226" : `person-${cleanUsername}`),
      username: cleanUsername,
      displayName,
      handle: `@${cleanUsername}`,
      email,
      city: String(req.body?.city || existing?.city || "بغداد").slice(0, 60),
      role,
      enabled: req.body?.enabled !== undefined ? Boolean(req.body.enabled) : true,
      verified: isOwner || Boolean(existing?.verified),
      updatedAt: new Date().toISOString(),
    };
    directoryPeopleStore.set(cleanUsername, record);
    res.json({ person: record });
  });

  // Admin & Supervisor Role Contact Request API
  app.get("/api/role-requests", (_req, res) => {
    res.json({ requests: Array.from(roleRequestsStore.values()) });
  });

  app.post("/api/role-requests", (req, res) => {
    const fullName = String(req.body?.fullName || "").trim().slice(0, 120);
    const email = String(req.body?.email || "").trim().slice(0, 254);
    const requestedRole =
      req.body?.requestedRole === "supervisor" ? "supervisor" : "admin";
    const note = String(req.body?.note || "").trim().slice(0, 500);

    if (!fullName || !email || !email.includes("@")) {
      res.status(400).json({
        error: "يرجى إدخال الاسم الكامل وبريد إلكتروني صحيح للتواصل مع الإدارة.",
      });
      return;
    }

    const id = String(req.body?.id || `rolereq-${Date.now()}`)
      .replace(/[^a-zA-Z0-9_-]/g, "")
      .slice(0, 128);

    const requestRecord: StoredRoleRequest = {
      id,
      fullName,
      email,
      requestedRole,
      note,
      status: "pending",
      createdAt: new Date().toISOString(),
    };

    roleRequestsStore.set(id, requestRecord);
    res.json({ request: requestRecord });
  });

  app.patch("/api/role-requests/:id", (req, res) => {
    const id = String(req.params.id || "").trim();
    const existing = roleRequestsStore.get(id);
    if (!existing) {
      res.status(404).json({ error: "الطلب غير موجود في الخادم." });
      return;
    }
    const statusRaw = String(req.body?.status || "");
    if (!["pending", "reviewed", "approved", "rejected"].includes(statusRaw)) {
      res.status(400).json({ error: "حالة غير صالحة." });
      return;
    }
    const updated: StoredRoleRequest = {
      ...existing,
      status: statusRaw as StoredRoleRequest["status"],
    };
    roleRequestsStore.set(id, updated);
    res.json({ request: updated });
  });

  // Custom Published Shop Products API (Developer / Moderator / Admin only)
  app.get("/api/shop-products", (_req, res) => {
    res.json({ products: Array.from(customShopProductsStore.values()) });
  });

  app.post("/api/shop-products", (req, res) => {
    const publisherRole = String(req.body?.publisherRole || "").trim().toLowerCase();
    if (!ALLOWED_SHOP_PUBLISH_ROLES.has(publisherRole)) {
      res.status(403).json({
        error: "هذه الميزة متاحة لأصحاب رتبة المطور أو المشرف أو المسؤول فقط.",
      });
      return;
    }

    const rawProduct = req.body?.product || {};
    const title = String(rawProduct.title || "").trim().slice(0, 140);
    const description = String(rawProduct.description || "").trim().slice(0, 1000);
    const priceUsd = Number(rawProduct.priceUsd);

    if (!title || !description || Number.isNaN(priceUsd) || priceUsd <= 0) {
      res.status(400).json({ error: "بيانات المنتج غير مكتملة أو السعر غير صالح." });
      return;
    }

    const cleanSafeUrl = (val: unknown): string | undefined => {
      const s = String(val || "").trim();
      if (!s) return undefined;
      if (/^https?:\/\//i.test(s)) return s.slice(0, 600);
      return undefined;
    };

    const validCategories = ["web", "games", "services", "tools"] as const;
    const category = validCategories.includes(rawProduct.category)
      ? (rawProduct.category as StoredShopProduct["category"])
      : "tools";

    const id =
      String(rawProduct.id || `prod-custom-${Date.now()}`)
        .replace(/[^a-zA-Z0-9_-]/g, "")
        .slice(0, 90) || `prod-custom-${Date.now()}`;

    const record: StoredShopProduct = {
      id,
      title,
      category,
      categoryLabel: String(rawProduct.categoryLabel || "منتج مجتمعي").slice(0, 60),
      description,
      features: Array.isArray(rawProduct.features)
        ? rawProduct.features
            .map((f: unknown) => String(f || "").trim().slice(0, 160))
            .filter(Boolean)
            .slice(0, 6)
        : ["منتج منشور مباشرة عبر فريق المنصة"],
      priceUsd: Number(priceUsd.toFixed(2)),
      availability:
        rawProduct.availability === "special_offer" ||
        rawProduct.availability === "limited"
          ? rawProduct.availability
          : "available",
      availabilityLabel: String(
        rawProduct.availabilityLabel || "متوفر الآن · منتج منشور"
      ).slice(0, 60),
      deliveryTime: String(
        rawProduct.deliveryTime || "تسليم فوري عبر التواصل"
      ).slice(0, 60),
      accentColor: ["emerald", "violet", "sky", "amber"].includes(
        rawProduct.accentColor
      )
        ? rawProduct.accentColor
        : "emerald",
      imageUrl: cleanSafeUrl(rawProduct.imageUrl),
      externalUrl: cleanSafeUrl(rawProduct.externalUrl),
      publishedBy: String(rawProduct.publishedBy || "فريق عراقي كودرز").slice(0, 80),
      publishedByRole: publisherRole as StoredShopProduct["publishedByRole"],
      isCustomPublished: true,
      createdAt: String(rawProduct.createdAt || new Date().toISOString()),
    };

    customShopProductsStore.set(record.id, record);
    res.json({ product: record });
  });

  app.delete("/api/shop-products/:id", (req, res) => {
    const publisherRole = String(req.headers["x-user-role"] || "").trim().toLowerCase();
    if (!ALLOWED_SHOP_PUBLISH_ROLES.has(publisherRole)) {
      res.status(403).json({ error: "صلاحية غير كافية لحذف المنتج." });
      return;
    }
    const id = String(req.params.id || "").trim();
    customShopProductsStore.delete(id);
    res.json({ ok: true });
  });

  // Challenges API (Developer / Director / Admin creation; open participation & comments)
  app.get("/api/challenges", (_req, res) => {
    res.json({ challenges: Array.from(challengesStore.values()) });
  });

  app.post("/api/challenges", (req, res) => {
    const publisherRole = String(req.body?.publisherRole || "").trim().toLowerCase();
    if (!ALLOWED_CHALLENGE_CREATE_ROLES.has(publisherRole)) {
      res.status(403).json({
        error: "إنشاء التحديات متاح لأصحاب رتبة المطور أو المدير أو المسؤول فقط.",
      });
      return;
    }

    const raw = req.body?.challenge || {};
    const title = String(raw.title || "").trim().slice(0, 140);
    const question = String(raw.question || "").trim().slice(0, 800);
    if (!title || !question) {
      res.status(400).json({ error: "أدخل عنوان التحدي ونص السؤال." });
      return;
    }

    const id =
      String(raw.id || `chal-${Date.now()}`)
        .replace(/[^a-zA-Z0-9_-]/g, "")
        .slice(0, 90) || `chal-${Date.now()}`;

    const record: StoredChallenge = {
      id,
      title,
      question,
      codeSnippet: raw.codeSnippet ? String(raw.codeSnippet).slice(0, 1500) : undefined,
      buttonALabel: String(raw.buttonALabel || "نعم").trim().slice(0, 60) || "نعم",
      buttonBLabel: String(raw.buttonBLabel || "لا").trim().slice(0, 60) || "لا",
      correctButton: raw.correctButton === "B" ? "B" : "A",
      publisherName: String(raw.publisherName || "فريق التطوير").slice(0, 80),
      publisherHandle: String(raw.publisherHandle || "@iraqi_dev").slice(0, 50),
      publisherRole: publisherRole as StoredChallenge["publisherRole"],
      createdAt: String(raw.createdAt || "الآن").slice(0, 40),
      comments: Array.isArray(raw.comments) ? raw.comments.slice(0, 30) : [],
    };
    challengesStore.set(record.id, record);
    res.json({ challenge: record });
  });

  app.post("/api/challenges/:id/comments", (req, res) => {
    const id = String(req.params.id || "").trim();
    const content = String(req.body?.content || "").trim().slice(0, 600);
    if (!content) {
      res.status(400).json({ error: "اكتب تعليقاً أو حلاً أولاً." });
      return;
    }
    const comment: StoredChallengeComment = {
      id: `cc-${Date.now()}`,
      authorName: String(req.body?.authorName || "عضو المنصة").slice(0, 80),
      authorRole: ["developer", "moderator", "director", "admin"].includes(
        String(req.body?.authorRole)
      )
        ? (String(req.body?.authorRole) as StoredChallengeComment["authorRole"])
        : "user",
      content,
      createdAt: "الآن",
    };
    const existing = challengesStore.get(id);
    if (existing) {
      existing.comments = [comment, ...existing.comments].slice(0, 50);
      challengesStore.set(id, existing);
    }
    res.json({ comment });
  });

  // Beta Mini-Apps & Mini-Games API (from المبرمج IDE)
  app.get("/api/beta-projects", (_req, res) => {
    res.json({ projects: Array.from(betaMiniProjectsStore.values()) });
  });

  app.post("/api/beta-projects", (req, res) => {
    const authorRole = String(req.body?.authorRole || "").trim().toLowerCase();
    if (!ALLOWED_CHALLENGE_CREATE_ROLES.has(authorRole)) {
      res.status(403).json({
        error: "نشر المشاريع من بيئة المبرمج متاح للمطورين والمدراء والمسؤولين فقط.",
      });
      return;
    }
    const raw = req.body?.project || {};
    const title = String(raw.title || "").trim().slice(0, 120);
    const code = String(raw.code || "");
    if (!title || !code.trimEnd().endsWith("Iraqi Coders  1329")) {
      res.status(400).json({
        error: "يجب أن ينتهي الكود بختم «Iraqi Coders  1329» مع مسافتين.",
      });
      return;
    }
    const id =
      String(raw.id || `mini-${Date.now()}`)
        .replace(/[^a-zA-Z0-9_-]/g, "")
        .slice(0, 90) || `mini-${Date.now()}`;
    const record: StoredBetaMiniProject = {
      id,
      title,
      description: String(raw.description || "مشروع منشور من المبرمج").slice(0, 400),
      kind: raw.kind === "game" ? "game" : "app",
      language: String(raw.language || "python").slice(0, 30),
      is3D: Boolean(raw.is3D),
      code: code.slice(0, 20000),
      authorName: String(raw.authorName || "مطور عراقي").slice(0, 80),
      authorHandle: String(raw.authorHandle || "@iraqi_dev").slice(0, 50),
      authorRole: authorRole as StoredBetaMiniProject["authorRole"],
      createdAt: "الآن",
    };
    betaMiniProjectsStore.set(record.id, record);
    res.json({ project: record });
  });

  // Maysoon Boys School Special Updates API
  app.get("/api/school-updates", (_req, res) => {
    res.json({ updates: Array.from(schoolUpdatesStore.values()) });
  });

  app.post("/api/school-updates", (req, res) => {
    const title = String(req.body?.title || "").trim().slice(0, 140);
    const details = String(req.body?.details || "").trim().slice(0, 600);
    if (!title || !details) {
      res.status(400).json({ error: "أدخل عنوان وتفاصيل التحديث المدرسي." });
      return;
    }
    const item: StoredSchoolUpdate = {
      id: `sch-${Date.now()}`,
      title,
      details,
      badge: String(req.body?.badge || "مدرسة ميسون للبنين").slice(0, 60),
      authorName: String(req.body?.authorName || "الإدارة").slice(0, 80),
      createdAt: "الآن",
    };
    schoolUpdatesStore.set(item.id, item);
    res.json({ update: item });
  });

  // Live Platform Updates API (supplements Firestore for instant public/private previews)
  app.get("/api/updates", (req, res) => {
    const includePrivateFor = String(req.query.authorId || "").trim();
    const list = Array.from(platformUpdatesStore.values()).filter(
      (u) => u.visibility === "public" || (includePrivateFor && u.authorId === includePrivateFor)
    );
    res.json({ updates: list });
  });

  app.post("/api/updates", (req, res) => {
    const item = req.body?.update as StoredPlatformUpdate | undefined;
    if (!item || !item.id || !item.title) {
      res.status(400).json({ error: "بيانات التحديث غير مكتملة." });
      return;
    }
    const clean: StoredPlatformUpdate = {
      id: String(item.id).replace(/[^a-zA-Z0-9_-]/g, "").slice(0, 128),
      authorId: String(item.authorId || "admin").slice(0, 128),
      authorName: String(item.authorName || "الإدارة").slice(0, 120),
      title: String(item.title).slice(0, 160),
      description: String(item.description || "").slice(0, 1000),
      badgeText: String(item.badgeText || "تحديث مباشر").slice(0, 50),
      accentColor: ["blue", "emerald", "violet", "amber"].includes(item.accentColor)
        ? item.accentColor
        : "blue",
      featureType: ["banner", "widget", "theme", "tool"].includes(item.featureType)
        ? item.featureType
        : "widget",
      actionLabel: String(item.actionLabel || "تشغيل").slice(0, 60),
      actionPayload: String(item.actionPayload || "").slice(0, 2000),
      targetVersion: String(item.targetVersion || "26.5").slice(0, 20),
      visibility: item.visibility === "public" ? "public" : "private",
      createdAt: String(item.createdAt || "الآن").slice(0, 40),
      isAiGenerated: true,
    };
    platformUpdatesStore.set(clean.id, clean);
    res.json({ update: clean });
  });

  app.delete("/api/updates/:id", (req, res) => {
    const id = String(req.params.id || "").trim();
    platformUpdatesStore.delete(id);
    res.json({ ok: true });
  });

  // Server-Side Gemini AI Live Feature & Update Generator (gemini-4-hydrogen)
  app.post("/api/gemini/generate-update", async (req, res) => {
    const prompt = String(req.body?.prompt || "").trim();
    const targetVersion = String(req.body?.targetVersion || "26.5").slice(0, 20);

    if (!prompt) {
      res.status(400).json({ error: "اكتب وصف الميزة أو التحديث المطلوب أولاً." });
      return;
    }

    const ai = getAiClient();
    if (!ai) {
      const fallback = buildFallbackGeneratedFeature(prompt, targetVersion);
      res.json({
        feature: fallback,
        model: "local-smart-engine",
      });
      return;
    }

    const systemInstruction = `أنت مهندس التحديثات الحية لمنصة «عراقي كودرز» (Iraqi Coders v${targetVersion}).
حوّل طلب المشرف إلى ميزة منصة تفاعلية جاهزة للعرض الفوري بصيغة JSON عربية أنيقة ومختصرة.
القواعد:
- title: عنوان الميزة باللغة العربية (أقل من 60 حرف).
- description: شرح عملي جذاب للميزة باللغة العربية (أقل من 220 حرف).
- badgeText: شارة قصيرة من كلمتين (مثل: ميزة AI، أداة سريعة، وضع المستقبل).
- accentColor: واحد فقط من: "blue", "emerald", "violet", "amber".
- featureType: واحد فقط من: "banner", "widget", "theme", "tool".
- actionLabel: نص زر قصير (مثل: تفعيل الميزة، فتح الأداة، تشغيل السكربت).
- actionPayload: كود JavaScript مختصر وآمن يعرض رسالة ترحيب أو يحسب معلومة مفيدة عند الضغط على الزر (بدون alert).`;

    try {
      const geminiPromise = ai.models.generateContent({
        model: "gemini-4-hydrogen",
        contents: `أمر المشرف لإنشاء ميزة لإصدار ${targetVersion}: ${prompt}`,
        config: {
          systemInstruction,
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              description: { type: Type.STRING },
              badgeText: { type: Type.STRING },
              accentColor: { type: Type.STRING },
              featureType: { type: Type.STRING },
              actionLabel: { type: Type.STRING },
              actionPayload: { type: Type.STRING },
            },
            required: [
              "title",
              "description",
              "badgeText",
              "accentColor",
              "featureType",
              "actionLabel",
              "actionPayload",
            ],
          },
        },
      });
      const timeoutPromise = new Promise<never>((_, reject) =>
        setTimeout(() => reject(new Error("Gemini request timeout")), 9000)
      );
      const response = await Promise.race([geminiPromise, timeoutPromise]);

      const rawText = response.text?.trim() || "";
      const parsed = JSON.parse(rawText) as Record<string, unknown>;
      const feature = {
        title: String(parsed.title || prompt).slice(0, 140),
        description: String(
          parsed.description || `ميزة جديدة مولدة بالذكاء الاصطناعي لإصدار ${targetVersion}`
        ).slice(0, 600),
        badgeText: String(parsed.badgeText || "تحديث Gemini").slice(0, 40),
        accentColor: ["blue", "emerald", "violet", "amber"].includes(
          String(parsed.accentColor)
        )
          ? (String(parsed.accentColor) as "blue" | "emerald" | "violet" | "amber")
          : "blue",
        featureType: ["banner", "widget", "theme", "tool"].includes(
          String(parsed.featureType)
        )
          ? (String(parsed.featureType) as "banner" | "widget" | "theme" | "tool")
          : "widget",
        actionLabel: String(parsed.actionLabel || "تفعيل الميزة").slice(0, 45),
        actionPayload: String(
          parsed.actionPayload || `console.log("Iraqi Coders v${targetVersion} Feature Active");`
        ).slice(0, 1600),
      };

      res.json({ feature, model: "gemini-4-hydrogen" });
    } catch (error) {
      const errMessage =
        error instanceof Error ? error.message : "تعذر التوليد عبر Gemini";
      console.error("Gemini Update Generator Fallback:", errMessage);
      const fallback = buildFallbackGeneratedFeature(prompt, targetVersion);
      res.json({
        feature: fallback,
        model: "local-smart-engine",
      });
    }
  });

  // Native In-Platform Iraqi Bots Chat Endpoint (zero external paid links)
  app.post("/api/gemini/iraqi-bot", async (req, res) => {
    const message = String(req.body?.message || "").trim();
    if (!message) {
      res.status(400).json({ error: "اكتب رسالتك إلى Iraqi Bots أولاً." });
      return;
    }

    const ai = getAiClient();
    if (!ai) {
      res.json({
        reply: buildFallbackIraqiBotReply(message),
        model: "local-smart-engine",
      });
      return;
    }

    try {
      const geminiPromise = ai.models.generateContent({
        model: "gemini-4-hydrogen",
        contents: message,
        config: {
          systemInstruction:
            "أنت «Iraqi Bots» المساعد الذكي المدمج داخل منصة عراقي كودرز v26.5. أجب باللغة العربية بأسلوب مطور عراقي عملي ومختصر ومفيد، وركّز على Roblox Luau و Minecraft Bedrock والويب HTML/JS واقتران إضافة «إدارة عراقي كودرز».",
        },
      });
      const timeoutPromise = new Promise<never>((_, reject) =>
        setTimeout(() => reject(new Error("Gemini chat timeout")), 9000)
      );
      const response = await Promise.race([geminiPromise, timeoutPromise]);
      const reply = response.text?.trim() || buildFallbackIraqiBotReply(message);
      res.json({ reply, model: "gemini-4-hydrogen" });
    } catch {
      res.json({
        reply: buildFallbackIraqiBotReply(message),
        model: "local-smart-engine",
      });
    }
  });

  // Omni-Creator Studio Endpoint ("انشئ كل شيء": مواقع، تطبيقات، موبايل APK، ألعاب، إضافات، Backend API، سكربتات)
  app.post("/api/gemini/omni-create", async (req, res) => {
    const prompt = String(req.body?.prompt || "").trim().slice(0, 600);
    const categoryRaw = String(req.body?.category || "website").trim();
    const validCategories = [
      "website",
      "webapp",
      "mobile-app",
      "game",
      "extension",
      "backend-api",
      "luau-mc",
    ] as const;
    type OmniCat = (typeof validCategories)[number];
    const category: OmniCat = (validCategories as readonly string[]).includes(
      categoryRaw
    )
      ? (categoryRaw as OmniCat)
      : "website";

    const safeTitle = prompt || "مشروع عراقي كودرز المتكامل";

    const buildFallbackProject = () => {
      if (category === "website") {
        return {
          title: safeTitle.slice(0, 64),
          summary: "موقع ويب متجاوب متكامل بأقسام تفاعلية وسلة طلبات مباشرة.",
          stackBadge: "HTML5 · CSS3 · JavaScript",
          html: `<div class="site" dir="rtl">
  <nav class="topbar">
    <strong>${safeTitle.slice(0, 28)}</strong>
    <div class="links">
      <a href="#features">المميزات</a>
      <a href="#catalog">العروض</a>
      <button id="cartOpenBtn" class="cta">الطلبات (<span id="cartCount">0</span>)</button>
    </div>
  </nav>
  <header class="hero">
    <h1>${safeTitle.slice(0, 56)}</h1>
    <p>تصميم عصري سريع الاستجابة مبني بالكامل داخل استوديو عراقي كودرز مع تفاعل مباشر.</p>
    <div class="hero-actions">
      <button id="exploreBtn" class="primary">استكشف الخدمات</button>
      <button id="themeBtn" class="ghost">تبديل الإضاءة</button>
    </div>
  </header>
  <section id="catalog" class="grid"></section>
  <div id="toast" class="toast"></div>
</div>`,
          css: `:root{--bg:#090d16;--card:#111827;--text:#f8fafc;--muted:#94a3b8;--accent:#10b981;}
body.light{--bg:#f8fafc;--card:#ffffff;--text:#0f172a;--muted:#475569;--accent:#7c3aed;}
body{margin:0;background:var(--bg);color:var(--text);font-family:'Cairo',system-ui,sans-serif;transition:background .25s,color .25s;}
.site{max-width:960px;margin:0 auto;padding:18px;}
.topbar{display:flex;justify-content:space-between;align-items:center;padding:12px 16px;border-radius:14px;background:var(--card);border:1px solid rgba(255,255,255,.1);}
.links{display:flex;gap:14px;align-items:center;font-size:13px;}
.links a{color:var(--muted);text-decoration:none;font-weight:700;}
.cta,.primary{background:var(--accent);color:#fff;border:0;border-radius:10px;padding:9px 15px;font-family:inherit;font-weight:700;cursor:pointer;}
.ghost{background:transparent;color:var(--text);border:1px solid rgba(148,163,184,.35);border-radius:10px;padding:9px 15px;font-family:inherit;font-weight:700;cursor:pointer;}
.hero{text-align:center;padding:38px 18px;}
.hero h1{margin:0 0 10px;font-size:28px;}
.hero p{margin:0 auto 20px;max-width:560px;color:var(--muted);line-height:1.7;font-size:14px;}
.hero-actions{display:flex;justify-content:center;gap:10px;flex-wrap:wrap;}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:14px;margin-top:14px;}
.card{background:var(--card);border:1px solid rgba(255,255,255,.1);border-radius:14px;padding:16px;display:flex;flex-direction:column;justify-content:space-between;gap:10px;}
.card h3{margin:0;font-size:15px;}
.card p{margin:0;color:var(--muted);font-size:12px;line-height:1.6;}
.price{font-weight:800;color:var(--accent);font-size:14px;}
.toast{position:fixed;bottom:14px;left:14px;background:#10b981;color:#fff;padding:10px 14px;border-radius:10px;font-size:12px;font-weight:700;display:none;}`,
          js: `const items=[
  {id:1,title:"باقة تصميم مواقع حديثة",desc:"واجهة متجاوبة مع لوحة تحكم سريعة",price:"45,000 د.ع"},
  {id:2,title:"نظام تطبيق ويب متكامل",desc:"ربط قاعدة بيانات وإدارة مستخدمين",price:"85,000 د.ع"},
  {id:3,title:"حزمة أتمتة وبوت ذكي",desc:"استجابة فورية وربط API بدون تعقيد",price:"60,000 د.ع"}
];
let cart=0;
const grid=document.getElementById('catalog');
const toast=document.getElementById('toast');
function notify(msg){toast.textContent=msg;toast.style.display='block';setTimeout(()=>toast.style.display='none',2200);}
grid.innerHTML=items.map(i=>\`<div class="card"><div><h3>\${i.title}</h3><p>\${i.desc}</p></div><div><div class="price">\${i.price}</div><button class="primary" style="width:100%;margin-top:10px" onclick="addCart('\${i.title}')">أضف للطلب</button></div></div>\`).join('');
window.addCart=(name)=>{cart++;document.getElementById('cartCount').textContent=String(cart);notify('تمت إضافة: '+name);console.log('إضافة للسلة:',name,'العدد:',cart);};
document.getElementById('themeBtn').onclick=()=>document.body.classList.toggle('light');
document.getElementById('exploreBtn').onclick=()=>grid.scrollIntoView({behavior:'smooth'});
document.getElementById('cartOpenBtn').onclick=()=>notify('مجموع الطلبات المختارة: '+cart);`,
          extraFiles: [
            {
              name: "sitemap.json",
              language: "json",
              content: JSON.stringify(
                {
                  project: safeTitle,
                  routes: ["/", "/features", "/catalog", "/contact"],
                  generatedBy: "Iraqi Coders Omni Studio",
                },
                null,
                2
              ),
            },
          ],
        };
      }

      if (category === "webapp") {
        return {
          title: safeTitle.slice(0, 64),
          summary: "تطبيق ويب عملي لإدارة المهام والمشاريع مع إحصائيات فورية.",
          stackBadge: "Web App · LocalStorage · Analytics",
          html: `<div class="app" dir="rtl">
  <header class="app-head">
    <div>
      <h2>${safeTitle.slice(0, 48)}</h2>
      <p>لوحة إدارة تفاعلية تحفظ بياناتك محلياً فوراً</p>
    </div>
    <div class="stats">
      <div><span id="totalCount">0</span><small>الكل</small></div>
      <div><span id="doneCount">0</span><small>منجز</small></div>
    </div>
  </header>
  <form id="taskForm" class="composer">
    <input id="titleIn" type="text" placeholder="أدخل مهمة أو عنصر جديد..." required />
    <select id="prioIn"><option value="عاجل">عاجل</option><option value="متوسط" selected>متوسط</option><option value="عادي">عادي</option></select>
    <button type="submit">إضافة</button>
  </form>
  <div id="items" class="list"></div>
</div>`,
          css: `body{margin:0;background:#080c15;color:#f8fafc;font-family:'Cairo',system-ui,sans-serif;padding:16px;}
.app{max-width:720px;margin:0 auto;background:#101728;border:1px solid rgba(139,92,246,.3);border-radius:16px;padding:20px;}
.app-head{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;border-bottom:1px solid rgba(255,255,255,.08);padding-bottom:14px;}
.app-head h2{margin:0;font-size:18px;}
.app-head p{margin:4px 0 0;color:#94a3b8;font-size:12px;}
.stats{display:flex;gap:12px;}
.stats div{background:#090d16;border:1px solid rgba(255,255,255,.08);border-radius:10px;padding:8px 14px;text-align:center;}
.stats span{display:block;font-weight:800;color:#34d399;font-size:16px;}
.stats small{color:#94a3b8;font-size:11px;}
.composer{display:flex;gap:8px;margin:16px 0;flex-wrap:wrap;}
.composer input,.composer select{background:#090d16;border:1px solid rgba(255,255,255,.15);border-radius:10px;padding:9px 12px;color:#fff;font-family:inherit;font-size:13px;}
.composer input{flex:1;min-width:180px;}
.composer button{background:#7c3aed;border:0;border-radius:10px;padding:9px 18px;color:#fff;font-family:inherit;font-weight:700;cursor:pointer;}
.list{display:grid;gap:8px;}
.row{display:flex;justify-content:space-between;align-items:center;background:#0b1120;border:1px solid rgba(255,255,255,.08);border-radius:10px;padding:10px 12px;}
.row.done span{text-decoration:line-through;color:#64748b;}
.row-actions{display:flex;gap:6px;}
.row button{border:1px solid rgba(255,255,255,.15);background:transparent;color:#cbd5e1;border-radius:8px;padding:5px 10px;font-size:11px;cursor:pointer;}`,
          js: `let tasks=[
  {id:1,title:"تجهيز واجهة المستخدم وتجربتها",prio:"عاجل",done:true},
  {id:2,title:"ربط التصدير إلى APK و ZIP",prio:"متوسط",done:false}
];
const listEl=document.getElementById('items');
function render(){
  document.getElementById('totalCount').textContent=String(tasks.length);
  document.getElementById('doneCount').textContent=String(tasks.filter(t=>t.done).length);
  listEl.innerHTML=tasks.map(t=>\`<div class="row \${t.done?'done':''}"><div><strong>\${t.title}</strong> · <small style="color:#38bdf8">\${t.prio}</small></div><div class="row-actions"><button onclick="toggleTask(\${t.id})">\${t.done?'تراجع':'إنجاز'}</button><button onclick="delTask(\${t.id})">حذف</button></div></div>\`).join('');
}
window.toggleTask=(id)=>{tasks=tasks.map(t=>t.id===id?{...t,done:!t.done}:t);render();};
window.delTask=(id)=>{tasks=tasks.filter(t=>t.id!==id);render();};
document.getElementById('taskForm').onsubmit=(e)=>{
  e.preventDefault();
  const title=document.getElementById('titleIn').value.trim();
  const prio=document.getElementById('prioIn').value;
  if(!title)return;
  tasks.unshift({id:Date.now(),title,prio,done:false});
  document.getElementById('titleIn').value='';
  console.log('تمت إضافة مهمة:',title);
  render();
};
render();`,
          extraFiles: [
            {
              name: "app-schema.json",
              language: "json",
              content: JSON.stringify(
                { appName: safeTitle, storage: "localStorage", fields: ["id", "title", "prio", "done"] },
                null,
                2
              ),
            },
          ],
        };
      }

      if (category === "mobile-app") {
        return {
          title: safeTitle.slice(0, 64),
          summary: "تطبيق موبايل جاهز للعرض على الهواتف والتصدير كحزمة Android APK.",
          stackBadge: "Mobile UI · Android APK Ready",
          html: `<div class="phone" dir="rtl">
  <div class="status-bar"><span>Iraqi App</span><span>100%</span></div>
  <div class="screen">
    <div class="banner">
      <small>تطبيق موبايل مباشر</small>
      <h3>${safeTitle.slice(0, 42)}</h3>
      <div class="balance" id="valDisplay">250,000 د.ع</div>
    </div>
    <div class="quick-grid">
      <button onclick="op(25000,'إيداع سريع')">+25,000</button>
      <button onclick="op(-10000,'دفع خدمة')">-10,000</button>
      <button onclick="op(50000,'مكافأة تطوير')">+50,000</button>
    </div>
    <h4>آخر العمليات</h4>
    <ul id="history"></ul>
  </div>
  <nav class="tabbar">
    <button onclick="console.log('الرئيسية')">الرئيسية</button>
    <button onclick="console.log('العمليات')">السجل</button>
    <button onclick="console.log('الحساب')">حسابي</button>
  </nav>
</div>`,
          css: `body{margin:0;min-height:100vh;display:grid;place-items:center;background:#060912;color:#fff;font-family:'Cairo',system-ui,sans-serif;}
.phone{width:340px;border:2px solid rgba(56,189,248,.35);border-radius:28px;background:#0e1424;overflow:hidden;box-shadow:0 20px 50px rgba(0,0,0,.6);}
.status-bar{display:flex;justify-content:space-between;padding:10px 18px;font-size:11px;color:#94a3b8;background:#090d16;}
.screen{padding:16px;}
.banner{background:linear-gradient(135deg,#4f46e5,#059669);border-radius:18px;padding:18px;}
.banner small{font-size:11px;opacity:.9;}
.banner h3{margin:4px 0 8px;font-size:16px;}
.balance{font-size:24px;font-weight:800;}
.quick-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin:14px 0;}
.quick-grid button{background:#162038;border:1px solid rgba(255,255,255,.12);color:#34d399;border-radius:12px;padding:10px 6px;font-weight:700;cursor:pointer;}
h4{margin:10px 0 8px;font-size:13px;color:#cbd5e1;}
ul{list-style:none;padding:0;margin:0;display:grid;gap:6px;max-height:140px;overflow:auto;}
li{background:#090d16;border-radius:10px;padding:8px 10px;font-size:12px;display:flex;justify-content:space-between;}
.tabbar{display:grid;grid-template-columns:repeat(3,1fr);border-top:1px solid rgba(255,255,255,.08);background:#090d16;}
.tabbar button{background:none;border:0;color:#cbd5e1;padding:12px;font-family:inherit;font-size:12px;font-weight:700;cursor:pointer;}`,
          js: `let balance=250000;
const logs=[];
function refresh(){
  document.getElementById('valDisplay').textContent=balance.toLocaleString('en-US')+' د.ع';
  document.getElementById('history').innerHTML=logs.map(l=>\`<li><span>\${l.label}</span><strong style="color:\${l.amt>0?'#34d399':'#fb7185'}">\${l.amt>0?'+':''}\${l.amt.toLocaleString('en-US')}</strong></li>\`).join('')||'<li>لا توجد عمليات بعد</li>';
}
window.op=(amt,label)=>{balance+=amt;logs.unshift({amt,label});refresh();console.log(label,amt);};
refresh();`,
          extraFiles: [
            {
              name: "capacitor.config.json",
              language: "json",
              content: JSON.stringify(
                { appId: "iq.coders.mobileapp", appName: safeTitle, webDir: "dist" },
                null,
                2
              ),
            },
          ],
        };
      }

      if (category === "extension") {
        return {
          title: safeTitle.slice(0, 64),
          summary: "إضافة متصفح Chrome/Edge متكاملة بملفات Manifest V3 جاهزة.",
          stackBadge: "Chrome Extension MV3 · 4 Files",
          html: `<div class="ext-popup" dir="rtl">
  <h3>${safeTitle.slice(0, 40)}</h3>
  <p id="extMsg">الإضافة متصلة بنواة عراقي كودرز وجاهزة لحقن الأدوات.</p>
  <button id="injectBtn">تفعيل الأداة في الصفحة</button>
  <button id="scanBtn" class="sec">فحص عناصر DOM</button>
</div>`,
          css: `body{margin:0;min-height:100vh;display:grid;place-items:center;background:#090d16;color:#f8fafc;font-family:'Cairo',sans-serif;}
.ext-popup{width:300px;background:#0f172a;border:1px solid #38bdf8;border-radius:14px;padding:18px;text-align:center;}
h3{margin:0 0 8px;color:#38bdf8;font-size:16px;}
p{margin:0 0 14px;font-size:12px;color:#94a3b8;line-height:1.6;}
button{width:100%;padding:10px;border:0;border-radius:10px;background:#0284c7;color:#fff;font-family:inherit;font-weight:700;cursor:pointer;margin-bottom:8px;}
button.sec{background:#1e293b;border:1px solid rgba(255,255,255,.15);margin-bottom:0;}`,
          js: `document.getElementById('injectBtn').onclick=()=>{
  document.getElementById('extMsg').textContent='تم حقن أداة التحكم في الصفحة بنجاح!';
  console.log('[Extension] Active script injected.');
};
document.getElementById('scanBtn').onclick=()=>{
  const nodes=document.querySelectorAll('*').length;
  document.getElementById('extMsg').textContent='تم فحص '+nodes+' عنصر DOM بنجاح.';
  console.log('[Extension] Scanned DOM nodes:',nodes);
};`,
          extraFiles: [
            {
              name: "manifest.json",
              language: "json",
              content: JSON.stringify(
                {
                  manifest_version: 3,
                  name: safeTitle.slice(0, 40),
                  version: "1.0.0",
                  permissions: ["activeTab", "storage", "scripting"],
                  action: { default_popup: "index.html" },
                },
                null,
                2
              ),
            },
          ],
        };
      }

      if (category === "backend-api") {
        return {
          title: safeTitle.slice(0, 64),
          summary: "خادم Node/Express API مع واجهة اختبار مسارات REST مباشرة.",
          stackBadge: "Express.js · REST API · JSON",
          html: `<div class="api-box" dir="rtl">
  <h3>واجهة اختبار الخادم — ${safeTitle.slice(0, 36)}</h3>
  <div class="bar">
    <select id="methodSel"><option>GET</option><option>POST</option></select>
    <input id="pathIn" value="/api/v1/projects" dir="ltr" />
    <button id="sendReq">إرسال طلب</button>
  </div>
  <pre id="resOut" dir="ltr">اضغط «إرسال طلب» لاختبار الخادم المولّد...</pre>
</div>`,
          css: `body{margin:0;background:#070b14;color:#f8fafc;font-family:'Cairo',sans-serif;padding:18px;}
.api-box{max-width:660px;margin:0 auto;background:#0f172a;border:1px solid rgba(16,185,129,.35);border-radius:14px;padding:18px;}
h3{margin:0 0 12px;color:#34d399;font-size:16px;}
.bar{display:flex;gap:8px;margin-bottom:12px;}
select,input{background:#070b14;border:1px solid rgba(255,255,255,.15);color:#fff;border-radius:8px;padding:9px;font-family:monospace;font-size:12px;}
input{flex:1;}
button{background:#10b981;border:0;color:#052e16;font-weight:800;border-radius:8px;padding:9px 16px;cursor:pointer;font-family:inherit;}
pre{background:#04070d;border:1px solid rgba(255,255,255,.08);border-radius:10px;padding:12px;color:#7dd3fc;font-size:12px;overflow:auto;min-height:130px;}`,
          js: `const db=[{id:1,name:"Iraqi Hub API",status:"ready"}];
document.getElementById('sendReq').onclick=()=>{
  const m=document.getElementById('methodSel').value;
  const p=document.getElementById('pathIn').value;
  if(m==='POST'){db.push({id:db.length+1,name:"New Resource",status:"created"});}
  const res={status:200,method:m,endpoint:p,data:db};
  document.getElementById('resOut').textContent=JSON.stringify(res,null,2);
  console.log('API Request:',m,p);
};`,
          extraFiles: [
            {
              name: "server.js",
              language: "javascript",
              content: `import express from "express";\nconst app = express();\napp.use(express.json());\n\nconst items = [{ id: 1, title: "${safeTitle.replace(/"/g, "'")}" }];\n\napp.get("/api/v1/projects", (_req, res) => res.json({ items }));\napp.post("/api/v1/projects", (req, res) => {\n  const created = { id: Date.now(), ...req.body };\n  items.push(created);\n  res.status(201).json({ created });\n});\n\napp.listen(3000, () => console.log("API Server running on port 3000"));`,
            },
          ],
        };
      }

      if (category === "luau-mc") {
        return {
          title: safeTitle.slice(0, 64),
          summary: "محاكي وسكربت Roblox Luau و Minecraft Bedrock Script API.",
          stackBadge: "Roblox Luau · Minecraft @minecraft/server",
          html: `<div class="box" dir="rtl">
  <h3>محاكي سكربت الألعاب — ${safeTitle.slice(0, 36)}</h3>
  <p>جرّب أحداث اللاعبين والنقاط قبل نقل الكود إلى Roblox أو Minecraft.</p>
  <button id="joinBtn">محاكاة دخول لاعب</button>
  <button id="rewardBtn">منح 100 نقطة</button>
  <pre id="simLog" dir="ltr">[Ready] Roblox Luau / Bedrock Sandbox</pre>
</div>`,
          css: `body{margin:0;background:#080c15;color:#f8fafc;font-family:'Cairo',sans-serif;padding:18px;}
.box{max-width:600px;margin:0 auto;background:#111827;border:1px solid rgba(139,92,246,.35);border-radius:14px;padding:18px;}
h3{margin:0 0 8px;color:#c4b5fd;}
p{margin:0 0 12px;color:#94a3b8;font-size:12px;}
button{background:#7c3aed;color:#fff;border:0;border-radius:8px;padding:8px 14px;font-family:inherit;font-weight:700;cursor:pointer;margin-left:8px;}
pre{margin-top:12px;background:#050810;padding:12px;border-radius:10px;color:#34d399;font-size:12px;min-height:110px;}`,
          js: `let coins=0;const log=document.getElementById('simLog');
document.getElementById('joinBtn').onclick=()=>{log.textContent+="\\nPlayerAdded: @iraqi_player spawned (Coins="+coins+")";};
document.getElementById('rewardBtn').onclick=()=>{coins+=100;log.textContent+="\\nLeaderstats updated -> Coins="+coins;console.log('Coins:',coins);};`,
          extraFiles: [
            {
              name: "main.luau",
              language: "luau",
              content: `-- ${safeTitle}\nlocal Players = game:GetService("Players")\nPlayers.PlayerAdded:Connect(function(player)\n  local ls = Instance.new("Folder")\n  ls.Name = "leaderstats"\n  ls.Parent = player\n  local coins = Instance.new("IntValue")\n  coins.Name = "Coins"\n  coins.Value = 100\n  coins.Parent = ls\n  print("Welcome to Iraqi Coders:", player.Name)\nend)`,
            },
          ],
        };
      }

      // Playable 2D Canvas Game
      return {
        title: safeTitle.slice(0, 64),
        summary: "لعبة HTML5 Canvas تفاعلية بمعدل إطارات سلس وتحكم مباشر.",
        stackBadge: "HTML5 Canvas · 60FPS Game Loop",
        html: `<div class="game-box" dir="rtl">
  <div class="hud"><strong>${safeTitle.slice(0, 32)}</strong><span>النقاط: <b id="sc">0</b></span></div>
  <canvas id="cv" width="420" height="240"></canvas>
  <p>حرّك المؤشر أو المس الشاشة لجمع النجوم وتفادي الشهب!</p>
</div>`,
        css: `body{margin:0;min-height:100vh;display:grid;place-items:center;background:#070b14;color:#f8fafc;font-family:'Cairo',sans-serif;}
.game-box{background:#0f172a;border:1px solid rgba(16,185,129,.35);border-radius:16px;padding:14px;text-align:center;}
.hud{display:flex;justify-content:space-between;margin-bottom:8px;font-size:13px;color:#34d399;}
canvas{border-radius:12px;background:#050810;border:1px solid rgba(255,255,255,.1);touch-action:none;max-width:100%;}
p{margin:8px 0 0;font-size:12px;color:#94a3b8;}`,
        js: `const cv=document.getElementById('cv'),ctx=cv.getContext('2d'),sc=document.getElementById('sc');
let px=210,score=0,star={x:120,y:20},rock={x:280,y:-40};
cv.addEventListener('pointermove',e=>{const r=cv.getBoundingClientRect();px=((e.clientX-r.left)/r.width)*cv.width;});
setInterval(()=>{
  ctx.clearRect(0,0,cv.width,cv.height);
  star.y+=3.2; rock.y+=4;
  if(star.y>cv.height){star={x:20+Math.random()*(cv.width-40),y:0};}
  if(rock.y>cv.height){rock={x:20+Math.random()*(cv.width-40),y:0};}
  if(Math.abs(star.x-px)<28&&star.y>195){score+=10;sc.textContent=String(score);star={x:20+Math.random()*(cv.width-40),y:0};}
  if(Math.abs(rock.x-px)<24&&rock.y>195){score=Math.max(0,score-5);sc.textContent=String(score);rock={x:20+Math.random()*(cv.width-40),y:0};console.log('اصطدام!');}
  ctx.fillStyle='#34d399';ctx.fillRect(px-22,205,44,14);
  ctx.fillStyle='#fbbf24';ctx.beginPath();ctx.arc(star.x,star.y,8,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#f43f5e';ctx.fillRect(rock.x-9,rock.y-9,18,18);
},18);`,
        extraFiles: [
          {
            name: "game-config.json",
            language: "json",
            content: JSON.stringify({ title: safeTitle, fps: 60, controls: ["pointer", "touch"] }, null, 2),
          },
        ],
      };
    };

    const ai = getAiClient();
    if (!ai) {
      res.json({ project: buildFallbackProject(), model: "local-smart-engine" });
      return;
    }

    try {
      const categoryGuide: Record<OmniCat, string> = {
        website: "موقع ويب متكامل احترافي (Landing / Store / Portfolio) بتصميم داكن أنيق وأقسام وتفاعل حقيقي.",
        webapp: "تطبيق ويب عملي ولوحة تحكم تفاعلية (Dashboard / CRUD / Tools) مع إدارة الحالة.",
        "mobile-app": "تطبيق موبايل بتصميم متجاوب للهواتف مع شريط تنقل سفلي وأزرار لمسية قابلة للتغليف كـ APK.",
        game: "لعبة HTML5 Canvas تفاعلية كاملة تعمل بالماوس أو اللمس مع عداد نقاط وحلقة لعب سلسة.",
        extension: "واجهة إضافة متصفح Chrome Manifest V3 فعّالة مع ملف manifest.json في extraFiles.",
        "backend-api": "محاكي واجهة REST API تفاعلية مع ملف server.js حقيقي بلغة Express.js في extraFiles.",
        "luau-mc": "محاكي تفاعلي في المتصفح مع كود Roblox Luau أو Minecraft @minecraft/server كامل في extraFiles.",
      };

      const geminiPromise = ai.models.generateContent({
        model: "gemini-4-hydrogen",
        contents: `الفئة: ${categoryGuide[category]}\nطلب المستخدم: ${safeTitle}\nأنتج مشروعاً حقيقياً كاملاً جاهزاً للتشغيل الفوري في المتصفح (بدون مكتبات خارجية مدفوعة أو صورية مكسورة، وبدون alert).`,
        config: {
          systemInstruction:
            "أنت كبير مهندسي البرمجيات في منصة عراقي كودرز. أرجع كائن JSON دقيق يحتوي html (محتوى body فقط بدون وسم html/body خارجي)، css، js، عنواناً عربياً قصيراً، وصفاً مختصراً، شارة التقنيات، وقائمة extraFiles بملفات مساعدة حقيقية للمشروع.",
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              summary: { type: Type.STRING },
              stackBadge: { type: Type.STRING },
              html: { type: Type.STRING },
              css: { type: Type.STRING },
              js: { type: Type.STRING },
              extraFiles: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING },
                    language: { type: Type.STRING },
                    content: { type: Type.STRING },
                  },
                  required: ["name", "language", "content"],
                },
              },
            },
            required: ["title", "summary", "stackBadge", "html", "css", "js", "extraFiles"],
          },
        },
      });

      const timeoutPromise = new Promise<never>((_, reject) =>
        setTimeout(() => reject(new Error("Gemini omni timeout")), 14000)
      );
      const response = await Promise.race([geminiPromise, timeoutPromise]);
      const parsed = JSON.parse((response.text || "").trim()) as Record<string, unknown>;
      const fallback = buildFallbackProject();
      const extraFilesRaw = Array.isArray(parsed.extraFiles) ? parsed.extraFiles : fallback.extraFiles;
      const project = {
        title: String(parsed.title || fallback.title).slice(0, 120),
        summary: String(parsed.summary || fallback.summary).slice(0, 320),
        stackBadge: String(parsed.stackBadge || fallback.stackBadge).slice(0, 80),
        html: String(parsed.html || fallback.html).slice(0, 24000),
        css: String(parsed.css || fallback.css).slice(0, 16000),
        js: String(parsed.js || fallback.js).slice(0, 24000),
        extraFiles: extraFilesRaw.slice(0, 6).map((f: unknown) => {
          const item = (f && typeof f === "object" ? f : {}) as Record<string, unknown>;
          return {
            name: String(item.name || "config.json").slice(0, 64),
            language: String(item.language || "json").slice(0, 24),
            content: String(item.content || "{}").slice(0, 16000),
          };
        }),
      };

      res.json({ project, model: "gemini-4-hydrogen" });
    } catch (err) {
      console.error("Omni Creator Fallback:", err instanceof Error ? err.message : err);
      res.json({ project: buildFallbackProject(), model: "local-smart-engine" });
    }
  });

  // =========================================================================
  // Pillar 8: Custom Nationality Cards API ("أنشئ جنسيتك الخاصة" + "خذ جنسية الناس")
  // =========================================================================
  app.get("/api/nationalities", (req, res) => {
    const rawQuery = String(req.query.lookup || req.query.q || "")
      .trim()
      .toLowerCase();
    const cleanQuery = rawQuery.replace(/^@/, "");
    const all = Array.from(nationalitiesStore.values());
    if (!cleanQuery) {
      res.json({ nationalities: all });
      return;
    }
    const matched = all.filter((card) => {
      const fields = [
        card.id,
        card.ownerUid,
        card.ownerHandle.replace(/^@/, ""),
        card.ownerEmail,
        card.nationalityCode,
        card.numericId,
        card.fullName,
      ].map((v) => String(v || "").toLowerCase());
      return fields.some(
        (f) => f === cleanQuery || f === rawQuery || f.includes(cleanQuery)
      );
    });
    res.json({ nationalities: matched });
  });

  app.post("/api/nationalities", (req, res) => {
    const raw = (req.body?.card || req.body || {}) as Record<string, unknown>;
    const fullName = String(raw.fullName || "").trim().slice(0, 120);
    const governorate = String(raw.governorate || "بغداد").trim().slice(0, 60);
    const nationalityCode = String(
      raw.nationalityCode || `IQ-${Math.floor(100000 + Math.random() * 899999)}`
    )
      .trim()
      .slice(0, 32);

    if (!fullName) {
      res.status(400).json({ error: "أدخل الاسم الكامل لإنشاء الجنسية." });
      return;
    }

    const ownerUid = String(raw.ownerUid || `uid-${Date.now()}`).slice(0, 128);
    const rawHandle = String(raw.ownerHandle || `@${fullName.replace(/\s+/g, "_").toLowerCase()}`)
      .trim()
      .slice(0, 50);
    const ownerHandle = rawHandle.startsWith("@") ? rawHandle : `@${rawHandle}`;
    const ownerEmail = String(raw.ownerEmail || "").trim().slice(0, 254);
    const numericId = String(
      raw.numericId || Math.floor(100000 + Math.random() * 899999)
    ).slice(0, 24);

    const id =
      String(raw.id || `nat-${ownerUid}`)
        .replace(/[^a-zA-Z0-9_-]/g, "")
        .slice(0, 128) || `nat-${Date.now()}`;

    const validateDataImg = (val: unknown): string => {
      const s = String(val || "").trim();
      if (s.startsWith("data:image/") || /^https?:\/\//i.test(s)) {
        return s.slice(0, 650000);
      }
      return "";
    };

    const nowIso = new Date().toISOString();
    const existing = nationalitiesStore.get(id);
    const frontImg = validateDataImg(raw.frontPhotoUrl || raw.frontPhotoDataUrl);
    const backImg = validateDataImg(raw.backEmblemUrl || raw.backPhotoDataUrl) || frontImg;
    const rankStr = String(
      raw.titleRank || raw.rankTitle || "مواطن رقمي عراقي"
    )
      .trim()
      .slice(0, 80);

    const record: StoredNationalityCard = {
      id,
      ownerUid,
      ownerHandle,
      ownerEmail,
      numericId,
      fullName,
      governorate,
      nationalityCode,
      specialty: String(raw.specialty || "تطوير برمجيات").trim().slice(0, 120),
      titleRank: rankStr,
      rankTitle: rankStr,
      bio: String(raw.bio || "عضو فعال في مجتمع عراقي كودرز").trim().slice(0, 600),
      frontPhotoUrl: frontImg,
      backEmblemUrl: backImg,
      frontPhotoDataUrl: frontImg,
      backPhotoDataUrl: backImg,
      issuedAt: String(raw.issuedAt || existing?.issuedAt || nowIso),
      updatedAt: nowIso,
      verified: raw.verified !== undefined ? Boolean(raw.verified) : true,
    };

    nationalitiesStore.set(record.id, record);

    const usernameKey = ownerHandle
      .replace(/^@/, "")
      .replace(/[^a-zA-Z0-9_.-]/g, "")
      .toLowerCase();
    if (usernameKey && !directoryPeopleStore.has(usernameKey)) {
      directoryPeopleStore.set(usernameKey, {
        id: ownerUid,
        username: usernameKey,
        displayName: fullName,
        handle: ownerHandle,
        email: ownerEmail || `${usernameKey}@iraqicoders.iq`,
        city: governorate,
        role: "user",
        enabled: true,
        verified: true,
        updatedAt: nowIso,
      });
    }

    res.json({ card: record });
  });

  // =========================================================================
  // Pillar 8 & 9: Platform Messages Store & Staff RBAC Role Assignment API
  // =========================================================================
  app.get("/api/messages", (req, res) => {
    const recipient = String(req.query.recipient || "").trim().toLowerCase();
    const list = recipient
      ? platformMessagesStore.filter((m) => {
          const rEmail = m.recipientEmail.toLowerCase();
          const rId = m.recipientIdentifier.toLowerCase();
          const sEmail = m.senderEmail.toLowerCase();
          return (
            rEmail === "all@iraqicoders.iq" ||
            rEmail === recipient ||
            rId === recipient ||
            sEmail === recipient
          );
        })
      : platformMessagesStore;
    res.json({ messages: list });
  });

  app.post("/api/messages", (req, res) => {
    const raw = (req.body?.message || req.body || {}) as Record<string, unknown>;
    const subject = String(raw.subject || "").trim().slice(0, 200);
    const body = String(raw.body || "").trim().slice(0, 4000);
    if (!subject || !body) {
      res.status(400).json({ error: "أدخل عنوان الرسالة ومحتواها." });
      return;
    }

    const record: StoredPlatformMessage = {
      id:
        String(raw.id || `msg-${Date.now()}`)
          .replace(/[^a-zA-Z0-9_-]/g, "")
          .slice(0, 128) || `msg-${Date.now()}`,
      direction: raw.direction === "outgoing" ? "outgoing" : "incoming",
      source: raw.source === "gmail" ? "gmail" : "platform",
      senderEmail: String(raw.senderEmail || "system@iraqicoders.iq").slice(0, 254),
      senderName: String(raw.senderName || "منصة عراقي كودرز").slice(0, 120),
      recipientEmail: String(raw.recipientEmail || "").slice(0, 254),
      recipientIdentifier: String(raw.recipientIdentifier || "").slice(0, 120),
      subject,
      body,
      rankGranted: ["user", "developer", "moderator", "director", "admin"].includes(
        String(raw.rankGranted)
      )
        ? (String(raw.rankGranted) as StoredPlatformMessage["rankGranted"])
        : undefined,
      sentViaGmail: Boolean(raw.gmailSynced || raw.sentViaGmail),
      gmailSynced: Boolean(raw.gmailSynced || raw.sentViaGmail),
      read: Boolean(raw.read),
      createdAt: String(raw.createdAt || new Date().toISOString()),
    };

    platformMessagesStore.unshift(record);
    if (platformMessagesStore.length > 200) {
      platformMessagesStore.length = 200;
    }
    res.json({ message: record });
  });

  app.post("/api/roles/assign", (req, res) => {
    const assignerRole = String(req.body?.assignerRole || "").trim().toLowerCase();
    if (!ALLOWED_STAFF_RANK_ASSIGN_ROLES.has(assignerRole)) {
      res.status(403).json({
        error: "هذه اللوحة الإدارية حصرية لأصحاب رتبة المسؤول أو المطور أو المشرف فقط.",
      });
      return;
    }

    const identifier = String(req.body?.identifier || "").trim();
    const targetRoleRaw = String(req.body?.targetRole || "").trim().toLowerCase();
    if (
      targetRoleRaw !== "moderator" &&
      targetRoleRaw !== "developer" &&
      targetRoleRaw !== "admin"
    ) {
      res.status(400).json({ error: "اختر رتبة صالحة (مشرف / مطور / مسؤول)." });
      return;
    }
    if (!identifier || identifier.length < 2) {
      res.status(400).json({
        error: "أدخل الآيدي أو المعرف أو الرقم أو البريد الإلكتروني للمستخدم.",
      });
      return;
    }

    const normalized = identifier.toLowerCase();
    const cleanKey = normalized
      .replace(/^@/, "")
      .split("@")[0]
      .replace(/[^a-zA-Z0-9_.-]/g, "") || `user_${Date.now()}`;

    let existingPerson: DirectoryPerson | undefined;
    for (const p of directoryPeopleStore.values()) {
      if (
        p.id.toLowerCase() === normalized ||
        p.username.toLowerCase() === cleanKey ||
        p.handle.toLowerCase() === normalized ||
        p.handle.toLowerCase() === `@${cleanKey}` ||
        p.email.toLowerCase() === normalized
      ) {
        existingPerson = p;
        break;
      }
    }

    const nowIso = new Date().toISOString();
    const inferredEmail = identifier.includes("@") && identifier.includes(".")
      ? identifier.slice(0, 254)
      : existingPerson?.email || `${cleanKey}@iraqicoders.iq`;

    const updatedPerson: DirectoryPerson = {
      id: existingPerson?.id || `person-${cleanKey}`,
      username: existingPerson?.username || cleanKey,
      displayName: existingPerson?.displayName || identifier,
      handle: existingPerson?.handle || `@${cleanKey}`,
      email: inferredEmail,
      city: existingPerson?.city || "بغداد",
      role: targetRoleRaw,
      enabled: true,
      verified: true,
      updatedAt: nowIso,
    };
    directoryPeopleStore.set(updatedPerson.username, updatedPerson);

    let matchedNationality: StoredNationalityCard | null = null;
    for (const card of nationalitiesStore.values()) {
      const cardKeys = [
        card.id,
        card.ownerUid,
        card.ownerHandle,
        card.ownerHandle.replace(/^@/, ""),
        card.ownerEmail,
        card.nationalityCode,
        card.numericId,
      ].map((v) => String(v || "").toLowerCase());
      if (cardKeys.some((k) => k === normalized || k === cleanKey)) {
        const copyInfo = buildServerRankNotificationCopy(targetRoleRaw);
        const updatedCard = {
          ...card,
          titleRank: copyInfo.arabicTitle,
          rankTitle: copyInfo.arabicTitle,
          updatedAt: nowIso,
        };
        nationalitiesStore.set(card.id, updatedCard);
        matchedNationality = updatedCard;
        break;
      }
    }

    const notifCopy = buildServerRankNotificationCopy(targetRoleRaw);
    const assignerEmail = String(
      req.body?.assignerEmail || "amirbaqir226@gmail.com"
    ).slice(0, 254);
    const assignerName = String(
      req.body?.assignerName || "إدارة عراقي كودرز"
    ).slice(0, 120);

    const messageRecord: StoredPlatformMessage = {
      id: `rankmsg-${Date.now()}`,
      direction: "outgoing",
      source: "platform",
      senderEmail: assignerEmail,
      senderName: assignerName,
      recipientEmail: matchedNationality?.ownerEmail || updatedPerson.email,
      recipientIdentifier: identifier,
      subject: notifCopy.subject,
      body: notifCopy.body,
      rankGranted: targetRoleRaw,
      sentViaGmail: Boolean(req.body?.gmailSynced),
      gmailSynced: Boolean(req.body?.gmailSynced),
      read: false,
      createdAt: nowIso,
    };

    platformMessagesStore.unshift(messageRecord);
    res.json({
      person: updatedPerson,
      nationality: matchedNationality,
      messageRecord,
    });
  });

  // ============================================================================
  // Export Complete Deployable Website Folder (.ZIP) with iPhone Font, Emojis & Keyboard
  // ============================================================================
  const ZIP_CRC_TABLE = (() => {
    const table = new Uint32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) {
        c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      }
      table[n] = c >>> 0;
    }
    return table;
  })();

  const computeCrc32 = (buf: Buffer): number => {
    let c = 0xffffffff;
    for (let i = 0; i < buf.length; i++) {
      c = ZIP_CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
    }
    return (c ^ 0xffffffff) >>> 0;
  };

  const INCOMPRESSIBLE_EXTS = new Set([
    ".jpg",
    ".jpeg",
    ".png",
    ".webp",
    ".gif",
    ".ico",
    ".woff",
    ".woff2",
    ".zip",
    ".mp3",
    ".mp4",
    ".ogg",
    ".webm",
    ".pdf",
  ]);

  const buildCompressedZipBuffer = (
    entries: Array<{ path: string; data: Buffer }>
  ): Buffer => {
    const localParts: Buffer[] = [];
    const centralParts: Buffer[] = [];
    let offset = 0;

    for (const entry of entries) {
      const cleanPath = entry.path.replace(/^\/+/, "");
      const nameBuf = Buffer.from(cleanPath, "utf8");
      const rawBuf = entry.data;
      const crc = computeCrc32(rawBuf);
      const ext = path.extname(cleanPath).toLowerCase();

      let compMethod = 0;
      let payload = rawBuf;
      if (!INCOMPRESSIBLE_EXTS.has(ext) && rawBuf.length > 64) {
        const deflated = zlib.deflateRawSync(rawBuf, { level: 5 });
        if (deflated.length < rawBuf.length) {
          compMethod = 8;
          payload = deflated;
        }
      }

      const localHeader = Buffer.alloc(30 + nameBuf.length);
      localHeader.writeUInt32LE(0x04034b50, 0);
      localHeader.writeUInt16LE(20, 4);
      localHeader.writeUInt16LE(0x0800, 6); // UTF-8 flag
      localHeader.writeUInt16LE(compMethod, 8);
      localHeader.writeUInt16LE(0, 10);
      localHeader.writeUInt16LE(0x5421, 12);
      localHeader.writeUInt32LE(crc, 14);
      localHeader.writeUInt32LE(payload.length, 18);
      localHeader.writeUInt32LE(rawBuf.length, 22);
      localHeader.writeUInt16LE(nameBuf.length, 26);
      localHeader.writeUInt16LE(0, 28);
      nameBuf.copy(localHeader, 30);

      localParts.push(localHeader, payload);

      const centralHeader = Buffer.alloc(46 + nameBuf.length);
      centralHeader.writeUInt32LE(0x02014b50, 0);
      centralHeader.writeUInt16LE(20, 4);
      centralHeader.writeUInt16LE(20, 6);
      centralHeader.writeUInt16LE(0x0800, 8);
      centralHeader.writeUInt16LE(compMethod, 10);
      centralHeader.writeUInt16LE(0, 12);
      centralHeader.writeUInt16LE(0x5421, 14);
      centralHeader.writeUInt32LE(crc, 16);
      centralHeader.writeUInt32LE(payload.length, 20);
      centralHeader.writeUInt32LE(rawBuf.length, 24);
      centralHeader.writeUInt16LE(nameBuf.length, 28);
      centralHeader.writeUInt16LE(0, 30);
      centralHeader.writeUInt16LE(0, 32);
      centralHeader.writeUInt16LE(0, 34);
      centralHeader.writeUInt16LE(0, 36);
      centralHeader.writeUInt32LE((0o100644 << 16) >>> 0, 38);
      centralHeader.writeUInt32LE(offset, 42);
      nameBuf.copy(centralHeader, 46);

      centralParts.push(centralHeader);
      offset += localHeader.length + payload.length;
    }

    const centralDir = Buffer.concat(centralParts);
    const eocd = Buffer.alloc(22);
    eocd.writeUInt32LE(0x06054b50, 0);
    eocd.writeUInt16LE(0, 4);
    eocd.writeUInt16LE(0, 6);
    eocd.writeUInt16LE(entries.length, 8);
    eocd.writeUInt16LE(entries.length, 10);
    eocd.writeUInt32LE(centralDir.length, 12);
    eocd.writeUInt32LE(offset, 16);
    eocd.writeUInt16LE(0, 20);

    return Buffer.concat([...localParts, centralDir, eocd]);
  };

  const collectFolderEntries = (
    dirAbs: string,
    zipPrefix: string,
    entries: Array<{ path: string; data: Buffer }>,
    skipNames = new Set([
      "node_modules",
      ".git",
      "dev-dist",
      ".env",
      ".aistudio",
    ])
  ) => {
    if (!fs.existsSync(dirAbs)) return;
    const list = fs.readdirSync(dirAbs, { withFileTypes: true });
    for (const item of list) {
      if (skipNames.has(item.name) || item.name.endsWith(".zip")) continue;
      const fullPath = path.join(dirAbs, item.name);
      const entryZipPath = `${zipPrefix}/${item.name}`;
      if (item.isDirectory()) {
        collectFolderEntries(fullPath, entryZipPath, entries, skipNames);
      } else if (item.isFile()) {
        entries.push({
          path: entryZipPath,
          data: fs.readFileSync(fullPath),
        });
      }
    }
  };

  let cachedSiteZip: {
    buffer: Buffer;
    fileCount: number;
    fingerprint: string;
  } | null = null;

  const siteZipTickets = new Map<string, { expiresAt: number }>();

  const pruneExpiredZipTickets = () => {
    const now = Date.now();
    for (const [token, info] of siteZipTickets.entries()) {
      if (info.expiresAt <= now) {
        siteZipTickets.delete(token);
      }
    }
  };

  const hasAdminExportHeaders = (req: express.Request): boolean => {
    const roleHeader = String(req.header("x-user-role") || "").toLowerCase();
    const adminUnlockedHeader =
      String(req.header("x-admin-unlocked") || "").toLowerCase() === "true";
    const adminEmailHeader = String(
      req.header("x-admin-email") || ""
    ).toLowerCase();
    return (
      roleHeader === "admin" ||
      adminUnlockedHeader ||
      adminEmailHeader === "amirbaqir226@gmail.com"
    );
  };

  const getSiteZipFingerprint = (): string => {
    const probePaths = [
      path.join(__dirname, "dist", "index.html"),
      path.join(__dirname, "src", "App.tsx"),
      path.join(__dirname, "server.ts"),
      path.join(__dirname, "firebase-applet-config.json"),
    ];
    return probePaths
      .map((p) => {
        try {
          const st = fs.statSync(p);
          return `${path.basename(p)}:${st.mtimeMs}`;
        } catch {
          return `${path.basename(p)}:0`;
        }
      })
      .join("|");
  };

  const getOrBuildSiteZipBuffer = (forceRefresh = false) => {
    const fingerprint = getSiteZipFingerprint();
    if (
      !forceRefresh &&
      cachedSiteZip &&
      cachedSiteZip.fingerprint === fingerprint
    ) {
      return cachedSiteZip;
    }

    const rootFolder = "iraqi-coders-website";
    const entries: Array<{ path: string; data: Buffer }> = [];

    // 1) Ready-to-publish compiled static build directly inside iraqi-coders-website/
    const distDir = path.join(__dirname, "dist");
    if (fs.existsSync(distDir)) {
      collectFolderEntries(distDir, rootFolder, entries);
    }

    // 2) Standalone iPhone Font + Emojis + Keyboard reference pack inside iraqi-coders-website/iphone-pack/
    const iphonePackCss = `/* حزمة خط وإيموجيات الآيفون - عراقي كودرز */
html.iphone-font-mode,
html.iphone-font-mode body,
html.iphone-font-mode button,
html.iphone-font-mode input,
html.iphone-font-mode textarea,
html.iphone-font-mode select {
  font-family: -apple-system, BlinkMacSystemFont, "SF Pro Display", "SF Pro Text",
    "SF Arabic", "Geeza Pro", "Cairo", "Apple Color Emoji", "Segoe UI Emoji",
    "Noto Color Emoji", sans-serif;
  -webkit-font-smoothing: antialiased;
}
.iphone-emoji-font {
  font-family: "Apple Color Emoji", "SF Pro Display", "Noto Color Emoji",
    "Segoe UI Emoji", sans-serif;
  font-variant-emoji: emoji;
}
`;
    entries.push({
      path: `${rootFolder}/iphone-pack/iphone-font-and-emoji.css`,
      data: Buffer.from(iphonePackCss, "utf8"),
    });

    const iphoneEmojisJson = JSON.stringify(
      {
        packName: "Iraqi Coders iPhone Emoji & Keyboard Pack",
        faces: ["😀", "🥹", "😂", "🤣", "😍", "🥰", "😎", "🤩", "🥳", "🤯", "🫡", "😭"],
        hearts: ["❤️", "🩷", "🩵", "💜", "🔥", "✨", "⚡", "👑", "💎", "💯"],
        tech: ["💻", "📱", "⌨️", "🤖", "🎮", "🚀", "🛠️", "🌐"],
        iraq: ["🇮🇶", "🕌", "🌴", "🦁", "🎉", "🎊"],
      },
      null,
      2
    );
    entries.push({
      path: `${rootFolder}/iphone-pack/iphone-emojis.json`,
      data: Buffer.from(iphoneEmojisJson, "utf8"),
    });

    // 3) Full editable project source inside iraqi-coders-website/full-source/
    collectFolderEntries(
      path.join(__dirname, "src"),
      `${rootFolder}/full-source/src`,
      entries
    );
    collectFolderEntries(
      path.join(__dirname, "pwa-assets"),
      `${rootFolder}/full-source/pwa-assets`,
      entries
    );
    collectFolderEntries(
      path.join(__dirname, "public"),
      `${rootFolder}/full-source/public`,
      entries
    );

    const rootConfigFiles = [
      "package.json",
      "server.ts",
      "index.html",
      "tsconfig.json",
      "vite.config.ts",
      "eslint.config.js",
      "firebase.json",
      "firebase-applet-config.json",
      "firebase-blueprint.json",
      "firestore.rules",
      "firestore.rules.test.ts",
      "security_spec.md",
      ".env.example",
      "metadata.json",
    ];
    for (const fileName of rootConfigFiles) {
      const abs = path.join(__dirname, fileName);
      if (fs.existsSync(abs) && fs.statSync(abs).isFile()) {
        entries.push({
          path: `${rootFolder}/full-source/${fileName}`,
          data: fs.readFileSync(abs),
        });
      }
    }

    // 4) Arabic deployment README
    const readmeAr = `=============================================================
نسخة مطابقة كاملة من موقع عراقي كودرز (مجلد النشر الشامل)
يحتوي على: جميع ملفات الموقع + خط الآيفون + إيموجيات الآيفون + كيبورد الآيفون
=============================================================

الطريقة 1 — النشر المباشر السريع (Netlify / Cloudflare Pages / cPanel / Vercel):
- قم بفك الضغط عن الملف.
- ارفع مجلد "iraqi-coders-website" (أو ملفات index.html و assets وما معها) مباشرة إلى الاستضافة ليعمل نسخة مطابقة فوراً!

الطريقة 2 — تشغيل نسخة مطابقة كاملة (واجهة + سيرفر API):
1. افتح مجلد "full-source" في الطرفية (Terminal).
2. نفّذ: npm install
3. لبناء نسخة الإنتاج: npm run build
4. للتشغيل الكامل: npm start
`;
    entries.push({
      path: `${rootFolder}/اقرأني-طريقة-النشر.txt`,
      data: Buffer.from(readmeAr, "utf8"),
    });

    const buffer = buildCompressedZipBuffer(entries);
    cachedSiteZip = {
      buffer,
      fileCount: entries.length,
      fingerprint,
    };
    return cachedSiteZip;
  };

  app.post("/api/export-site-zip/prepare", (req, res) => {
    try {
      if (!hasAdminExportHeaders(req)) {
        res.status(403).json({
          error: "عذراً، زر «نزل ملف الموقع» متاح حصرياً للمسؤولين فقط.",
        });
        return;
      }

      pruneExpiredZipTickets();
      const zipPkg = getOrBuildSiteZipBuffer(false);
      const ticket = crypto.randomBytes(24).toString("hex");
      siteZipTickets.set(ticket, {
        expiresAt: Date.now() + 15 * 60 * 1000,
      });

      res.json({
        ok: true,
        ticket,
        downloadUrl: `/api/export-site-zip?ticket=${encodeURIComponent(ticket)}`,
        fileName: "iraqi-coders-website-complete.zip",
        fileCount: zipPkg.fileCount,
        sizeBytes: zipPkg.buffer.length,
      });
    } catch (err) {
      console.error("Prepare export ZIP error:", err);
      res.status(500).json({ error: "تعذر تجهيز رابط التنزيل المباشر للموقع." });
    }
  });

  app.get("/api/export-site-zip", (req, res) => {
    try {
      pruneExpiredZipTickets();
      const ticketParam = String(req.query.ticket || "").trim();
      const ticketRecord = ticketParam
        ? siteZipTickets.get(ticketParam)
        : undefined;
      const hasValidTicket = Boolean(
        ticketRecord && ticketRecord.expiresAt > Date.now()
      );

      if (!hasValidTicket && !hasAdminExportHeaders(req)) {
        res.status(403).json({
          error: "عذراً، زر «نزل ملف الموقع» متاح حصرياً للمسؤولين فقط.",
        });
        return;
      }

      const zipPkg = getOrBuildSiteZipBuffer(false);
      res.status(200);
      res.setHeader("Content-Type", "application/zip");
      res.setHeader(
        "Content-Disposition",
        'attachment; filename="iraqi-coders-website-complete.zip"; filename*=UTF-8\'\'iraqi-coders-website-complete.zip'
      );
      res.setHeader("Content-Length", String(zipPkg.buffer.length));
      res.setHeader(
        "Cache-Control",
        "no-store, no-cache, must-revalidate, private"
      );
      res.setHeader("X-Content-Type-Options", "nosniff");
      res.setHeader("Accept-Ranges", "none");
      res.end(zipPkg.buffer);
    } catch (err) {
      console.error("Export ZIP error:", err);
      res.status(500).json({ error: "تعذر إنشاء الملف المضغوط للموقع." });
    }
  });

  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  const port = Number(process.env.PORT || 3000);
  app.listen(port, "0.0.0.0", () => {
    console.log(`[Iraqi Coders v26.5] Running on http://0.0.0.0:${port}`);
    setTimeout(() => {
      try {
        getOrBuildSiteZipBuffer(false);
      } catch (err) {
        console.warn("Warmup site ZIP skipped:", err);
      }
    }, 1500);
  });
}

void startServer();
