import fs from 'fs';
import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig, Plugin} from 'vite';
import {VitePWA} from 'vite-plugin-pwa';

const PWA_ASSET_FILES = [
  {name: 'icon.svg', contentType: 'image/svg+xml'},
  {name: 'apple-touch-icon.png', contentType: 'image/png'},
  {name: 'pwa-192x192.png', contentType: 'image/png'},
  {name: 'pwa-512x512.png', contentType: 'image/png'},
  {name: 'pwa-maskable-512x512.png', contentType: 'image/png'},
] as const;

function pwaAssetsPlugin(): Plugin {
  const assetsDir = path.resolve(__dirname, 'pwa-assets');
  return {
    name: 'iraqi-coders-pwa-assets',
    configureServer(server) {
      server.middlewares.use((req, res, next) => {
        const cleanUrl = (req.url || '').split('?')[0].replace(/^\/+/, '');
        const match = PWA_ASSET_FILES.find((f) => f.name === cleanUrl);
        if (!match) {
          next();
          return;
        }
        const filePath = path.join(assetsDir, match.name);
        if (!fs.existsSync(filePath)) {
          next();
          return;
        }
        res.setHeader('Content-Type', match.contentType);
        res.setHeader('Cache-Control', 'public, max-age=86400');
        res.end(fs.readFileSync(filePath));
      });
    },
    generateBundle() {
      for (const asset of PWA_ASSET_FILES) {
        const filePath = path.join(assetsDir, asset.name);
        if (fs.existsSync(filePath)) {
          this.emitFile({
            type: 'asset',
            fileName: asset.name,
            source: fs.readFileSync(filePath),
          });
        }
      }
    },
  };
}

export default defineConfig(() => {
  return {
    plugins: [
      react(),
      tailwindcss(),
      pwaAssetsPlugin(),
      VitePWA({
        registerType: 'autoUpdate',
        includeAssets: [
          'icon.svg',
          'apple-touch-icon.png',
          'pwa-192x192.png',
          'pwa-512x512.png',
          'pwa-maskable-512x512.png',
        ],
        manifest: {
          id: '/',
          name: 'عراقي كودرز · Iraqi Coders',
          short_name: 'IraqiCoders',
          description:
            'منصة عراقي كودرز للبرمجة وإنشاء المواقع والتطبيقات والألعاب والمتجر مع دعم التصفح دون اتصال.',
          start_url: '/',
          scope: '/',
          display: 'standalone',
          orientation: 'any',
          theme_color: '#0B0F19',
          background_color: '#0B0F19',
          lang: 'ar',
          dir: 'rtl',
          categories: ['developer', 'education', 'shopping'],
          icons: [
            {
              src: '/pwa-192x192.png',
              sizes: '192x192',
              type: 'image/png',
              purpose: 'any',
            },
            {
              src: '/pwa-512x512.png',
              sizes: '512x512',
              type: 'image/png',
              purpose: 'any',
            },
            {
              src: '/pwa-maskable-512x512.png',
              sizes: '512x512',
              type: 'image/png',
              purpose: 'maskable',
            },
            {
              src: '/icon.svg',
              sizes: 'any',
              type: 'image/svg+xml',
              purpose: 'any',
            },
          ],
        },
        workbox: {
          globPatterns: ['**/*.{js,css,html,ico,png,svg,woff,woff2}'],
          navigateFallback: '/index.html',
          navigateFallbackDenylist: [/^\/api\//],
          maximumFileSizeToCacheInBytes: 6 * 1024 * 1024,
          runtimeCaching: [
            {
              urlPattern:
                /^\/api\/(shop-products|challenges|updates|beta-projects|school-updates|nationalities|forum-posts|cloud-files)/i,
              handler: 'NetworkFirst',
              method: 'GET',
              options: {
                cacheName: 'iraqi-coders-api-live-cache',
                networkTimeoutSeconds: 4,
                expiration: {
                  maxEntries: 60,
                  maxAgeSeconds: 60 * 60 * 24 * 14,
                },
                cacheableResponse: {
                  statuses: [0, 200],
                },
              },
            },
            {
              urlPattern: /^https:\/\/fonts\.googleapis\.com\/.*/i,
              handler: 'CacheFirst',
              options: {
                cacheName: 'google-fonts-stylesheets',
                expiration: {
                  maxEntries: 10,
                  maxAgeSeconds: 60 * 60 * 24 * 365,
                },
              },
            },
            {
              urlPattern: /^https:\/\/fonts\.gstatic\.com\/.*/i,
              handler: 'CacheFirst',
              options: {
                cacheName: 'google-fonts-webfonts',
                expiration: {
                  maxEntries: 30,
                  maxAgeSeconds: 60 * 60 * 24 * 365,
                },
                cacheableResponse: {
                  statuses: [0, 200],
                },
              },
            },
          ],
        },
        devOptions: {
          enabled: true,
          type: 'module',
        },
      }),
    ],
    // Keep standalone Firebase Hosting public/ folder separate from Vite build output
    publicDir: false as const,
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
