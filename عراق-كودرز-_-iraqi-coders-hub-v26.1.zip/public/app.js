import { initializeApp } from "https://www.gstatic.com/firebasejs/11.0.1/firebase-app.js";
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signOut,
} from "https://www.gstatic.com/firebasejs/11.0.1/firebase-auth.js";
import {
  doc,
  getFirestore,
  serverTimestamp,
  setDoc,
} from "https://www.gstatic.com/firebasejs/11.0.1/firebase-firestore.js";

export const firebaseConfig = {
  projectId: "inspiring-bonito-vvc14",
  appId: "1:272267264281:web:96a374b8632ff1f5370588",
  apiKey: "AIzaSyAB3S6OB1La1nPgqhEB816RPi7QFJPTYIM",
  authDomain: "inspiring-bonito-vvc14.firebaseapp.com",
  firestoreDatabaseId:
    "ai-studio-iraqicodershubv2-c2936688-472a-4ef3-9093-9e19b38b83b0",
  storageBucket: "inspiring-bonito-vvc14.firebasestorage.app",
  messagingSenderId: "272267264281",
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
const googleProvider = new GoogleAuthProvider();

const KEYS = {
  USER: "iraqi_coders_user_v26_4",
  MAINT: "iraqi_coders_maintenance_bypassed_v26_4",
  BAN: "iraqi_coders_comedy_ban_v26_4",
  THEME: "iraqi_coders_theme_v26_4",
  DESKTOP: "iraqi_coders_desktop_mode_v26_4",
  CLOUD: "iraqi_coders_cloud_files_v26_4",
  ECONOMY: "iraqi_coders_economy_v26_4",
};

const codeState = {
  html: '<div style="padding:24px;color:#fff;font-family:Cairo,sans-serif"><h2>عراقي كودرز 26.5</h2><p>محرر الكود المباشر يعمل بنجاح!</p></div>',
  css: "body{margin:0;background:#0b0f19;}",
  js: "console.log('Iraqi Coders Hub v26.5');",
};
let activeTab = "html";
let cloudTab = "private";
const runtimeLogs = ["[INFO] تم تهيئة عراقي كودرز 26.5"];

let economy = JSON.parse(
  localStorage.getItem(KEYS.ECONOMY) ||
    '{"activeSeconds":60,"coins":50,"unlocked":[]}'
);

function isAdminUser() {
  const email = auth.currentUser?.email || "";
  return (
    email === "amirbaqir226@gmail.com" ||
    localStorage.getItem("iraqi_coders_admin_unlocked") === "true"
  );
}

function buildSimpleZipBlob(entries) {
  const enc = new TextEncoder();
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[n] = c >>> 0;
  }
  const crc = (b) => {
    let c = 0xffffffff;
    for (let i = 0; i < b.length; i++) c = table[(c ^ b[i]) & 0xff] ^ (c >>> 8);
    return (c ^ 0xffffffff) >>> 0;
  };
  const locals = [];
  const centrals = [];
  let offset = 0;
  for (const e of entries) {
    const nb = enc.encode(e.path);
    const db = typeof e.data === "string" ? enc.encode(e.data) : e.data;
    const sum = crc(db);
    const lh = new Uint8Array(30 + nb.length);
    const lv = new DataView(lh.buffer);
    lv.setUint32(0, 0x04034b50, true);
    lv.setUint16(4, 20, true);
    lv.setUint16(6, 0x0800, true);
    lv.setUint32(14, sum, true);
    lv.setUint32(18, db.length, true);
    lv.setUint32(22, db.length, true);
    lv.setUint16(26, nb.length, true);
    lh.set(nb, 30);
    locals.push(lh, db);

    const ch = new Uint8Array(46 + nb.length);
    const cv = new DataView(ch.buffer);
    cv.setUint32(0, 0x02014b50, true);
    cv.setUint16(4, 20, true);
    cv.setUint16(6, 20, true);
    cv.setUint16(8, 0x0800, true);
    cv.setUint32(16, sum, true);
    cv.setUint32(20, db.length, true);
    cv.setUint32(24, db.length, true);
    cv.setUint16(28, nb.length, true);
    cv.setUint32(42, offset, true);
    ch.set(nb, 46);
    centrals.push(ch);
    offset += lh.length + db.length;
  }
  const csize = centrals.reduce((a, p) => a + p.length, 0);
  const eocd = new Uint8Array(22);
  const ev = new DataView(eocd.buffer);
  ev.setUint32(0, 0x06054b50, true);
  ev.setUint16(8, entries.length, true);
  ev.setUint16(10, entries.length, true);
  ev.setUint32(12, csize, true);
  ev.setUint32(16, offset, true);
  const out = new Uint8Array(offset + csize + 22);
  let p = 0;
  for (const x of locals) { out.set(x, p); p += x.length; }
  for (const x of centrals) { out.set(x, p); p += x.length; }
  out.set(eocd, p);
  return new Blob([out.buffer], { type: "application/octet-stream" });
}

function logEvent(msg) {
  runtimeLogs.unshift(`[${new Date().toLocaleTimeString("en-GB")}] ${msg}`);
  const box = document.getElementById("devLogsBox");
  if (box) {
    box.innerHTML = runtimeLogs
      .map((line) => `<div class="owl-msg" dir="ltr">${line}</div>`)
      .join("");
  }
}

function applyThemeAndDesktop(explicitChoice) {
  const theme = localStorage.getItem(KEYS.THEME) || "default";
  let desktop = false;
  if (typeof explicitChoice === "boolean") {
    desktop = explicitChoice;
    localStorage.setItem(KEYS.DESKTOP, String(desktop));
  } else if (window.innerWidth >= 1024) {
    desktop = localStorage.getItem(KEYS.DESKTOP) === "true";
  }

  document.documentElement.classList.toggle("desktop-mode", desktop);
  document.body.classList.remove("theme-halloween", "theme-cyber", "theme-electric", "desktop-mode");
  if (theme !== "default") document.body.classList.add(`theme-${theme}`);
  if (desktop) document.body.classList.add("desktop-mode");

  const devBtn = document.getElementById("openDevOptionsBtn");
  if (devBtn) devBtn.classList.toggle("hidden", !desktop);
  const desktopToggle = document.getElementById("settingsDesktopToggle");
  if (desktopToggle) desktopToggle.checked = desktop;

  ["mobileViewBtn", "maintMobileViewBtn"].forEach((id) => {
    const el = document.getElementById(id);
    if (el) el.classList.toggle("active", !desktop);
  });
  ["desktopViewBtn", "maintDesktopViewBtn"].forEach((id) => {
    const el = document.getElementById(id);
    if (el) el.classList.toggle("active", desktop);
  });
}

function launchIraqiBot() {
  const sec = document.getElementById("assistant");
  if (sec) sec.scrollIntoView({ behavior: "smooth" });
}

function updateCountdown() {
  const el = document.getElementById("maintCountdown");
  if (!el) return;
  const now = new Date();
  const target = new Date(now);
  target.setHours(22, 0, 0, 0);
  const diff = Math.max(0, Math.floor((target.getTime() - now.getTime()) / 1000));
  const h = String(Math.floor(diff / 3600)).padStart(2, "0");
  const m = String(Math.floor((diff % 3600) / 60)).padStart(2, "0");
  const s = String(diff % 60).padStart(2, "0");
  el.textContent = `${h}:${m}:${s}`;
}

function renderAuth() {
  const mount = document.getElementById("authArea");
  const raw = localStorage.getItem(KEYS.USER);
  if (raw) {
    const u = JSON.parse(raw);
    mount.innerHTML = `<div style="display:flex;align-items:center;gap:8px"><button id="avatarSettingsBtn" class="btn btn-outline">${u.name}</button><button id="logoutBtn" class="btn btn-outline">خروج</button></div>`;
    document.getElementById("avatarSettingsBtn").onclick = () =>
      document.getElementById("settingsModal").classList.remove("hidden");
    document.getElementById("logoutBtn").onclick = async () => {
      try {
        await signOut(auth);
      } catch {}
      localStorage.removeItem(KEYS.USER);
      renderAuth();
    };
  } else {
    mount.innerHTML = `<button id="openAuthBtn" class="btn btn-primary">دخول Google</button>`;
    document.getElementById("openAuthBtn").onclick = () =>
      document.getElementById("authModal").classList.remove("hidden");
  }
}

function renderCloudFiles() {
  const grid = document.getElementById("cloudFilesGrid");
  if (!grid) return;
  const saved = JSON.parse(localStorage.getItem(KEYS.CLOUD) || "[]");
  const items = saved.filter((f) => f.visibility === cloudTab);
  if (items.length === 0) {
    grid.innerHTML = `<div class="card"><p>لا توجد ملفات في قسم ${cloudTab === "private" ? "سحابتي الخاصة" : "سحابات الناس"} بعد.</p></div>`;
    return;
  }
  grid.innerHTML = items
    .map(
      (item) => `<article class="card"><h3>${item.title}</h3><p class="mono-url">${item.fileName}</p><p>${item.fileType}</p></article>`
    )
    .join("");
}

function initPlayground() {
  const ta = document.getElementById("codeTextarea");
  const frame = document.getElementById("previewFrame");
  const renderPreview = () => {
    frame.srcdoc = `<!doctype html><html><head><style>${codeState.css}</style></head><body>${codeState.html}<script>${codeState.js}<\/script></body></html>`;
  };
  ta.value = codeState[activeTab];
  document.querySelectorAll(".tab").forEach((btn) => {
    btn.onclick = () => {
      codeState[activeTab] = ta.value;
      activeTab = btn.dataset.tab;
      document.querySelectorAll(".tab").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      ta.value = codeState[activeTab];
    };
  });
  document.getElementById("runPlaygroundBtn").onclick = () => {
    codeState[activeTab] = ta.value;
    renderPreview();
    logEvent("تم تشغيل كود المحرر المباشر");
  };
  renderPreview();
}

function initInteractions() {
  document.getElementById("navIraqiBotBtn").onclick = launchIraqiBot;
  document.getElementById("heroIraqiBotBtn").onclick = launchIraqiBot;
  document.getElementById("sectionIraqiBotBtn").onclick = launchIraqiBot;

  ["mobileViewBtn", "maintMobileViewBtn"].forEach((id) => {
    const el = document.getElementById(id);
    if (el) el.onclick = () => applyThemeAndDesktop(false);
  });
  ["desktopViewBtn", "maintDesktopViewBtn"].forEach((id) => {
    const el = document.getElementById(id);
    if (el) el.onclick = () => applyThemeAndDesktop(true);
  });

  const settingsModal = document.getElementById("settingsModal");
  const devOptionsModal = document.getElementById("devOptionsModal");
  document.getElementById("openSettingsBtn").onclick = () =>
    settingsModal.classList.remove("hidden");
  document.getElementById("closeSettingsBtn").onclick = () =>
    settingsModal.classList.add("hidden");
  document.getElementById("openDevOptionsBtn").onclick = () => {
    settingsModal.classList.add("hidden");
    devOptionsModal.classList.remove("hidden");
    logEvent("فتح نافذة خيارات المطورين");
  };
  document.getElementById("closeDevOptionsBtn").onclick = () =>
    devOptionsModal.classList.add("hidden");

  document.getElementById("settingsForm").onsubmit = (e) => {
    e.preventDefault();
    const theme = document.getElementById("settingsThemeSelect").value;
    const desktop = document.getElementById("settingsDesktopToggle").checked;
    localStorage.setItem(KEYS.THEME, theme);
    applyThemeAndDesktop(desktop);
    logEvent(`تحديث الثيم (${theme}) ووضع سطح المكتب (${desktop})`);
    settingsModal.classList.add("hidden");
  };

  document.getElementById("tabPrivateCloud").onclick = () => {
    cloudTab = "private";
    renderCloudFiles();
  };
  document.getElementById("tabPublicCloud").onclick = () => {
    cloudTab = "public";
    renderCloudFiles();
  };
  document.getElementById("cloudUploadForm").onsubmit = async (e) => {
    e.preventDefault();
    const title = document.getElementById("cloudTitleInput").value.trim();
    const fileName = document.getElementById("cloudFileNameInput").value.trim();
    const fileType = document.getElementById("cloudTypeSelect").value;
    const visibility = document.getElementById("cloudVisSelect").value;
    const content = document.getElementById("cloudContentInput").value;
    const id = `cloud-${Date.now()}`;
    const saved = JSON.parse(localStorage.getItem(KEYS.CLOUD) || "[]");
    saved.unshift({ id, title, fileName, fileType, visibility, content });
    localStorage.setItem(KEYS.CLOUD, JSON.stringify(saved));

    if (auth.currentUser?.emailVerified) {
      await setDoc(doc(db, "cloud_files", id), {
        id,
        ownerId: auth.currentUser.uid,
        ownerName: auth.currentUser.displayName || "مطور عراقي",
        ownerHandle: "@iraqi_dev",
        title,
        description: "ملف مرفوع من عراقي كودرز",
        fileName,
        fileType,
        fileSizeBytes: content.length,
        content,
        visibility,
        downloads: 0,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }
    logEvent(`رفع ملف سحابي: ${fileName} (${visibility})`);
    cloudTab = visibility;
    renderCloudFiles();
    document.getElementById("cloudTitleInput").value = "";
  };

  const maint = document.getElementById("maintenanceOverlay");
  const pinModal = document.getElementById("pinModal");
  if (localStorage.getItem(KEYS.MAINT) === "true") {
    maint.classList.add("hidden");
  }
  setInterval(updateCountdown, 1000);
  updateCountdown();

  document.getElementById("showMaintenanceBtn").onclick = () => {
    localStorage.removeItem(KEYS.MAINT);
    maint.classList.remove("hidden");
  };
  document.getElementById("secretMaintTrigger").onclick = () =>
    pinModal.classList.remove("hidden");
  document.getElementById("closePinBtn").onclick = () =>
    pinModal.classList.add("hidden");
  document.getElementById("simTenPmBtn").onclick = () => {
    document.getElementById("maintStatusText").textContent =
      "لقد انفتح الموقع وأخيراً بعد عناء طويل!";
    localStorage.setItem(KEYS.MAINT, "true");
    setTimeout(() => maint.classList.add("hidden"), 1000);
  };

  document.getElementById("pinForm").onsubmit = (e) => {
    e.preventDefault();
    const val = document.getElementById("pinInput").value.trim();
    if (val === "2019") {
      localStorage.setItem(KEYS.MAINT, "true");
      pinModal.classList.add("hidden");
      maint.classList.add("hidden");
      document.getElementById("adminModal").classList.remove("hidden");
      document.getElementById("adminLoginView").classList.add("hidden");
      document.getElementById("adminPanelView").classList.remove("hidden");
    } else if (val === "404") {
      localStorage.setItem(KEYS.MAINT, "true");
      pinModal.classList.add("hidden");
      maint.classList.add("hidden");
    } else {
      const err = document.getElementById("pinError");
      err.textContent = "رمز غير صحيح";
      err.classList.remove("hidden");
    }
  };

  const owlModal = document.getElementById("brownOwlModal");
  const comedyModal = document.getElementById("comedyModal");
  const banOverlay = document.getElementById("banOverlay");

  if (localStorage.getItem(KEYS.BAN)) {
    banOverlay.classList.remove("hidden");
  }

  document.getElementById("openBrownOwlBtn").onclick = () =>
    owlModal.classList.remove("hidden");
  document.getElementById("closeOwlBtn").onclick = () =>
    owlModal.classList.add("hidden");
  document.getElementById("owlForm").onsubmit = (e) => {
    e.preventDefault();
    const txt = document.getElementById("owlInput").value.trim();
    if (txt.includes("مليت")) {
      owlModal.classList.add("hidden");
      comedyModal.classList.remove("hidden");
    }
  };

  document.getElementById("laughBtn").onclick = () => {
    comedyModal.classList.add("hidden");
  };
  document.getElementById("notFunnyBtn").onclick = () => {
    comedyModal.classList.add("hidden");
    localStorage.setItem(KEYS.BAN, "banned");
    banOverlay.classList.remove("hidden");
  };
  document.getElementById("apologizeBtn").onclick = () => {
    localStorage.removeItem(KEYS.BAN);
    banOverlay.classList.add("hidden");
    comedyModal.classList.remove("hidden");
    document.getElementById("comedyJokeText").textContent =
      "المسامح كريم! مقلب! الجميع يضحك ويصفق!";
  };

  const storeModal = document.getElementById("storeModal");
  const refreshStoreUi = () => {
    const admin = isAdminUser();
    const label = document.getElementById("navCoinsLabel");
    if (label) label.textContent = admin ? "∞" : String(economy.coins);
    const stats = document.getElementById("storeStatsText");
    if (stats) {
      stats.textContent = admin
        ? `الوقت المتراكم: ${economy.activeSeconds} ثانية · رصيد المدير أمير: ∞ (فتح مجاني)`
        : `الوقت المتراكم: ${economy.activeSeconds} ثانية · الرصيد: ${economy.coins} عملة`;
    }
  };
  setInterval(() => {
    if (document.visibilityState === "visible") {
      economy.activeSeconds += 1;
      if (economy.activeSeconds % 10 === 0) {
        localStorage.setItem(KEYS.ECONOMY, JSON.stringify(economy));
      }
      refreshStoreUi();
    }
  }, 1000);
  refreshStoreUi();

  document.getElementById("openStoreBtn").onclick = () => {
    refreshStoreUi();
    storeModal.classList.remove("hidden");
  };
  document.getElementById("closeStoreBtn").onclick = () =>
    storeModal.classList.add("hidden");
  document.getElementById("tradeMinuteBtn").onclick = () => {
    if (isAdminUser() || economy.activeSeconds >= 60) {
      if (!isAdminUser()) economy.activeSeconds -= 60;
      economy.coins += 25;
      localStorage.setItem(KEYS.ECONOMY, JSON.stringify(economy));
      refreshStoreUi();
      logEvent("تم تحويل دقيقة تفاعل إلى +25 عملة");
    }
  };
  document.getElementById("buyVipSkinBtn").onclick = () => {
    if (isAdminUser() || economy.coins >= 80) {
      if (!isAdminUser()) economy.coins -= 80;
      if (!economy.unlocked.includes("vip-gold")) economy.unlocked.push("vip-gold");
      localStorage.setItem(KEYS.ECONOMY, JSON.stringify(economy));
      refreshStoreUi();
      logEvent("تم تفعيل الإطار الذهبي للمطور!");
    }
  };

  const slashModal = document.getElementById("slashStudioModal");
  document.getElementById("openSlashStudioBtn").onclick = () =>
    slashModal.classList.remove("hidden");
  document.getElementById("closeSlashStudioBtn").onclick = () =>
    slashModal.classList.add("hidden");
  document.getElementById("studioHamburgerBtn").onclick = () =>
    document.getElementById("studioSidebarBox").classList.toggle("hidden");
  document.getElementById("studioCreateForm").onsubmit = (e) => {
    e.preventDefault();
    const title = document.getElementById("studioTitleInput").value.trim() || "iraqi_app";
    const fmt = document.getElementById("studioFormatSelect").value;
    const code = document.getElementById("studioCodeInput").value || "// Iraqi Coders 26.5";
    const fileName = `${title.replace(/\s+/g, "_")}.${fmt}`;
    const blob = buildSimpleZipBlob([
      { path: fmt === "apk" ? "AndroidManifest.xml" : fmt === "mcaddon" ? "behavior_pack/manifest.json" : "index.html", data: code },
      { path: "README.txt", data: `Built by Iraqi Coders Hub 26.5: ${title}` },
    ]);
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    logEvent(`تجميع وتنزيل الحزمة الحقيقية: ${fileName}`);
  };

  const authModal = document.getElementById("authModal");
  document.getElementById("closeAuthBtn").onclick = () =>
    authModal.classList.add("hidden");
  document.getElementById("googleSignInBtn").onclick = async () => {
    try {
      const res = await signInWithPopup(auth, googleProvider);
      await setDoc(
        doc(db, "users", res.user.uid),
        {
          uid: res.user.uid,
          displayName: res.user.displayName || "مطور Google",
          handle: `@${(res.user.email?.split("@")[0] || "iraqi_dev").slice(0, 28)}`,
          city: "العراق",
          avatarUrl: res.user.photoURL || "",
          themeDecoration: localStorage.getItem(KEYS.THEME) || "default",
          desktopMode: localStorage.getItem(KEYS.DESKTOP) === "true",
          updatedAt: serverTimestamp(),
        },
        { merge: true }
      );
      localStorage.setItem(
        KEYS.USER,
        JSON.stringify({ name: res.user.displayName || "مطور Google" })
      );
      authModal.classList.add("hidden");
      renderAuth();
      refreshStoreUi();
      logEvent("تسجيل دخول Google عبر Firebase Auth");
    } catch (err) {
      const errEl = document.getElementById("authError");
      errEl.textContent = err?.message || "تعذر الدخول";
      errEl.classList.remove("hidden");
    }
  };
}

applyThemeAndDesktop();
renderAuth();
renderCloudFiles();
initPlayground();
initInteractions();
