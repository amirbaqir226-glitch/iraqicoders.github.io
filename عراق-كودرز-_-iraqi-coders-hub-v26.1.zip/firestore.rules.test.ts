/**
 * Security Rule Verification Harness for Iraqi Coders Hub (v26.3)
 * Documents expected PERMISSION_DENIED outcomes for the Dirty Dozen payloads.
 */
export const dirtyDozenCases = [
  { name: "Shadow Field Injection on Post Create", path: "forum_posts/p1", expected: "PERMISSION_DENIED" },
  { name: "Identity Spoofing on Post Create", path: "forum_posts/p2", expected: "PERMISSION_DENIED" },
  { name: "Client Timestamp Forgery", path: "forum_posts/p3", expected: "PERMISSION_DENIED" },
  { name: "Oversized ID Poisoning", path: "forum_posts/../bad", expected: "PERMISSION_DENIED" },
  { name: "Oversized Content DoS", path: "forum_posts/p4", expected: "PERMISSION_DENIED" },
  { name: "PII Cross-User Read", path: "users_private/userA", expected: "PERMISSION_DENIED" },
  { name: "Unverified Admin Spoof", path: "platform_settings/public_bot", expected: "PERMISSION_DENIED" },
  { name: "Self-Privilege Escalation", path: "admins/attacker", expected: "PERMISSION_DENIED" },
  { name: "Orphan Reply Write", path: "forum_posts/missing/replies/r1", expected: "PERMISSION_DENIED" },
  { name: "Immutable Field Mutation", path: "forum_posts/p1", expected: "PERMISSION_DENIED" },
  { name: "Unpermitted Update Field", path: "forum_posts/p1", expected: "PERMISSION_DENIED" },
  { name: "Blanket Query Scraping of Private Data", path: "users_private", expected: "PERMISSION_DENIED" },
];
