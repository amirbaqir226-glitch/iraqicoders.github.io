# Security Specification — Iraqi Coders Hub (v26.3)

## 1. Data Invariants
1. A user's private PII (`/users_private/{userId}`) including email and ban flags can only be read or written by the authenticated owner (`request.auth.uid == userId && email_verified == true`) or a verified admin.
2. Every `/forum_posts/{postId}` document must have `authorId == request.auth.uid`, valid bounded string sizes, `visibility == 'public'`, and server timestamps (`createdAt == request.time`, `updatedAt == request.time`).
3. Every `/forum_posts/{postId}/replies/{replyId}` and `/likes/{userId}` document must verify parent `/forum_posts/{postId}` exists via `exists()` and enforce `authorId == request.auth.uid` / `userId == request.auth.uid`.
4. `/platform_settings/{settingId}` and `/admins/{adminId}` can only be written by verified admins (`isAdmin()`).
5. Unverified email tokens (`email_verified != true`) are rejected for all writes and admin checks.

## 2. Adversarial "Dirty Dozen" Payloads (Expected: PERMISSION_DENIED)
1. **Shadow Field Injection on Post Create**: Adding `isVerified: true` or `role: 'admin'` to `/forum_posts/{postId}` -> Rejected by `keys().hasOnly(...)`.
2. **Identity Spoofing on Post Create**: Setting `authorId: 'someone-else'` -> Rejected by `data.authorId == request.auth.uid`.
3. **Client Timestamp Forgery**: Setting `createdAt` to a past timestamp instead of `request.time` -> Rejected by `data.createdAt == request.time`.
4. **Oversized ID Poisoning**: Using a 500-char `postId` or invalid characters (`../bad`) -> Rejected by `isValidId(postId)`.
5. **Oversized Content DoS**: Sending 10KB string in `content` -> Rejected by `data.content.size() <= 4000`.
6. **PII Cross-User Read**: Signed-in user B reading `/users_private/userA` -> Rejected by `isOwner(userId) || isAdmin()`.
7. **Unverified Admin Spoof**: Token with `email: 'amirbaqir226@gmail.com'` and `email_verified: false` -> Rejected by `email_verified == true`.
8. **Self-Privilege Escalation**: Signed-in non-admin writing to `/admins/{uid}` -> Rejected by `isAdmin()`.
9. **Orphan Reply Write**: Writing to `/forum_posts/nonexistent/replies/r1` -> Rejected by `exists(...)` Master Gate.
10. **Immutable Field Mutation**: Updating `authorId` or `createdAt` on `/forum_posts/{postId}` -> Rejected by `incoming().authorId == existing().authorId && incoming().createdAt == existing().createdAt`.
11. **Unpermitted Update Field**: Non-author updating `title` or `content` -> Rejected by `isOwner(existing().authorId) || isAdmin()` + `affectedKeys().hasOnly(...)`.
12. **Blanket Query Scraping of Private Data**: Listing `/users_private` as a regular user -> Denied completely (no `list` permission for non-admins).
